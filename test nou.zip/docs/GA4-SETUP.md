# Google Analytics 4 (GA4) - Ghid de Configurare

## 📊 Overview

Acest proiect include integrarea completă Google Analytics 4 (GA4) pentru monitorizarea traficului și a evenimentelor de pe site. GA4 oferă analytics avansate și tracking îmbunătățit față de versiunile anterioare.

## 🚀 Configurare Rapidă

### 1. Obține Measurement ID-ul GA4

1. Accesează [Google Analytics](https://analytics.google.com)
2. Selectează proprietatea ta (sau creează una nouă)
3. Mergi la **Admin** > **Data Streams** > **Web stream**
4. Click pe stream-ul tău web
5. Copiază **Measurement ID-ul** (format: `G-XXXXXXXXXX`)

### 2. Configurează Environment Variables

Creează fișierul `.env.local` în rădăcina proiectului:

```bash
# Google Analytics 4 Configuration
NEXT_PUBLIC_GA4_MEASUREMENT_ID=G-XXXXXXXXXX
```

Înlocuiește `G-XXXXXXXXXX` cu Measurement ID-ul real din pasul 1.

### 3. Restart Server

```bash
npm run dev
```

## 📝 Funcționalități Includ

### ✅ Tracking Automat
- **Page Views**: Se urmăresc automat la navigarea între pagini
- **Session Tracking**: Urmărirea sesiunilor de utilizatori
- **User Engagement**: Măsurarea timpului petrecut pe pagină

### ✅ Evenimente Custom
- **Button Clicks**: Urmărirea click-urilor pe butoane
- **Form Submissions**: Tracking-ul trimiterilor de formulare
- **Search Events**: Căutări efectuate de utilizatori
- **Scroll Tracking**: Progresul scroll-ului pe pagină
- **File Downloads**: Descărcările de fișiere
- **JavaScript Errors**: Erorile de JavaScript
- **Custom Events**: Evenimente personalizate

### ✅ Configurări Privacy
- **IP Anonymization**: Ascunderea automată a IP-urilor
- **Google Signals**: Respectarea setărilor de privacy
- **Ad Personalization**: Control complet asupra personalizării

## 🛠️ Utilizare în Componente

### Hook Principal

```tsx
import { useGA4Tracking } from '@/hooks/useGA4Tracking';

function MyComponent() {
  const {
    trackButtonClick,
    trackEvent,
    trackScrollProgress,
    trackTimeOnPage,
    isActive,
    measurementId,
  } = useGA4Tracking();

  const handleButtonClick = () => {
    trackButtonClick('buton-contact', 'header', {
      user_type: 'visitor',
      page_section: 'hero'
    });
  };

  return (
    <button onClick={handleButtonClick}>
      Contactează-ne
    </button>
  );
}
```

### Tracking Avansat

```tsx
import { useGA4Tracking } from '@/hooks/useGA4Tracking';

function AdvancedTrackingComponent() {
  const { trackScrollProgress, trackTimeOnPage, trackFormSubmit } = useGA4Tracking();

  useEffect(() => {
    // Scroll tracking pentru un element specific
    const cleanupScroll = trackScrollProgress('main-content', 25);

    // Time on page tracking
    const cleanupTime = trackTimeOnPage();

    return () => {
      cleanupScroll?.();
      cleanupTime?.();
    };
  }, [trackScrollProgress, trackTimeOnPage]);

  const handleFormSubmit = (formData) => {
    trackFormSubmit('newsletter-signup', true, {
      email_domain: formData.email.split('@')[1],
      user_agent: navigator.userAgent
    });
  };

  return <form onSubmit={handleFormSubmit}>{/* ... */}</form>;
}
```

## 📊 Monitoring și Debug

### Console Logging

GA4 va logs informații în console când este activ:

```javascript
// Verifică dacă GA4 este activ
console.log('GA4 Active:', ga4.isActive());
console.log('Measurement ID:', ga4.getMeasurementId());
```

### Admin Dashboard

Accesează `/admin/analytics` pentru a vedea:
- Statistici locale de trafic
- Real-time page views
- Top pagini populare
- Tracking status pentru GA4

### Google Analytics UI

După configurare, verifică:
1. **Real-time reports** pentru activitate instant
2. **Events** pentru evenimentele custom
3. **Engagement** pentru metrici de interacțiune
4. **Technology** pentru informații despre utilizatori

## 📋 Lista de Evenimente Trackuite Automat

### Page Views
- Se urmăresc automat la fiecare schimbare de pagină
- Exclude `/admin/*` și `/auth/*` (tracking local doar)

### Button Clicks
- Toate butoanele din interfață
- Include numele butonului și locația

### Scroll Events
- 25%, 50%, 75%, 100% din scroll-ul pe pagină
- Element-specific scrolling tracking

### Form Submissions
- Toate formularele cu success/error tracking
- Date customizabile pentru fiecare submit

### Search Events
- Query terms și numărul de rezultate
- Context despre pagina de căutare

### File Downloads
- Filename, file type
- Context despre download

### JavaScript Errors
- Error messages și stack traces
- URL-ul unde a apărut eroarea

### Page Engagement
- Time spent on page
- Scroll depth
- Interaction events

## 🔧 Configurări Avansate

### Custom Dimensions

Pentru tracking suplimentar, configurează custom dimensions în GA4:

```javascript
trackEvent({
  action: 'custom_action',
  category: 'engagement',
  label: 'custom_label',
  custom_parameters: {
    user_segment: 'premium',
    page_template: 'landing_page',
    interaction_type: 'button_click'
  }
});
```

### Enhanced Ecommerce

Pentru site-uri de e-commerce, adaugă tracking ecommerce:

```javascript
trackEvent({
  action: 'purchase',
  category: 'ecommerce',
  label: 'product_purchase',
  value: 99.99,
  custom_parameters: {
    transaction_id: 'order_123',
    currency: 'USD',
    items: [
      {
        item_id: 'sku_123',
        item_name: 'Product Name',
        price: 99.99,
        quantity: 1
      }
    ]
  }
});
```

## 🐛 Troubleshooting

### GA4 nu se încarcă

1. Verifică Measurement ID-ul în `.env.local`
2. Confirmă că fișierul `.env.local` este în rădăcina proiectului
3. Verifică consola browser pentru erori

### Evenimente nu apar în GA4

1. **Delay normal**: Evenimentele pot apărea cu întârziere (până la 24h pentru real-time)
2. **Filtre GA4**: Verifică dacă filtrele GA4 blochează traficul
3. **Ad Blockers**: Unele extensii de browser pot bloca GA4

### Debug Mode

Activează debug mode în GA4:

```javascript
// În browser console
gtag('config', 'G-XXXXXXXXXX', { 'debug_mode': true });
```

## 📈 Best Practices

### Privacy & GDPR
- Informează utilizatorii despre tracking în Privacy Policy
- Implementează cookie consent management
- Respectă regulile GDPR pentru colectarea datelor

### Performance
- GA4 se încarcă asincron pentru a nu afecta performanța
- Tracking-ul este optimizat pentru viteze rapide
- Event batching pentru eficiență maximă

### Data Quality
- Testează toate evenimentele în Real-time reports
- Monitorizează bounce rate și engagement metrics
- Configurează alerts pentru probleme de tracking

## 🔗 Resurse Utile

- [Google Analytics 4 Documentation](https://support.google.com/analytics/answer/10089681)
- [GA4 Event Schema](https://support.google.com/analytics/answer/1033068)
- [Enhanced Ecommerce Guide](https://support.google.com/analytics/answer/1037663)
- [Privacy & Security Best Practices](https://support.google.com/analytics/answer/7667180)

## 📞 Support

Pentru probleme cu integrarea GA4:

1. Verifică logs din browser console
2. Testează în incognito/private mode
3. Consultă Google Analytics Real-time reports
4. Verifică configurația în GA4 Admin panel

---

**Configurat cu ❤️ pentru Next.js + Google Analytics 4**