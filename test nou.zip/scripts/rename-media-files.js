/**
 * Script pentru redenumirea fișierelor media eliminând prefixul numeric (timestamp)
 * și actualizarea tuturor referințelor în baza de date
 */

const fs = require('fs');
const path = require('path');

const DB_DIR = path.join(__dirname, '..', 'db');
const PUBLIC_DIR = path.join(__dirname, '..', 'public');
const UPLOADS_DIR = path.join(PUBLIC_DIR, 'imageuploads');

// Funcție pentru generarea numelui SEO-friendly
function generateSeoName(filename) {
  const ext = path.extname(filename);
  const baseName = path.basename(filename, ext);
  
  // Elimină prefixul numeric (ex: 1759181269195-)
  const nameWithoutPrefix = baseName.replace(/^\d+-/, '');
  
  // Convertește la format SEO-friendly
  const seoName = nameWithoutPrefix
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '');
  
  return seoName + ext.toLowerCase();
}

// Funcție pentru actualizarea referințelor într-un obiect
function updateReferences(obj, oldPath, newPath) {
  if (typeof obj === 'string') {
    return obj.replace(oldPath, newPath);
  }
  
  if (Array.isArray(obj)) {
    return obj.map(item => updateReferences(item, oldPath, newPath));
  }
  
  if (obj && typeof obj === 'object') {
    const result = {};
    for (const key of Object.keys(obj)) {
      result[key] = updateReferences(obj[key], oldPath, newPath);
    }
    return result;
  }
  
  return obj;
}

async function main() {
  console.log('🔄 Începe redenumirea fișierelor media...\n');
  
  // Citește fișierele din directorul de upload
  let files;
  try {
    files = fs.readdirSync(UPLOADS_DIR);
  } catch (error) {
    console.error('❌ Nu s-a putut citi directorul de upload:', error.message);
    return;
  }
  
  // Map pentru vechile și noile căi
  const renameMap = new Map();
  
  // Procesează fiecare fișier
  for (const file of files) {
    const oldPath = path.join(UPLOADS_DIR, file);
    
    // Verifică dacă fișierul are prefix numeric
    if (/^\d+-/.test(file)) {
      const newName = generateSeoName(file);
      const newPath = path.join(UPLOADS_DIR, newName);
      
      // Verifică dacă noul nume există deja
      if (fs.existsSync(newPath) && oldPath !== newPath) {
        console.log(`⚠️  Fișierul ${newName} există deja, se adaugă sufix...`);
        const baseNewName = path.basename(newName, path.extname(newName));
        let counter = 1;
        let finalName = `${baseNewName}-${counter}${path.extname(newName)}`;
        while (fs.existsSync(path.join(UPLOADS_DIR, finalName))) {
          counter++;
          finalName = `${baseNewName}-${counter}${path.extname(newName)}`;
        }
        renameMap.set(file, finalName);
      } else {
        renameMap.set(file, newName);
      }
    }
  }
  
  console.log(`📁 ${renameMap.size} fișiere de redenumit:\n`);
  
  // Redenumesc fișierele
  for (const [oldName, newName] of renameMap) {
    const oldPath = path.join(UPLOADS_DIR, oldName);
    const newPath = path.join(UPLOADS_DIR, newName);
    
    try {
      fs.renameSync(oldPath, newPath);
      console.log(`✅ ${oldName} → ${newName}`);
    } catch (error) {
      console.error(`❌ Eroare la redenumirea ${oldName}:`, error.message);
    }
  }
  
  console.log('\n📝 Actualizare referințe în baza de date...\n');
  
  // Actualizează media.json
  const mediaPath = path.join(DB_DIR, 'media.json');
  let media = JSON.parse(fs.readFileSync(mediaPath, 'utf-8'));
  
  for (const [oldName, newName] of renameMap) {
    const oldSrc = `/imageuploads/${oldName}`;
    const newSrc = `/imageuploads/${newName}`;
    
    media = media.map(item => {
      if (item.src === oldSrc) {
        return {
          ...item,
          src: newSrc,
          filename: newName,
          alt: path.basename(newName, path.extname(newName)).replace(/-/g, ' ')
        };
      }
      return item;
    });
  }
  
  fs.writeFileSync(mediaPath, JSON.stringify(media, null, 2));
  console.log('✅ media.json actualizat');
  
  // Actualizează pages.json
  const pagesPath = path.join(DB_DIR, 'pages.json');
  let pages = JSON.parse(fs.readFileSync(pagesPath, 'utf-8'));
  
  for (const [oldName, newName] of renameMap) {
    const oldSrc = `/imageuploads/${oldName}`;
    const newSrc = `/imageuploads/${newName}`;
    pages = updateReferences(pages, oldSrc, newSrc);
  }
  
  fs.writeFileSync(pagesPath, JSON.stringify(pages, null, 2));
  console.log('✅ pages.json actualizat');
  
  // Actualizează site-settings.json
  const settingsPath = path.join(DB_DIR, 'site-settings.json');
  let settings = JSON.parse(fs.readFileSync(settingsPath, 'utf-8'));
  
  for (const [oldName, newName] of renameMap) {
    const oldSrc = `/imageuploads/${oldName}`;
    const newSrc = `/imageuploads/${newName}`;
    settings = updateReferences(settings, oldSrc, newSrc);
  }
  
  fs.writeFileSync(settingsPath, JSON.stringify(settings, null, 2));
  console.log('✅ site-settings.json actualizat');
  
  console.log('\n🎉 Redenumire completă!');
}

main().catch(console.error);
