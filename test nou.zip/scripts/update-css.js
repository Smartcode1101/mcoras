const fs = require('fs').promises;
const path = require('path');

const dbPath = path.join(process.cwd(), 'db', 'pages.json');

// Copy the generateCss function from actions.ts
function styleObjectToString(style = {}) {
  return Object.entries(style)
    .map(([key, value]) => {
      if (value === undefined || value === null) return '';
      const cssKey = key.replace(/([A-Z])/g, '-$1').toLowerCase();
      return `${cssKey}:${value}`;
    })
    .filter(Boolean)
    .join(';');
}

function generateCss(elements) {
  let css = '';

  function traverse(widgets) {
    widgets.forEach(widget => {
      const className = `.widget-${widget.id}`;

      // Desktop styles
      const desktopStyles = styleObjectToString(widget.styles?.desktop || widget.styles);
      if (desktopStyles) {
        css += `${className} { ${desktopStyles} }\n`;
      }

      // Tablet styles
      const tabletStyles = styleObjectToString(widget.styles?.tablet);
      if (tabletStyles) {
        css += `@media (max-width: 1024px) { ${className} { ${tabletStyles} } }\n`;
      }

      // Mobile styles
      const mobileStyles = styleObjectToString(widget.styles?.mobile);
      if (mobileStyles) {
        css += `@media (max-width: 768px) { ${className} { ${mobileStyles} } }\n`;
      }

      if (widget.type === 'Image' && widget.styles) {
         const imageClassName = `.widget-${widget.id} img`;
         const desktopImgStyles = styleObjectToString({
            backgroundColor: widget.styles.desktop?.backgroundColor,
            borderTopLeftRadius: widget.styles.desktop?.borderTopLeftRadius,
            borderTopRightRadius: widget.styles.desktop?.borderTopRightRadius,
            borderBottomLeftRadius: widget.styles.desktop?.borderBottomLeftRadius,
            borderBottomRightRadius: widget.styles.desktop?.borderBottomRightRadius,
            boxShadow: widget.styles.desktop?.boxShadow,
            width: widget.props.width?.desktop ? `${widget.props.width.desktop}px` : undefined,
            height: widget.props.height?.desktop ? `${widget.props.height.desktop}px` : undefined,
            objectFit: widget.props.objectFit?.desktop,
            aspectRatio: widget.props.aspectRatio?.desktop,
         });
         if (desktopImgStyles) css += `${imageClassName} { ${desktopImgStyles} }\n`;

         const tabletImgStyles = styleObjectToString({
            width: widget.props.width?.tablet ? `${widget.props.width.tablet}px` : undefined,
            height: widget.props.height?.tablet ? `${widget.props.height.tablet}px` : undefined,
            objectFit: widget.props.objectFit?.tablet,
            aspectRatio: widget.props.aspectRatio?.tablet,
         });
         if (tabletImgStyles) css += `@media (max-width: 1024px) { ${imageClassName} { ${tabletImgStyles} } }\n`;

         const mobileImgStyles = styleObjectToString({
            width: widget.props.width?.mobile ? `${widget.props.width.mobile}px` : undefined,
            height: widget.props.height?.mobile ? `${widget.props.height.mobile}px` : undefined,
            objectFit: widget.props.objectFit?.mobile,
            aspectRatio: widget.props.aspectRatio?.mobile,
         });
         if (mobileImgStyles) css += `@media (max-width: 768px) { ${imageClassName} { ${mobileImgStyles} } }\n`;
      }

      if (widget.children) {
        traverse(widget.children);
      }
    });
  }

  traverse(elements);

  return css;
}

async function updateCss() {
  try {
    const data = await fs.readFile(dbPath, 'utf-8');
    const pages = JSON.parse(data);

    for (const page of pages) {
      if (page.elements) {
        page.css = generateCss(page.elements);
        console.log(`Updated CSS for page: ${page.title}`);
      }
    }

    await fs.writeFile(dbPath, JSON.stringify(pages, null, 2), 'utf-8');
    console.log('All pages updated with new CSS.');
  } catch (error) {
    console.error('Error updating CSS:', error);
  }
}

updateCss();