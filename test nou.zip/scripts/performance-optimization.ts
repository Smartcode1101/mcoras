/**
 * Script pentru optimizarea performanței la build time
 * Aplică minificare HTML, CSS, JS pe fișierele statice
 */

import fs from 'fs';
import path from 'path';

const settingsPath = path.join(process.cwd(), 'db', 'site-settings.json');

interface PerformanceSettings {
  minifyHtml: boolean;
  minifyCss: boolean;
  minifyJs: boolean;
  delayedJs: boolean;
  delayedJsTimeout: number;
}

interface SiteSettings {
  performanceSettings?: PerformanceSettings;
  [key: string]: unknown;
}

function getPerformanceSettings(): PerformanceSettings {
  try {
    const data = fs.readFileSync(settingsPath, 'utf-8');
    const settings: SiteSettings = JSON.parse(data);
    
    return {
      minifyHtml: settings.performanceSettings?.minifyHtml ?? true,
      minifyCss: settings.performanceSettings?.minifyCss ?? true,
      minifyJs: settings.performanceSettings?.minifyJs ?? true,
      delayedJs: settings.performanceSettings?.delayedJs ?? true,
      delayedJsTimeout: settings.performanceSettings?.delayedJsTimeout ?? 2000
    };
  } catch {
    return {
      minifyHtml: true,
      minifyCss: true,
      minifyJs: true,
      delayedJs: true,
      delayedJsTimeout: 2000
    };
  }
}

function minifyHtml(html: string): string {
  return html
    .replace(/<!--[\s\S]*?-->/g, '')
    .replace(/\s+/g, ' ')
    .replace(/>\s+</g, '><')
    .replace(/^\s+|\s+$/gm, '')
    .replace(/\n\s*\n/g, '\n')
    .trim();
}

function minifyCss(css: string): string {
  return css
    .replace(/\/\*[\s\S]*?\*\//g, '')
    .replace(/\s+/g, ' ')
    .replace(/\s*([{}:;,>+~])\s*/g, '$1')
    .replace(/^\s+|\s+$/gm, '')
    .replace(/;}/g, '}')
    .replace(/\b0(px|em|rem|%|pt|pc|in|cm|mm|ex|vh|vw|vmin|vmax)\b/g, '0')
    .trim();
}

function minifyJs(js: string): string {
  return js
    .replace(/\/\/.*$/gm, '')
    .replace(/\/\*[\s\S]*?\*\//g, '')
    .replace(/\s+/g, ' ')
    .replace(/\s*([{}:;,=+\-*/<>!&|()])\s*/g, '$1')
    .trim();
}

function processDirectory(dir: string, settings: PerformanceSettings): void {
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  
  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    
    if (entry.isDirectory()) {
      // Skip node_modules and .next directories
      if (entry.name === 'node_modules' || entry.name === '.next' || entry.name.startsWith('.')) {
        continue;
      }
      processDirectory(fullPath, settings);
    } else if (entry.isFile()) {
      const ext = path.extname(entry.name).toLowerCase();
      
      try {
        const content = fs.readFileSync(fullPath, 'utf-8');
        let minified: string | null = null;
        
        if (ext === '.html' && settings.minifyHtml) {
          minified = minifyHtml(content);
          console.log(`✓ Minified HTML: ${entry.name}`);
        } else if (ext === '.css' && settings.minifyCss) {
          minified = minifyCss(content);
          console.log(`✓ Minified CSS: ${entry.name}`);
        } else if ((ext === '.js' || ext === '.mjs') && settings.minifyJs) {
          // Skip minifying already minified files
          if (!entry.name.includes('.min.')) {
            minified = minifyJs(content);
            console.log(`✓ Minified JS: ${entry.name}`);
          }
        }
        
        if (minified && minified !== content) {
          fs.writeFileSync(fullPath, minified, 'utf-8');
        }
      } catch (error) {
        console.error(`Error processing ${entry.name}:`, error);
      }
    }
  }
}

// Main execution
console.log('🚀 Starting performance optimization...\n');

const settings = getPerformanceSettings();
console.log('Settings:', settings);
console.log('');

const publicDir = path.join(process.cwd(), 'public');
const outDir = path.join(process.cwd(), 'out');

// Process public directory
if (fs.existsSync(publicDir)) {
  console.log('Processing public directory...');
  processDirectory(publicDir, settings);
}

// Process out directory (if exists - for static export)
if (fs.existsSync(outDir)) {
  console.log('\nProcessing out directory...');
  processDirectory(outDir, settings);
}

console.log('\n✅ Performance optimization complete!');
