'use client';

import React, { createContext, useReducer, Dispatch, useContext, useEffect } from 'react';
import type { EditorState, EditorAction, Widget, PageData } from '@/lib/types';
import type { CSSProperties } from 'react';
import { getWidgetDefaults } from '@/components/widgets/defaults';
import { useParams } from 'next/navigation';
import { generateId } from '@/lib/utils';

const createInitialState = (pageId: string | string[] | undefined, initialData?: PageData): EditorState => {
  if (initialData) {
    return {
      id: initialData.id,
      pageTitle: initialData.title,
      pageSlug: initialData.slug,
      pageType: initialData.type,
      thumbnail: initialData.thumbnail,
      seoDescription: initialData.seoDescription,
      seoKeywords: initialData.seoKeywords,
      robotsIndex: initialData.robotsIndex,
      robotsFollow: initialData.robotsFollow,
      robotsNoImageIndex: initialData.robotsNoImageIndex,
      categoryId: initialData.categoryId,
      tags: initialData.tags,
      elements: initialData.elements,
      selectedElementId: null,
      inlineEditingElementId: null,
      activeSidebarTab: 'widgets',
      responsiveMode: 'desktop',
      isFullScreen: false,
      zoom: 100,
    };
  }

  const isNewPage = pageId === 'new';
  return {
    id: isNewPage ? null : (pageId as string || null),
    elements: [],
    selectedElementId: null,
    inlineEditingElementId: null,
    activeSidebarTab: 'widgets',
    pageTitle: 'Pagină Fără Titlu',
    pageSlug: '',
    pageType: 'page',
    thumbnail: undefined,
    seoDescription: '',
    seoKeywords: '',
    robotsIndex: true,
    robotsFollow: true,
    robotsNoImageIndex: false,
    categoryId: undefined,
    tags: [],
    responsiveMode: 'desktop',
    isFullScreen: false,
    zoom: 100,
  };
};


const createColumns = (count: number): Widget[] => {
  return Array.from({ length: count }, () => ({
    id: generateId(),
    type: 'Container', // We can treat columns as special containers
    props: {},
    styles: {
      desktop: {
        display: 'flex',
        flexDirection: 'column',
        gap: '0px',
        padding: '0px',
        minHeight: '100px',
      },
    },
    children: [],
  }));
};

const editorReducer = (state: EditorState, action: EditorAction): EditorState => {
  switch (action.type) {
    case 'LOAD_PAGE_DATA':
       // Convert styles to ResponsiveValue if needed
       const convertStyles = (elements: Widget[]): Widget[] => {
         return elements.map(el => {
           if (el.styles && typeof el.styles === 'object' && !('desktop' in el.styles)) {
             // It's CSSProperties, convert to ResponsiveValue
             el.styles = { desktop: el.styles as CSSProperties };
           }
           if (el.children) {
             el.children = convertStyles(el.children);
           }
           // Special handling for FlexContainer - ensure it always has columns
           if (el.type === 'FlexContainer' && (!el.children || el.children.length === 0)) {
             const columnCount = el.props.columns?.desktop || 2;
             el.children = createColumns(columnCount);
             console.log(`[LOAD_PAGE_DATA] FlexContainer ${el.id} restored with ${columnCount} columns`);
           }
           return el;
         });
       };
       
       const convertedElements = convertStyles(action.payload.data.elements);
       
       // Additional pass to ensure all FlexContainers have columns
       const ensureFlexContainerColumns = (widgets: Widget[]): Widget[] => {
         return widgets.map(w => {
           if (w.type === 'FlexContainer' && (!w.children || w.children.length === 0)) {
             const columnCount = w.props.columns?.desktop || 2;
             return { ...w, children: createColumns(columnCount) };
           }
           if (w.children) {
             return { ...w, children: ensureFlexContainerColumns(w.children) };
           }
           return w;
         });
       };

       return {
          id: action.payload.data.id,
          pageTitle: action.payload.data.title,
          pageSlug: action.payload.data.slug,
          pageType: action.payload.data.type,
          thumbnail: action.payload.data.thumbnail,
          seoDescription: action.payload.data.seoDescription,
          seoKeywords: action.payload.data.seoKeywords,
          robotsIndex: action.payload.data.robotsIndex,
          robotsFollow: action.payload.data.robotsFollow,
          robotsNoImageIndex: action.payload.data.robotsNoImageIndex,
          categoryId: action.payload.data.categoryId,
          tags: action.payload.data.tags,
          elements: ensureFlexContainerColumns(convertedElements),
          selectedElementId: null,
          inlineEditingElementId: null,
          activeSidebarTab: 'widgets',
          responsiveMode: state.responsiveMode, // Preserve current responsive mode
          isFullScreen: state.isFullScreen, // Preserve full screen mode
          zoom: state.zoom, // Preserve zoom
        };
    case 'ADD_ELEMENT': {
       const { index, element, parentId } = action.payload;
       const newElement: Widget = {
         ...getWidgetDefaults(element.type),
         id: generateId(),
       };

       const addElement = (widgets: Widget[]): Widget[] => {
         if (!parentId) {
           const newWidgets = [...widgets];
           newWidgets.splice(index, 0, newElement);
           return newWidgets;
         }
         return widgets.map((w) => {
           if (w.id === parentId) {
             const newChildren = [...(w.children || [])];
             newChildren.splice(index, 0, newElement);
             return { ...w, children: newChildren };
           }
           if (w.children) {
             return { ...w, children: addElement(w.children) };
           }
           return w;
         });
       };

       const newElements = addElement(state.elements);
       
       // Special handling for FlexContainer - ensure it always has columns after adding element
       const ensureFlexContainerColumns = (widgets: Widget[]): Widget[] => {
         return widgets.map(w => {
           if (w.type === 'FlexContainer' && (!w.children || w.children.length === 0)) {
             const columnCount = w.props.columns?.desktop || 2;
             return { ...w, children: createColumns(columnCount) };
           }
           if (w.children) {
             return { ...w, children: ensureFlexContainerColumns(w.children) };
           }
           return w;
         });
       };

       return {
         ...state,
         elements: ensureFlexContainerColumns(newElements),
         selectedElementId: newElement.id,
         activeSidebarTab: 'styles',
       };
    }
    case 'UPDATE_ELEMENT': {
       const { elementId, props, styles } = action.payload;
       const update = (widgets: Widget[]): Widget[] => {
         return widgets.map((el) => {
           if (el.id === elementId) {
             const updatedEl = JSON.parse(JSON.stringify(el));
 
             if (props) {
               updatedEl.props = { ...updatedEl.props, ...props };
               console.log('Editor reducer - updated element props:', updatedEl.props);
               
               // Handle columns update for Container and FlexContainer
               if (props.columns !== undefined && props.columns !== el.props.columns) {
                 const newColumns = typeof props.columns === 'object' ? 
                   Math.max(props.columns.desktop || 1, 1) : 
                   props.columns;
                 updatedEl.children = createColumns(newColumns);
               }
               
               // Special handling for FlexContainer - ensure it always has columns
               if (el.type === 'FlexContainer' && (!updatedEl.children || updatedEl.children.length === 0)) {
                 const columnCount = updatedEl.props.columns?.desktop || 2;
                 updatedEl.children = createColumns(columnCount);
                 console.log(`[Editor reducer] FlexContainer ${el.id} restored with ${columnCount} columns`);
               }
             }
             if (styles) {
               updatedEl.styles = {
                    ...updatedEl.styles,
                    ...styles
                 };
             }
             return updatedEl;
           }
           if (el.children) {
             return { ...el, children: update(el.children) };
           }
           return el;
         });
       };
       
       const newElements = update(state.elements);
       
       // Special handling for FlexContainer - ensure it always has columns after updating
       const ensureFlexContainerColumns = (widgets: Widget[]): Widget[] => {
         return widgets.map(w => {
           if (w.type === 'FlexContainer' && (!w.children || w.children.length === 0)) {
             const columnCount = w.props.columns?.desktop || 2;
             return { ...w, children: createColumns(columnCount) };
           }
           if (w.children) {
             return { ...w, children: ensureFlexContainerColumns(w.children) };
           }
           return w;
         });
       };

       return {
         ...state,
         elements: ensureFlexContainerColumns(newElements),
       };
      }
    case 'DELETE_ELEMENT': {
       const { elementId } = action.payload;
       const remove = (widgets: Widget[]): Widget[] => {
         const filtered = widgets.filter((el) => el.id !== elementId);
         return filtered.map((el) => {
           if (el.children) {
             return { ...el, children: remove(el.children) };
           }
           return el;
         });
       };
       
       const newElements = remove(state.elements);
       
       // Special handling for FlexContainer - ensure it always has columns after deleting element
       const ensureFlexContainerColumns = (widgets: Widget[]): Widget[] => {
         return widgets.map(w => {
           if (w.type === 'FlexContainer' && (!w.children || w.children.length === 0)) {
             const columnCount = w.props.columns?.desktop || 2;
             return { ...w, children: createColumns(columnCount) };
           }
           if (w.children) {
             return { ...w, children: ensureFlexContainerColumns(w.children) };
           }
           return w;
         });
       };

       return {
         ...state,
         elements: ensureFlexContainerColumns(newElements),
         selectedElementId: state.selectedElementId === elementId ? null : state.selectedElementId,
         inlineEditingElementId:
           state.inlineEditingElementId === elementId
             ? null
             : state.inlineEditingElementId,
       };
    }
    case 'DUPLICATE_ELEMENT': {
       const { elementId } = action.payload;
       const duplicate = (widgets: Widget[]): Widget[] => {
         const newWidgets: Widget[] = [];
         for (const el of widgets) {
           newWidgets.push(el);
           if (el.id === elementId) {
             const newElement: Widget = JSON.parse(JSON.stringify(el)); // Deep copy
             newElement.id = generateId();
             if (newElement.children) {
                 const fixIds = (children: Widget[]) => {
                     children.forEach(child => {
                         child.id = generateId();
                         if(child.children) {
                             fixIds(child.children);
                         }
                     })
                 }
                 fixIds(newElement.children)
             }
             newWidgets.push(newElement);
           } else if (el.children) {
             el.children = duplicate(el.children);
           }
         }
         return newWidgets;
       };

       const newElements = duplicate(state.elements);
       
       // Special handling for FlexContainer - ensure it always has columns after duplicating
       const ensureFlexContainerColumns = (widgets: Widget[]): Widget[] => {
         return widgets.map(w => {
           if (w.type === 'FlexContainer' && (!w.children || w.children.length === 0)) {
             const columnCount = w.props.columns?.desktop || 2;
             return { ...w, children: createColumns(columnCount) };
           }
           if (w.children) {
             return { ...w, children: ensureFlexContainerColumns(w.children) };
           }
           return w;
         });
       };

       return {
         ...state,
         elements: ensureFlexContainerColumns(newElements),
       };
    }
    case 'SELECT_ELEMENT': {
       const newTab = action.payload.elementId ? 'styles' : 'widgets';
       return {
         ...state,
         selectedElementId: action.payload.elementId,
         activeSidebarTab: newTab,
         inlineEditingElementId: null,
       };
    }
    case 'SET_INLINE_EDITING_ELEMENT': {
       return {
         ...state,
         inlineEditingElementId: action.payload.elementId,
         selectedElementId: action.payload.elementId,
       };
    }
    case 'SET_ELEMENTS': {
       const newElements = action.payload.elements;
       
       // Special handling for FlexContainer - ensure it always has columns
       const ensureFlexContainerColumns = (widgets: Widget[]): Widget[] => {
         return widgets.map(w => {
           if (w.type === 'FlexContainer' && (!w.children || w.children.length === 0)) {
             const columnCount = w.props.columns?.desktop || 2;
             return { ...w, children: createColumns(columnCount) };
           }
           if (w.children) {
             return { ...w, children: ensureFlexContainerColumns(w.children) };
           }
           return w;
         });
       };

       return {
         ...state,
         elements: ensureFlexContainerColumns(newElements),
       };
    }
    case 'SET_ACTIVE_TAB': {
       if (action.payload.tab === 'styles' && !state.selectedElementId) {
         return state;
       }
       return {
         ...state,
         activeSidebarTab: action.payload.tab,
       };
    }
    case 'UPDATE_PAGE_SETTINGS': {
        return {
          ...state,
          pageTitle: action.payload.title ?? state.pageTitle,
          pageSlug: action.payload.slug ?? state.pageSlug,
          pageType: action.payload.pageType ?? state.pageType,
          thumbnail: action.payload.thumbnail ?? state.thumbnail,
          seoDescription: action.payload.description ?? state.seoDescription,
          seoKeywords: action.payload.keywords ?? state.seoKeywords,
          robotsIndex: action.payload.robotsIndex ?? state.robotsIndex,
          robotsFollow: action.payload.robotsFollow ?? state.robotsFollow,
          robotsNoImageIndex: action.payload.robotsNoImageIndex ?? state.robotsNoImageIndex,
          categoryId: action.payload.categoryId !== undefined ? action.payload.categoryId : state.categoryId,
          tags: action.payload.tags !== undefined ? action.payload.tags : state.tags,
        };
     }
    case 'MOVE_ELEMENT': {
       const { fromIndex, toIndex } = action.payload;
       const newElements = [...state.elements];
       const [removed] = newElements.splice(fromIndex, 1);
       newElements.splice(toIndex, 0, removed);
       
       // Special handling for FlexContainer - ensure it always has columns
       const ensureFlexContainerColumns = (widgets: Widget[]): Widget[] => {
         return widgets.map(w => {
           if (w.type === 'FlexContainer' && (!w.children || w.children.length === 0)) {
             const columnCount = w.props.columns?.desktop || 2;
             return { ...w, children: createColumns(columnCount) };
           }
           if (w.children) {
             return { ...w, children: ensureFlexContainerColumns(w.children) };
           }
           return w;
         });
       };

       return {
         ...state,
         elements: ensureFlexContainerColumns(newElements),
       };
    }
    case 'SET_RESPONSIVE_MODE': {
       return {
         ...state,
         responsiveMode: action.payload.mode,
       };
    }
    case 'TOGGLE_FULLSCREEN': {
       return {
         ...state,
         isFullScreen: !state.isFullScreen,
       };
    }
    case 'SET_ZOOM': {
       return {
         ...state,
         zoom: action.payload.zoom,
       };
    }
    default:
      return state;
  }
};

type EditorContextType = {
  state: EditorState;
  dispatch: Dispatch<EditorAction>;
};

const EditorContext = createContext<EditorContextType>({
  state: createInitialState('new'),
  dispatch: () => null,
});

export const useEditor = () => {
  const context = useContext(EditorContext);
  if (!context) {
    throw new Error('useEditor must be used within an EditorProvider');
  }
  return context;
};

export const EditorProvider = ({ children, initialData }: { children: React.ReactNode, initialData?: PageData }) => {
  const params = useParams();
  const [state, dispatch] = useReducer(editorReducer, createInitialState(params.pageId, initialData));
  
  useEffect(() => {
    if (initialData) {
      dispatch({ type: 'LOAD_PAGE_DATA', payload: { data: initialData } });
    }
  }, [initialData]);
 
  return <EditorContext.Provider value={{ state, dispatch }}>{children}</EditorContext.Provider>;
};
