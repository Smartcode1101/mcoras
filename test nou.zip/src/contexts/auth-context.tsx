'use client';

import React, { createContext, useContext, useState, useEffect } from 'react';
import { User } from '@/lib/user-data';

interface AuthContextType {
  user: User | null;
  token: string | null;
  login: (user: User, token: string) => void;
  logout: () => void;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check for stored JWT token in localStorage
    const storedToken = localStorage.getItem('authToken');
    console.log('AuthContext: Checking for stored JWT token on mount:', !!storedToken);

    if (storedToken) {
      // For client-side, we'll trust the token is valid since middleware handles verification
      // We'll decode the payload without full verification to avoid client-side JWT library issues
      try {
        const payload = JSON.parse(atob(storedToken.split('.')[1]));
        console.log('AuthContext: Decoded JWT payload:', { userId: payload.userId, username: payload.username, role: payload.role });

        // Check if token is expired
        const currentTime = Math.floor(Date.now() / 1000);
        if (payload.exp && payload.exp < currentTime) {
          console.log('AuthContext: JWT token expired, clearing it');
          localStorage.removeItem('authToken');
          setIsLoading(false);
          return;
        }

        setUser({
          id: payload.userId,
          email: payload.email,
          username: payload.username,
          password: '', // Not stored in JWT for security
          role: payload.role,
          createdAt: '', // Not stored in JWT
        });
        setToken(storedToken);
      } catch (error) {
        console.log('AuthContext: Invalid JWT token format, clearing it');
        localStorage.removeItem('authToken');
      }
    } else {
      console.log('AuthContext: No JWT token found');
    }
    setIsLoading(false);
  }, []);

  const login = (userData: User, jwtToken: string) => {
    console.log('AuthContext: Logging in user:', { id: userData.id, username: userData.username, role: userData.role });
    setUser(userData);
    setToken(jwtToken);
    // Store JWT token in localStorage
    localStorage.setItem('authToken', jwtToken);
    // Store additional session info
    localStorage.setItem('lastLoginTime', new Date().toISOString());
    localStorage.setItem('userId', userData.id);
    console.log('AuthContext: JWT token and session data stored in localStorage');
  };

  const logout = async () => {
    console.log('AuthContext: Logging out user');

    try {
      // Call logout API to invalidate token on server side if needed
      const response = await fetch('/api/auth/logout', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': token ? `Bearer ${token}` : '',
        },
      });

      if (response.ok) {
        console.log('AuthContext: Server-side logout successful');
      } else {
        console.log('AuthContext: Server-side logout failed, but continuing with client-side cleanup');
      }
    } catch (error) {
      console.log('AuthContext: Error during server-side logout, continuing with client-side cleanup:', error);
    }

    // Clear local state
    setUser(null);
    setToken(null);

    // Clear JWT token from localStorage
    localStorage.removeItem('authToken');

    // Clear any other auth-related data from localStorage
    localStorage.removeItem('userPreferences');
    localStorage.removeItem('lastLoginTime');

    console.log('AuthContext: Complete logout cleanup finished');
  };

  return (
    <AuthContext.Provider value={{ user, token, login, logout, isLoading }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}