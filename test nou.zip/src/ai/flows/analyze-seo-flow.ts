'use server';

/**
 * @fileOverview An AI agent for analyzing and providing SEO feedback on a webpage.
 *
 * - analyzeSeo - A function that handles the SEO analysis process.
 * - AnalyzeSeoInput - The input type for the analyzeSeo function.
 * - AnalyzeSeoOutput - The return type for the analyzeSeo function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';
import type { Widget } from '@/lib/types';

const AnalyzeSeoInputSchema = z.object({
  pageTitle: z.string().describe('The meta title of the page.'),
  pageSlug: z.string().describe('The URL slug of the page.'),
  seoDescription: z.string().describe('The meta description of the page.'),
  pageContent: z.string().describe('The main text content from the page, concatenated together.'),
});
export type AnalyzeSeoInput = z.infer<typeof AnalyzeSeoInputSchema>;

const AnalyzeSeoOutputSchema = z.object({
  suggestions: z.string().describe('Actionable suggestions to improve SEO, in Romanian. Should be formatted as a list.'),
  rankingEstimate: z.string().describe('An estimation of where the page could rank on Google for its target keywords, in Romanian.'),
  eeatAnalysis: z.string().describe("An analysis of the page based on Google's E-E-A-T principles (Experience, Expertise, Authoritativeness, Trustworthiness), in Romanian."),
});
export type AnalyzeSeoOutput = z.infer<typeof AnalyzeSeoOutputSchema>;

function extractTextFromElements(elements: Widget[]): string {
  let content = '';
  function traverse(widgets: Widget[]) {
    widgets.forEach((widget) => {
      if (widget.type === 'Heading' || widget.type === 'Text') {
        content += `${widget.props.text} `;
      }
      if (widget.children) {
        traverse(widget.children);
      }
    });
  }
  traverse(elements);
  return content.trim();
}


export async function analyzeSeo(input: Omit<AnalyzeSeoInput, 'pageContent'> & { elements: Widget[] }): Promise<AnalyzeSeoOutput> {
  const pageContent = extractTextFromElements(input.elements);
  return analyzeSeoFlow({ ...input, pageContent });
}

const prompt = ai.definePrompt({
  name: 'analyzeSeoPrompt',
  input: { schema: AnalyzeSeoInputSchema },
  output: { schema: AnalyzeSeoOutputSchema },
  prompt: `Ești un expert SEO avansat. Analizează următoarea pagină web pe baza datelor furnizate și oferă feedback în limba română.

Datele paginii:
- Meta Titlu: {{{pageTitle}}}
- URL Slug: /{{{pageSlug}}}
- Meta Descriere: {{{seoDescription}}}
- Conținutul principal al paginii: {{{pageContent}}}

Sarcina ta este să oferi următoarele, în limba română:
1.  **Sugestii de optimizare:** Oferă o listă cu puncte concrete și acționabile pentru a îmbunătăți SEO-ul paginii. Fii specific.
2.  **Estimare de clasare pe Google:** Oferă o estimare realistă a potențialului de clasare a paginii pentru cuvintele cheie vizate. Explică raționamentul tău.
3.  **Analiză Google E-E-A-T:** Evaluează pagina din perspectiva principiilor Google E-E-A-T (Experience, Expertise, Authoritativeness, Trustworthiness - Experiență, Expertiză, Autoritate, Încredere). Explică ce face bine și unde poate fi îmbunătățită.

Răspunde strict în formatul JSON solicitat.`,
});

const analyzeSeoFlow = ai.defineFlow(
  {
    name: 'analyzeSeoFlow',
    inputSchema: AnalyzeSeoInputSchema,
    outputSchema: AnalyzeSeoOutputSchema,
  },
  async (input) => {
    const { output } = await prompt(input);
    return output!;
  }
);
