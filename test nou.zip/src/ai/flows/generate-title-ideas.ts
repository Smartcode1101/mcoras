'use server';

/**
 * @fileOverview AI agent that generates title ideas for a page based on a description.
 *
 * - generateTitleIdeas - A function that generates title ideas.
 * - GenerateTitleIdeasInput - The input type for the generateTitleIdeas function.
 * - GenerateTitleIdeasOutput - The return type for the generateTitleIdeas function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GenerateTitleIdeasInputSchema = z.object({
  description: z
    .string()
    .describe('A description of the page for which to generate title ideas.'),
});
export type GenerateTitleIdeasInput = z.infer<typeof GenerateTitleIdeasInputSchema>;

const GenerateTitleIdeasOutputSchema = z.object({
  titleIdeas: z
    .array(z.string())
    .describe('An array of title ideas generated based on the description.'),
});
export type GenerateTitleIdeasOutput = z.infer<typeof GenerateTitleIdeasOutputSchema>;

export async function generateTitleIdeas(
  input: GenerateTitleIdeasInput
): Promise<GenerateTitleIdeasOutput> {
  return generateTitleIdeasFlow(input);
}

const prompt = ai.definePrompt({
  name: 'generateTitleIdeasPrompt',
  input: {schema: GenerateTitleIdeasInputSchema},
  output: {schema: GenerateTitleIdeasOutputSchema},
  prompt: `You are a creative title generator. Based on the description of the page, generate 5 title ideas.

Description: {{{description}}}

Title Ideas:`,
});

const generateTitleIdeasFlow = ai.defineFlow(
  {
    name: 'generateTitleIdeasFlow',
    inputSchema: GenerateTitleIdeasInputSchema,
    outputSchema: GenerateTitleIdeasOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
