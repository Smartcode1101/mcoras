import { config } from 'dotenv';
config();

import '@/ai/flows/generate-title-ideas.ts';
import '@/ai/flows/analyze-seo-flow.ts';
