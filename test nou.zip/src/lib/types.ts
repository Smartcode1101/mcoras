import type { CSSProperties } from 'react';

export type WidgetType = 'Heading' | 'Text' | 'Image' | 'Button' | 'Spacer' | 'Container' | 'FlexContainer' | 'Video' | 'Html' | 'PostGrid' | 'PostTags';

export type Widget = {
  id: string;
  type: WidgetType;
  props: {
    [key: string]: any;
  };
  styles: ResponsiveValue<CSSProperties>;
  children?: Widget[]; // For container columns
};

export type PageTemplate = {
  id: string;
  name: string;
  elements: Widget[];
};

export type MenuItem = {
    pageId?: string;
    categoryId?: string;
    title?: string; // Optional custom title
    children?: MenuItem[]; // Submenu items
    isSubmenu?: boolean; // Flag to identify submenu
}

export type SiteSettings = {
    language?: string;
    logoUrl: string;
    siteTitle?: string;
    siteName?: string;
    siteUrl?: string;
    siteDescription?: string;
    ogImage?: string;
    twitterImage?: string;
    logo?: string;
    menu: {
        alignment: 'left' | 'center' | 'right';
        items: MenuItem[];
    };
    headerSettings: {
        backgroundColor: string;
        backdropBlur: number;
        borderColor: string;
    };
    footerSettings: {
        backgroundColor: string;
        backdropBlur: number;
        borderColor: string;
        showCopyright: boolean;
    };
}

export type EditorState = {
  id: string | null;
  pageTitle: string;
  pageSlug: string;
  pageType: PageType;
  thumbnail?: string;
  seoDescription: string;
  seoKeywords: string;
  robotsIndex: boolean;
  robotsFollow: boolean;
  robotsNoImageIndex: boolean;
  categoryId?: string;
  tags?: string[];
  elements: Widget[];
  selectedElementId: string | null;
  inlineEditingElementId: string | null;
  activeSidebarTab: 'widgets' | 'styles' | 'settings';
  responsiveMode: ResponsiveMode;
  isFullScreen: boolean;
  zoom: number;
};

export type PageType = 'page' | 'post';

export type Category = {
    id: string;
    name: string;
    slug: string;
    description?: string;
    metaTitle?: string;
    metaDescription?: string;
    metaKeywords?: string;
    createdAt: string;
    updatedAt: string;
};

export type Tag = {
    id: string;
    name: string;
    slug: string;
    description?: string;
    metaTitle?: string;
    metaDescription?: string;
    metaKeywords?: string;
    createdAt: string;
    updatedAt: string;
};

export type PageData = {
    id: string;
    title: string;
    slug: string;
    type: PageType;
    thumbnail?: string;
    elements: Widget[];
    seoDescription: string;
    seoKeywords: string;
    robotsIndex: boolean;
    robotsFollow: boolean;
    robotsNoImageIndex: boolean;
    css: string;
    createdAt: string;
    updatedAt: string;
    viewsLast24h?: number;
    lastActivity?: string; // ISO timestamp of last user activity
    categoryId?: string; // ID-ul categoriei asociate
    tags?: string[]; // Array de ID-uri ale tag-urilor asociate
};

export type EditorAction =
  | { type: 'LOAD_PAGE_DATA', payload: { data: PageData } }
  | { type: 'ADD_ELEMENT'; payload: { index: number; element: Widget; parentId?: string | null } }
  | {
      type: 'UPDATE_ELEMENT';
      payload: {
        elementId: string;
        props?: Partial<Widget['props']>;
        styles?: ResponsiveValue<CSSProperties>;
      };
    }
  | { type: 'DELETE_ELEMENT'; payload: { elementId: string } }
  | { type: 'DUPLICATE_ELEMENT'; payload: { elementId: string } }
  | { type: 'SELECT_ELEMENT'; payload: { elementId: string | null } }
  | { type: 'SET_INLINE_EDITING_ELEMENT'; payload: { elementId: string | null } }
  | { type: 'SET_ELEMENTS'; payload: { elements: Widget[] } }
  | { type: 'SET_ACTIVE_TAB'; payload: { tab: EditorState['activeSidebarTab'] } }
  | {
      type: 'UPDATE_PAGE_SETTINGS';
      payload: {
        title?: string;
        slug?: string;
        pageType?: PageType;
        thumbnail?: string;
        description?: string;
        keywords?: string;
        robotsIndex?: boolean;
        robotsFollow?: boolean;
        robotsNoImageIndex?: boolean;
        categoryId?: string;
        tags?: string[];
      };
    }
  | { type: 'MOVE_ELEMENT'; payload: { fromIndex: number; toIndex: number; fromParentId?: string | null; toParentId?: string | null } }
  | { type: 'SET_RESPONSIVE_MODE'; payload: { mode: ResponsiveMode } }
  | { type: 'TOGGLE_FULLSCREEN' }
  | { type: 'SET_ZOOM'; payload: { zoom: number } };

export type ResponsiveMode = 'desktop' | 'tablet' | 'mobile';

export type ResponsiveValue<T> = {
  desktop?: T;
  tablet?: T;
  mobile?: T;
};

export type MediaItem = {
  id: string;
  src: string;
  alt: string;
  filename: string;
  createdAt: string;
};
