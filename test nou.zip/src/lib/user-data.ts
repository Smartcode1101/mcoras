import fs from 'fs';
import path from 'path';
import bcrypt from 'bcryptjs';
import { v4 as uuidv4 } from 'uuid';

export interface User {
  id: string;
  email: string;
  username: string;
  password: string;
  role: 'admin' | 'subscriber';
  createdAt: string;
}

const usersFilePath = path.join(process.cwd(), 'db', 'users.json');

export function getUsers(): User[] {
  try {
    const data = fs.readFileSync(usersFilePath, 'utf8');
    return JSON.parse(data);
  } catch (error) {
    return [];
  }
}

export function saveUsers(users: User[]): void {
  fs.writeFileSync(usersFilePath, JSON.stringify(users, null, 2));
}

export async function createUser(email: string, username: string, password: string, role: 'admin' | 'subscriber' = 'subscriber'): Promise<User> {
  const users = getUsers();

  // Check if user already exists
  if (users.find(u => u.email === email || u.username === username)) {
    throw new Error('User already exists');
  }

  const hashedPassword = await bcrypt.hash(password, 10);
  const newUser: User = {
    id: uuidv4(),
    email,
    username,
    password: hashedPassword,
    role,
    createdAt: new Date().toISOString(),
  };

  users.push(newUser);
  saveUsers(users);

  return newUser;
}

export async function authenticateUser(usernameOrEmail: string, password: string): Promise<User | null> {
  const users = getUsers();
  const user = users.find(u => u.email === usernameOrEmail || u.username === usernameOrEmail);

  if (!user) return null;

  const isValidPassword = await bcrypt.compare(password, user.password);
  return isValidPassword ? user : null;
}

export function getUserById(id: string): User | null {
  const users = getUsers();
  return users.find(u => u.id === id) || null;
}

export function updateUserRole(id: string, role: 'admin' | 'subscriber'): boolean {
  const users = getUsers();
  const userIndex = users.findIndex(u => u.id === id);

  if (userIndex === -1) return false;

  users[userIndex].role = role;
  saveUsers(users);
  return true;
}

export function deleteUser(id: string): boolean {
  const users = getUsers();
  const filteredUsers = users.filter(u => u.id !== id);

  if (filteredUsers.length === users.length) return false;

  saveUsers(filteredUsers);
  return true;
}