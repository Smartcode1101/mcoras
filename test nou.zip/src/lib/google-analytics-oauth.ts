// Google OAuth și Google Analytics Management API Service
import { google } from 'googleapis';

export interface GoogleAnalyticsProperty {
  id: string;
  name: string;
  websiteUrl?: string;
  industryVertical?: string;
  country?: string;
  currency?: string;
  timezone?: string;
  serviceLevel?: string;
  defaultPropertyId?: string;
  measurementId?: string;
}

export interface OAuthConfig {
  clientId: string;
  clientSecret: string;
  redirectUri: string;
}

export interface TokenInfo {
  access_token: string;
  refresh_token?: string;
  scope: string;
  token_type: string;
  expiry_date: number;
}

class GoogleAnalyticsOAuthService {
  private oauth2Client: any;
  private analyticsAdmin: any;
  private analyticsData: any;

  constructor() {
    this.oauth2Client = new google.auth.OAuth2(
      process.env.GOOGLE_CLIENT_ID,
      process.env.GOOGLE_CLIENT_SECRET,
      process.env.GOOGLE_REDIRECT_URI || 'http://localhost:3000/api/analytics/google/callback'
    );
  }

  /**
   * Validează formatul Client ID-ului Google
   */
  public validateClientId(clientId: string): { isValid: boolean; error?: string } {
    if (!clientId) {
      return { isValid: false, error: 'Client ID is required' };
    }

    if (!clientId.endsWith('.apps.googleusercontent.com')) {
      return { isValid: false, error: 'Client ID must end with .apps.googleusercontent.com' };
    }

    if (clientId.includes('your-google-client-id')) {
      return { isValid: false, error: 'Please replace placeholder Client ID with real value from Google Cloud Console' };
    }

    if (clientId.length < 50) {
      return { isValid: false, error: 'Client ID appears to be too short' };
    }

    return { isValid: true };
  }

  /**
   * Generează URL-ul pentru autentificarea Google OAuth
   */
  public getAuthUrl(state?: string): string {
    const clientId = process.env.GOOGLE_CLIENT_ID;
    const clientSecret = process.env.GOOGLE_CLIENT_SECRET;
    
    // Validare Client ID și Client Secret
    const clientIdValidation = this.validateClientId(clientId || '');
    if (!clientIdValidation.isValid) {
      throw new Error(`Invalid Client ID: ${clientIdValidation.error}`);
    }

    if (!clientSecret) {
      throw new Error('Client Secret is required. Please configure GOOGLE_CLIENT_SECRET in .env.local');
    }

    if (clientSecret.includes('your-google-client-secret')) {
      throw new Error('Please replace placeholder Client Secret with real value from Google Cloud Console');
    }

    const scopes = [
      'https://www.googleapis.com/auth/analytics.readonly',
      'https://www.googleapis.com/auth/analytics.manage.users'
    ];

    return this.oauth2Client.generateAuthUrl({
      access_type: 'offline',
      prompt: 'consent',
      scope: scopes,
      state: state || 'analytics_setup',
      include_granted_scopes: true
    });
  }

  /**
   * Schimbă codul de autorizare cu token-uri de acces
   */
  public async getTokens(authCode: string): Promise<TokenInfo> {
    try {
      const { tokens } = await this.oauth2Client.getToken(authCode);
      
      return {
        access_token: tokens.access_token!,
        refresh_token: tokens.refresh_token,
        scope: tokens.scope!,
        token_type: tokens.token_type!,
        expiry_date: tokens.expiry_date!
      };
    } catch (error) {
      console.error('Error exchanging auth code for tokens:', error);
      throw new Error('Failed to exchange authorization code for tokens');
    }
  }

  /**
   * Setează credentialele și authorizează clientul
   */
  public setCredentials(tokens: TokenInfo) {
    this.oauth2Client.setCredentials({
      access_token: tokens.access_token,
      refresh_token: tokens.refresh_token,
      scope: tokens.scope,
      token_type: tokens.token_type,
      expiry_date: tokens.expiry_date
    });

    // Inițializează serviciile Google Analytics
    this.analyticsAdmin = google.analyticsadmin({
      version: 'v1beta',
      auth: this.oauth2Client,
    });
    this.analyticsData = google.analyticsdata({
      version: 'v1beta',
      auth: this.oauth2Client,
    });
  }

  /**
   * Verifică dacă token-ul de acces este valid
   */
  public async isTokenValid(tokens: TokenInfo): Promise<boolean> {
    try {
      this.setCredentials(tokens);
      await this.analyticsAdmin.accountSummaries.list();
      return true;
    } catch (error) {
      console.error('Token validation failed:', error);
      return false;
    }
  }

  /**
   * Obține toate proprietățile Google Analytics ale utilizatorului
   */
  public async getAnalyticsProperties(tokens: TokenInfo): Promise<GoogleAnalyticsProperty[]> {
    try {
      this.setCredentials(tokens);

      // Obține toate conturile și proprietățile
      const accountSummaries = await this.analyticsAdmin.accountSummaries.list();
      
      const properties: GoogleAnalyticsProperty[] = [];

      if (accountSummaries.data.accountSummaries) {
        for (const account of accountSummaries.data.accountSummaries) {
          if (account.propertySummaries) {
            for (const property of account.propertySummaries) {
              try {
                // Obține detaliile complete pentru fiecare proprietate
                const propertyDetails = await this.analyticsAdmin.properties.get({
                  name: property.property!,
                });

                const details = propertyDetails.data;
                
                // Încearcă să obțină Measurement ID-ul
                const measurementId = await this.extractMeasurementId(property.property!);

                properties.push({
                  id: property.property!.split('/').pop()!,
                  name: property.displayName || details.displayName || 'Unnamed Property',
                  websiteUrl: details.websiteUrl,
                  industryVertical: details.industryVertical,
                  country: details.country,
                  currency: details.currencyCode,
                  timezone: details.timeZone,
                  serviceLevel: details.serviceLevel,
                  measurementId: measurementId,
                });
              } catch (error) {
                console.warn(`Failed to get details for property ${property.property}:`, error);
                // Adaugă proprietatea cu detalii minime
                properties.push({
                  id: property.property!.split('/').pop()!,
                  name: property.displayName || 'Unnamed Property',
                  measurementId: undefined,
                });
              }
            }
          }
        }
      }

      return properties.sort((a, b) => a.name.localeCompare(b.name));
    } catch (error) {
      console.error('Error fetching analytics properties:', error);
      throw new Error('Failed to fetch Google Analytics properties');
    }
  }

  /**
   * Extrage Measurement ID-ul pentru o proprietate GA4
   */
  private async extractMeasurementId(propertyName: string): Promise<string | undefined> {
    try {
      // Încearcă să obțină stream-urile de date pentru proprietate
      const dataStreams = await this.analyticsAdmin.properties.dataStreams.list({
        parent: propertyName,
      });

      if (dataStreams.data.dataStreams && dataStreams.data.dataStreams.length > 0) {
        const webStream = dataStreams.data.dataStreams.find(
          (stream: any) => stream.type === 'WEB_DATA_STREAM'
        );
        
        if (webStream?.webStreamData?.measurementId) {
          return webStream.webStreamData.measurementId;
        }
      }

      // Dacă nu găsește stream web, încearcă orice stream disponibil
      if (dataStreams.data.dataStreams && dataStreams.data.dataStreams.length > 0) {
        return dataStreams.data.dataStreams[0].webStreamData?.measurementId;
      }

      return undefined;
    } catch (error) {
      console.warn(`Failed to extract measurement ID for ${propertyName}:`, error);
      return undefined;
    }
  }

  /**
   * Selectează o proprietate și salvează configurația
   */
  public async selectProperty(
    tokens: TokenInfo, 
    propertyId: string
  ): Promise<{ success: boolean; message: string; measurementId?: string }> {
    try {
      const properties = await this.getAnalyticsProperties(tokens);
      const selectedProperty = properties.find(p => p.id === propertyId);

      if (!selectedProperty) {
        throw new Error('Selected property not found');
      }

      if (!selectedProperty.measurementId) {
        throw new Error('Selected property does not have a valid Measurement ID');
      }

      // Salvează configurația în baza de date sau fișier
      await this.saveAnalyticsConfig({
        propertyId: selectedProperty.id,
        propertyName: selectedProperty.name,
        measurementId: selectedProperty.measurementId,
        websiteUrl: selectedProperty.websiteUrl,
        connectedAt: new Date().toISOString(),
      });

      return {
        success: true,
        message: `Proprietatea "${selectedProperty.name}" a fost conectată cu succes!`,
        measurementId: selectedProperty.measurementId,
      };
    } catch (error) {
      console.error('Error selecting property:', error);
      return {
        success: false,
        message: error instanceof Error ? error.message : 'Eroare necunoscută',
      };
    }
  }

  /**
   * Salvează configurația Analytics
   */
  private async saveAnalyticsConfig(config: any): Promise<void> {
    try {
      const fs = require('fs').promises;
      const path = require('path');
      
      const configPath = path.join(process.cwd(), 'db', 'analytics-config.json');
      const existingConfig = await this.loadAnalyticsConfig();

      const updatedConfig = {
        ...existingConfig,
        google: {
          ...existingConfig.google,
          selected: config,
          updatedAt: new Date().toISOString(),
        }
      };

      await fs.writeFile(configPath, JSON.stringify(updatedConfig, null, 2));
    } catch (error) {
      console.error('Error saving analytics config:', error);
      throw error;
    }
  }

  /**
   * Încarcă configurația Analytics
   */
  public async loadAnalyticsConfig(): Promise<any> {
    try {
      const fs = require('fs').promises;
      const path = require('path');
      
      const configPath = path.join(process.cwd(), 'db', 'analytics-config.json');
      const data = await fs.readFile(configPath, 'utf8');
      return JSON.parse(data);
    } catch (error) {
      // Returnează configurația default dacă fișierul nu există
      return {
        google: {
          connected: false,
          properties: [],
          selected: null,
          updatedAt: null,
        },
        local: {
          enabled: true,
        }
      };
    }
  }

  /**
   * Deconectează Google Analytics
   */
  public async disconnectAnalytics(): Promise<{ success: boolean; message: string }> {
    try {
      const fs = require('fs').promises;
      const path = require('path');
      
      const configPath = path.join(process.cwd(), 'db', 'analytics-config.json');
      const existingConfig = await this.loadAnalyticsConfig();

      const updatedConfig = {
        ...existingConfig,
        google: {
          connected: false,
          properties: [],
          selected: null,
          updatedAt: new Date().toISOString(),
        }
      };

      await fs.writeFile(configPath, JSON.stringify(updatedConfig, null, 2));

      return {
        success: true,
        message: 'Google Analytics a fost deconectat cu succes.',
      };
    } catch (error) {
      console.error('Error disconnecting analytics:', error);
      return {
        success: false,
        message: 'Eroare la deconectarea Google Analytics',
      };
    }
  }

  /**
   * Obține statusul conexiunii
   */
  public async getConnectionStatus(): Promise<{
    connected: boolean;
    selectedProperty?: GoogleAnalyticsProperty;
    properties: GoogleAnalyticsProperty[];
  }> {
    try {
      const config = await this.loadAnalyticsConfig();
      
      if (config.google?.selected) {
        return {
          connected: true,
          selectedProperty: config.google.selected,
          properties: config.google.properties || [],
        };
      }

      return {
        connected: false,
        properties: [],
      };
    } catch (error) {
      console.error('Error getting connection status:', error);
      return {
        connected: false,
        properties: [],
      };
    }
  }

  /**
   * Actualizează token-urile utilizând refresh token
   */
  public async refreshTokens(refreshToken: string): Promise<TokenInfo> {
    try {
      this.oauth2Client.setCredentials({
        refresh_token: refreshToken,
      });

      const { credentials } = await this.oauth2Client.refreshAccessToken();
      
      return {
        access_token: credentials.access_token!,
        refresh_token: credentials.refresh_token || refreshToken,
        scope: credentials.scope!,
        token_type: credentials.token_type!,
        expiry_date: credentials.expiry_date!,
      };
    } catch (error) {
      console.error('Error refreshing tokens:', error);
      throw new Error('Failed to refresh access tokens');
    }
  }
}

// Singleton instance
export const googleAnalyticsOAuth = new GoogleAnalyticsOAuthService();

export default googleAnalyticsOAuth;