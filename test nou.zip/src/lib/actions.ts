
'use server';

import { generateTitleIdeas } from '@/ai/flows/generate-title-ideas';
import { z } from 'zod';
import type { EditorState, Widget, SiteSettings } from './types';
import { generateId } from './utils';
import React from 'react';
import fs from 'fs/promises';
import path from 'path';
import { savePage, deletePage, getPages, getActivePages } from './page-data';
import { saveMediaItem, getMediaItems, deleteMediaItem, type MediaItem } from './media-data';
import { getTemplates, saveTemplate } from './template-data';
import { getSiteSettings, saveSiteSettings } from './settings-data';
import { revalidatePath } from 'next/cache';
import { analyzeSeo } from '@/ai/flows/analyze-seo-flow';

const generateTitleIdeasSchema = z.object({
  description: z.string().min(10, 'Descrierea trebuie să aibă cel puțin 10 caractere.'),
});

export async function generateTitleIdeasAction(values: z.infer<typeof generateTitleIdeasSchema>) {
  const validatedFields = generateTitleIdeasSchema.safeParse(values);
  if (!validatedFields.success) {
    return { error: 'Descriere invalidă.' };
  }

  try {
    const result = await generateTitleIdeas({
      description: validatedFields.data.description,
    });
    return { data: result.titleIdeas };
  } catch (error) {
    console.error(error);
    return { error: 'Nu s-au putut genera idei de titluri.' };
  }
}

const analyzeSeoActionSchema = z.object({
  pageTitle: z.string(),
  pageSlug: z.string(),
  seoDescription: z.string(),
  elements: z.any(), // Not parsing complex widget structure here
});

export async function analyzeSeoAction(values: z.infer<typeof analyzeSeoActionSchema>) {
  const validatedFields = analyzeSeoActionSchema.safeParse(values);
  if (!validatedFields.success) {
    return { error: 'Datele paginii furnizate sunt invalide.' };
  }

  try {
    const result = await analyzeSeo({
      pageTitle: validatedFields.data.pageTitle,
      pageSlug: validatedFields.data.pageSlug,
      seoDescription: validatedFields.data.seoDescription,
      elements: validatedFields.data.elements as Widget[],
    });
    return { data: result };
  } catch (error) {
    console.error('Eroare Analiză SEO:', error);
    return { error: 'AI-ul nu a putut finaliza analiza. Încercați din nou.' };
  }
}


export async function uploadImageAction(formData: FormData) {
  const file = formData.get('file') as File;
  if (!file) {
    return { error: 'Niciun fișier furnizat.' };
  }
 
  try {
    console.log('Uploading file:', file.name);
    const buffer = Buffer.from(await file.arrayBuffer());
    const originalFilename = file.name.replace(/\s/g, '_');
    const filename = `${Date.now()}-${originalFilename}`;
    const uploadDir = path.join(process.cwd(), 'public/imageuploads');
 
    await fs.mkdir(uploadDir, { recursive: true });
    await fs.writeFile(path.join(uploadDir, filename), buffer);
    console.log('File written to disk:', filename);
 
    const fileUrl = `/imageuploads/${filename}`;
    console.log('File URL:', fileUrl);
    
    // Save metadata to the database
    const mediaItem: MediaItem = {
        id: generateId(),
        src: fileUrl,
        alt: originalFilename.replace(/\.[^/.]+$/, ''), // Alt text from filename without extension
        filename: originalFilename,
        createdAt: new Date().toISOString(),
    };
    await saveMediaItem(mediaItem);
    console.log('Media item added to DB:', mediaItem);
 
    return { data: mediaItem };
  } catch (error) {
    console.error('Încărcare eșuată:', error);
    return { error: 'Nu s-a putut încărca imaginea.' };
  }
}
export async function getImagesAction() {
  try {
    const media = await getMediaItems();
    return { data: media.sort((a: MediaItem, b: MediaItem) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()) }; // Show newest first
  } catch (error) {
    console.error('Eroare la citirea imaginilor din DB:', error);
    return { error: 'Nu s-au putut încărca imaginile.' };
  }
}

function styleObjectToString(style: React.CSSProperties | any = {}): string {
  // If it's ResponsiveValue, use desktop
  const actualStyle = style.desktop || style;
  return Object.entries(actualStyle)
    .map(([key, value]) => {
      if (value === undefined || value === null) return '';
      const cssKey = key.replace(/([A-Z])/g, '-$1').toLowerCase();
      return `${cssKey}:${value}`;
    })
    .filter(Boolean)
    .join(';');
}

const getEmbedUrl = (url: string) => {
  if (!url) return '';
  let videoId = '';
  try {
    const urlObj = new URL(url);
    if (urlObj.hostname === 'youtu.be') {
      videoId = urlObj.pathname.slice(1);
    } else if (
      urlObj.hostname === 'www.youtube.com' ||
      urlObj.hostname === 'youtube.com'
    ) {
      videoId = urlObj.searchParams.get('v') || '';
    }
  } catch (error) {
    return '';
  }
  return videoId ? `https://www.youtube.com/embed/${videoId}` : '';
};

function renderWidgetToHtml(element: Widget): string {
  const { id, type, props, children } = element;
  const className = `widget-${id}`;

  switch (type) {
    case 'Heading':
      const level = props.level || 1;
      const Tag = `h${level}`;
      return `<${Tag} class="${className}">${props.text || ''}</${Tag}>`;
    case 'Text':
      return `<p class="${className}">${props.text || ''}</p>`;
    case 'Button':
      return `<a href="${props.href || '#'}" class="${className}">${props.text || ''}</a>`;
    case 'Spacer':
      return `<div class="${className}"></div>`;
    case 'Image': {
      const { src = '', alt = '', description = '' } = props;
      const imageStyles = styleObjectToString({
        display: 'block',
        width: '100%',
        height: '100%',
        objectFit: 'cover',
      });
      const imageHtml = `<img src="${src}" alt="${alt}" style="${imageStyles}" />`;
      const captionHtml = description ? `<figcaption style="font-size: 0.875rem; color: #666; text-align: center; margin-top: 8px;">${description}</figcaption>` : '';
      return `<figure class="${className}">${imageHtml}${captionHtml}</figure>`;
    }
    case 'Video':
      const embedUrl = getEmbedUrl(props.src || '');
      if (!embedUrl) return `<div class="${className}">URL video invalid</div>`;
      const iframeStyles = styleObjectToString({
        position: 'absolute',
        top: '0',
        left: '0',
        width: '100%',
        height: '100%',
      });
      return `<div class="${className}" style="position: relative; padding-bottom: 56.25%; height: 0; overflow: hidden;">
        <iframe
          src="${embedUrl}"
          title="Player video YouTube"
          frameborder="0"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowfullscreen
          style="${iframeStyles}"
        ></iframe>
      </div>`;
    case 'Container':
      const ContainerTag = props.tag || 'div';
      const childrenHtml = children?.map(renderWidgetToHtml).join('') || '';
      return `<${ContainerTag} class="${className}">${childrenHtml}</${ContainerTag}>`;
    case 'Html':
      return `<div class="${className}">${props.html || ''}</div>`;
    default:
      return '';
  }
}

function generateCss(elements: Widget[]): string {
  let css = '';

  function traverse(widgets: Widget[]) {
    widgets.forEach(widget => {
      const className = `.widget-${widget.id}`;

      // Desktop styles
      const desktopStyles = styleObjectToString(widget.styles.desktop || widget.styles);
      if (desktopStyles) {
        css += `${className} { ${desktopStyles} }\n`;
      }

      // Tablet styles
      const tabletStyles = styleObjectToString(widget.styles.tablet);
      if (tabletStyles) {
        css += `@media (max-width: 1024px) { ${className} { ${tabletStyles} } }\n`;
      }

      // Mobile styles
      const mobileStyles = styleObjectToString(widget.styles.mobile);
      if (mobileStyles) {
        css += `@media (max-width: 768px) { ${className} { ${mobileStyles} } }\n`;
      }

      if (widget.type === 'Image' && widget.styles) {
         const imageClassName = `.widget-${widget.id} img`;
         const desktopImgStyles = styleObjectToString({
            backgroundColor: widget.styles.desktop?.backgroundColor,
            borderTopLeftRadius: widget.styles.desktop?.borderTopLeftRadius,
            borderTopRightRadius: widget.styles.desktop?.borderTopRightRadius,
            borderBottomLeftRadius: widget.styles.desktop?.borderBottomLeftRadius,
            borderBottomRightRadius: widget.styles.desktop?.borderBottomRightRadius,
            boxShadow: widget.styles.desktop?.boxShadow,
            width: widget.props.width?.desktop ? `${widget.props.width.desktop}px` : undefined,
            height: widget.props.height?.desktop ? `${widget.props.height.desktop}px` : undefined,
            objectFit: widget.props.objectFit?.desktop,
            aspectRatio: widget.props.aspectRatio?.desktop,
         });
         if (desktopImgStyles) css += `${imageClassName} { ${desktopImgStyles} }\n`;

         const tabletImgStyles = styleObjectToString({
            width: widget.props.width?.tablet ? `${widget.props.width.tablet}px` : undefined,
            height: widget.props.height?.tablet ? `${widget.props.height.tablet}px` : undefined,
            objectFit: widget.props.objectFit?.tablet,
            aspectRatio: widget.props.aspectRatio?.tablet,
         });
         if (tabletImgStyles) css += `@media (max-width: 1024px) { ${imageClassName} { ${tabletImgStyles} } }\n`;

         const mobileImgStyles = styleObjectToString({
            width: widget.props.width?.mobile ? `${widget.props.width.mobile}px` : undefined,
            height: widget.props.height?.mobile ? `${widget.props.height.mobile}px` : undefined,
            objectFit: widget.props.objectFit?.mobile,
            aspectRatio: widget.props.aspectRatio?.mobile,
         });
         if (mobileImgStyles) css += `@media (max-width: 768px) { ${imageClassName} { ${mobileImgStyles} } }\n`;
      }

      if (widget.children) {
        traverse(widget.children);
      }
    });
  }

  traverse(elements);

  return css;
}

export async function savePageAction(editorState: EditorState) {
  const {
    id,
    pageTitle,
    pageSlug,
    pageType,
    thumbnail,
    elements,
    seoDescription,
    seoKeywords,
    robotsIndex,
    robotsFollow,
    robotsNoImageIndex,
    categoryId,
    tags,
  } = editorState;
  
  if (!pageTitle) {
    return { error: 'Titlul paginii este obligatoriu.' };
  }
  if (!pageSlug) {
    return { error: 'URL-ul paginii (slug) este obligatoriu.' };
  }

  const css = generateCss(elements);

  const pageData = {
    id: id,
    title: pageTitle,
    slug: pageSlug,
    type: pageType,
    thumbnail: thumbnail,
    elements: elements,
    seoDescription: seoDescription,
    seoKeywords: seoKeywords,
    robotsIndex: robotsIndex,
    robotsFollow: robotsFollow,
    robotsNoImageIndex: robotsNoImageIndex,
    categoryId: categoryId,
    tags: tags,
    css: css,
  };

  try {
    const savedPage = await savePage(pageData);
    // Revalidate paths to show changes immediately
    revalidatePath('/admin', 'layout');
    revalidatePath(`/${pageSlug}/`);
    revalidatePath(`/${pageSlug}`);
    if (pageSlug === 'home') {
        revalidatePath('/');
    }
    
    return { id: savedPage.id, slug: savedPage.slug };
  } catch (error: any) {
    return { error: error.message };
  }
}

export async function deletePageAction(pageId: string) {
    try {
        await deletePage(pageId);
        revalidatePath('/admin');
        // We'd also need to revalidate the slug path, but we don't have it here.
        // A full revalidation might be an option, but for now, just admin.
        return { success: true };
    } catch (error: any) {
        return { error: error.message };
    }
}


export async function setHomepageAction(pageId: string) {
  try {
    const pages = await getPages();
    const currentHomepage = pages.find(p => p.slug === 'home');
    const newHomepage = pages.find(p => p.id === pageId);

    if (!newHomepage) {
      return { error: 'Pagina nu a fost găsită.' };
    }

    if (newHomepage.slug === 'home') {
      return { success: true, message: 'Aceasta este deja pagina principală.' };
    }
    
    const oldSlugForNewHomepage = newHomepage.slug;

    // 1. Unset current homepage if it exists
    if (currentHomepage) {
      // Restore its old slug if we had one, or create a unique one
      const newSlugForOldHomepage = `home-old-${currentHomepage.id.slice(0, 6)}`;
      currentHomepage.slug = newSlugForOldHomepage;
      await savePage(currentHomepage);
    }
    
    // 2. Set new homepage
    newHomepage.slug = 'home';
    await savePage(newHomepage);
    
    revalidatePath('/admin');
    revalidatePath('/');
    revalidatePath(`/${oldSlugForNewHomepage}`);

    return { success: true };
  } catch (error: any) {
    console.error(error);
    return { error: 'Nu s-a putut seta pagina principală.' };
  }
}

const saveTemplateSchema = z.object({
  name: z.string().min(3, 'Numele șablonului trebuie să aibă cel puțin 3 caractere.'),
  elements: z.array(z.any()),
});

export async function saveTemplateAction(values: z.infer<typeof saveTemplateSchema>) {
  const validatedFields = saveTemplateSchema.safeParse(values);
  if (!validatedFields.success) {
    return { error: 'Nume de șablon invalid.' };
  }

  try {
    await saveTemplate(validatedFields.data);
    return { success: true };
  } catch (error: any) {
    return { error: error.message };
  }
}

export async function getTemplatesAction() {
  try {
    const templates = await getTemplates();
    return { data: templates };
  } catch (error) {
    return { error: 'Nu s-au putut încărca șabloanele.' };
  }
}


const menuItemSchema: z.ZodType<any> = z.lazy(() => z.object({
    pageId: z.string().optional(),
    categoryId: z.string().optional(),
    title: z.string().optional(),
    children: z.array(menuItemSchema).optional(),
    isSubmenu: z.boolean().optional(),
}));

const siteSettingsSchema = z.object({
    language: z.string().optional(),
    siteName: z.string().optional(),
    siteDescription: z.string().optional(),
    ogImage: z.string().optional(),
    twitterImage: z.string().optional(),
    logoUrl: z.string().or(z.literal('')),
    siteTitle: z.string().optional(),
    menu: z.object({
        alignment: z.enum(['left', 'center', 'right']),
        items: z.array(menuItemSchema)
    }),
    headerSettings: z.object({
        backgroundColor: z.string(),
        backdropBlur: z.number().min(0).max(100),
        borderColor: z.string(),
    }),
    footerSettings: z.object({
        backgroundColor: z.string(),
        backdropBlur: z.number().min(0).max(100),
        borderColor: z.string(),
        showCopyright: z.boolean(),
    })
});

export async function getPagesAction() {
    try {
        const pages = await getPages();
        return { data: pages };
    } catch (error) {
        return { error: 'Nu s-au putut încărca paginile.' };
    }
}

export async function getActivePagesAction() {
    try {
        const activeCount = await getActivePages();
        return { data: activeCount };
    } catch (error) {
        return { error: 'Nu s-au putut încărca datele despre paginile active.' };
    }
}

export async function getSiteSettingsAction() {
    try {
        const settings = await getSiteSettings();
        return { data: settings };
    } catch (error) {
        return { error: 'Nu s-au putut încărca setările site-ului.' };
    }
}

export async function saveSiteSettingsAction(values: SiteSettings) {
    const validatedFields = siteSettingsSchema.safeParse(values);
    if (!validatedFields.success) {
        console.error('Menu settings validation failed:', validatedFields.error.flatten().fieldErrors);
        return { error: 'Setări invalide.' };
    }

    try {
        await saveSiteSettings(validatedFields.data);
        revalidatePath('/', 'layout'); // Revalidate all pages that might show the header
        return { success: true };
    } catch (error: any) {
        console.error('Menu settings save error:', error);
        return { error: 'Nu s-au putut salva setările.' };
    }
}
