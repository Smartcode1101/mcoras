/**
 * Utilitare pentru optimizarea performanței site-ului
 * Include funcții pentru minificare HTML, CSS, JS și delayed JavaScript
 */

import fs from 'fs';
import path from 'path';

const settingsPath = path.join(process.cwd(), 'db', 'site-settings.json');

interface PerformanceSettings {
  minifyHtml: boolean;
  minifyCss: boolean;
  minifyJs: boolean;
  delayedJs: boolean;
  delayedJsTimeout: number;
  lazyLoadImages: boolean;
  reduceJsExecution: boolean;
}

interface SiteSettings {
  performanceSettings?: PerformanceSettings;
  [key: string]: unknown;
}

/**
 * Obține setările de performanță din fișierul de configurare
 */
export function getPerformanceSettings(): PerformanceSettings {
  try {
    const data = fs.readFileSync(settingsPath, 'utf-8');
    const settings: SiteSettings = JSON.parse(data);
    
    return {
      minifyHtml: settings.performanceSettings?.minifyHtml ?? true,
      minifyCss: settings.performanceSettings?.minifyCss ?? true,
      minifyJs: settings.performanceSettings?.minifyJs ?? true,
      delayedJs: settings.performanceSettings?.delayedJs ?? true,
      delayedJsTimeout: settings.performanceSettings?.delayedJsTimeout ?? 2000,
      lazyLoadImages: settings.performanceSettings?.lazyLoadImages ?? true,
      reduceJsExecution: settings.performanceSettings?.reduceJsExecution ?? true
    };
  } catch {
    return {
      minifyHtml: true,
      minifyCss: true,
      minifyJs: true,
      delayedJs: true,
      delayedJsTimeout: 2000,
      lazyLoadImages: true,
      reduceJsExecution: true
    };
  }
}

/**
 * Minifică HTML-ul eliminând spațiile inutile, comentariile și newline-urile
 */
export function minifyHtml(html: string): string {
  return html
    // Elimină comentariile HTML
    .replace(/<!--[\s\S]*?-->/g, '')
    // Elimină spațiile multiple
    .replace(/\s+/g, ' ')
    // Elimină spațiile între tag-uri
    .replace(/>\s+</g, '><')
    // Elimină spațiile la începutul și sfârșitul liniilor
    .replace(/^\s+|\s+$/gm, '')
    // Elimină liniile goale
    .replace(/\n\s*\n/g, '\n')
    .trim();
}

/**
 * Minifică CSS-ul eliminând spațiile, comentariile și optimizând valorile
 */
export function minifyCss(css: string): string {
  return css
    // Elimină comentariile CSS
    .replace(/\/\*[\s\S]*?\*\//g, '')
    // Elimină spațiile multiple
    .replace(/\s+/g, ' ')
    // Elimină spațiile în jurul caracterelor speciale
    .replace(/\s*([{}:;,>+~])\s*/g, '$1')
    // Elimină spațiile la începutul și sfârșitul
    .replace(/^\s+|\s+$/gm, '')
    // Elimină ultimul ; din blocuri
    .replace(/;}/g, '}')
    // Elimină unitățile zero
    .replace(/\b0(px|em|rem|%|pt|pc|in|cm|mm|ex|vh|vw|vmin|vmax)\b/g, '0')
    .trim();
}

/**
 * Minifică JavaScript-ul eliminând spațiile, comentariile și optimizând codul
 * Notă: Aceasta este o minificare de bază. Pentru producție, folosiți terser sau uglify-js
 */
export function minifyJs(js: string): string {
  return js
    // Elimină comentariile single-line
    .replace(/\/\/.*$/gm, '')
    // Elimină comentariile multi-line
    .replace(/\/\*[\s\S]*?\*\//g, '')
    // Elimină spațiile multiple
    .replace(/\s+/g, ' ')
    // Elimină spațiile în jurul operatorilor
    .replace(/\s*([{}:;,=+\-*/<>!&|()])\s*/g, '$1')
    // Elimină spațiile la începutul și sfârșitul
    .trim();
}

/**
 * Generează script-ul pentru delayed JavaScript
 */
export function generateDelayedJsScript(scripts: string[], timeout: number): string {
  const scriptsJson = JSON.stringify(scripts);
  
  return `
(function() {
  var scripts = ${scriptsJson};
  var timeout = ${timeout};
  
  function loadScripts() {
    scripts.forEach(function(src) {
      var script = document.createElement('script');
      script.src = src;
      script.async = true;
      document.body.appendChild(script);
    });
  }
  
  if (document.readyState === 'complete') {
    setTimeout(loadScripts, timeout);
  } else {
    window.addEventListener('load', function() {
      setTimeout(loadScripts, timeout);
    });
  }
})();
`.trim();
}

/**
 * Aplică minificarea pe conținut bazat pe tip și setări
 */
export function applyMinification(content: string, type: 'html' | 'css' | 'js'): string {
  const settings = getPerformanceSettings();
  
  switch (type) {
    case 'html':
      return settings.minifyHtml ? minifyHtml(content) : content;
    case 'css':
      return settings.minifyCss ? minifyCss(content) : content;
    case 'js':
      return settings.minifyJs ? minifyJs(content) : content;
    default:
      return content;
  }
}

/**
 * Verifică dacă delayed JS este activat
 */
export function isDelayedJsEnabled(): boolean {
  return getPerformanceSettings().delayedJs;
}

/**
 * Obține timeout-ul pentru delayed JS
 */
export function getDelayedJsTimeout(): number {
  return getPerformanceSettings().delayedJsTimeout;
}

/**
 * Verifică dacă lazy loading pentru imagini este activat
 */
export function isLazyLoadImagesEnabled(): boolean {
  return getPerformanceSettings().lazyLoadImages;
}

/**
 * Verifică dacă reducerea execuției JS este activată
 */
export function isReduceJsExecutionEnabled(): boolean {
  return getPerformanceSettings().reduceJsExecution;
}
