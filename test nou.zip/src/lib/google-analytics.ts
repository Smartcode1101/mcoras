// Google Analytics 4 (GA4) Service
// Acest serviciu gestionează integrarea cu Google Analytics 4

export interface GA4Event {
  action: string;
  category: string;
  label?: string;
  value?: number;
  custom_parameters?: Record<string, any>;
}

export interface GA4PageView {
  page_title: string;
  page_location: string;
  page_path: string;
}

// Extinderea interfeței Window pentru TypeScript
declare global {
  interface Window {
    gtag?: (...args: any[]) => void;
    dataLayer?: any[];
  }
}

class GoogleAnalyticsService {
  private measurementId: string;
  private isInitialized: boolean = false;

  constructor() {
    this.measurementId = process.env.NEXT_PUBLIC_GA4_MEASUREMENT_ID || '';
  }

  /**
   * Inițializează Google Analytics 4
   */
  public init(): void {
    if (typeof window === 'undefined' || !this.measurementId) {
      console.warn('GA4 nu poate fi inițializat: Measurement ID lipsă sau server-side rendering');
      return;
    }

    // Don't initialize GA4 on admin pages
    if (window.location.pathname.startsWith('/admin')) {
      console.log('GA4 nu este inițializat pe paginile admin');
      return;
    }

    if (this.isInitialized) {
      return;
    }

    // Creează dataLayer dacă nu există
    if (!window.dataLayer) {
      window.dataLayer = [];
    }

    // Funcția gtag
    function gtag(...args: any[]) {
      window.dataLayer?.push(arguments);
    }

    window.gtag = gtag;

    // Configurează GA4
    window.gtag('js', new Date());
    window.gtag('config', this.measurementId, {
      page_title: document.title,
      page_location: window.location.href,
      send_page_view: true,
      // Configurări suplimentare pentru GA4
      anonymize_ip: true,
      allow_google_signals: true,
      allow_ad_personalization_signals: true,
    });

    this.isInitialized = true;
    console.log('Google Analytics 4 inițializat cu succes:', this.measurementId);
  }

  /**
   * Urmărește un page view
   */
  public trackPageView(pageData: GA4PageView): void {
    if (!this.isInitialized || !window.gtag) {
      console.warn('GA4 nu este inițializat pentru trackPageView');
      return;
    }

    window.gtag('event', 'page_view', {
      page_title: pageData.page_title,
      page_location: pageData.page_location,
      page_path: pageData.page_path,
    });

    console.log('Page view tracking:', pageData);
  }

  /**
   * Urmărește un eveniment custom
   */
  public trackEvent(event: GA4Event): void {
    if (!this.isInitialized || !window.gtag) {
      console.warn('GA4 nu este inițializat pentru trackEvent');
      return;
    }

    const eventData: Record<string, any> = {
      event_category: event.category,
      event_action: event.action,
    };

    if (event.label) {
      eventData.event_label = event.label;
    }

    if (event.value !== undefined) {
      eventData.value = event.value;
    }

    if (event.custom_parameters) {
      Object.assign(eventData, event.custom_parameters);
    }

    window.gtag('event', event.action, eventData);
    console.log('Event tracking:', event);
  }

  /**
   * Urmărește click-uri pe butoane/link-uri
   */
  public trackButtonClick(buttonName: string, buttonLocation: string): void {
    this.trackEvent({
      action: 'click',
      category: 'engagement',
      label: `${buttonName} - ${buttonLocation}`,
      custom_parameters: {
        button_name: buttonName,
        button_location: buttonLocation,
        timestamp: new Date().toISOString(),
      },
    });
  }

  /**
   * Urmărește descărcări de fișiere
   */
  public trackFileDownload(fileName: string, fileType: string): void {
    this.trackEvent({
      action: 'file_download',
      category: 'engagement',
      label: `${fileName}.${fileType}`,
      custom_parameters: {
        file_name: fileName,
        file_type: fileType,
        timestamp: new Date().toISOString(),
      },
    });
  }

  /**
   * Urmărește timpul petrecut pe pagină
   */
  public trackPageEngagement(timeOnPage: number): void {
    if (timeOnPage > 0) {
      this.trackEvent({
        action: 'user_engagement',
        category: 'engagement',
        value: timeOnPage,
        custom_parameters: {
          engagement_time_msec: timeOnPage * 1000,
          timestamp: new Date().toISOString(),
        },
      });
    }
  }

  /**
   * Urmărește evenimente de căutare
   */
  public trackSearch(searchTerm: string, resultsCount: number): void {
    this.trackEvent({
      action: 'search',
      category: 'engagement',
      label: searchTerm,
      custom_parameters: {
        search_term: searchTerm,
        results_count: resultsCount,
        timestamp: new Date().toISOString(),
      },
    });
  }

  /**
   * Urmărește contactarea formularului
   */
  public trackFormSubmission(formName: string, success: boolean): void {
    this.trackEvent({
      action: success ? 'form_submit_success' : 'form_submit_error',
      category: 'lead_generation',
      label: formName,
      custom_parameters: {
        form_name: formName,
        success: success,
        timestamp: new Date().toISOString(),
      },
    });
  }

  /**
   * Urmărește erori JavaScript
   */
  public trackJavaScriptError(errorMessage: string, errorUrl: string): void {
    this.trackEvent({
      action: 'exception',
      category: 'error',
      label: errorMessage,
      custom_parameters: {
        error_message: errorMessage,
        error_url: errorUrl,
        timestamp: new Date().toISOString(),
      },
    });
  }

  /**
   * Urmărește scroll-ul pe pagină
   */
  public trackScroll(percentScrolled: number): void {
    if (percentScrolled >= 25 && percentScrolled <= 100) {
      this.trackEvent({
        action: 'scroll',
        category: 'engagement',
        value: percentScrolled,
        custom_parameters: {
          percent_scrolled: percentScrolled,
          timestamp: new Date().toISOString(),
        },
      });
    }
  }

  /**
   * Verifică dacă GA4 este activ
   */
  public isActive(): boolean {
    return this.isInitialized && !!this.measurementId;
  }

  /**
   * Returnează Measurement ID-ul
   */
  public getMeasurementId(): string {
    return this.measurementId;
  }
}

// Singleton instance
export const ga4 = new GoogleAnalyticsService();

// Hook React pentru GA4
export function useGA4() {
  const trackPageView = (pageData: GA4PageView) => {
    ga4.trackPageView(pageData);
  };

  const trackEvent = (event: GA4Event) => {
    ga4.trackEvent(event);
  };

  const trackButtonClick = (buttonName: string, buttonLocation: string) => {
    ga4.trackButtonClick(buttonName, buttonLocation);
  };

  const trackFileDownload = (fileName: string, fileType: string) => {
    ga4.trackFileDownload(fileName, fileType);
  };

  const trackSearch = (searchTerm: string, resultsCount: number) => {
    ga4.trackSearch(searchTerm, resultsCount);
  };

  const trackFormSubmission = (formName: string, success: boolean) => {
    ga4.trackFormSubmission(formName, success);
  };

  const trackScroll = (percentScrolled: number) => {
    ga4.trackScroll(percentScrolled);
  };

  return {
    trackPageView,
    trackEvent,
    trackButtonClick,
    trackFileDownload,
    trackSearch,
    trackFormSubmission,
    trackScroll,
    isActive: ga4.isActive(),
    measurementId: ga4.getMeasurementId(),
  };
}

export default ga4;