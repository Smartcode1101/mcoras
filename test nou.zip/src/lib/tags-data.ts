import fs from 'fs';
import path from 'path';
import type { Tag } from './types';

const tagsPath = path.join(process.cwd(), 'db', 'tags.json');

// Funcție pentru a citi tag-urile
export const getTags = async (): Promise<Tag[]> => {
  try {
    const data = await fs.promises.readFile(tagsPath, 'utf-8');
    return JSON.parse(data);
  } catch {
    return [];
  }
};

// Funcție pentru a obține un tag după ID
export const getTagById = async (id: string): Promise<Tag | null> => {
  const tags = await getTags();
  return tags.find(tag => tag.id === id) || null;
};

// Funcție pentru a obține un tag după slug
export const getTagBySlug = async (slug: string): Promise<Tag | null> => {
  const tags = await getTags();
  return tags.find(tag => tag.slug === slug) || null;
};
