import fs from 'fs/promises';
import path from 'path';
import type { SiteSettings } from './types';

const dbPath = path.join(process.cwd(), 'db', 'site-settings.json');

const defaultSettings: SiteSettings = {
    logoUrl: '',
    siteTitle: 'PageForge',
    menu: {
        alignment: 'center',
        items: []
    },
    headerSettings: {
        backgroundColor: 'rgba(0, 0, 0, 0.3)',
        backdropBlur: 12,
        borderColor: 'rgba(255, 255, 255, 0.2)',
    },
    footerSettings: {
        backgroundColor: 'rgba(0, 0, 0, 0.3)',
        backdropBlur: 12,
        borderColor: 'rgba(255, 255, 255, 0.2)',
        showCopyright: true,
    }
}

async function readDb(): Promise<SiteSettings> {
  try {
    await fs.mkdir(path.dirname(dbPath), { recursive: true });
    const data = await fs.readFile(dbPath, 'utf-8');
    const parsedData = JSON.parse(data);
    // Merge with defaults to ensure new settings are present
    return {
        ...defaultSettings,
        ...parsedData,
        menu: {
            ...defaultSettings.menu,
            ...(parsedData.menu || {})
        },
        headerSettings: {
            ...defaultSettings.headerSettings,
            ...(parsedData.headerSettings || {})
        },
        footerSettings: {
            ...defaultSettings.footerSettings,
            ...(parsedData.footerSettings || {})
        }
    };
  } catch (error) {
    // If the file doesn't exist or is invalid, return default settings
    return defaultSettings;
  }
}

async function writeDb(data: SiteSettings): Promise<void> {
  await fs.writeFile(dbPath, JSON.stringify(data, null, 2), 'utf-8');
}

export async function getSiteSettings(): Promise<SiteSettings> {
  return await readDb();
}

export async function saveSiteSettings(settings: SiteSettings): Promise<void> {
  await writeDb(settings);
}
