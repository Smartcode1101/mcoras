import nodemailer from 'nodemailer';
import { User } from './user-data';

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST || 'smtp.gmail.com',
  port: parseInt(process.env.SMTP_PORT || '587'),
  secure: false, // true for 465, false for other ports
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
});

export async function sendWelcomeEmail(user: User) {
  const mailOptions = {
    from: process.env.SMTP_FROM || 'noreply@pageforge.com',
    to: user.email,
    subject: 'Bun venit în administrarea site-ului PageForge!',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h1 style="color: #333; text-align: center;">Bun venit, ${user.username}!</h1>
        <p style="font-size: 16px; line-height: 1.6; color: #666;">
          Contul tău a fost creat cu succes în sistemul de administrare PageForge.
        </p>
        <div style="background-color: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin-top: 0; color: #333;">Detaliile contului tău:</h3>
          <p><strong>Email:</strong> ${user.email}</p>
          <p><strong>Username:</strong> ${user.username}</p>
          <p><strong>Parola:</strong> ${user.password ? '********' : 'Setată la înregistrare'}</p>
          <p><strong>Data înregistrării:</strong> ${new Date(user.createdAt).toLocaleDateString('ro-RO')}</p>
        </div>
        <p style="font-size: 16px; line-height: 1.6; color: #666;">
          Poți accesa panoul de administrare la adresa: <a href="${process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'}/admin" style="color: #007bff;">${process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'}/admin</a>
        </p>
        <p style="font-size: 14px; color: #999; text-align: center; margin-top: 40px;">
          Acest email a fost trimis automat. Te rugăm să nu răspunzi la acest mesaj.
        </p>
      </div>
    `,
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log('Welcome email sent to:', user.email);
  } catch (error) {
    console.error('Error sending welcome email:', error);
    // Don't throw error to prevent registration failure
  }
}