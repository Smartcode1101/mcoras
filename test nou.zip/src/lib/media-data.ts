import fs from 'fs/promises';
import path from 'path';
import { generateId } from '@/lib/utils';

export interface MediaItem {
  id: string;
  src: string;
  alt: string;
  filename: string;
  createdAt: string;
}

const dbPath = path.join(process.cwd(), 'db', 'media.json');

async function readDb(): Promise<MediaItem[]> {
  try {
    await fs.mkdir(path.dirname(dbPath), { recursive: true });
    const data = await fs.readFile(dbPath, 'utf-8');
    const parsedData = JSON.parse(data);
    return Array.isArray(parsedData) ? parsedData : [];
  } catch (error) {
    // If the file doesn't exist or is invalid, return empty array
    return [];
  }
}

async function writeDb(data: MediaItem[]): Promise<void> {
  await fs.writeFile(dbPath, JSON.stringify(data, null, 2), 'utf-8');
}

export async function getMediaItems(): Promise<MediaItem[]> {
  return await readDb();
}

export async function saveMediaItem(item: MediaItem): Promise<void> {
  const items = await readDb();
  const existingIndex = items.findIndex(i => i.id === item.id);
  
  if (existingIndex >= 0) {
    items[existingIndex] = item;
  } else {
    items.push(item);
  }
  
  await writeDb(items);
}

export async function deleteMediaItem(id: string): Promise<boolean> {
  const items = await readDb();
  const itemIndex = items.findIndex(item => item.id === id);
  
  if (itemIndex === -1) {
    return false; // Item not found
  }
  
  // Get the media item before removing it
  const mediaItem = items[itemIndex];
  
  // Remove the item from the database
  items.splice(itemIndex, 1);
  await writeDb(items);
  
  // Also delete the physical file
  try {
    const filePath = path.join(process.cwd(), 'public', mediaItem.src);
    await fs.unlink(filePath);
  } catch (error) {
    console.warn('Could not delete physical file:', error);
    // Continue even if file deletion fails
  }
  
  return true;
}