import fs from 'fs/promises';
import path from 'path';

export interface VisitedPage {
  slug: string;
  url: string;
  timestamp: string;
  userAgent: string;
  ip: string;
  referrer?: string;
  sessionId: string;
  userId?: string;
  environment: 'local' | 'domain';
}

const dbPath = path.join(process.cwd(), 'db', 'visited-pages.json');

async function readDb(): Promise<VisitedPage[]> {
  try {
    await fs.mkdir(path.dirname(dbPath), { recursive: true });
    const data = await fs.readFile(dbPath, 'utf-8');
    return JSON.parse(data) as VisitedPage[];
  } catch (error) {
    // If the file doesn't exist, return an empty array
    return [];
  }
}

async function writeDb(data: VisitedPage[]): Promise<void> {
  await fs.writeFile(dbPath, JSON.stringify(data, null, 2), 'utf-8');
}

export async function trackVisitedPage(pageData: {
  slug: string;
  url: string;
  userAgent: string;
  ip: string;
  referrer?: string;
  userId?: string;
}): Promise<void> {
  try {
    const data = await readDb();
    const now = new Date().toISOString();
    const sessionId = generateSessionId();

    // Determine environment
    const isLocal = pageData.url.includes('localhost') || pageData.url.includes('127.0.0.1') || pageData.url.includes('::1');
    const environment: 'local' | 'domain' = isLocal ? 'local' : 'domain';

    const visitedPage: VisitedPage = {
      slug: pageData.slug,
      url: pageData.url,
      timestamp: now,
      userAgent: pageData.userAgent,
      ip: pageData.ip,
      referrer: pageData.referrer,
      sessionId,
      userId: pageData.userId,
      environment,
    };

    data.push(visitedPage);

    // Keep only last 30 days of data
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    const filteredData = data.filter(vp => new Date(vp.timestamp) > thirtyDaysAgo);

    await writeDb(filteredData);
  } catch (error) {
    console.error('Error tracking visited page:', error);
  }
}

export async function getVisitedPages(): Promise<VisitedPage[]> {
  return await readDb();
}

export async function getVisitedPagesBySlug(slug: string): Promise<VisitedPage[]> {
  const data = await readDb();
  return data.filter(vp => vp.slug === slug);
}

export async function getVisitedPagesStats(): Promise<{
  totalVisits: number;
  uniqueSlugs: number;
  localVisits: number;
  domainVisits: number;
  recentVisits: VisitedPage[];
}> {
  const data = await readDb();

  const totalVisits = data.length;
  const uniqueSlugs = new Set(data.map(vp => vp.slug)).size;
  const localVisits = data.filter(vp => vp.environment === 'local').length;
  const domainVisits = data.filter(vp => vp.environment === 'domain').length;

  // Last 24 hours
  const twentyFourHoursAgo = new Date();
  twentyFourHoursAgo.setHours(twentyFourHoursAgo.getHours() - 24);
  const recentVisits = data.filter(vp => new Date(vp.timestamp) > twentyFourHoursAgo);

  return {
    totalVisits,
    uniqueSlugs,
    localVisits,
    domainVisits,
    recentVisits,
  };
}

function generateSessionId(): string {
  return `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}