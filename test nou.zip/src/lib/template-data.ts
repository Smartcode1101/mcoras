import fs from 'fs/promises';
import path from 'path';
import type { PageTemplate, Widget } from './types';
import { generateId } from '@/lib/utils';

const dbPath = path.join(process.cwd(), 'db', 'templates.json');

async function readDb(): Promise<PageTemplate[]> {
  try {
    await fs.mkdir(path.dirname(dbPath), { recursive: true });
    const data = await fs.readFile(dbPath, 'utf-8');
    return JSON.parse(data) as PageTemplate[];
  } catch (error) {
    // If the file doesn't exist, return an empty array
    return [];
  }
}

async function writeDb(data: PageTemplate[]): Promise<void> {
  await fs.writeFile(dbPath, JSON.stringify(data, null, 2), 'utf-8');
}

export async function getTemplates(): Promise<PageTemplate[]> {
  return await readDb();
}

export async function saveTemplate(templateData: { name: string, elements: Widget[] }): Promise<PageTemplate> {
  const templates = await readDb();
  
  const existingTemplate = templates.find(t => t.name.toLowerCase() === templateData.name.toLowerCase());
  if (existingTemplate) {
    throw new Error('Un șablon cu acest nume există deja.');
  }

  const newTemplate: PageTemplate = {
    id: generateId(),
    name: templateData.name,
    elements: templateData.elements,
  };
  
  templates.push(newTemplate);
  await writeDb(templates);
  return newTemplate;
}
