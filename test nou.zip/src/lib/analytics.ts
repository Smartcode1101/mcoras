export interface PageView {
  id: string;
  page: string;
  timestamp: string;
  userAgent: string;
  ip: string;
  referrer?: string;
  sessionId: string;
  userId?: string;
  sessionType: 'new' | 'returning';
  // Live Traffic fields
  trafficType?: 'direct' | 'organic' | 'referral' | 'crawler';
  country?: string;
  countryCode?: string;
  city?: string;
  crawlerName?: string;
  isCrawler?: boolean;
}

export interface LiveTrafficEntry {
  id: string;
  page: string;
  timestamp: string;
  ip: string;
  userAgent: string;
  trafficType: 'direct' | 'organic' | 'referral' | 'crawler';
  country: string;
  countryCode: string;
  city: string;
  crawlerName?: string;
  referrer: string;
  isCrawler: boolean;
}

export interface Session {
  id: string;
  startTime: string;
  endTime?: string;
  pageViews: number;
  duration: number;
  ip: string;
  userAgent: string;
  country?: string;
  city?: string;
}

export interface AnalyticsData {
  totalViews: number;
  uniqueVisitors: number;
  pageViews: PageView[];
  hourlyStats: { hour: string; views: number }[];
  topPages: { page: string; views: number }[];
  trafficStats?: { type: string; count: number; percentage: number }[];
  countryStats?: { country: string; countryCode: string; count: number }[];
}

const analyticsFilePath = 'db/analytics.json';
const fs = require('fs');
const path = require('path');

// Helper functions for analytics
function getAnalyticsFilePath(): string {
  // Check if we're in Node.js environment vs Edge Runtime
  const isNodeJS = typeof process !== 'undefined' && 
                   typeof process.versions !== 'undefined' && 
                   process.versions.node;
  
  if (isNodeJS) {
    return path.join(process.cwd(), analyticsFilePath);
  }
  
  // For Edge Runtime or other environments
  // Use a relative path that should work in most contexts
  return analyticsFilePath;
}

function readAnalyticsData(): any {
  try {
    const filePath = getAnalyticsFilePath();
    console.log('Reading analytics data from:', filePath);

    const data = fs.readFileSync(filePath, 'utf8');
    const parsed = JSON.parse(data);
    console.log('Read analytics data:', { pageViewsCount: parsed.pageViews?.length || 0 });
    return parsed;
  } catch (error) {
    console.log('Analytics file not found or invalid, returning default structure');
    // Return default structure if file doesn't exist
    return {
      pageViews: [],
      sessions: [],
      realtime: {
        activeUsers: 0,
        pageViews: 0,
        topPages: []
      },
      dailyStats: {},
      referrers: {}
    };
  }
}

function writeAnalyticsData(data: any): void {
  try {
    const filePath = getAnalyticsFilePath();
    console.log('Writing analytics data to:', filePath);
    console.log('Data to write:', JSON.stringify(data, null, 2).substring(0, 500) + '...');

    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
    console.log('Analytics data written successfully to file');

    // Verify the file was written
    const verifyData = readAnalyticsData();
    console.log('Verification: file contains', verifyData.pageViews?.length || 0, 'page views');
  } catch (error) {
    console.error('Error writing analytics data:', error);
  }
}

export function trackPageView(pageData: {
  page: string;
  userAgent: string;
  ip: string;
  referrer?: string;
  userId?: string;
}): void {
  try {
    console.log('trackPageView called with:', pageData);
    const data = readAnalyticsData();
    console.log('Current analytics data:', { pageViewsCount: data.pageViews?.length || 0 });

    const now = new Date().toISOString();
    const sessionId = generateSessionId();

    // Detect traffic type
    const trafficType = detectTrafficType(pageData.referrer || '', pageData.userAgent);
    
    // Detect crawler
    const crawlerCheck = isCrawler(pageData.userAgent);
    
    // Check if this is a new or returning session based on IP
    // Only count sessions from the last 24 hours to determine returning users
    const twentyFourHoursAgo = new Date();
    twentyFourHoursAgo.setHours(twentyFourHoursAgo.getHours() - 24);

    const recentSessions = data.pageViews?.filter((pv: any) =>
      pv.ip === pageData.ip && new Date(pv.timestamp) > twentyFourHoursAgo
    ) || [];
    const isReturningSession = recentSessions.length > 0;
    const sessionType: 'new' | 'returning' = isReturningSession ? 'returning' : 'new';

    // Create page view with all traffic info
    const pageView: PageView = {
      id: generateId(),
      page: pageData.page,
      timestamp: now,
      userAgent: pageData.userAgent,
      ip: pageData.ip,
      referrer: pageData.referrer,
      sessionId,
      userId: pageData.userId,
      sessionType,
      // Live Traffic fields
      trafficType,
      country: 'Unknown', // Will be updated asynchronously
      countryCode: 'XX',
      city: 'Unknown',
      crawlerName: crawlerCheck.crawlerName,
      isCrawler: crawlerCheck.isCrawler,
    };

    console.log('Created page view:', pageView);

    // Add to pageViews
    if (!data.pageViews) data.pageViews = [];
    data.pageViews.push(pageView);
    console.log('Added to pageViews, new count:', data.pageViews.length);

    // Update realtime stats
    if (!data.realtime) data.realtime = { activeUsers: 0, pageViews: 0, topPages: [] };
    data.realtime.pageViews += 1;
    console.log('Updated realtime pageViews to:', data.realtime.pageViews);

    // Update top pages
    updateTopPages(data, pageData.page);


    // Clean old data (keep last 30 days)
    cleanOldData(data);

    writeAnalyticsData(data);
    console.log('Analytics data written successfully');
  } catch (error) {
    console.error('Error tracking page view:', error);
  }
}

export function resetAnalyticsData(): void {
  try {
    const defaultData = {
      pageViews: [],
      sessions: [],
      realtime: {
        activeUsers: 0,
        pageViews: 0,
        topPages: []
      },
      dailyStats: {},
      referrers: {}
    };

    writeAnalyticsData(defaultData);
    console.log('Analytics data reset successfully');
  } catch (error) {
    console.error('Error resetting analytics data:', error);
  }
}

function updateTopPages(data: any, page: string): void {
  const existingPage = data.realtime.topPages.find((p: any) => p.page === page);
  if (existingPage) {
    existingPage.views += 1;
  } else {
    data.realtime.topPages.push({ page, views: 1 });
  }

  // Sort and keep top 10
  data.realtime.topPages.sort((a: any, b: any) => b.views - a.views);
  data.realtime.topPages = data.realtime.topPages.slice(0, 10);
}


function cleanOldData(data: any): void {
  const thirtyDaysAgo = new Date();
  thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

  data.pageViews = data.pageViews.filter((pv: PageView) =>
    new Date(pv.timestamp) > thirtyDaysAgo
  );
}

function generateId(): string {
  return Math.random().toString(36).substr(2, 9);
}

function generateSessionId(): string {
  return `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

export function getAnalyticsData(): AnalyticsData {
  try {
    const data = readAnalyticsData();

    // Calculate stats from real data
    const pageViews = data.pageViews || [];
    const totalViews = pageViews.length;
    const uniqueVisitors = new Set(pageViews.map((pv: PageView) => pv.sessionId)).size;

    // Calculate hourly stats for last 24 hours
    const hourlyStats = calculateHourlyStats(pageViews);

    // Get top pages
    const topPages = calculateTopPages(pageViews);

    return {
      totalViews,
      uniqueVisitors,
      pageViews,
      hourlyStats,
      topPages,
    };
  } catch (error) {
    console.error('Error reading analytics data:', error);
    return getFallbackAnalyticsData();
  }
}

function calculateHourlyStats(pageViews: PageView[]): { hour: string; views: number }[] {
  const hourlyStats: { [hour: string]: number } = {};

  // Initialize last 24 hours
  for (let i = 23; i >= 0; i--) {
    const date = new Date();
    date.setHours(date.getHours() - i);
    const hourKey = date.getHours().toString().padStart(2, '0') + ':00';
    hourlyStats[hourKey] = 0;
  }

  // Count views per hour
  pageViews.forEach((pv) => {
    const date = new Date(pv.timestamp);
    const hourKey = date.getHours().toString().padStart(2, '0') + ':00';
    if (hourlyStats.hasOwnProperty(hourKey)) {
      hourlyStats[hourKey]++;
    }
  });

  return Object.entries(hourlyStats).map(([hour, views]) => ({ hour, views }));
}

function calculateTopPages(pageViews: PageView[]): { page: string; views: number }[] {
  const pageStats: { [page: string]: number } = {};

  pageViews.forEach((pv) => {
    pageStats[pv.page] = (pageStats[pv.page] || 0) + 1;
  });

  return Object.entries(pageStats)
    .map(([page, views]) => ({ page, views }))
    .sort((a, b) => b.views - a.views)
    .slice(0, 10);
}

function getFallbackAnalyticsData(): AnalyticsData {
  return {
    totalViews: 0,
    uniqueVisitors: 0,
    pageViews: [],
    hourlyStats: Array.from({ length: 24 }, (_, i) => ({
      hour: i.toString().padStart(2, '0') + ':00',
      views: 0
    })),
    topPages: [],
  };
}


export function getLast24HoursViews(): { timestamp: string; views: number }[] {
  try {
    const analyticsData = readAnalyticsData();
    const pageViews = analyticsData.pageViews || [];

    // Get page views from the last 24 hours
    const twentyFourHoursAgo = new Date();
    twentyFourHoursAgo.setHours(twentyFourHoursAgo.getHours() - 24);

    const recentViews = pageViews.filter((pv: PageView) =>
      new Date(pv.timestamp) > twentyFourHoursAgo
    );

    // Group by hour for the last 24 hours
    const data: { timestamp: string; views: number }[] = [];
    const now = new Date();

    for (let i = 23; i >= 0; i--) {
      const hourTime = new Date(now.getTime() - i * 60 * 60 * 1000);
      const hourStart = new Date(hourTime);
      hourStart.setMinutes(0, 0, 0);

      const hourEnd = new Date(hourStart);
      hourEnd.setHours(hourEnd.getHours() + 1);

      // Count views in this hour
      const viewsInHour = recentViews.filter((pv: PageView) => {
        const pvTime = new Date(pv.timestamp);
        return pvTime >= hourStart && pvTime < hourEnd;
      }).length;

      data.push({
        timestamp: hourStart.toISOString(),
        views: viewsInHour
      });
    }

    return data;
  } catch (error) {
    console.error('Error getting last 24 hours views:', error);
    // Return empty data if error
    const now = new Date();
    const data: { timestamp: string; views: number }[] = [];

    for (let i = 23; i >= 0; i--) {
      const hour = new Date(now.getTime() - i * 60 * 60 * 1000);
      data.push({ timestamp: hour.toISOString(), views: 0 });
    }

    return data;
  }
}

export function getRealtimeViews(): { timestamp: string; views: number }[] {
  try {
    const analyticsData = readAnalyticsData();
    const pageViews = analyticsData.pageViews || [];

    // Get page views from the last 60 seconds
    const sixtySecondsAgo = new Date();
    sixtySecondsAgo.setSeconds(sixtySecondsAgo.getSeconds() - 60);

    const recentViews = pageViews.filter((pv: PageView) =>
      new Date(pv.timestamp) > sixtySecondsAgo
    );

    // Group by second for the last 60 seconds
    const data: { timestamp: string; views: number }[] = [];
    const now = new Date();

    for (let i = 59; i >= 0; i--) {
      const secondTime = new Date(now.getTime() - i * 1000);
      const secondStart = new Date(secondTime);
      secondStart.setMilliseconds(0);

      const secondEnd = new Date(secondStart);
      secondEnd.setSeconds(secondEnd.getSeconds() + 1);

      // Count views in this second
      const viewsInSecond = recentViews.filter((pv: PageView) => {
        const pvTime = new Date(pv.timestamp);
        return pvTime >= secondStart && pvTime < secondEnd;
      }).length;

      data.push({
        timestamp: secondTime.toISOString(),
        views: viewsInSecond
      });
    }

    return data;
  } catch (error) {
    console.error('Error getting realtime views:', error);
    // Return empty data if error
    const now = new Date();
    const data: { timestamp: string; views: number }[] = [];

    for (let i = 59; i >= 0; i--) {
      const second = new Date(now.getTime() - i * 1000);
      data.push({ timestamp: second.toISOString(), views: 0 });
    }

    return data;
  }
}

// ============== Wordfence Live Traffic Functions ==============

// Common crawler/bot user agents
const CRAWLER_USER_AGENTS = [
  'googlebot', 'bingbot', 'slurp', 'duckduckbot', 'baiduspider',
  'yandex', 'sogou', 'exabot', 'facebookexternalhit', 'twitterbot',
  'rogerbot', 'linkedinbot', 'embedly', 'quora link preview', 'showyoubot',
  'outbrain', 'pinterest', 'applebot', 'semrush', 'ahrefs', 'mj12bot',
  'dotbot', 'google-inspectiontool', 'pagespeed', 'chromeframe', 'lighthouse',
  'gtmetrix', 'pingdom', 'sitebulb', 'screaming frog', 'deepcrawl',
  'censysinspector', 'trivy', 'nmap', 'wpscan', 'python-requests',
  'curl', 'wget', 'go-http', 'httpclient', 'java/', 'libwww-perl',
  'scrapy', 'mechanize', 'selenium', 'phantomjs', 'headlesschrome',
  'bot', 'crawler', 'spider', 'checker', 'monitor', 'extractor'
];

// Detect if user agent is a crawler/bot
export function isCrawler(userAgent: string): { isCrawler: boolean; crawlerName?: string } {
  if (!userAgent) return { isCrawler: false };
  
  const lowerUA = userAgent.toLowerCase();
  
  for (const crawler of CRAWLER_USER_AGENTS) {
    if (lowerUA.includes(crawler)) {
      return { isCrawler: true, crawlerName: crawler };
    }
  }
  
  // Additional check: user agents that are just typical browser user agents
  // but don't contain common browser names are likely bots
  const isBrowser = lowerUA.includes('mozilla') && 
                   (lowerUA.includes('chrome') || lowerUA.includes('safari') || lowerUA.includes('firefox') || lowerUA.includes('edg'));
  
  if (!isBrowser && lowerUA.length < 50) {
    return { isCrawler: true, crawlerName: 'unknown' };
  }
  
  return { isCrawler: false };
}

// Detect traffic type based on referrer and other factors
export function detectTrafficType(referrer: string, userAgent: string): 'direct' | 'organic' | 'referral' | 'crawler' {
  // Check if it's a crawler first
  const crawlerCheck = isCrawler(userAgent);
  if (crawlerCheck.isCrawler) {
    return 'crawler';
  }
  
  if (!referrer || referrer === '') {
    return 'direct';
  }
  
  const lowerReferrer = referrer.toLowerCase();
  
  // Google and other search engines
  const searchEngines = [
    'google', 'bing', 'yahoo', 'yandex', 'duckduckgo', 'baidu',
    'ask.com', 'search.naver', 'search.brave', 'startpage', 'qwant'
  ];
  
  for (const engine of searchEngines) {
    if (lowerReferrer.includes(engine)) {
      return 'organic';
    }
  }
  
  // Check if it's from the same domain (internal referral)
  if (lowerReferrer.includes('localhost') || lowerReferrer.includes('onesmart.ro') || lowerReferrer.includes(process.env.NEXT_PUBLIC_SITE_URL || '')) {
    return 'referral';
  }
  
  // External referral
  return 'referral';
}

// Get country from IP using ipapi.co (free tier)
export async function getCountryFromIP(ip: string): Promise<{ country: string; countryCode: string; city: string }> {
  // Skip local IPs
  if (ip === '::1' || ip === '127.0.0.1' || ip.startsWith('192.168.') || ip.startsWith('10.') || ip.startsWith('172.')) {
    return { country: 'Local', countryCode: 'XX', city: 'Local' };
  }
  
  try {
    // Use ipapi.co for geolocation (free tier: 1000 requests/day)
    const response = await fetch(`https://ipapi.co/${ip}/json/`);
    
    if (response.ok) {
      const data = await response.json();
      return {
        country: data.country_name || 'Unknown',
        countryCode: data.country_code || 'XX',
        city: data.city || 'Unknown'
      };
    }
  } catch (error) {
    console.error('Error getting country from IP:', error);
  }
  
  return { country: 'Unknown', countryCode: 'XX', city: 'Unknown' };
}

// Synchronous version with cached data for server-side use
export function getCountryFromIPSync(ip: string): { country: string; countryCode: string; city: string } {
  // Skip local IPs
  if (ip === '::1' || ip === '127.0.0.1' || ip.startsWith('192.168.') || ip.startsWith('10.') || ip.startsWith('172.')) {
    return { country: 'Local', countryCode: 'XX', city: 'Local' };
  }
  
  return { country: 'Unknown', countryCode: 'XX', city: 'Unknown' };
}

// Get live traffic data (last 100 entries)
export function getLiveTrafficData(): LiveTrafficEntry[] {
  try {
    const data = readAnalyticsData();
    const pageViews = data.pageViews || [];
    
    // Sort by timestamp descending and take last 100
    const recentViews = pageViews
      .sort((a: PageView, b: PageView) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
      .slice(0, 100);
    
    return recentViews.map((pv: PageView) => ({
      id: pv.id,
      page: pv.page,
      timestamp: pv.timestamp,
      ip: pv.ip,
      userAgent: pv.userAgent || '',
      trafficType: pv.trafficType || detectTrafficType(pv.referrer || '', pv.userAgent || ''),
      country: pv.country || 'Unknown',
      countryCode: pv.countryCode || 'XX',
      city: pv.city || 'Unknown',
      crawlerName: pv.crawlerName,
      referrer: pv.referrer || '',
      isCrawler: pv.isCrawler || false
    }));
  } catch (error) {
    console.error('Error getting live traffic data:', error);
    return [];
  }
}

// Get traffic type statistics
export function getTrafficTypeStats(): { type: string; count: number; percentage: number }[] {
  try {
    const data = readAnalyticsData();
    const pageViews = data.pageViews || [];
    
    const stats: { [key: string]: number } = {
      direct: 0,
      organic: 0,
      referral: 0,
      crawler: 0
    };
    
    pageViews.forEach((pv: PageView) => {
      const trafficType = pv.trafficType || detectTrafficType(pv.referrer || '', pv.userAgent || '');
      stats[trafficType]++;
    });
    
    const total = pageViews.length || 1;
    
    return [
      { type: 'Direct', count: stats.direct, percentage: Math.round((stats.direct / total) * 100) },
      { type: 'Organic (Google)', count: stats.organic, percentage: Math.round((stats.organic / total) * 100) },
      { type: 'Referral', count: stats.referral, percentage: Math.round((stats.referral / total) * 100) },
      { type: 'Crawlers/Bots', count: stats.crawler, percentage: Math.round((stats.crawler / total) * 100) }
    ];
  } catch (error) {
    console.error('Error getting traffic type stats:', error);
    return [
      { type: 'Direct', count: 0, percentage: 0 },
      { type: 'Organic (Google)', count: 0, percentage: 0 },
      { type: 'Referral', count: 0, percentage: 0 },
      { type: 'Crawlers/Bots', count: 0, percentage: 0 }
    ];
  }
}

// Get country statistics
export function getCountryStats(): { country: string; countryCode: string; count: number }[] {
  try {
    const data = readAnalyticsData();
    const pageViews = data.pageViews || [];
    
    const countryStats: { [key: string]: number } = {};
    
    pageViews.forEach((pv: PageView) => {
      const country = pv.country || 'Unknown';
      countryStats[country] = (countryStats[country] || 0) + 1;
    });
    
    return Object.entries(countryStats)
      .map(([country, count]) => ({ country, countryCode: 'XX', count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 20);
  } catch (error) {
    console.error('Error getting country stats:', error);
    return [];
  }
}

// Update country info for page views that don't have it yet
// This should be called periodically to enrich existing data
export async function updateCountryInfo(): Promise<void> {
  try {
    const data = readAnalyticsData();
    const pageViews = data.pageViews || [];
    let updated = false;
    
    for (const pv of pageViews) {
      if (!pv.country || pv.country === 'Unknown') {
        const geoInfo = await getCountryFromIP(pv.ip);
        pv.country = geoInfo.country;
        pv.countryCode = geoInfo.countryCode;
        pv.city = geoInfo.city;
        updated = true;
      }
    }
    
    if (updated) {
      writeAnalyticsData(data);
      console.log('Updated country info for page views');
    }
  } catch (error) {
    console.error('Error updating country info:', error);
  }
}