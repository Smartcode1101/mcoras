import fs from 'fs/promises';
import path from 'path';
import type { PageData } from './types';
import { generateId } from '@/lib/utils';

const dbPath = path.join(process.cwd(), 'db', 'pages.json');

async function readDb(): Promise<PageData[]> {
  try {
    await fs.mkdir(path.dirname(dbPath), { recursive: true });
    const data = await fs.readFile(dbPath, 'utf-8');
    return JSON.parse(data) as PageData[];
  } catch (error) {
    // If the file doesn't exist, return an empty array
    return [];
  }
}

async function writeDb(data: PageData[]): Promise<void> {
  await fs.writeFile(dbPath, JSON.stringify(data, null, 2), 'utf-8');
}

export async function getPages(): Promise<PageData[]> {
  return await readDb();
}

export async function getPageById(id: string): Promise<PageData | null> {
  const pages = await readDb();
  return pages.find(p => p.id === id) || null;
}

export async function getPageBySlug(slug: string): Promise<PageData | null> {
  const pages = await readDb();
  return pages.find(p => p.slug === slug) || null;
}

export async function savePage(pageData: Omit<PageData, 'id' | 'createdAt' | 'updatedAt'> & { id: string | null }): Promise<PageData> {
  const pages = await readDb();
  
  if (pageData.id) { // Update existing page
    const index = pages.findIndex(p => p.id === pageData.id);
    if (index === -1) {
      throw new Error('Pagina nu a fost găsită');
    }
    const existingPageWithSameSlug = pages.find(p => p.slug === pageData.slug && p.id !== pageData.id);
    if (existingPageWithSameSlug) {
      throw new Error('O altă pagină cu acest slug există deja.');
    }

    const updatedPage: PageData = {
      ...pages[index],
      ...pageData,
      id: pageData.id,
      updatedAt: new Date().toISOString(),
    };
    pages[index] = updatedPage;
    await writeDb(pages);
    return updatedPage;
  } else { // Create new page
    const existingPageWithSameSlug = pages.find(p => p.slug === pageData.slug);
     if (existingPageWithSameSlug) {
      throw new Error('O pagină cu acest slug există deja.');
    }
    const now = new Date().toISOString();
    const newPage: PageData = {
      ...pageData,
      id: generateId(),
      createdAt: now,
      updatedAt: now,
    };
    pages.push(newPage);
    await writeDb(pages);
    return newPage;
  }
}

export async function deletePage(id: string): Promise<void> {
    const pages = await readDb();
    const newPages = pages.filter(p => p.id !== id);
    if (pages.length === newPages.length) {
        throw new Error('Pagina nu a fost găsită');
    }
    await writeDb(newPages);
}

export async function updatePageViews(slug: string): Promise<void> {
    const pages = await readDb();
    const pageIndex = pages.findIndex(p => p.slug === slug);

    if (pageIndex === -1) {
        return; // Page not found, silently ignore
    }

    // Update views for last 24h
    const now = new Date();
    const last24h = new Date(now.getTime() - 24 * 60 * 60 * 1000);

    // Reset views if it's been more than 24h since last update
    if (!pages[pageIndex].viewsLast24h || new Date(pages[pageIndex].updatedAt) < last24h) {
        pages[pageIndex].viewsLast24h = 1;
    } else {
        pages[pageIndex].viewsLast24h = (pages[pageIndex].viewsLast24h || 0) + 1;
    }

    // Update last activity timestamp
    pages[pageIndex].lastActivity = now.toISOString();
    pages[pageIndex].updatedAt = now.toISOString();
    await writeDb(pages);
}

export async function getActivePages(): Promise<number> {
    const pages = await readDb();
    const now = new Date();
    const twelveSecondsAgo = new Date(now.getTime() - 12 * 1000); // 12 seconds ago

    return pages.filter(page => {
        if (!page.lastActivity) return false;
        return new Date(page.lastActivity) > twelveSecondsAgo;
    }).length;
}
