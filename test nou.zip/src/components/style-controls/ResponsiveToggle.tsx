'use client';

import { Monitor, Tablet, Smartphone } from 'lucide-react';
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group';
import type { ResponsiveMode } from '@/lib/types';

interface ResponsiveToggleProps {
  selectedMode: ResponsiveMode;
  onModeChange: (mode: ResponsiveMode) => void;
}

export function ResponsiveToggle({ selectedMode, onModeChange }: ResponsiveToggleProps) {
    return (
      <ToggleGroup
        type="single"
        size="sm"
        value={selectedMode}
        onValueChange={(mode: ResponsiveMode) => {
          if (mode) onModeChange(mode);
        }}
        aria-label="Responsive mode"
      >
      <ToggleGroupItem value="desktop" aria-label="Desktop">
        <Monitor className="h-4 w-4" />
      </ToggleGroupItem>
      <ToggleGroupItem value="tablet" aria-label="Tablet">
        <Tablet className="h-4 w-4" />
      </ToggleGroupItem>
      <ToggleGroupItem value="mobile" aria-label="Mobile">
        <Smartphone className="h-4 w-4" />
      </ToggleGroupItem>
    </ToggleGroup>
  );
}
