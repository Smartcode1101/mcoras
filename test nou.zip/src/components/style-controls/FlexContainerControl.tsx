'use client';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import type { CSSProperties } from 'react';
import type { ResponsiveValue, ResponsiveMode } from '@/lib/types';

type FlexContainerProps = {
  props: { [key: string]: any };
  onPropsChange: (newProps: { [key: string]: any }) => void;
  styles: ResponsiveValue<CSSProperties>;
  onStylesChange: (newStyles: ResponsiveValue<CSSProperties>) => void;
  responsiveMode: ResponsiveMode;
};

export function FlexContainerControl({ 
  props, 
  onPropsChange, 
  styles, 
  onStylesChange, 
  responsiveMode 
}: FlexContainerProps) {
  const currentStyles = styles[responsiveMode] || {};
  const desktopStyles = styles.desktop || {};
  const effectiveStyles = { ...desktopStyles, ...currentStyles };
  
  const currentColumns = props.columns?.[responsiveMode] || props.columns?.desktop || 2;
  const currentGap = typeof props.gap === 'object' ? props.gap[responsiveMode] || props.gap.desktop : props.gap || '20px';

  // Debug logging for component initialization
  if (process.env.NODE_ENV === 'development') {
    console.log('FlexContainerControl - Component initialized:', {
      responsiveMode,
      allProps: props,
      allStyles: styles,
      onPropsChange: typeof onPropsChange,
      onStylesChange: typeof onStylesChange
    });
  }
  
  // Debug logging for current values
  if (process.env.NODE_ENV === 'development') {
    console.log('FlexContainerControl - Current values:', {
      currentStyles,
      effectiveStyles,
      currentColumns,
      currentGap,
      columnsObject: props.columns,
      gapObject: props.gap
    });
  }

  const handleColumnsChange = (value: string) => {
    const columns = parseInt(value, 10);
    if (columns > 0) {
      const newColumns = {
        ...props.columns,
        [responsiveMode]: columns
      };
      
      // Debug logging for column changes
      if (process.env.NODE_ENV === 'development') {
        console.log(`FlexContainerControl - Columns change:`, {
          responsiveMode,
          previousColumns: props.columns,
          newColumns,
          onPropsChange: Object.keys(onPropsChange || {})
        });
      }
      
      onPropsChange({ ...props, columns: newColumns });
    }
  };

  const handleDirectionChange = (value: 'row' | 'column') => {
    const newStyles = {
      ...styles,
      [responsiveMode]: {
        ...currentStyles,
        flexDirection: value,
        flexWrap: value === 'row' ? 'wrap' : 'nowrap'
      },
    };
    
    // Debug logging for direction changes
    if (process.env.NODE_ENV === 'development') {
      console.log(`FlexContainerControl - Direction change:`, {
        responsiveMode,
        previousDirection: props.direction,
        newDirection: value,
        newStyles
      });
    }
    
    onStylesChange(newStyles);
    onPropsChange({ ...props, direction: value });
  };

  const handleJustifyContentChange = (value: string) => {
    const newStyles = {
      ...styles,
      [responsiveMode]: {
        ...currentStyles,
        justifyContent: value,
      },
    };
    
    // Debug logging for justify content changes
    if (process.env.NODE_ENV === 'development') {
      console.log(`FlexContainerControl - JustifyContent change:`, {
        responsiveMode,
        previousJustifyContent: props.justifyContent,
        newJustifyContent: value,
        newStyles
      });
    }
    
    onStylesChange(newStyles);
    onPropsChange({ ...props, justifyContent: value });
  };

  const handleAlignItemsChange = (value: string) => {
    const newStyles = {
      ...styles,
      [responsiveMode]: {
        ...currentStyles,
        alignItems: value,
      },
    };
    
    // Debug logging for align items changes
    if (process.env.NODE_ENV === 'development') {
      console.log(`FlexContainerControl - AlignItems change:`, {
        responsiveMode,
        previousAlignItems: props.alignItems,
        newAlignItems: value,
        newStyles
      });
    }
    
    onStylesChange(newStyles);
    onPropsChange({ ...props, alignItems: value });
  };

  const handleGapChange = (value: string) => {
    const gap = value ? `${value}px` : undefined;
    const newGap = typeof props.gap === 'object' 
      ? { ...props.gap, [responsiveMode]: gap }
      : gap;
    
    // Debug logging for gap changes
    if (process.env.NODE_ENV === 'development') {
      console.log(`FlexContainerControl - Gap change:`, {
        responsiveMode,
        previousGap: props.gap,
        newGap,
        inputValue: value
      });
    }
    
    onPropsChange({ ...props, gap: newGap });
  };

  const handleTagChange = (value: 'div' | 'section') => {
    onPropsChange({ ...props, tag: value });
  };

  const parseValue = (value: string | number | undefined) => {
    if (typeof value === 'string') {
      return value.replace('px', '');
    }
    return value || '';
  };

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label>Etichetă HTML</Label>
        <Select value={props.tag || 'div'} onValueChange={handleTagChange}>
          <SelectTrigger>
            <SelectValue placeholder="Selectează o etichetă" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="div">div</SelectItem>
            <SelectItem value="section">section</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="flex justify-between items-center">
        <Label htmlFor="columns">Coloane Responsiv</Label>
      </div>
      <div className="grid grid-cols-3 gap-2">
        <div>
          <Label htmlFor="columns-desktop" className="text-xs">Desktop</Label>
          <Input
            id="columns-desktop"
            type="number"
            min="1"
            max="12"
            value={props.columns?.desktop || 2}
            onChange={(e) => {
              const columns = { ...props.columns, desktop: parseInt(e.target.value) || 1 };
              
              if (process.env.NODE_ENV === 'development') {
                console.log(`FlexContainerControl - Desktop columns change:`, {
                  responsiveMode: 'desktop',
                  previousValue: props.columns?.desktop,
                  newValue: columns.desktop,
                  fullColumnsObject: columns
                });
              }
              
              onPropsChange({ ...props, columns });
            }}
            placeholder="Desktop"
            className="text-xs"
          />
        </div>
        <div>
          <Label htmlFor="columns-tablet" className="text-xs">Tablet</Label>
          <Input
            id="columns-tablet"
            type="number"
            min="1"
            max="8"
            value={props.columns?.tablet || 2}
            onChange={(e) => {
              const columns = { ...props.columns, tablet: parseInt(e.target.value) || 1 };
              
              if (process.env.NODE_ENV === 'development') {
                console.log(`FlexContainerControl - Tablet columns change:`, {
                  responsiveMode: 'tablet',
                  previousValue: props.columns?.tablet,
                  newValue: columns.tablet,
                  fullColumnsObject: columns
                });
              }
              
              onPropsChange({ ...props, columns });
            }}
            placeholder="Tablet"
            className="text-xs"
          />
        </div>
        <div>
          <Label htmlFor="columns-mobile" className="text-xs">Mobile</Label>
          <Input
            id="columns-mobile"
            type="number"
            min="1"
            max="4"
            value={props.columns?.mobile || 1}
            onChange={(e) => {
              const columns = { ...props.columns, mobile: parseInt(e.target.value) || 1 };
              
              if (process.env.NODE_ENV === 'development') {
                console.log(`FlexContainerControl - Mobile columns change:`, {
                  responsiveMode: 'mobile',
                  previousValue: props.columns?.mobile,
                  newValue: columns.mobile,
                  fullColumnsObject: columns
                });
              }
              
              onPropsChange({ ...props, columns });
            }}
            placeholder="Mobile"
            className="text-xs"
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label>Direcție Flex</Label>
        <Select value={props.direction || 'row'} onValueChange={handleDirectionChange}>
          <SelectTrigger>
            <SelectValue placeholder="Selectează direcția" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="row">Orizontală (Row)</SelectItem>
            <SelectItem value="column">Verticală (Column)</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label>Justify Content</Label>
        <Select value={props.justifyContent || 'flex-start'} onValueChange={handleJustifyContentChange}>
          <SelectTrigger>
            <SelectValue placeholder="Selectează alinierea" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="flex-start">Start</SelectItem>
            <SelectItem value="center">Centru</SelectItem>
            <SelectItem value="flex-end">End</SelectItem>
            <SelectItem value="space-between">Între Elemente</SelectItem>
            <SelectItem value="space-around">În Jurul Elemente</SelectItem>
            <SelectItem value="space-evenly">Egal</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label>Align Items</Label>
        <Select value={props.alignItems || 'flex-start'} onValueChange={handleAlignItemsChange}>
          <SelectTrigger>
            <SelectValue placeholder="Selectează alinierea" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="flex-start">Start</SelectItem>
            <SelectItem value="center">Centru</SelectItem>
            <SelectItem value="flex-end">End</SelectItem>
            <SelectItem value="stretch">Stretch</SelectItem>
            <SelectItem value="baseline">Baseline</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="flex justify-between items-center">
        <Label htmlFor="gap">Spațiu (px)</Label>
      </div>
      <Input
        id="gap"
        type="number"
        min="0"
        value={parseValue(currentGap)}
        onChange={(e) => handleGapChange(e.target.value)}
        placeholder="0"
      />
    </div>
  );
}