
'use client';

import { useEffect, useState } from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { Button } from '../ui/button';
import { Trash2 } from 'lucide-react';

interface BoxShadowControlProps {
  value?: string;
  onChange: (value: string | undefined) => void;
}

interface ShadowState {
  offsetX: number;
  offsetY: number;
  blurRadius: number;
  spreadRadius: number;
  color: string;
  opacity: number;
}

const parseRgba = (rgba: string): { color: string; opacity: number } => {
  const result = { color: '#000000', opacity: 1 };
  const match = rgba.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?\)/);
  if (match) {
    const r = parseInt(match[1], 10);
    const g = parseInt(match[2], 10);
    const b = parseInt(match[3], 10);
    result.color = `#${r.toString(16).padStart(2, '0')}${g.toString(16).padStart(2, '0')}${b.toString(16).padStart(2, '0')}`;
    if (match[4] !== undefined) {
      result.opacity = parseFloat(match[4]);
    }
  }
  return result;
};

const hexToRgb = (hex: string): { r: number, g: number, b: number } | null => {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
        r: parseInt(result[1], 16),
        g: parseInt(result[2], 16),
        b: parseInt(result[3], 16)
    } : null;
}

export function BoxShadowControl({ value, onChange }: BoxShadowControlProps) {
  const [shadow, setShadow] = useState<ShadowState>({
    offsetX: 0,
    offsetY: 2,
    blurRadius: 4,
    spreadRadius: 0,
    color: '#000000',
    opacity: 0.1,
  });

  useEffect(() => {
    if (value && value !== 'none') {
      const parts = value.split(/(?![^(]*\)),\s*/); // Split by comma, but not inside rgba()
      const firstShadow = parts[0];
      const colorMatch = firstShadow.match(/(rgba?\(.*\)|#\w+)/);
      const colorPart = colorMatch ? colorMatch[0] : 'rgba(0,0,0,0.1)';
      
      const numericParts = firstShadow.replace(colorPart, '').trim().split(/\s+/).map(p => parseFloat(p) || 0);

      const { color, opacity } = parseRgba(colorPart);
      
      setShadow({
        offsetX: numericParts[0] || 0,
        offsetY: numericParts[1] || 0,
        blurRadius: numericParts[2] || 0,
        spreadRadius: numericParts[3] || 0,
        color: color,
        opacity: opacity,
      });
    }
  }, [value]);

  const handleShadowChange = (
    prop: keyof ShadowState,
    val: number | string
  ) => {
    const newShadow = { ...shadow, [prop]: val };
    setShadow(newShadow);
    
    const rgb = hexToRgb(newShadow.color);
    if (rgb) {
        const newBoxShadow = `${newShadow.offsetX}px ${newShadow.offsetY}px ${newShadow.blurRadius}px ${newShadow.spreadRadius}px rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, ${newShadow.opacity})`;
        onChange(newBoxShadow);
    }
  };

  const handleClearShadow = () => {
    onChange(undefined);
  }
  
  const safeParseInt = (val: string) => {
    const parsed = parseInt(val, 10);
    return isNaN(parsed) ? 0 : parsed;
  }

  return (
    <div className="space-y-4 rounded-md border p-3 mt-2">
      <div className="grid grid-cols-2 gap-2">
        <div>
          <Label className="text-xs">Offset X</Label>
          <Input
            type="number"
            value={shadow.offsetX}
            onChange={(e) => handleShadowChange('offsetX', safeParseInt(e.target.value))}
          />
        </div>
        <div>
          <Label className="text-xs">Offset Y</Label>
          <Input
            type="number"
            value={shadow.offsetY}
            onChange={(e) => handleShadowChange('offsetY', safeParseInt(e.target.value))}
          />
        </div>
        <div>
          <Label className="text-xs">Estompare</Label>
          <Input
            type="number"
            min="0"
            value={shadow.blurRadius}
            onChange={(e) => handleShadowChange('blurRadius', safeParseInt(e.target.value))}
          />
        </div>
        <div>
          <Label className="text-xs">Răspândire</Label>
          <Input
            type="number"
            value={shadow.spreadRadius}
            onChange={(e) => handleShadowChange('spreadRadius', safeParseInt(e.target.value))}
          />
        </div>
      </div>
      <div>
        <Label>Culoare & Opacitate</Label>
        <div className="flex items-center gap-2 mt-1">
          <Input
            type="color"
            value={shadow.color}
            onChange={(e) => handleShadowChange('color', e.target.value)}
            className="w-10 h-10 p-1"
          />
          <Slider
            min={0}
            max={1}
            step={0.01}
            value={[shadow.opacity]}
            onValueChange={(v) => handleShadowChange('opacity', v[0])}
          />
          <span className="text-xs text-muted-foreground w-8 text-right">
            {Math.round(shadow.opacity * 100)}%
          </span>
        </div>
      </div>
      <Button variant="outline" size="sm" className="w-full" onClick={handleClearShadow}>
        <Trash2 className="w-3 h-3 mr-2"/>
        Elimină Umbra
      </Button>
    </div>
  );
}
