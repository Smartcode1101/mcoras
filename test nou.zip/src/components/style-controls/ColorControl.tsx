'use client';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import type { CSSProperties } from 'react';
import type { ResponsiveValue, ResponsiveMode } from '@/lib/types';

type ColorProps = {
  styles: ResponsiveValue<CSSProperties>;
  onStylesChange: (newStyles: ResponsiveValue<CSSProperties>) => void;
  responsiveMode: ResponsiveMode;
  showBackgroundColor?: boolean;
};

export function ColorControl({ styles, onStylesChange, responsiveMode, showBackgroundColor = true }: ColorProps) {

  const currentStyles = styles[responsiveMode] || {};
  const desktopStyles = styles.desktop || {};
  const effectiveStyles = { ...desktopStyles, ...currentStyles };

  const handleColorChange = (property: 'color' | 'backgroundColor', value: string) => {
    const newStyles = {
      ...styles,
      [responsiveMode]: {
        ...currentStyles,
        [property]: value || undefined,
      },
    };
    onStylesChange(newStyles);
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <Label>Culoare Text</Label>
      </div>
      <div className="flex items-center gap-2">
        <Input
          type="color"
          value={(effectiveStyles.color as string) || '#000000'}
          onChange={(e) => handleColorChange('color', e.target.value)}
          className="w-10 h-10 p-1"
        />
        <Input
          type="text"
          value={(effectiveStyles.color as string) || ''}
          onChange={(e) => handleColorChange('color', e.target.value)}
          placeholder="#000000"
        />
      </div>
      {showBackgroundColor && (
        <>
          <div className="flex justify-between items-center">
            <Label>Culoare Fundal</Label>
          </div>
          <div className="flex items-center gap-2">
            <Input
              type="color"
              value={(effectiveStyles.backgroundColor as string) || '#FFFFFF'}
              onChange={(e) => handleColorChange('backgroundColor', e.target.value)}
              className="w-10 h-10 p-1"
            />
            <Input
              type="text"
              value={(effectiveStyles.backgroundColor as string) || ''}
              onChange={(e) => handleColorChange('backgroundColor', e.target.value)}
              placeholder="transparent"
            />
          </div>
        </>
      )}
    </div>
  );
}
