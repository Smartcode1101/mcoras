
'use client';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import type { CSSProperties } from 'react';
import type { ResponsiveValue, ResponsiveMode } from '@/lib/types';

type ContainerProps = {
  props: { [key: string]: any };
  onPropsChange: (newProps: { [key: string]: any }) => void;
  styles: ResponsiveValue<CSSProperties>;
  onStylesChange: (newStyles: ResponsiveValue<CSSProperties>) => void;
  responsiveMode: ResponsiveMode;
};

export function ContainerControl({ props, onPropsChange, styles, onStylesChange, responsiveMode }: ContainerProps) {
  const currentStyles = styles[responsiveMode] || {};
  const desktopStyles = styles.desktop || {};
  const effectiveStyles = { ...desktopStyles, ...currentStyles };

  const handleColumnsChange = (value: string) => {
    const columns = parseInt(value, 10);
    if (columns > 0) {
      onPropsChange({ ...props, columns });
      const newStyles = {
        ...styles,
        [responsiveMode]: {
          ...currentStyles,
          gridTemplateColumns: `repeat(${columns}, 1fr)`,
        },
      };
      onStylesChange(newStyles);
    }
  };

  const handleTagChange = (value: 'div' | 'section') => {
    onPropsChange({ ...props, tag: value });
  };

  const handleGapChange = (value: string) => {
    const gap = value ? `${value}px` : undefined;
    const newStyles = {
      ...styles,
      [responsiveMode]: {
        ...currentStyles,
        gap,
      },
    };
    onStylesChange(newStyles);
  };

  const handleFullWidthChange = (checked: boolean) => {
    onPropsChange({ ...props, fullWidth: checked });
    if (checked) {
      const newStyles = {
        ...styles,
        [responsiveMode]: {
          ...currentStyles,
          width: '100vw',
          maxWidth: '100vw',
          position: 'relative',
          left: '50%',
          transform: 'translateX(-50%)',
        },
      };
      onStylesChange(newStyles);
    } else {
      const newStyles = {
        ...styles,
        [responsiveMode]: {
          ...currentStyles,
          width: undefined,
          maxWidth: undefined,
          position: undefined,
          left: undefined,
          transform: undefined,
        },
      };
      onStylesChange(newStyles);
    }
  };

  const parseValue = (value: string | number | undefined) => {
    if (typeof value === 'string') {
      return value.replace('px', '');
    }
    return value || '';
  };

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label>Etichetă HTML</Label>
        <Select value={props.tag || 'div'} onValueChange={handleTagChange}>
          <SelectTrigger>
            <SelectValue placeholder="Selectează o etichetă" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="div">div</SelectItem>
            <SelectItem value="section">section</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="flex items-center justify-between rounded-lg border p-3 shadow-sm">
        <div className="space-y-0.5">
          <Label>Lățime Completă</Label>
          <p className="text-xs text-muted-foreground">
            Extinde containerul pe toată lățimea paginii.
          </p>
        </div>
        <Switch
          checked={props.fullWidth || false}
          onCheckedChange={handleFullWidthChange}
        />
      </div>

      <div className="flex justify-between items-center">
        <Label htmlFor="columns">Coloane Grilă</Label>
      </div>
      <Input
        id="columns"
        type="number"
        min="1"
        max="12"
        value={props.columns || 1}
        onChange={(e) => handleColumnsChange(e.target.value)}
        placeholder="Număr de coloane"
      />

      <div className="flex justify-between items-center">
        <Label htmlFor="gap">Spațiu (px)</Label>
      </div>
      <Input
        id="gap"
        type="number"
        min="0"
        value={parseValue(effectiveStyles.gap)}
        onChange={(e) => handleGapChange(e.target.value)}
        placeholder="0"
      />
    </div>
  );
}
