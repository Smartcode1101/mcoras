
'use client';
import { useState, useEffect } from 'react';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Images, Upload } from 'lucide-react';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import { ScrollArea } from '../ui/scroll-area';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Textarea } from '../ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '../ui/progress';
import { uploadImageAction, getImagesAction } from '@/lib/actions';
import { ResponsiveToggle } from './ResponsiveToggle';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import type { ResponsiveMode, ResponsiveValue } from '@/lib/types';
import { useEditor } from '@/contexts/editor-context';
 
interface ImageControlProps {
  currentSrc: string;
  currentAlt: string;
  currentDescription?: string;
  currentWidth?: ResponsiveValue<number>;
  currentHeight?: ResponsiveValue<number>;
  currentObjectFit?: ResponsiveValue<'cover' | 'contain' | 'fill' | 'none' | 'scale-down'>;
  currentAspectRatio?: ResponsiveValue<string>;
  currentAlignment?: ResponsiveValue<'left' | 'center' | 'right'>;
  onPropChange: (props: {
    src?: string;
    alt?: string;
    description?: string;
    width?: ResponsiveValue<number>;
    height?: ResponsiveValue<number>;
    objectFit?: ResponsiveValue<'cover' | 'contain' | 'fill' | 'none' | 'scale-down'>;
    aspectRatio?: ResponsiveValue<string>;
    alignment?: ResponsiveValue<'left' | 'center' | 'right'>;
  }) => void;
}

type UserImage = {
  src: string;
  alt: string;
};

export function ImageControl({
   currentSrc,
   currentAlt,
   currentDescription,
   currentWidth,
   currentHeight,
   currentObjectFit,
   currentAspectRatio,
   currentAlignment,
   onPropChange
 }: ImageControlProps) {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [userImages, setUserImages] = useState<UserImage[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const { toast } = useToast();

  // Get responsive mode from editor context instead of local state
  const { state: editorState, dispatch } = useEditor();

  // Guard against undefined context
  if (!editorState) {
    return <div>Loading...</div>;
  }

  const responsiveMode = editorState.responsiveMode || 'desktop'; // Fallback to desktop if undefined

   // Helper function to get current responsive value
   const getCurrentResponsiveValue = <T,>(value: ResponsiveValue<T> | T | undefined): T | undefined => {
     if (value === undefined || value === null) {
       return undefined;
     }

     // If it's a responsive value object, get the current mode value or fallback to desktop
     if (typeof value === 'object' && !Array.isArray(value) && 'desktop' in value) {
       const responsiveValue = value as ResponsiveValue<T>;
       return responsiveValue[responsiveMode] ?? responsiveValue.desktop ?? undefined;
     }

     // If it's a direct value, return it
     return value as T;
   };

   // Helper function to update responsive value
    const updateResponsiveValue = <T,>(
      currentValue: ResponsiveValue<T> | T | undefined,
      newValue: T | undefined,
      propName: keyof ImageControlProps
    ) => {
 
      let updatedValue: ResponsiveValue<T>;
 
      // Clean up any corrupted objects that might have undefined keys
      const cleanValue = (value: any): ResponsiveValue<T> | T | undefined => {
        if (value && typeof value === 'object' && !Array.isArray(value)) {
          const cleaned: any = {};
          for (const key in value) {
            if (key !== 'undefined' && value[key] !== undefined) {
              cleaned[key] = value[key];
            }
          }
          // If the cleaned object is empty, return undefined
          if (Object.keys(cleaned).length === 0) {
            return undefined;
          }
          return cleaned;
        }
        return value;
      };
 
      const cleanedCurrentValue = cleanValue(currentValue);
 
      // If current value is a direct value (not responsive), convert it to responsive format
      if (cleanedCurrentValue !== undefined && cleanedCurrentValue !== null && (typeof cleanedCurrentValue !== 'object' || Array.isArray(cleanedCurrentValue) || !('desktop' in cleanedCurrentValue))) {
        updatedValue = { desktop: cleanedCurrentValue as T };
      } else {
        updatedValue = { ...(cleanedCurrentValue as ResponsiveValue<T>) };
      }
 
      if (newValue === undefined) {
        delete updatedValue[responsiveMode];
        // If no values left, pass undefined to clear the prop
        if (Object.keys(updatedValue).length === 0) {
          onPropChange({ [propName]: undefined });
          return;
        }
      } else {
        updatedValue[responsiveMode] = newValue;
      }
 
      // Map ImageControl prop names to actual element prop names
      const propMapping: Record<string, string> = {
        'currentWidth': 'width',
        'currentHeight': 'height',
        'currentObjectFit': 'objectFit',
        'currentAspectRatio': 'aspectRatio',
        'currentAlignment': 'alignment'
      };
 
      const actualPropName = propMapping[propName as string] || propName;

      onPropChange({ [actualPropName]: updatedValue });
    };

   // Handler to update responsive mode in editor context
   const handleResponsiveModeChange = (mode: ResponsiveMode) => {
     dispatch({ type: 'SET_RESPONSIVE_MODE', payload: { mode } });
   };

   // Local state for Select values to ensure proper controlled behavior
   const [localAlignment, setLocalAlignment] = useState<string>(() => getCurrentResponsiveValue(currentAlignment) || 'center');
   const [localObjectFit, setLocalObjectFit] = useState<string>(() => getCurrentResponsiveValue(currentObjectFit) || 'cover');
   const [localAspectRatio, setLocalAspectRatio] = useState<string>(() => getCurrentResponsiveValue(currentAspectRatio) || 'auto');

   // Update local state when responsive mode or props change
   useEffect(() => {
     const newAlignment = getCurrentResponsiveValue(currentAlignment) || 'center';
     const newObjectFit = getCurrentResponsiveValue(currentObjectFit) || 'cover';
     const newAspectRatio = getCurrentResponsiveValue(currentAspectRatio) || 'auto';

     setLocalAlignment(newAlignment);
     setLocalObjectFit(newObjectFit);
     setLocalAspectRatio(newAspectRatio);
   }, [responsiveMode, currentAlignment, currentObjectFit, currentAspectRatio]);

  useEffect(() => {
    const fetchImages = async () => {
      if (isDialogOpen) {
        const result = await getImagesAction();
        if (result.data) {
          setUserImages(result.data);
        } else if (result.error) {
          toast({
            variant: 'destructive',
            title: 'Eroare la încărcarea imaginilor',
            description: result.error,
          });
        }
      }
    };
    fetchImages();
  }, [isDialogOpen, toast]);
 
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 20 * 1024 * 1024) {
      toast({
        variant: 'destructive',
        title: 'Fișier prea mare',
        description: 'Te rog încarcă o imagine mai mică de 20MB.',
      });
      return;
    }

    setIsUploading(true);
    setUploadProgress(0);

    // --- Optimistic UI Update ---
    // 1. Create a local URL and update the editor immediately.
    const localUrl = URL.createObjectURL(file);
    onPropChange({ src: localUrl, alt: file.name, description: '' });
    setIsDialogOpen(false); // Close dialog immediately for better UX
    
    // Animate progress bar
    const progressInterval = setInterval(() => {
      setUploadProgress((prev) => (prev < 90 ? prev + 10 : prev));
    }, 200);

    const formData = new FormData();
    formData.append('file', file);
    
    // 2. Upload to server in the background.
    const result = await uploadImageAction(formData);
    
    clearInterval(progressInterval);
    setUploadProgress(100);

    if (result.error) {
      toast({
        variant: 'destructive',
        title: 'Încărcare Eșuată',
        description: result.error,
      });
       // Revert optimistic update on failure
      onPropChange({ src: currentSrc, alt: currentAlt, description: currentDescription });
    } else if (result.data) {
      const newImage = { src: result.data.src, alt: result.data.alt };
      setUserImages((prev) => [newImage, ...prev]);
      
      // 3. Update the editor with the permanent server URL.
      onPropChange({ src: newImage.src, alt: newImage.alt });

      toast({ title: 'Încărcare Reușită', description: 'Imaginea ta a fost salvată pe server.' });
    }

    // Clean up local URL to prevent memory leaks
    URL.revokeObjectURL(localUrl);

    setTimeout(() => {
        setIsUploading(false);
        setUploadProgress(0);
    }, 1000);

    e.target.value = '';
  };

  const handleSelectImage = (img: { src: string; alt: string }) => {
    onPropChange({ src: img.src, alt: img.alt });
    setIsDialogOpen(false);
  };

  const handleOpenChange = (open: boolean) => {
    setIsDialogOpen(open);
  };


  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="alt-text">Text Alternativ</Label>
        <Input
          id="alt-text"
          value={currentAlt}
          onChange={(e) => onPropChange({ alt: e.target.value })}
          placeholder="Text alternativ descriptiv"
        />
        <p className="text-xs text-muted-foreground">
          Descrie imaginea pentru cititoarele de ecran și SEO.
        </p>
      </div>
      <div className="space-y-2">
        <Label htmlFor="description">Descriere (legendă)</Label>
        <Textarea
          id="description"
          value={currentDescription}
          onChange={(e) => onPropChange({ description: e.target.value })}
          placeholder="Legendă opțională pentru imagine"
          rows={3}
        />
        <p className="text-xs text-muted-foreground">
          Aceasta poate fi afișată ca o legendă sub imagine.
        </p>
      </div>

      {/* Responsive Controls */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <Label>Responsive Settings</Label>
          <ResponsiveToggle
            selectedMode={responsiveMode}
            onModeChange={handleResponsiveModeChange}
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="width">Lățime (px)</Label>
            <Input
              id="width"
              type="number"
              value={getCurrentResponsiveValue(currentWidth) ?? ''}
              onChange={(e) => updateResponsiveValue(currentWidth, e.target.value ? Number(e.target.value) : undefined, 'currentWidth')}
              placeholder="Auto"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="height">Înălțime (px)</Label>
            <Input
              id="height"
              type="number"
              value={getCurrentResponsiveValue(currentHeight) ?? ''}
              onChange={(e) => updateResponsiveValue(currentHeight, e.target.value ? Number(e.target.value) : undefined, 'currentHeight')}
              placeholder="Auto"
            />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="object-fit">Object Fit</Label>
          <Select
            value={localObjectFit}
            onValueChange={(value: string) => {
              setLocalObjectFit(value);
              const objectFitValue = value as 'cover' | 'contain' | 'fill' | 'none' | 'scale-down';
              updateResponsiveValue(currentObjectFit, objectFitValue, 'currentObjectFit');
            }}
          >
            <SelectTrigger>
              <SelectValue placeholder="Selectează object fit" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="cover">Cover</SelectItem>
              <SelectItem value="contain">Contain</SelectItem>
              <SelectItem value="fill">Fill</SelectItem>
              <SelectItem value="none">None</SelectItem>
              <SelectItem value="scale-down">Scale Down</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="aspect-ratio">Aspect Ratio</Label>
          <Select
            value={localAspectRatio}
            onValueChange={(value: string) => {
              setLocalAspectRatio(value);
              const aspectRatioValue = value;
              updateResponsiveValue(currentAspectRatio, aspectRatioValue, 'currentAspectRatio');
            }}
          >
            <SelectTrigger>
              <SelectValue placeholder="Selectează aspect ratio" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="auto">Auto</SelectItem>
              <SelectItem value="1/1">1:1 (Square)</SelectItem>
              <SelectItem value="4/3">4:3</SelectItem>
              <SelectItem value="16/9">16:9</SelectItem>
              <SelectItem value="3/2">3:2</SelectItem>
              <SelectItem value="21/9">21:9 (Ultra-wide)</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="alignment">Aliniere</Label>
          <Select
            value={localAlignment}
            onValueChange={(value: string) => {
              setLocalAlignment(value);
              const alignmentValue = value as 'left' | 'center' | 'right';
              updateResponsiveValue(currentAlignment, alignmentValue, 'currentAlignment');
            }}
          >
            <SelectTrigger>
              <SelectValue placeholder="Selectează alinierea" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="left">Stânga</SelectItem>
              <SelectItem value="center">Centru</SelectItem>
              <SelectItem value="right">Dreapta</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div>
        <Label>Previzualizare Imagine Curentă</Label>
        <div className="mt-2 aspect-video w-full rounded-md border p-2 bg-slate-50">
          {(() => {
            const isTempUrl = typeof currentSrc === 'string' && (currentSrc.startsWith('blob:') || currentSrc.startsWith('data:'));
            const previewSrc = currentSrc || 'https://picsum.photos/seed/placeholder/600/400';
            if (isTempUrl) {
              // next/image nu suportă URL-uri blob:/data:, folosim img standard pentru previzualizare optimistă
              return (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  src={previewSrc}
                  alt={currentAlt || 'Selecția curentă'}
                  className="w-full h-full object-contain rounded-sm"
                />
              );
            }
            return (
              <Image
                src={previewSrc}
                alt={currentAlt || 'Selecția curentă'}
                width={300}
                height={150}
                className="w-full h-full object-contain rounded-sm"
              />
            );
          })()}
        </div>
      </div>

      <Dialog open={isDialogOpen} onOpenChange={handleOpenChange}>
        <DialogTrigger asChild>
          <Button className="w-full" variant="outline">
            <Images className="w-4 h-4 mr-2" />
            Schimbă Imaginea
          </Button>
        </DialogTrigger>
        <DialogContent className="max-w-6xl h-[90vh] flex flex-col p-0">
          <DialogHeader className="p-4 border-b">
            <DialogTitle>Bibliotecă Media</DialogTitle>
            <DialogDescription>
              Selectează o imagine din bibliotecă sau încarcă una nouă.
            </DialogDescription>
          </DialogHeader>
          <Tabs defaultValue="stock" className="flex-1 flex flex-col overflow-hidden">
            <TabsList className="mx-4 mt-4">
              <TabsTrigger value="stock">Imagini Stoc</TabsTrigger>
              <TabsTrigger value="my-images">Imaginile Mele</TabsTrigger>
            </TabsList>
            <TabsContent value="stock" className="flex-1 overflow-hidden mt-0">
              <ScrollArea className="h-full">
                <div className="grid grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 p-4">
                  {PlaceHolderImages.map((img) => (
                    <div
                      key={img.id}
                      className="relative group aspect-square cursor-pointer rounded-md overflow-hidden ring-offset-background focus-within:ring-2 focus-within:ring-primary"
                      onClick={() => handleSelectImage({ src: img.imageUrl, alt: img.description })}
                      tabIndex={0}
                      onKeyDown={(e) =>
                        e.key === 'Enter' && handleSelectImage({ src: img.imageUrl, alt: img.description })
                      }
                    >
                      <Image
                        src={img.imageUrl}
                        alt={img.description}
                        fill
                        sizes="(max-width: 768px) 33vw, 20vw"
                        className="object-cover"
                        data-ai-hint={img.imageHint}
                        priority={img.id === 'office-space'} 
                      />
                      <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                        <span className="text-white text-sm text-center p-2">Selectează</span>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </TabsContent>
            <TabsContent value="my-images" className="flex-1 flex flex-col overflow-hidden mt-0">
              <div className="p-4 border-b">
                <div className="relative border-2 border-dashed border-muted rounded-lg p-6 text-center">
                  <Upload className="mx-auto h-12 w-12 text-muted-foreground" />
                  <h3 className="mt-2 text-sm font-medium text-foreground">Încarcă o imagine</h3>
                  <p className="mt-1 text-xs text-muted-foreground">PNG, JPG, GIF, BMP până la 60MB.</p>
                  <Input
                    id="file-upload"
                    name="file-upload"
                    type="file"
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                    onChange={handleFileChange}
                    disabled={isUploading}
                    accept="image/png, image/jpeg, image/gif, image/bmp"
                  />
                </div>
                {isUploading && (
                  <div className="mt-4 w-full">
                    <Progress value={uploadProgress} />
                    <p className="text-xs text-center mt-1 text-muted-foreground">Se încarcă...</p>
                  </div>
                )}
              </div>
              <ScrollArea className="flex-1">
                {userImages.length === 0 ? (
                  <div className="flex items-center justify-center h-full text-muted-foreground">
                    <p>Nu ai încărcat nicio imagine încă.</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 p-4">
                    {userImages.map((img, index) => (
                      <div
                        key={index}
                        className="relative group aspect-square cursor-pointer rounded-md overflow-hidden ring-offset-background focus-within:ring-2 focus-within:ring-primary"
                        onClick={() => handleSelectImage(img)}
                        tabIndex={0}
                        onKeyDown={(e) => e.key === 'Enter' && handleSelectImage(img)}
                      >
                        <Image
                          src={img.src}
                          alt={img.alt}
                          fill
                          sizes="(max-width: 768px) 33vw, 20vw"
                          className="object-cover"
                        />
                        <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                          <span className="text-white text-sm text-center p-2">Selectează</span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </ScrollArea>
            </TabsContent>
          </Tabs>
        </DialogContent>
      </Dialog>
    </div>
  );
}
