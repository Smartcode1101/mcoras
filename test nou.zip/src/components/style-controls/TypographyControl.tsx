'use client';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group';
import { AlignCenter, AlignLeft, AlignRight } from 'lucide-react';
import type { CSSProperties } from 'react';
import type { ResponsiveValue, ResponsiveMode } from '@/lib/types';

type TypographyProps = {
  styles: ResponsiveValue<CSSProperties>;
  onStylesChange: (newStyles: ResponsiveValue<CSSProperties>) => void;
  responsiveMode: ResponsiveMode;
};

export function TypographyControl({ styles, onStylesChange, responsiveMode }: TypographyProps) {

  const currentStyles = styles[responsiveMode] || {};
  const desktopStyles = styles.desktop || {};
  const effectiveStyles = { ...desktopStyles, ...currentStyles };

  const handleStyleChange = (property: keyof React.CSSProperties, value: string | undefined) => {
    const newStyles = {
      ...styles,
      [responsiveMode]: {
        ...currentStyles,
        [property]: value,
      },
    };
    onStylesChange(newStyles);
  };

  const parseValue = (value: string | number | undefined) => {
    if (typeof value === 'string') {
      return value.replace(/px$/, '');
    }
    return value || '';
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label>Dimensiune Font (px)</Label>
          <Input
            type="number"
            placeholder="16"
            value={parseValue(effectiveStyles.fontSize)}
            onChange={(e) => handleStyleChange('fontSize', e.target.value ? `${e.target.value}px` : undefined)}
          />
        </div>
        <div className="space-y-2">
          <Label>Grosime Font</Label>
          <Select
            value={effectiveStyles.fontWeight as string}
            onValueChange={(value) => handleStyleChange('fontWeight', value)}
          >
            <SelectTrigger>
              <SelectValue placeholder="Selectează grosimea" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="normal">Normal</SelectItem>
              <SelectItem value="bold">Bold</SelectItem>
              <SelectItem value="300">Subțire</SelectItem>
              <SelectItem value="500">Mediu</SelectItem>
              <SelectItem value="600">Semi-Bold</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="space-y-2">
        <Label>Aliniere Text</Label>
        <ToggleGroup
          type="single"
          value={effectiveStyles.textAlign || ''}
          onValueChange={(value) => handleStyleChange('textAlign', value)}
          className="w-full"
        >
          <ToggleGroupItem value="left" aria-label="Aliniere la stânga" className="flex-1">
            <AlignLeft className="h-4 w-4" />
          </ToggleGroupItem>
          <ToggleGroupItem value="center" aria-label="Aliniere la centru" className="flex-1">
            <AlignCenter className="h-4 w-4" />
          </ToggleGroupItem>
          <ToggleGroupItem value="right" aria-label="Aliniere la dreapta" className="flex-1">
            <AlignRight className="h-4 w-4" />
          </ToggleGroupItem>
        </ToggleGroup>
      </div>
    </div>
  );
}
