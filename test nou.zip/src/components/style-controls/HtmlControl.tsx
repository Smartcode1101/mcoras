'use client';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';

type HtmlControlProps = {
  props: { [key: string]: any };
  onPropChange: (newProps: { [key: string]: any }) => void;
};

export function HtmlControl({ props, onPropChange }: HtmlControlProps) {
  const handleHtmlChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    onPropChange({ html: e.target.value });
  };

  return (
    <div className="space-y-2">
      <Label htmlFor="html-code">HTML Personalizat</Label>
      <Textarea
        id="html-code"
        value={props.html || ''}
        onChange={handleHtmlChange}
        placeholder="<div>HTML-ul tău aici</div>"
        className="font-mono"
        rows={15}
      />
      <p className="text-xs text-muted-foreground">
        Notă: Scripturile s-ar putea să nu se randeze corect în previzualizarea editorului.
      </p>
    </div>
  );
}
