'use client';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  ArrowUp,
} from 'lucide-react';
import type { CSSProperties } from 'react';
import type { ResponsiveValue, ResponsiveMode } from '@/lib/types';

type SpacingProps = {
  styles: ResponsiveValue<CSSProperties>;
  onStylesChange: (newStyles: ResponsiveValue<CSSProperties>) => void;
  responsiveMode: ResponsiveMode;
  elementType?: string;
};

export function SpacingControl({ styles, onStylesChange, responsiveMode, elementType }: SpacingProps) {

  const currentStyles = styles[responsiveMode] || {};
  const desktopStyles = styles.desktop || {};
  const effectiveStyles = { ...desktopStyles, ...currentStyles };

  const handleSpacingChange = (
    property: 'padding' | 'margin',
    side: string,
    value: string
  ) => {
    const newSpacing = value ? `${value}px` : undefined;
    const newStyles = {
      ...styles,
      [responsiveMode]: {
        ...currentStyles,
        [`${property}${side}`]: newSpacing,
      },
    };
    onStylesChange(newStyles);
  };

  const parseValue = (value: string | number | undefined) => {
    if (typeof value === 'string') {
      return value.replace('px', '');
    }
    return value || '';
  };

  const handleHeightChange = (value: string) => {
    const newHeight = value ? `${value}px` : undefined;
    const newStyles = {
      ...styles,
      [responsiveMode]: {
        ...currentStyles,
        height: newHeight,
      },
    };
    onStylesChange(newStyles);
  };

  return (
    <div className="space-y-4">
      {elementType === 'Spacer' && (
        <div>
          <Label className="text-sm font-medium">Înălțime Spațiu</Label>
          <Input
            type="number"
            placeholder="Înălțime (px)"
            value={parseValue(effectiveStyles.height)}
            onChange={(e) => handleHeightChange(e.target.value)}
            className="mt-1"
          />
        </div>
      )}
      <div>
        <div className="flex justify-between items-center mb-2">
          <Label className="text-sm font-medium">Padding</Label>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <div className="relative">
            <ArrowUp className="absolute left-2 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              type="number"
              className="pl-7"
              placeholder="Sus"
              value={parseValue(effectiveStyles.paddingTop)}
              onChange={(e) => handleSpacingChange('padding', 'Top', e.target.value)}
            />
          </div>
          <div className="relative">
            <ArrowDown className="absolute left-2 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              type="number"
              className="pl-7"
              placeholder="Jos"
              value={parseValue(effectiveStyles.paddingBottom)}
              onChange={(e) => handleSpacingChange('padding', 'Bottom', e.target.value)}
            />
          </div>
          <div className="relative">
            <ArrowLeft className="absolute left-2 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              type="number"
              className="pl-7"
              placeholder="Stânga"
              value={parseValue(effectiveStyles.paddingLeft)}
              onChange={(e) => handleSpacingChange('padding', 'Left', e.target.value)}
            />
          </div>
          <div className="relative">
            <ArrowRight className="absolute left-2 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              type="number"
              className="pl-7"
              placeholder="Dreapta"
              value={parseValue(effectiveStyles.paddingRight)}
              onChange={(e) => handleSpacingChange('padding', 'Right', e.target.value)}
            />
          </div>
        </div>
      </div>
      <div>
        <div className="flex justify-between items-center mb-2">
          <Label className="text-sm font-medium">Margine</Label>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <div className="relative">
            <ArrowUp className="absolute left-2 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              type="number"
              className="pl-7"
              placeholder="Sus"
              value={parseValue(effectiveStyles.marginTop)}
              onChange={(e) => handleSpacingChange('margin', 'Top', e.target.value)}
            />
          </div>
          <div className="relative">
            <ArrowDown className="absolute left-2 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              type="number"
              className="pl-7"
              placeholder="Jos"
              value={parseValue(effectiveStyles.marginBottom)}
              onChange={(e) => handleSpacingChange('margin', 'Bottom', e.target.value)}
            />
          </div>
          <div className="relative">
            <ArrowLeft className="absolute left-2 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              type="number"
              className="pl-7"
              placeholder="Stânga"
              value={parseValue(effectiveStyles.marginLeft)}
              onChange={(e) => handleSpacingChange('margin', 'Left', e.target.value)}
            />
          </div>
          <div className="relative">
            <ArrowRight className="absolute left-2 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              type="number"
              className="pl-7"
              placeholder="Dreapta"
              value={parseValue(effectiveStyles.marginRight)}
              onChange={(e) => handleSpacingChange('margin', 'Right', e.target.value)}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
