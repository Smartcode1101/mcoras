'use client';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  CornerUpLeft,
  CornerUpRight,
  CornerDownLeft,
  CornerDownRight,
} from 'lucide-react';
import { BoxShadowControl } from './BoxShadowControl';
import type { CSSProperties } from 'react';
import type { ResponsiveValue, ResponsiveMode } from '@/lib/types';

type BorderProps = {
  styles: ResponsiveValue<CSSProperties>;
  onStylesChange: (newStyles: ResponsiveValue<CSSProperties>) => void;
  responsiveMode: ResponsiveMode;
};

export function BorderControl({ styles, onStylesChange, responsiveMode }: BorderProps) {

  const currentStyles = styles[responsiveMode] || {};
  const desktopStyles = styles.desktop || {};
  const effectiveStyles = { ...desktopStyles, ...currentStyles };

  const handleBorderRadiusChange = (side: string, value: string) => {
    const newRadius = value ? `${value}px` : undefined;
    const newStyles = {
      ...styles,
      [responsiveMode]: {
        ...currentStyles,
        [side]: newRadius,
      },
    };
    onStylesChange(newStyles);
  };

  const handleBoxShadowChange = (value: string | undefined) => {
    const newStyles = {
      ...styles,
      [responsiveMode]: {
        ...currentStyles,
        boxShadow: value,
      },
    };
    onStylesChange(newStyles);
  };

  const parseValue = (value: string | number | undefined) => {
    if (typeof value === 'string') {
      return value.replace('px', '');
    }
    return value || '';
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <Label className="text-sm font-medium">Raza Bordurii</Label>
      </div>
      <div className="grid grid-cols-2 gap-2">
        <div className="relative">
          <CornerUpLeft className="absolute left-2 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            type="number"
            className="pl-7"
            placeholder="SS"
            value={parseValue(effectiveStyles.borderTopLeftRadius)}
            onChange={(e) => handleBorderRadiusChange('borderTopLeftRadius', e.target.value)}
          />
        </div>
        <div className="relative">
          <CornerUpRight className="absolute left-2 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            type="number"
            className="pl-7"
            placeholder="SD"
            value={parseValue(effectiveStyles.borderTopRightRadius)}
            onChange={(e) => handleBorderRadiusChange('borderTopRightRadius', e.target.value)}
          />
        </div>
        <div className="relative">
          <CornerDownLeft className="absolute left-2 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            type="number"
            className="pl-7"
            placeholder="JS"
            value={parseValue(effectiveStyles.borderBottomLeftRadius)}
            onChange={(e) => handleBorderRadiusChange('borderBottomLeftRadius', e.target.value)}
          />
        </div>
        <div className="relative">
          <CornerDownRight className="absolute left-2 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            type="number"
            className="pl-7"
            placeholder="JD"
            value={parseValue(effectiveStyles.borderBottomRightRadius)}
            onChange={(e) => handleBorderRadiusChange('borderBottomRightRadius', e.target.value)}
          />
        </div>
      </div>

      <div className="flex justify-between items-center">
        <Label className="text-sm font-medium">Umbră</Label>
      </div>
      <BoxShadowControl
        value={effectiveStyles.boxShadow as string}
        onChange={handleBoxShadowChange}
      />
    </div>
  );
}
