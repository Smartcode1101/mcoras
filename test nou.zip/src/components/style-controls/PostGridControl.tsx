'use client';

import { useState, useEffect } from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import type { ResponsiveValue } from '@/lib/types';
import { useEditor } from '@/contexts/editor-context';

interface PostGridControlProps {
  props: {
    postsPerPage?: number;
    showExcerpt?: boolean;
    excerptLength?: number;
    thumbnailWidth?: ResponsiveValue<number>;
    thumbnailHeight?: ResponsiveValue<number>;
    columns?: ResponsiveValue<number>;
    buttonText?: string;
    buttonStyle?: {
      backgroundColor?: string;
      backgroundGradient?: string;
      color?: string;
      borderRadius?: number;
      padding?: { top: number; bottom: number; left: number; right: number };
    };
  };
  onPropsChange: (newProps: { [key: string]: any }) => void;
}

export function PostGridControl({ props, onPropsChange }: PostGridControlProps) {
  const { state } = useEditor();
  const [activeTab, setActiveTab] = useState('grid');

  // Force re-render when responsive mode changes
  const [renderKey, setRenderKey] = useState(0);

  useEffect(() => {
    setRenderKey(prev => prev + 1);
  }, [state.responsiveMode]);

  const handleNumberChange = (key: string, value: number) => {
    onPropsChange({ [key]: value });
  };

  const handleResponsiveNumberChange = (key: string, mode: 'desktop' | 'tablet' | 'mobile', value: number) => {
    const currentValue = props[key as keyof typeof props] as ResponsiveValue<number> || {};
    const newValue = {
      ...currentValue,
      [mode]: value
    };
    
    // Debug logging for column changes (only when value actually changes)
    if (key === 'columns' && process.env.NODE_ENV === 'development' && currentValue[mode] !== value) {
      console.log('PostGrid Column Update:', {
        property: key,
        mode,
        previousValue: currentValue[mode],
        newValue: value,
        fullObject: newValue,
        responsiveMode: state.responsiveMode
      });
    }
    
    onPropsChange({ [key]: newValue });
    
    // Only keep mobile/tablet values if they're different from desktop for better responsive behavior
    if (mode !== 'desktop' && currentValue.desktop === value) {
      const cleanedValue = { ...newValue };
      delete cleanedValue[mode];
      onPropsChange({ [key]: cleanedValue });
    }
  };

  const handleResponsiveNumberUpdate = (key: string, mode: 'desktop' | 'tablet' | 'mobile', value: number) => {
    handleResponsiveNumberChange(key, mode, value);
  };

  const handleSwitchChange = (key: string, value: boolean) => {
    onPropsChange({ [key]: value });
  };

  const handleTextChange = (key: string, value: string) => {
    onPropsChange({ [key]: value });
  };

  const handleButtonStyleChange = (key: string, value: any) => {
    const currentStyle = props.buttonStyle || {};
    onPropsChange({
      buttonStyle: {
        ...currentStyle,
        [key]: value
      }
    });
  };

  const createGradient = (color1: string, color2: string, direction: string = 'to right') => {
    return `linear-gradient(${direction}, ${color1}, ${color2})`;
  };

  return (
    <div className="space-y-4" key={`postgrid-control-${renderKey}`}>
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="grid">Grilă</TabsTrigger>
          <TabsTrigger value="thumbnails">Miniaturi</TabsTrigger>
          <TabsTrigger value="button">Buton</TabsTrigger>
        </TabsList>

        <TabsContent value="grid" className="space-y-4 mt-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Configurare Coloane</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Desktop columns */}
              <div className="space-y-2">
                <Label htmlFor="desktop-columns" className="text-sm">
                  Desktop - Coloane 
                  {state.responsiveMode === 'desktop' && (
                    <span className="ml-2 text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">ACTUAL</span>
                  )}
                </Label>
                <Input
                  id="desktop-columns"
                  type="number"
                  min="1"
                  max="6"
                  value={props.columns?.desktop || 4}
                  onChange={(e) => handleResponsiveNumberUpdate('columns', 'desktop', parseInt(e.target.value) || 1)}
                />
              </div>

              {/* Tablet columns */}
              <div className="space-y-2">
                <Label htmlFor="tablet-columns" className="text-sm">
                  Tabletă - Coloane 
                  {state.responsiveMode === 'tablet' && (
                    <span className="ml-2 text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">ACTUAL</span>
                  )}
                </Label>
                <Input
                  id="tablet-columns"
                  type="number"
                  min="1"
                  max="4"
                  value={props.columns?.tablet || 2}
                  onChange={(e) => handleResponsiveNumberUpdate('columns', 'tablet', parseInt(e.target.value) || 1)}
                />
              </div>

              {/* Mobile columns */}
              <div className="space-y-2">
                <Label htmlFor="mobile-columns" className="text-sm">
                  Telefon - Coloane 
                  {state.responsiveMode === 'mobile' && (
                    <span className="ml-2 text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">ACTUAL</span>
                  )}
                </Label>
                <Input
                  id="mobile-columns"
                  type="number"
                  min="1"
                  max="2"
                  value={props.columns?.mobile || 1}
                  onChange={(e) => handleResponsiveNumberUpdate('columns', 'mobile', parseInt(e.target.value) || 1)}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Conținut</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="posts-per-page" className="text-sm">Postări pe pagină</Label>
                <Input
                  id="posts-per-page"
                  type="number"
                  min="1"
                  max="50"
                  value={props.postsPerPage || 12}
                  onChange={(e) => handleNumberChange('postsPerPage', parseInt(e.target.value) || 1)}
                />
              </div>

              <div className="flex items-center space-x-2">
                <Switch
                  id="show-excerpt"
                  checked={props.showExcerpt !== false}
                  onCheckedChange={(checked) => handleSwitchChange('showExcerpt', checked)}
                />
                <Label htmlFor="show-excerpt" className="text-sm">Afișează fragmentul</Label>
              </div>

              {props.showExcerpt !== false && (
                <div className="space-y-2">
                  <Label htmlFor="excerpt-length" className="text-sm">Lungime fragment (caractere)</Label>
                  <Input
                    id="excerpt-length"
                    type="number"
                    min="50"
                    max="500"
                    value={props.excerptLength || 150}
                    onChange={(e) => handleNumberChange('excerptLength', parseInt(e.target.value) || 150)}
                  />
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="thumbnails" className="space-y-4 mt-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Dimensiuni Miniaturi</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Desktop thumbnail size */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="desktop-width" className="text-sm">Lățime Desktop</Label>
                  <Input
                    id="desktop-width"
                    type="number"
                    min="100"
                    max="600"
                    value={props.thumbnailWidth?.desktop || 300}
                    onChange={(e) => handleResponsiveNumberUpdate('thumbnailWidth', 'desktop', parseInt(e.target.value) || 300)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="desktop-height" className="text-sm">Înălțime Desktop</Label>
                  <Input
                    id="desktop-height"
                    type="number"
                    min="100"
                    max="400"
                    value={props.thumbnailHeight?.desktop || 200}
                    onChange={(e) => handleResponsiveNumberUpdate('thumbnailHeight', 'desktop', parseInt(e.target.value) || 200)}
                  />
                </div>
              </div>

              {/* Tablet thumbnail size */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="tablet-width" className="text-sm">Lățime Tabletă</Label>
                  <Input
                    id="tablet-width"
                    type="number"
                    min="100"
                    max="500"
                    value={props.thumbnailWidth?.tablet || 250}
                    onChange={(e) => handleResponsiveNumberUpdate('thumbnailWidth', 'tablet', parseInt(e.target.value) || 250)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="tablet-height" className="text-sm">Înălțime Tabletă</Label>
                  <Input
                    id="tablet-height"
                    type="number"
                    min="100"
                    max="350"
                    value={props.thumbnailHeight?.tablet || 180}
                    onChange={(e) => handleResponsiveNumberUpdate('thumbnailHeight', 'tablet', parseInt(e.target.value) || 180)}
                  />
                </div>
              </div>

              {/* Mobile thumbnail size */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="mobile-width" className="text-sm">Lățime Telefon</Label>
                  <Input
                    id="mobile-width"
                    type="number"
                    min="100"
                    max="400"
                    value={props.thumbnailWidth?.mobile || 200}
                    onChange={(e) => handleResponsiveNumberUpdate('thumbnailWidth', 'mobile', parseInt(e.target.value) || 200)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="mobile-height" className="text-sm">Înălțime Telefon</Label>
                  <Input
                    id="mobile-height"
                    type="number"
                    min="100"
                    max="300"
                    value={props.thumbnailHeight?.mobile || 150}
                    onChange={(e) => handleResponsiveNumberUpdate('thumbnailHeight', 'mobile', parseInt(e.target.value) || 150)}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="button" className="space-y-4 mt-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Text Buton</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <Label htmlFor="button-text" className="text-sm">Text afișat</Label>
                <Input
                  id="button-text"
                  value={props.buttonText || 'Citește mai mult'}
                  onChange={(e) => handleTextChange('buttonText', e.target.value)}
                  placeholder="Citește mai mult"
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Stil Buton</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="button-color" className="text-sm">Culoare text</Label>
                <Input
                  id="button-color"
                  type="color"
                  value={props.buttonStyle?.color || '#ffffff'}
                  onChange={(e) => handleButtonStyleChange('color', e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label className="text-sm">Tip fundal</Label>
                <Select 
                  value={props.buttonStyle?.backgroundGradient ? 'gradient' : 'solid'}
                  onValueChange={(value) => {
                    if (value === 'solid') {
                      handleButtonStyleChange('backgroundGradient', undefined);
                    }
                  }}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="solid">Culoare simplă</SelectItem>
                    <SelectItem value="gradient">Degrade</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {props.buttonStyle?.backgroundGradient ? (
                <div className="grid grid-cols-2 gap-2">
                  <div className="space-y-2">
                    <Label htmlFor="gradient-color-1" className="text-sm">Culoare 1</Label>
                    <Input
                      id="gradient-color-1"
                      type="color"
                      value={props.buttonStyle?.backgroundColor || '#3b82f6'}
                      onChange={(e) => {
                        const color2 = props.buttonStyle?.backgroundColor || '#1d4ed8';
                        handleButtonStyleChange('backgroundGradient', createGradient(e.target.value, color2));
                      }}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="gradient-color-2" className="text-sm">Culoare 2</Label>
                    <Input
                      id="gradient-color-2"
                      type="color"
                      value={props.buttonStyle?.backgroundColor || '#1d4ed8'}
                      onChange={(e) => {
                        const color1 = props.buttonStyle?.backgroundColor || '#3b82f6';
                        handleButtonStyleChange('backgroundGradient', createGradient(color1, e.target.value));
                      }}
                    />
                  </div>
                </div>
              ) : (
                <div className="space-y-2">
                  <Label htmlFor="button-bg-color" className="text-sm">Culoare fundal</Label>
                  <Input
                    id="button-bg-color"
                    type="color"
                    value={props.buttonStyle?.backgroundColor || '#3b82f6'}
                    onChange={(e) => handleButtonStyleChange('backgroundColor', e.target.value)}
                  />
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="button-border-radius" className="text-sm">Rotunjire colțuri (px)</Label>
                <Input
                  id="button-border-radius"
                  type="number"
                  min="0"
                  max="50"
                  value={props.buttonStyle?.borderRadius || 8}
                  onChange={(e) => handleButtonStyleChange('borderRadius', parseInt(e.target.value) || 8)}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="button-padding-x" className="text-sm">Padding X</Label>
                  <Input
                    id="button-padding-x"
                    type="number"
                    min="8"
                    max="40"
                    value={props.buttonStyle?.padding?.left || 20}
                    onChange={(e) => {
                      const currentPadding = props.buttonStyle?.padding || { top: 12, bottom: 12, left: 20, right: 20 };
                      handleButtonStyleChange('padding', { ...currentPadding, left: parseInt(e.target.value) || 20, right: parseInt(e.target.value) || 20 });
                    }}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="button-padding-y" className="text-sm">Padding Y</Label>
                  <Input
                    id="button-padding-y"
                    type="number"
                    min="4"
                    max="20"
                    value={props.buttonStyle?.padding?.top || 12}
                    onChange={(e) => {
                      const currentPadding = props.buttonStyle?.padding || { top: 12, bottom: 12, left: 20, right: 20 };
                      handleButtonStyleChange('padding', { ...currentPadding, top: parseInt(e.target.value) || 12, bottom: parseInt(e.target.value) || 12 });
                    }}
                  />
                </div>
              </div>

              {/* Preview button */}
              <div className="pt-4">
                <Label className="text-sm">Previzualizare</Label>
                <div className="mt-2">
                  <Button
                    style={{
                      background: props.buttonStyle?.backgroundGradient || props.buttonStyle?.backgroundColor || '#3b82f6',
                      color: props.buttonStyle?.color || '#ffffff',
                      borderRadius: `${props.buttonStyle?.borderRadius || 8}px`,
                      padding: `${props.buttonStyle?.padding?.top || 12}px ${props.buttonStyle?.padding?.left || 20}px`,
                    }}
                    className="w-full"
                  >
                    {props.buttonText || 'Citește mai mult'}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}