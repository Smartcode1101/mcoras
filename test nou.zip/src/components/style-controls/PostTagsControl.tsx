'use client';

import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import type { CSSProperties } from 'react';

interface PostTagsControlProps {
  props: {
    label?: string;
    showLabel?: boolean;
    buttonStyle?: CSSProperties;
  };
  onPropsChange: (newProps: { [key: string]: any }) => void;
}

export function PostTagsControl({ props, onPropsChange }: PostTagsControlProps) {
  const handleTextChange = (key: string, value: string) => {
    onPropsChange({ [key]: value });
  };

  const handleSwitchChange = (key: string, value: boolean) => {
    onPropsChange({ [key]: value });
  };

  const handleButtonStyleChange = (key: string, value: any) => {
    const currentStyle = props.buttonStyle || {};
    onPropsChange({
      buttonStyle: {
        ...currentStyle,
        [key]: value
      }
    });
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="text-sm">Setări Etichetă</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center space-x-2">
            <Switch
              id="show-label"
              checked={props.showLabel !== false}
              onCheckedChange={(checked) => handleSwitchChange('showLabel', checked)}
            />
            <Label htmlFor="show-label" className="text-sm">Afișează eticheta</Label>
          </div>

          {props.showLabel !== false && (
            <div className="space-y-2">
              <Label htmlFor="label-text" className="text-sm">Text etichetă</Label>
              <Input
                id="label-text"
                value={props.label || 'Tag-uri:'}
                onChange={(e) => handleTextChange('label', e.target.value)}
                placeholder="Tag-uri:"
              />
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-sm">Stil Butoane</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="button-bg-color" className="text-sm">Culoare fundal</Label>
            <Input
              id="button-bg-color"
              type="color"
              value={(props.buttonStyle?.backgroundColor as string) || '#3b82f6'}
              onChange={(e) => handleButtonStyleChange('backgroundColor', e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="button-text-color" className="text-sm">Culoare text</Label>
            <Input
              id="button-text-color"
              type="color"
              value={(props.buttonStyle?.color as string) || '#ffffff'}
              onChange={(e) => handleButtonStyleChange('color', e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="button-border-radius" className="text-sm">Rotunjire colțuri (px)</Label>
            <Input
              id="button-border-radius"
              type="number"
              min="0"
              max="50"
              value={parseInt(String(props.buttonStyle?.borderRadius)) || 20}
              onChange={(e) => handleButtonStyleChange('borderRadius', `${e.target.value}px`)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="button-font-size" className="text-sm">Dimensiune font (px)</Label>
            <Input
              id="button-font-size"
              type="number"
              min="10"
              max="24"
              value={parseInt(String(props.buttonStyle?.fontSize)) || 14}
              onChange={(e) => handleButtonStyleChange('fontSize', `${e.target.value}px`)}
            />
          </div>

          {/* Preview */}
          <div className="pt-4">
            <Label className="text-sm">Previzualizare</Label>
            <div className="mt-2 flex flex-wrap gap-2">
              <span
                style={{
                  display: 'inline-block',
                  padding: '6px 14px',
                  backgroundColor: (props.buttonStyle?.backgroundColor as string) || '#3b82f6',
                  color: (props.buttonStyle?.color as string) || '#ffffff',
                  borderRadius: props.buttonStyle?.borderRadius || '20px',
                  fontSize: props.buttonStyle?.fontSize || '0.875rem',
                  fontWeight: '500',
                }}
              >
                Exemplu Tag
              </span>
              <span
                style={{
                  display: 'inline-block',
                  padding: '6px 14px',
                  backgroundColor: (props.buttonStyle?.backgroundColor as string) || '#3b82f6',
                  color: (props.buttonStyle?.color as string) || '#ffffff',
                  borderRadius: props.buttonStyle?.borderRadius || '20px',
                  fontSize: props.buttonStyle?.fontSize || '0.875rem',
                  fontWeight: '500',
                }}
              >
                Alt Tag
              </span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
