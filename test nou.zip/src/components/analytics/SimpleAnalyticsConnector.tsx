'use client';

import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  CheckCircle, 
  XCircle, 
  ExternalLink, 
  RefreshCw, 
  Settings, 
  Globe, 
  Calendar,
  AlertCircle,
  Zap,
  Wand2,
  Shield,
  Play
} from 'lucide-react';

interface SimpleAnalyticsConfig {
  measurementId: string;
  enabled: boolean;
}

export default function SimpleAnalyticsConnector() {
  const [mode, setMode] = useState<'auto' | 'manual'>('auto');
  const [config, setConfig] = useState<SimpleAnalyticsConfig>({
    measurementId: '',
    enabled: false,
  });
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);

  // Încarcă configurația la mount
  React.useEffect(() => {
    loadSimpleConfig();
  }, []);

  const loadSimpleConfig = async () => {
    try {
      const response = await fetch('/api/analytics/simple/config');
      const data = await response.json();
      if (data.success) {
        setConfig(data.config);
      }
    } catch (error) {
      console.error('Error loading simple config:', error);
    }
  };

  const handleSaveSimple = async () => {
    if (!config.measurementId) {
      alert('Te rog să introduci un Measurement ID valid');
      return;
    }

    setSaving(true);
    try {
      const response = await fetch('/api/analytics/simple/config', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(config),
      });

      const data = await response.json();
      
      if (data.success) {
        alert('✅ Google Analytics configurat cu succes!');
        loadSimpleConfig();
      } else {
        alert(`❌ ${data.error}`);
      }
    } catch (error) {
      console.error('Error saving simple config:', error);
      alert('❌ Eroare la salvarea configurației');
    } finally {
      setSaving(false);
    }
  };

  const handleTestTracking = async () => {
    setTesting(true);
    try {
      const response = await fetch('/api/analytics/simple/test', {
        method: 'POST',
      });

      const data = await response.json();
      
      if (data.success) {
        alert('✅ Test tracking trimis cu succes! Verifică Google Analytics Real-time.');
      } else {
        alert(`❌ ${data.error}`);
      }
    } catch (error) {
      console.error('Error testing tracking:', error);
      alert('❌ Eroare la testarea tracking-ului');
    } finally {
      setTesting(false);
    }
  };

  const openGoogleAnalyticsHelp = () => {
    window.open('https://support.google.com/analytics/answer/10089681', '_blank');
  };

  const getMeasurementIdHelp = () => {
    window.open('https://analytics.google.com/analytics/web/#/a538348p321882559/admin/property/item', '_blank');
  };

  return (
    <div className="space-y-6">
      {/* Header cu Toggle între moduri */}
      <Card className="w-full">
        <CardHeader className="pb-4">
          <CardTitle className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <Zap className="h-5 w-5" />
              <span className="text-lg">Google Analytics 4 - Setup Simplu</span>
            </div>
            <div className="flex gap-2 w-full sm:w-auto">
              <Button
                variant={mode === 'auto' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setMode('auto')}
                className="flex-1 sm:flex-none"
              >
                <Wand2 className="h-4 w-4 mr-1" />
                Mod Simplu
              </Button>
              <Button
                variant={mode === 'manual' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setMode('manual')}
                className="flex-1 sm:flex-none"
              >
                <Settings className="h-4 w-4 mr-1" />
                OAuth Avansat
              </Button>
            </div>
          </CardTitle>
          <CardDescription>
            Activează Google Analytics în câteva secunde, ca în pluginurile WordPress!
          </CardDescription>
        </CardHeader>
      </Card>

      {mode === 'auto' ? (
        /* MOD SIMPLU - ca pluginurile WordPress */
        <Card className="w-full">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Wand2 className="h-5 w-5 text-purple-600" />
              Mod Simplu - Setup în 30 Secunde
            </CardTitle>
            <CardDescription>
              Introdu doar Measurement ID-ul și gata! Nu ai nevoie de configurări complexe OAuth.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Status actual */}
            {config.enabled && config.measurementId ? (
              <div className="p-4 border border-green-200 bg-green-50 rounded-lg">
                <div className="flex items-center gap-3">
                  <CheckCircle className="h-6 w-6 text-green-600" />
                  <div>
                    <h4 className="font-semibold text-green-800">Google Analytics Activ!</h4>
                    <p className="text-sm text-green-700 mt-1">
                      Measurement ID: <code className="bg-green-100 px-2 py-1 rounded">{config.measurementId}</code>
                    </p>
                    <p className="text-xs text-green-600 mt-1">
                      Tracking-ul este activ pentru toate paginile
                    </p>
                  </div>
                </div>
              </div>
            ) : (
              <div className="p-4 border border-yellow-200 bg-yellow-50 rounded-lg">
                <div className="flex items-center gap-3">
                  <AlertCircle className="h-6 w-6 text-yellow-600" />
                  <div>
                    <h4 className="font-semibold text-yellow-800">Google Analytics Neconfigurat</h4>
                    <p className="text-sm text-yellow-700 mt-1">
                      Introdu Measurement ID-ul pentru a activa tracking-ul
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* Formularul de configurare */}
            <div className="space-y-4">
              <div>
                <Label htmlFor="measurementId" className="text-sm font-medium">
                  Measurement ID (G-XXXXXXXXXX)
                </Label>
                <div className="flex flex-col sm:flex-row gap-2 mt-1">
                  <Input
                    id="measurementId"
                    placeholder="G-XXXXXXXXXX"
                    value={config.measurementId}
                    onChange={(e) => setConfig(prev => ({ ...prev, measurementId: e.target.value }))}
                    className="flex-1"
                  />
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={getMeasurementIdHelp}
                    className="sm:w-auto w-full"
                  >
                    <ExternalLink className="h-4 w-4 sm:mr-0 mr-2" />
                    <span className="sm:hidden">Ajutor</span>
                  </Button>
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  Găsește Measurement ID-ul în Google Analytics → Admin → Data Streams → Web stream
                </p>
              </div>

              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="enabled"
                  checked={config.enabled}
                  onChange={(e) => setConfig(prev => ({ ...prev, enabled: e.target.checked }))}
                  className="h-4 w-4 text-blue-600 rounded"
                />
                <Label htmlFor="enabled" className="text-sm">
                  Activează Google Analytics tracking
                </Label>
              </div>
            </div>

            {/* Butoanele de acțiune */}
            <div className="flex flex-col sm:flex-row gap-2">
              <Button 
                onClick={handleSaveSimple}
                disabled={saving || !config.measurementId}
                className="flex-1 order-2 sm:order-1"
              >
                {saving ? (
                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                ) : (
                  <Shield className="h-4 w-4 mr-2" />
                )}
                {config.enabled ? 'Actualizează Configurarea' : 'Activează Google Analytics'}
              </Button>

              {config.enabled && (
                <Button 
                  onClick={handleTestTracking}
                  disabled={testing}
                  variant="outline"
                  className="order-1 sm:order-2"
                >
                  {testing ? (
                    <RefreshCw className="h-4 w-4 mr-1 animate-spin" />
                  ) : (
                    <Play className="h-4 w-4 mr-1" />
                  )}
                  Test
                </Button>
              )}
            </div>


          </CardContent>
        </Card>
      ) : (
        /* MOD MANUAL - OAuth avansat (existent) */
        <Card className="w-full">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Settings className="h-5 w-5" />
              OAuth Avansat
            </CardTitle>
            <CardDescription>
              Pentru utilizatori avansați care doresc configurare automată prin Google OAuth.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-center py-8">
              <p className="text-gray-600 mb-4">
                Modul OAuth necesită configurare în Google Cloud Console.
              </p>
              <Button 
                onClick={() => window.location.href = '/admin/analytics?tab=oauth'}
                variant="outline"
              >
                <Settings className="h-4 w-4 mr-2" />
                Mergi la Setup OAuth
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Link către Google Analytics Real-time */}
      {config.enabled && (
        <Card className="w-full">
          <CardContent className="p-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h4 className="font-semibold">Verifică Tracking-ul</h4>
                <p className="text-sm text-gray-600">
                  Accesează Google Analytics Real-time pentru a vedea vizitatorii live
                </p>
              </div>
              <Button 
                onClick={() => window.open('https://analytics.google.com/analytics/web/#/realtime', '_blank')}
                variant="outline"
                className="sm:w-auto w-full"
              >
                <ExternalLink className="h-4 w-4 mr-2" />
                GA4 Real-time
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}