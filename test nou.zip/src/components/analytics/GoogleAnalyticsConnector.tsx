'use client';

import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  CheckCircle, 
  XCircle, 
  ExternalLink, 
  RefreshCw, 
  Settings, 
  Globe, 
  Calendar,
  AlertCircle,
  Zap
} from 'lucide-react';

interface GoogleAnalyticsProperty {
  id: string;
  name: string;
  websiteUrl?: string;
  industryVertical?: string;
  country?: string;
  currency?: string;
  timezone?: string;
  measurementId?: string;
}

interface ConnectionState {
  connected: boolean;
  properties: GoogleAnalyticsProperty[];
  selected?: GoogleAnalyticsProperty;
  connectedAt?: string;
}

export default function GoogleAnalyticsConnector() {
  const [connectionState, setConnectionState] = useState<ConnectionState>({
    connected: false,
    properties: [],
  });
  const [loading, setLoading] = useState(false);
  const [selecting, setSelecting] = useState<string | null>(null);
  const [disconnecting, setDisconnecting] = useState(false);

  // Încarcă starea conexiunii la mount
  useEffect(() => {
    fetchConnectionState();
  }, []);

  const fetchConnectionState = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/analytics/google/properties');
      const data = await response.json();
      
      if (data.success) {
        setConnectionState({
          connected: data.connected,
          properties: data.properties || [],
          selected: data.selected,
          connectedAt: data.connectedAt,
        });
      }
    } catch (error) {
      console.error('Error fetching connection state:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleConnect = () => {
    // Redirect către Google OAuth
    window.location.href = '/api/analytics/google/auth';
  };

  const handleSelectProperty = async (propertyId: string) => {
    setSelecting(propertyId);
    try {
      const response = await fetch('/api/analytics/google/select', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ propertyId }),
      });

      const data = await response.json();
      
      if (data.success) {
        // Actualizează starea locală
        const selectedProperty = connectionState.properties.find(p => p.id === propertyId);
        setConnectionState(prev => ({
          ...prev,
          selected: selectedProperty,
        }));
        
        alert(`✅ ${data.message}`);
        
        // Reîncarcă pagina pentru a activa tracking-ul
        setTimeout(() => {
          window.location.reload();
        }, 1500);
      } else {
        alert(`❌ ${data.error}`);
      }
    } catch (error) {
      console.error('Error selecting property:', error);
      alert('❌ Eroare la selectarea proprietății');
    } finally {
      setSelecting(null);
    }
  };

  const handleDisconnect = async () => {
    if (!confirm('Sigur vrei să deconectezi Google Analytics? Tracking-ul va fi oprit.')) {
      return;
    }

    setDisconnecting(true);
    try {
      const response = await fetch('/api/analytics/google/disconnect', {
        method: 'POST',
      });

      const data = await response.json();
      
      if (data.success) {
        setConnectionState({
          connected: false,
          properties: [],
        });
        alert('✅ Google Analytics deconectat cu succes!');
        
        // Reîncarcă pagina pentru a opri tracking-ul
        setTimeout(() => {
          window.location.reload();
        }, 1500);
      } else {
        alert(`❌ ${data.error}`);
      }
    } catch (error) {
      console.error('Error disconnecting:', error);
      alert('❌ Eroare la deconectarea Google Analytics');
    } finally {
      setDisconnecting(false);
    }
  };

  if (loading) {
    return (
      <Card className="w-full">
        <CardContent className="p-6">
          <div className="flex items-center justify-center">
            <RefreshCw className="h-6 w-6 animate-spin mr-2" />
            <span>Se încarcă statusul Google Analytics...</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Status Connection */}
      <Card className="w-full">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Globe className="h-5 w-5" />
              Google Analytics 4 - Conectare Automată
            </div>
            {connectionState.connected ? (
              <Badge variant="default" className="bg-green-500">
                <CheckCircle className="h-3 w-3 mr-1" />
                Conectat
              </Badge>
            ) : (
              <Badge variant="destructive">
                <XCircle className="h-3 w-3 mr-1" />
                Deconectat
              </Badge>
            )}
          </CardTitle>
          <CardDescription>
            Conectează-te cu contul tău Google pentru a selecta proprietatea Analytics și a activa tracking-ul automat.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {!connectionState.connected ? (
            <div className="space-y-4">
              <div className="p-4 border border-yellow-200 bg-yellow-50 rounded-lg">
                <div className="flex items-start gap-3">
                  <AlertCircle className="h-5 w-5 text-yellow-600 mt-0.5" />
                  <div>
                    <h4 className="font-semibold text-yellow-800">Configurare Rapidă</h4>
                    <p className="text-sm text-yellow-700 mt-1">
                      Click pe butonul de mai jos pentru a te conecta cu Google și a selecta proprietatea ta Analytics.
                      Tracking-ul se va activa automat!
                    </p>
                  </div>
                </div>
              </div>
              
              <Button onClick={handleConnect} className="w-full">
                <svg className="w-5 h-5 mr-2" viewBox="0 0 24 24">
                  <path fill="currentColor" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                  <path fill="currentColor" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                  <path fill="currentColor" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                  <path fill="currentColor" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                </svg>
                Conectează cu Google Analytics
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {/* Connected Info */}
              <div className="p-4 border border-green-200 bg-green-50 rounded-lg">
                <div className="flex items-start gap-3">
                  <CheckCircle className="h-5 w-5 text-green-600 mt-0.5" />
                  <div className="flex-1">
                    <h4 className="font-semibold text-green-800">Conectat cu succes!</h4>
                    {connectionState.connectedAt && (
                      <p className="text-sm text-green-700 mt-1">
                        Conectat pe: {new Date(connectionState.connectedAt).toLocaleDateString('ro-RO', {
                          year: 'numeric',
                          month: 'long',
                          day: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </p>
                    )}
                  </div>
                </div>
              </div>

              {/* Selected Property */}
              {connectionState.selected && (
                <div className="p-4 border border-blue-200 bg-blue-50 rounded-lg">
                  <div className="flex items-start gap-3">
                    <Zap className="h-5 w-5 text-blue-600 mt-0.5" />
                    <div className="flex-1">
                      <h4 className="font-semibold text-blue-800">Proprietate Selectată</h4>
                      <p className="text-sm text-blue-700 mt-1">
                        <strong>{connectionState.selected.name}</strong>
                      </p>
                      {connectionState.selected.websiteUrl && (
                        <p className="text-sm text-blue-600 mt-1">
                          🌐 {connectionState.selected.websiteUrl}
                        </p>
                      )}
                      {connectionState.selected.measurementId && (
                        <p className="text-sm text-blue-600 mt-1">
                          📊 Measurement ID: <code className="bg-blue-100 px-1 rounded">{connectionState.selected.measurementId}</code>
                        </p>
                      )}
                      <p className="text-sm text-green-700 mt-2 font-medium">
                        ✅ Tracking-ul este activ pentru toate paginile!
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* Actions */}
              <div className="flex gap-2">
                <Button onClick={fetchConnectionState} variant="outline" size="sm">
                  <RefreshCw className="h-4 w-4 mr-1" />
                  Refresh
                </Button>
                
                <Button onClick={handleDisconnect} variant="destructive" size="sm" disabled={disconnecting}>
                  {disconnecting ? (
                    <RefreshCw className="h-4 w-4 mr-1 animate-spin" />
                  ) : (
                    <XCircle className="h-4 w-4 mr-1" />
                  )}
                  Deconectează
                </Button>

                <Button 
                  onClick={() => window.open('https://analytics.google.com/analytics/web/#/realtime', '_blank')} 
                  variant="outline" 
                  size="sm"
                >
                  <ExternalLink className="h-4 w-4 mr-1" />
                  GA4 Real-time
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Properties List */}
      {connectionState.connected && connectionState.properties.length > 0 && (
        <Card className="w-full">
          <CardHeader>
            <CardTitle>Proprietățile Tale Google Analytics</CardTitle>
            <CardDescription>
              Selectează proprietatea pe care vrei să o monitorizezi. Tracking-ul se va activa imediat.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {connectionState.properties.map((property) => (
              <div
                key={property.id}
                className={`p-4 border rounded-lg transition-all cursor-pointer hover:shadow-md ${
                  connectionState.selected?.id === property.id
                    ? 'border-green-500 bg-green-50'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
                onClick={() => handleSelectProperty(property.id)}
              >
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h4 className="font-semibold">{property.name}</h4>
                      {connectionState.selected?.id === property.id && (
                        <Badge variant="default" className="bg-green-500">
                          <CheckCircle className="h-3 w-3 mr-1" />
                          Selectat
                        </Badge>
                      )}
                    </div>
                    
                    <div className="space-y-1 text-sm text-gray-600">
                      {property.websiteUrl && (
                        <div className="flex items-center gap-1">
                          <Globe className="h-3 w-3" />
                          {property.websiteUrl}
                        </div>
                      )}
                      
                      {property.industryVertical && (
                        <div>📂 {property.industryVertical}</div>
                      )}
                      
                      {property.currency && property.timezone && (
                        <div className="flex items-center gap-4">
                          <span>💰 {property.currency}</span>
                          <span>🕐 {property.timezone}</span>
                        </div>
                      )}

                      {property.measurementId && (
                        <div className="mt-2">
                          <Badge variant="outline" className="text-xs">
                            📊 {property.measurementId}
                          </Badge>
                        </div>
                      )}
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    {selecting === property.id ? (
                      <RefreshCw className="h-4 w-4 animate-spin" />
                    ) : connectionState.selected?.id === property.id ? (
                      <CheckCircle className="h-5 w-5 text-green-500" />
                    ) : (
                      <Button size="sm" variant="outline">
                        Selectează
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}
    </div>
  );
}