'use client';

import { useEffect, useCallback } from 'react';
import { usePathname } from 'next/navigation';
import { ga4, type GA4PageView } from '@/lib/google-analytics';

export function AnalyticsProvider({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();

  // Inițializează GA4
  useEffect(() => {
    ga4.init();
  }, []);

  // Urmărește schimbările de pagină local (pentru dashboard-ul intern)
  const trackLocalPageView = useCallback(async (path: string) => {
    try {
      await fetch('/api/analytics/track', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          page: path,
          referrer: document.referrer || undefined,
        }),
      });
    } catch (error) {
      console.error('Local analytics tracking failed:', error);
    }
  }, []);

  // Urmărește schimbările de pagină
  const trackPageView = useCallback((path: string) => {
    const pageData: GA4PageView = {
      page_title: document.title,
      page_location: window.location.href,
      page_path: path,
    };

    // Urmărește cu Google Analytics 4
    ga4.trackPageView(pageData);

    // Urmărește și local pentru dashboard
    trackLocalPageView(path);

    console.log('Page view tracked:', path);
  }, [trackLocalPageView]);

  // Urmărește schimbările de pathname
  useEffect(() => {
    if (pathname) {
      // Exclude admin și auth pages de la tracking public GA4
      const shouldTrack = !pathname.startsWith('/admin') && !pathname.startsWith('/auth');
      
      if (shouldTrack) {
        trackPageView(pathname);
      }
    }
  }, [pathname, trackPageView]);

  return <>{children}</>;
}

export default AnalyticsProvider;