'use client';

import React, { useEffect, useState } from 'react';
import { useGA4Tracking } from '@/hooks/useGA4Tracking';

interface ExampleAnalyticsComponentProps {
  title?: string;
  showScrollTracking?: boolean;
  showTimeTracking?: boolean;
}

/**
 * Component exemplu pentru Google Analytics 4 Tracking
 * 
 * Acest component demonstrează cum să utilizezi tracking-ul GA4 pentru:
 * - Page views automate
 * - Button clicks
 * - Scroll tracking
 * - Time on page tracking
 * - Error tracking
 * - Search tracking
 */
export default function ExampleAnalyticsComponent({
  title = "Component de Exemplu GA4",
  showScrollTracking = true,
  showTimeTracking = true,
}: ExampleAnalyticsComponentProps) {
  const {
    trackButtonClick,
    trackScrollProgress,
    trackTimeOnPage,
    trackJavaScriptError,
    trackSearch,
    trackFormSubmit,
    trackEvent,
    isActive,
    measurementId,
  } = useGA4Tracking();

  const [searchTerm, setSearchTerm] = useState('');
  const [formData, setFormData] = useState({ name: '', email: '' });

  // Configurare tracking scroll și timp pe pagină
  useEffect(() => {
    let cleanupScroll: (() => void) | undefined;
    let cleanupTime: (() => void) | undefined;

    if (showScrollTracking) {
      cleanupScroll = trackScrollProgress('example-content', 25);
    }

    if (showTimeTracking) {
      cleanupTime = trackTimeOnPage();
    }

    return () => {
      if (cleanupScroll) cleanupScroll();
      if (cleanupTime) cleanupTime();
    };
  }, [showScrollTracking, showTimeTracking, trackScrollProgress, trackTimeOnPage]);

  // Handler pentru buton click
  const handleButtonClick = (buttonName: string, additionalData?: Record<string, any>) => {
    trackButtonClick(buttonName, 'Example Component', additionalData);
  };

  // Handler pentru căutare
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchTerm.trim()) {
      trackSearch(searchTerm, Math.floor(Math.random() * 100) + 1); // Simulare rezultate
      alert(`Căutare efectuată: "${searchTerm}"`);
    }
  };

  // Handler pentru form submit
  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const success = formData.name.length > 0 && formData.email.includes('@');
    
    trackFormSubmit('contact-form', success, {
      form_data: formData,
      user_agent: navigator.userAgent,
    });

    if (success) {
      alert('Formular trimis cu succes!');
      setFormData({ name: '', email: '' });
    } else {
      alert('Eroare în formular. Verifică datele.');
    }
  };

  // Handler pentru simularea unei erori
  const handleSimulateError = () => {
    try {
      throw new Error('Eroare simulată pentru testing GA4');
    } catch (error) {
      trackJavaScriptError(error as Error);
      alert('Eroare simulată trimisă la GA4');
    }
  };

  // Handler pentru eveniment custom
  const handleCustomEvent = () => {
    trackEvent({
      action: 'custom_interaction',
      category: 'engagement',
      label: 'exemplu-interactiune',
      value: Math.floor(Math.random() * 100),
      custom_parameters: {
        user_interaction_type: 'button_click',
        timestamp: new Date().toISOString(),
        random_value: Math.random(),
      },
    });
    alert('Eveniment custom trimis la GA4');
  };

  if (!isActive) {
    return (
      <div className="p-4 border-2 border-dashed border-gray-300 rounded-lg bg-gray-50">
        <h3 className="text-lg font-semibold text-gray-600 mb-2">Google Analytics 4 Inactiv</h3>
        <p className="text-gray-500">
          GA4 nu este configurat. Adaugă NEXT_PUBLIC_GA4_MEASUREMENT_ID în fișierul .env.local
        </p>
        <p className="text-sm text-gray-400 mt-2">
          Vezi fișierul .env.example pentru instrucțiuni
        </p>
      </div>
    );
  }

  return (
    <div className="p-6 border rounded-lg shadow-sm bg-white space-y-6" id="example-content">
      {/* Header */}
      <div className="border-b pb-4">
        <h2 className="text-2xl font-bold text-gray-800">{title}</h2>
        <p className="text-sm text-gray-600 mt-1">
          Google Analytics 4 Measurement ID: <code className="bg-gray-100 px-2 py-1 rounded">{measurementId}</code>
        </p>
      </div>

      {/* Status */}
      <div className="flex items-center gap-2">
        <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
        <span className="text-sm font-medium text-green-700">Google Analytics 4 Activ</span>
      </div>

      {/* Button Examples */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold">Exemple de Button Tracking</h3>
        <div className="grid grid-cols-2 gap-4">
          <button
            onClick={() => handleButtonClick('simple-button', { button_color: 'blue' })}
            className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
          >
            Buton Simplu
          </button>
          <button
            onClick={() => handleButtonClick('important-button', { 
              button_color: 'red', 
              priority: 'high' 
            })}
            className="px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600"
          >
            Buton Important
          </button>
        </div>
      </div>

      {/* Search Example */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold">Exemplu Search Tracking</h3>
        <form onSubmit={handleSearch} className="flex gap-2">
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Caută ceva..."
            className="flex-1 px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <button
            type="submit"
            className="px-4 py-2 bg-green-500 text-white rounded hover:bg-green-600"
          >
            Caută
          </button>
        </form>
      </div>

      {/* Form Example */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold">Exemplu Form Tracking</h3>
        <form onSubmit={handleFormSubmit} className="space-y-3">
          <input
            type="text"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            placeholder="Numele tău"
            className="w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
            required
          />
          <input
            type="email"
            value={formData.email}
            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            placeholder="Email-ul tău"
            className="w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
            required
          />
          <button
            type="submit"
            className="w-full px-4 py-2 bg-purple-500 text-white rounded hover:bg-purple-600"
          >
            Trimite Formularul
          </button>
        </form>
      </div>

      {/* Error and Custom Event Examples */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold">Evenimente Specializate</h3>
        <div className="grid grid-cols-2 gap-4">
          <button
            onClick={handleSimulateError}
            className="px-4 py-2 bg-orange-500 text-white rounded hover:bg-orange-600"
          >
            Simulează Eroare
          </button>
          <button
            onClick={handleCustomEvent}
            className="px-4 py-2 bg-indigo-500 text-white rounded hover:bg-indigo-600"
          >
            Eveniment Custom
          </button>
        </div>
      </div>

      {/* Instructions */}
      <div className="mt-6 p-4 bg-blue-50 rounded-lg">
        <h4 className="font-semibold text-blue-800 mb-2">Cum să utilizezi în proiectul tău:</h4>
        <div className="text-sm text-blue-700 space-y-1">
          <p>1. Adaugă Measurement ID-ul în .env.local: <code>NEXT_PUBLIC_GA4_MEASUREMENT_ID=G-XXXXXXXXXX</code></p>
          <p>2. Importă hook-ul: <code>import {'{ useGA4Tracking }'} from '@/hooks/useGA4Tracking'</code></p>
          <p>3. Folosește funcțiile de tracking în componentele tale</p>
          <p>4. Verifică rezultatele în Google Analytics 4</p>
        </div>
      </div>
    </div>
  );
}

// Export tipurile pentru utilizare în alte componente
export type { ExampleAnalyticsComponentProps };