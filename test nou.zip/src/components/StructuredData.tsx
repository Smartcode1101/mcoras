interface StructuredDataProps {
  schemas: Record<string, unknown>[];
}

export default function StructuredData({ schemas }: StructuredDataProps) {
  if (!schemas || schemas.length === 0) return null;

  return (
    <>
      {schemas.map((schema, index) => (
        <script
          key={index}
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }}
        />
      ))}
    </>
  );
}

// Funcție pentru generarea schemei NewsArticle
export function generateNewsArticleSchema(data: {
  title: string;
  description?: string;
  image?: string;
  datePublished: string;
  dateModified?: string;
  author?: string;
  publisherName?: string;
  publisherLogo?: string;
  url: string;
  siteUrl: string;
}): Record<string, unknown> {
  return {
    "@context": "https://schema.org",
    "@type": "NewsArticle",
    "headline": data.title,
    "image": data.image ? [`${data.siteUrl}${data.image}`] : [],
    "datePublished": data.datePublished,
    "dateModified": data.dateModified || data.datePublished,
    "author": {
      "@type": "Person",
      "name": data.author || "Admin"
    },
    "publisher": {
      "@type": "Organization",
      "name": data.publisherName || "Website",
      "url": data.siteUrl,
      "logo": {
        "@type": "ImageObject",
        "url": data.publisherLogo ? `${data.siteUrl}${data.publisherLogo}` : ''
      }
    },
    "description": data.description || '',
    "mainEntityOfPage": {
      "@type": "WebPage",
      "@id": data.url
    }
  };
}

// Funcție pentru generarea schemei WebPage
export function generateWebPageSchema(data: {
  title: string;
  description?: string;
  url: string;
  datePublished?: string;
  dateModified?: string;
  author?: string;
  publisherName?: string;
  siteUrl: string;
}): Record<string, unknown> {
  return {
    "@context": "https://schema.org",
    "@type": "WebPage",
    "name": data.title,
    "description": data.description || '',
    "url": data.url,
    "datePublished": data.datePublished,
    "dateModified": data.dateModified,
    "author": {
      "@type": "Person",
      "name": data.author || "Admin"
    },
    "publisher": {
      "@type": "Organization",
      "name": data.publisherName || "Website",
      "url": data.siteUrl
    }
  };
}

// Funcție pentru generarea schemei BreadcrumbList
export function generateBreadcrumbSchema(data: {
  items: Array<{ name: string; url: string }>;
}): Record<string, unknown> {
  return {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    "itemListElement": data.items.map((item, index) => ({
      "@type": "ListItem",
      "position": index + 1,
      "name": item.name,
      "item": item.url
    }))
  };
}

// Funcție pentru generarea schemei Organization
export function generateOrganizationSchema(data: {
  name: string;
  url: string;
  logo?: string;
  sameAs?: string[];
}): Record<string, unknown> {
  return {
    "@context": "https://schema.org",
    "@type": "Organization",
    "name": data.name,
    "url": data.url,
    "logo": data.logo ? `${data.url}${data.logo}` : undefined,
    "sameAs": data.sameAs || []
  };
}

// Funcție pentru generarea schemei CollectionPage (pentru categorii și arhive)
export function generateCollectionPageSchema(data: {
  title: string;
  description?: string;
  url: string;
  siteUrl: string;
}): Record<string, unknown> {
  return {
    "@context": "https://schema.org",
    "@type": "CollectionPage",
    "name": data.title,
    "description": data.description || '',
    "url": data.url,
    "mainEntity": {
      "@type": "ItemPage",
      "name": data.title
    }
  };
}
