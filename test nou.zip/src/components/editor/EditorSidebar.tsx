'use client';

import React, { useState, useEffect } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Settings, Brush, SquarePlus } from 'lucide-react';
import { useEditor } from '@/contexts/editor-context';
import { WidgetPanel } from './WidgetPanel';
import { StylePanel } from './StylePanel';
import { SettingsPanel } from './SettingsPanel';
import { useId } from 'react';

// Client-side only wrapper to prevent Radix UI tabs hydration issues
const ClientSideTabs = React.memo(({ 
  activeTab, 
  onTabChange, 
  children 
}: { 
  activeTab: string; 
  onTabChange: (value: string) => void;
  children: React.ReactNode;
}) => {
  const [isClient, setIsClient] = useState(false);
  const id = useId();

  useEffect(() => {
    setIsClient(true);
  }, []);

  // During SSR, don't render the tabs at all to avoid hydration mismatch
  if (!isClient) {
    return (
      <div className="flex-1 flex flex-col overflow-hidden">
        <div className="grid w-full grid-cols-3 rounded-none flex-shrink-0">
          <div className="flex items-center justify-center px-3 py-2 text-sm border-b-2 border-primary">
            <SquarePlus className="w-4 h-4 mr-2" />
            Widget-uri
          </div>
          <div className="flex items-center justify-center px-3 py-2 text-sm text-muted-foreground border-b">
            <Brush className="w-4 h-4 mr-2" />
            Stiluri
          </div>
          <div className="flex items-center justify-center px-3 py-2 text-sm text-muted-foreground border-b">
            <Settings className="w-4 h-4 mr-2" />
            Pagină
          </div>
        </div>
        <ScrollArea className="flex-1">
          <div className="p-4">
            <WidgetPanel />
          </div>
        </ScrollArea>
      </div>
    );
  }

  return (
    <Tabs
      value={activeTab}
      onValueChange={onTabChange}
      className="flex-1 flex flex-col overflow-hidden"
    >
      {children}
    </Tabs>
  );
});

ClientSideTabs.displayName = 'ClientSideTabs';

export function EditorSidebar({ className }: { className?: string }) {
  const { state, dispatch } = useEditor();

  const handleTabChange = (value: string) => {
    dispatch({
      type: 'SET_ACTIVE_TAB',
      payload: { tab: value as 'widgets' | 'styles' | 'settings' },
    });
  };

  return (
    <aside className={`w-64 min-w-64 max-w-80 border-r bg-card flex flex-col ${className || ''}`}>
      <ClientSideTabs 
        activeTab={state.activeSidebarTab}
        onTabChange={handleTabChange}
      >
        <TabsList className="grid w-full grid-cols-3 rounded-none flex-shrink-0">
          <TabsTrigger value="widgets">
            <SquarePlus className="w-4 h-4 mr-2" />
            Widget-uri
          </TabsTrigger>
          <TabsTrigger value="styles" disabled={!state.selectedElementId}>
            <Brush className="w-4 h-4 mr-2" />
            Stiluri
          </TabsTrigger>
          <TabsTrigger value="settings">
            <Settings className="w-4 h-4 mr-2" />
            Pagină
          </TabsTrigger>
        </TabsList>
        <ScrollArea className="flex-1">
          <div className="p-4 w-full">
            <TabsContent value="widgets" className="mt-0">
              <WidgetPanel />
            </TabsContent>
            <TabsContent value="styles" className="mt-0">
              <StylePanel />
            </TabsContent>
            <TabsContent value="settings" className="mt-0">
              <SettingsPanel />
            </TabsContent>
          </div>
        </ScrollArea>
      </ClientSideTabs>
    </aside>
  );
}
