'use client';
import { useState } from 'react';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Textarea } from '@/components/ui/textarea';
import { Sparkles } from 'lucide-react';
import { generateTitleIdeasAction } from '@/lib/actions';
import { useToast } from '@/hooks/use-toast';
import { Skeleton } from '../ui/skeleton';

const formSchema = z.object({
  description: z.string().min(10, {
    message: 'Descrierea trebuie să aibă cel puțin 10 caractere.',
  }),
});

interface TitleGeneratorProps {
  currentTitle: string;
  onTitleSelect: (title: string) => void;
}

export function TitleGenerator({ currentTitle, onTitleSelect }: TitleGeneratorProps) {
  const [ideas, setIdeas] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      description: '',
    },
  });

  async function onSubmit(values: z.infer<typeof formSchema>) {
    setIsLoading(true);
    setIdeas([]);
    const result = await generateTitleIdeasAction(values);
    setIsLoading(false);
    if (result.error) {
      toast({
        variant: 'destructive',
        title: 'Eroare',
        description: result.error,
      });
    } else if (result.data) {
      setIdeas(result.data);
    }
  }

  return (
    <div className="space-y-4">
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <FormField
            control={form.control}
            name="description"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Descrierea Paginii</FormLabel>
                <FormControl>
                  <Textarea
                    placeholder="ex: O pagină de prezentare pentru o nouă aplicație de productivitate."
                    {...field}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <Button type="submit" disabled={isLoading} className="w-full">
            <Sparkles className="w-4 h-4 mr-2" />
            {isLoading ? 'Se generează...' : 'Generează Idei'}
          </Button>
        </form>
      </Form>
      {isLoading && (
        <div className="space-y-2">
            {[...Array(5)].map((_, i) => (
                <Skeleton key={i} className="h-8 w-full" />
            ))}
        </div>
      )}
      {ideas.length > 0 && (
        <div className="space-y-2">
          <h4 className="font-medium">Sugestii:</h4>
          {ideas.map((idea, index) => (
            <Button
              key={index}
              variant="outline"
              size="sm"
              className="w-full justify-start text-left h-auto"
              onClick={() => onTitleSelect(idea)}
            >
              {idea}
            </Button>
          ))}
        </div>
      )}
    </div>
  );
}
