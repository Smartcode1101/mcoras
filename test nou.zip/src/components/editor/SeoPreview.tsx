'use client';

import { Progress } from '@/components/ui/progress';
import { cn } from '@/lib/utils';

interface SeoPreviewProps {
  title: string;
  description: string;
  url: string;
}

const TITLE_MAX_LENGTH = 60;
const DESCRIPTION_MAX_LENGTH = 160;

export function SeoPreview({ title, description, url }: SeoPreviewProps) {
  const titleLength = title.length;
  const descriptionLength = description.length;

  const titleProgress = (titleLength / TITLE_MAX_LENGTH) * 100;
  const descriptionProgress = (descriptionLength / DESCRIPTION_MAX_LENGTH) * 100;

  return (
    <div className="space-y-3 w-full max-w-full overflow-x-hidden">
      <div>
        <h3 className="font-semibold text-sm">Previzualizare Google</h3>
      </div>
      <div className="p-3 border rounded-md bg-slate-50 overflow-hidden w-full">
        <div className="flex flex-col w-full">
          <span className="text-xs text-gray-500 truncate">{url}</span>
          <h3 className="text-blue-600 text-sm truncate font-medium">
            {title || 'Pagină Fără Titlu'}
          </h3>
          <p className="text-xs text-gray-600 line-clamp-2">
            {description || 'Introdu o meta descriere...'}
          </p>
        </div>
      </div>
      <div className="space-y-2 w-full">
        <div className="w-full">
          <div className="flex justify-between items-center mb-1">
            <label className="text-xs font-medium">Titlu</label>
            <span
              className={cn(
                'text-xs',
                titleLength > TITLE_MAX_LENGTH ? 'text-destructive' : 'text-muted-foreground'
              )}
            >
              {titleLength}/{TITLE_MAX_LENGTH}
            </span>
          </div>
          <Progress value={titleProgress} className={cn('h-1', titleLength > TITLE_MAX_LENGTH ? '[&>*]:bg-destructive' : '')} />
        </div>
        <div className="w-full">
          <div className="flex justify-between items-center mb-1">
            <label className="text-xs font-medium">Descriere</label>
            <span
              className={cn(
                'text-xs',
                descriptionLength > DESCRIPTION_MAX_LENGTH ? 'text-destructive' : 'text-muted-foreground'
              )}
            >
              {descriptionLength}/{DESCRIPTION_MAX_LENGTH}
            </span>
          </div>
          <Progress value={descriptionProgress} className={cn('h-1', descriptionLength > DESCRIPTION_MAX_LENGTH ? '[&>*]:bg-destructive' : '')} />
        </div>
      </div>
    </div>
  );
}
