'use client';

import { useEditor } from '@/contexts/editor-context';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Separator } from '../ui/separator';
import { SeoPreview } from './SeoPreview';
import { useEffect, useState } from 'react';
import { ThumbnailSelector } from '@/components/editor/ThumbnailSelector';
import type { Category, Tag } from '@/lib/types';

export function SettingsPanel() {
  const { state, dispatch } = useEditor();
  const [slug, setSlug] = useState(state.pageSlug);
  const [categories, setCategories] = useState<Category[]>([]);
  const [tags, setTags] = useState<Tag[]>([]);

  useEffect(() => {
    setSlug(state.pageSlug);
  }, [state.pageSlug]);

  // Încarcă categoriile și tag-urile
  useEffect(() => {
    const fetchTaxonomies = async () => {
      try {
        const [catRes, tagRes] = await Promise.all([
          fetch('/api/categories'),
          fetch('/api/tags')
        ]);
        if (catRes.ok) setCategories(await catRes.json());
        if (tagRes.ok) setTags(await tagRes.json());
      } catch (error) {
        console.error('Eroare la încărcarea taxonomiilor:', error);
      }
    };
    fetchTaxonomies();
  }, []);

  const handleTitleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    dispatch({
      type: 'UPDATE_PAGE_SETTINGS',
      payload: { title: e.target.value },
    });
  };

  const handleSlugChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newSlug = e.target.value
      .toLowerCase()
      .replace(/\s+/g, '-')
      .replace(/[^a-z0-9-]/g, '');
    setSlug(newSlug);
  };

  const handleSlugBlur = () => {
    dispatch({
      type: 'UPDATE_PAGE_SETTINGS',
      payload: { slug: slug },
    });
  };

  const handleDescriptionChange = (
    e: React.ChangeEvent<HTMLTextAreaElement>
  ) => {
    dispatch({
      type: 'UPDATE_PAGE_SETTINGS',
      payload: { description: e.target.value },
    });
  };
  
  const handleKeywordsChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    dispatch({
      type: 'UPDATE_PAGE_SETTINGS',
      payload: { keywords: e.target.value },
    });
  };

  const handleRobotsChange = (type: 'index' | 'follow' | 'noimageindex', value: boolean) => {
    switch (type) {
      case 'index':
        dispatch({ type: 'UPDATE_PAGE_SETTINGS', payload: { robotsIndex: value } });
        break;
      case 'follow':
        dispatch({ type: 'UPDATE_PAGE_SETTINGS', payload: { robotsFollow: value } });
        break;
      case 'noimageindex':
        dispatch({ type: 'UPDATE_PAGE_SETTINGS', payload: { robotsNoImageIndex: value } });
        break;
    }
  };

  return (
    <div className="space-y-4 w-full max-w-full overflow-x-hidden">
      <div className="space-y-1">
        <h3 className="font-semibold text-sm">Setări Pagină</h3>
        <p className="text-xs text-muted-foreground">
          Gestionează titlul, URL-ul și SEO.
        </p>
      </div>
      
      <Separator />

      <div className="space-y-3 w-full">
        <div className="space-y-1.5 w-full">
          <Label htmlFor="page-title" className="text-xs">Titlul Paginii</Label>
          <Input
            id="page-title"
            value={state.pageTitle}
            onChange={handleTitleChange}
            placeholder="Introdu titlul paginii"
            className="h-8 text-sm w-full"
          />
        </div>
        <div className="space-y-1.5 w-full">
          <Label htmlFor="page-slug" className="text-xs">URL Pagină (Slug)</Label>
          <Input
            id="page-slug"
            value={slug}
            onChange={handleSlugChange}
            onBlur={handleSlugBlur}
            placeholder="ex. despre-noi"
            className="h-8 text-sm w-full"
          />
           <p className="text-xs text-muted-foreground truncate">
            Calea: /<strong>{slug || '...'}/</strong>
          </p>
        </div>

        {state.pageType === 'post' && (
          <ThumbnailSelector
            currentThumbnail={state.thumbnail}
            onThumbnailChange={(thumbnail: string | undefined) => dispatch({ type: 'UPDATE_PAGE_SETTINGS', payload: { thumbnail } })}
          />
        )}

        {state.pageType === 'post' && (
          <>
            <div className="space-y-1.5 w-full">
              <Label htmlFor="category" className="text-xs flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 bg-blue-500 rounded-full flex-shrink-0"></span>
                Categorie
              </Label>
              <select
                id="category"
                value={state.categoryId || ''}
                onChange={(e) => dispatch({ type: 'UPDATE_PAGE_SETTINGS', payload: { categoryId: e.target.value || undefined } })}
                className="w-full border border-gray-300 rounded-md px-2 py-1.5 text-xs bg-white focus:ring-1 focus:ring-blue-500 focus:border-blue-500 outline-none text-gray-900 truncate"
              >
                <option value="">Fără categorie</option>
                {categories.map(cat => (
                  <option key={cat.id} value={cat.id}>{cat.name}</option>
                ))}
              </select>
              {state.categoryId && (
                <div className="flex items-center gap-1.5 p-1.5 bg-blue-50 rounded border border-blue-200 w-full">
                  <span className="text-xs text-blue-800 font-medium truncate">
                    ✓ {categories.find(c => c.id === state.categoryId)?.name || 'Necunoscut'}
                  </span>
                </div>
              )}
            </div>

            <div className="space-y-1.5 w-full">
              <Label className="text-xs flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 bg-purple-500 rounded-full flex-shrink-0"></span>
                Tag-uri
              </Label>
              <div className="border border-gray-300 rounded-md p-2 max-h-36 overflow-y-auto overflow-x-hidden bg-white w-full">
                {tags.length === 0 ? (
                  <p className="text-xs text-muted-foreground text-center py-2">Nu există tag-uri.</p>
                ) : (
                  <div className="flex flex-wrap gap-1">
                    {tags.map(tag => {
                      const isSelected = state.tags?.includes(tag.id) || false;
                      return (
                        <button
                          key={tag.id}
                          type="button"
                          onClick={() => {
                            const currentTags = state.tags || [];
                            const newTags = isSelected
                              ? currentTags.filter(t => t !== tag.id)
                              : [...currentTags, tag.id];
                            dispatch({ type: 'UPDATE_PAGE_SETTINGS', payload: { tags: newTags } });
                          }}
                          className={`px-2 py-0.5 rounded text-xs font-medium transition-all whitespace-nowrap ${
                            isSelected
                              ? 'bg-purple-500 text-white'
                              : 'bg-gray-100 text-gray-700 hover:bg-gray-200 border border-gray-300'
                          }`}
                        >
                          {tag.name}
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
              {state.tags && state.tags.length > 0 && (
                <div className="text-xs text-purple-600 font-medium">
                  {state.tags.length} selectate
                </div>
              )}
            </div>
          </>
        )}
      </div>

      <Separator />

      <div className="w-full">
        <SeoPreview
          title={state.pageTitle}
          description={state.seoDescription}
          url={`https://exemplu.com/${state.pageSlug}`}
        />
      </div>

      <Separator />

      <div className="space-y-3 w-full">
        <div className="space-y-1.5 w-full">
          <Label htmlFor="seo-description" className="text-xs">Meta Descriere SEO</Label>
          <Textarea
            id="seo-description"
            value={state.seoDescription}
            onChange={handleDescriptionChange}
            placeholder="Descriere pentru motoarele de căutare"
            rows={3}
            className="text-xs w-full"
          />
        </div>
         <div className="space-y-1.5 w-full">
          <Label htmlFor="seo-keywords" className="text-xs">Cuvinte Cheie SEO</Label>
          <Input
            id="seo-keywords"
            value={state.seoKeywords}
            onChange={handleKeywordsChange}
            placeholder="ex. artă, tutorial, jocuri"
            className="h-8 text-sm w-full"
          />
        </div>
      </div>
      <Separator />
      <div className="space-y-1">
        <h3 className="font-semibold text-sm">Roboți Motoare de Căutare</h3>
      </div>
      <div className="space-y-2 w-full">
        <div className="rounded-md border p-2 space-y-1 w-full">
          <div className="flex items-center justify-between w-full">
            <Label className="text-xs">Indexare</Label>
            <Switch
              checked={state.robotsIndex}
              onCheckedChange={(checked) => handleRobotsChange('index', checked)}
            />
          </div>
        </div>
        <div className="rounded-md border p-2 space-y-1 w-full">
          <div className="flex items-center justify-between w-full">
            <Label className="text-xs">Urmărire link-uri</Label>
            <Switch
              checked={state.robotsFollow}
              onCheckedChange={(checked) => handleRobotsChange('follow', checked)}
            />
          </div>
        </div>
        <div className="rounded-md border p-2 space-y-1 w-full">
          <div className="flex items-center justify-between w-full">
            <Label className="text-xs">Fără index imagini</Label>
            <Switch
              checked={state.robotsNoImageIndex}
              onCheckedChange={(checked) => handleRobotsChange('noimageindex', checked)}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
