'use client';

import { useEditor } from '@/contexts/editor-context';
import type { Widget } from '@/lib/types';
import { cn } from '@/lib/utils';
import { Trash2, GripVertical, Copy } from 'lucide-react';
import { WIDGET_COMPONENTS } from '../widgets';
import {
  ContextMenu,
  ContextMenuContent,
  ContextMenuItem,
  ContextMenuTrigger,
} from '@/components/ui/context-menu';
import { CSSProperties } from 'react';

export function WidgetWrapper({ element }: { element: Widget }) {
  // Check if we're in editor mode or frontend mode
  let state, dispatch: (action: any) => void;
  let isEditorMode = false;
  try {
    const editorContext = useEditor();
    state = editorContext.state;
    dispatch = editorContext.dispatch;
    isEditorMode = true;
  } catch (error) {
    // Frontend mode - provide default values and no-op dispatch
    state = {
      selectedElementId: null,
      inlineEditingElementId: null,
      responsiveMode: 'desktop' as const
    };
    dispatch = (action: any) => {};
  }

  const isSelected = state.selectedElementId === element.id;
  const isEditing = state.inlineEditingElementId === element.id;

  const handleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isEditing) return;
    dispatch({ type: 'SELECT_ELEMENT', payload: { elementId: element.id } });
  };

  const handleDelete = () => {
    dispatch({ type: 'DELETE_ELEMENT', payload: { elementId: element.id } });
  };

  const handleDuplicate = () => {
    dispatch({ type: 'DUPLICATE_ELEMENT', payload: { elementId: element.id } });
  };

  const handleDragStart = (e: React.DragEvent) => {
    e.stopPropagation();
    e.dataTransfer.setData('widgetId', element.id);
  };

  const handleDoubleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (element.type === 'Heading' || element.type === 'Text' || element.type === 'Button' || element.type === 'Video') {
      dispatch({ type: 'SET_INLINE_EDITING_ELEMENT', payload: { elementId: element.id } });
    }
  };

  const handleTextChange = (text: string) => {
    dispatch({
      type: 'UPDATE_ELEMENT',
      payload: { elementId: element.id, props: { text } },
    });
  };
  
   const handlePropChange = (newProps: { [key: string]: any }) => {
    dispatch({
      type: 'UPDATE_ELEMENT',
      payload: { elementId: element.id, props: newProps },
    });
  };

  const stopEditing = () => {
    dispatch({ type: 'SET_INLINE_EDITING_ELEMENT', payload: { elementId: null } });
  };

  const Component = WIDGET_COMPONENTS[element.type];

  const baseProps = {
    id: element.id,
    styles: element.styles,
    children: element.children, // Pass children to container
    isEditing: isEditing,
    onTextChange: handleTextChange,
    onPropChange: handlePropChange,
    onStopEditing: stopEditing,
  };


  // Create component-specific props based on widget type
  let componentProps: any = { ...baseProps, ...element.props };

  switch (element.type) {
    case 'Heading':
    case 'Text':
    case 'Button':
      componentProps = {
        ...componentProps,
        text: element.props.text || '',
        className: element.props.className || '',
        responsiveMode: state.responsiveMode,
      };
      break;
    case 'Image':
      componentProps = {
        ...componentProps,
        src: element.props.src || '',
        alt: element.props.alt || '',
        className: element.props.className || '',
        alignment: element.props.alignment,
        responsiveMode: state.responsiveMode, // Pass responsive mode from editor context
        isEditorMode: true, // Images in editor should use regular img tags for better editing
      };
      break;
    case 'Spacer':
      componentProps = {
        ...componentProps,
        className: element.props.className || '',
        responsiveMode: state.responsiveMode,
      };
      break;
    case 'PostGrid':
      componentProps = {
        ...componentProps,
        responsiveMode: state.responsiveMode, // Pass responsive mode for PostGrid widget
      };
      break;
    case 'FlexContainer':
      componentProps = {
        ...componentProps,
        responsiveMode: state.responsiveMode,
        isEditorMode: true,
      };
      break;
    case 'Container':
      componentProps = {
        ...componentProps,
        isEditorMode: true,
      };
      break;
    case 'PostTags':
      componentProps = {
        ...componentProps,
        responsiveMode: state.responsiveMode,
        isEditorMode: true,
        pageTags: state.tags || [],
        allTags: [], // Va fi încărcat dinamic în editor
      };
      break;
  }
  
  const wrapperStyle: CSSProperties = {
    padding: 0,
    margin: 0,
    border: 'none',
    boxShadow: 'none',
    background: 'transparent',
    color: 'inherit',
    fontSize: 'inherit',
    fontWeight: 'inherit',
    textAlign: 'inherit',
    textDecoration: 'inherit',
    minHeight: element.type === 'Image' ? 'auto' : undefined, // Ensure images have proper height
  };


  return (
    <ContextMenu>
      <ContextMenuTrigger asChild>
        <div
          style={wrapperStyle}
          className={cn(
            'relative group transition-all widget-wrapper',
            isSelected && !isEditing ? 'outline-2 outline-offset-2 outline outline-primary' : '',
            isEditing && 'outline-2 outline-offset-2 outline-ring'
          )}
          onClick={handleClick}
          onDoubleClick={handleDoubleClick}
          draggable={!isEditing}
          onDragStart={handleDragStart}
        >
          {!isEditing && (
            <>
              <div
                className={cn(
                  'absolute -top-3 -right-3 flex gap-1 z-50'
                )}
              >
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    handleDelete();
                  }}
                  className="p-1 rounded-md bg-red-600 text-white hover:bg-red-700 shadow-lg"
                  aria-label="Delete element"
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              </div>
              <div
                className={cn(
                  'absolute -top-3 -left-3 z-50 cursor-move'
                )}
              >
                <div
                  className="p-1 rounded-md bg-blue-600 text-white hover:bg-blue-700 shadow-lg"
                  aria-label="Drag to move element"
                >
                  <GripVertical className="w-3 h-3" />
                </div>
              </div>
            </>
          )}
          {Component ? (
            <Component {...componentProps} />
          ) : (
            <div className="text-destructive">Unknown widget type: {element.type}</div>
          )}
        </div>
      </ContextMenuTrigger>
      <ContextMenuContent>
        <ContextMenuItem onSelect={handleDuplicate}>
          <Copy className="w-4 h-4 mr-2" />
          Duplicate
        </ContextMenuItem>
        <ContextMenuItem onSelect={handleDelete} className="text-destructive focus:text-destructive">
          <Trash2 className="w-4 h-4 mr-2" />
          Delete
        </ContextMenuItem>
      </ContextMenuContent>
    </ContextMenu>
  );
}
