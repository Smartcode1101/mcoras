'use client';

import {
  Heading1,
  Type,
  ImageIcon,
  RectangleHorizontal,
  MoveVertical,
  Container,
  Youtube,
  Code,
  Grid3X3,
  Tags,
} from 'lucide-react';
import type { WidgetType } from '@/lib/types';

const WIDGETS = [
  { type: 'Heading' as WidgetType, icon: Heading1, label: 'Titlu' },
  { type: 'Text' as WidgetType, icon: Type, label: 'Text' },
  { type: 'Image' as WidgetType, icon: ImageIcon, label: 'Imagine' },
  { type: 'Video' as WidgetType, icon: Youtube, label: 'Video' },
  { type: 'Button' as WidgetType, icon: RectangleHorizontal, label: 'Buton' },
  { type: 'Spacer' as WidgetType, icon: MoveVertical, label: 'Spațier' },
  { type: 'Container' as WidgetType, icon: Container, label: 'Container' },
  { type: 'FlexContainer' as WidgetType, icon: Grid3X3, label: 'FlexGrid' },
  { type: 'Html' as WidgetType, icon: Code, label: 'HTML' },
  { type: 'PostGrid' as WidgetType, icon: Grid3X3, label: 'Grilă Postări' },
  { type: 'PostTags' as WidgetType, icon: Tags, label: 'Tag-uri Postare' },
];

function Widget({
  type,
  icon: Icon,
  label,
}: {
  type: WidgetType;
  icon: React.ElementType;
  label: string;
}) {
  const handleDragStart = (e: React.DragEvent) => {
    e.dataTransfer.setData('widgetType', type);
  };

  return (
    <div
      draggable
      onDragStart={handleDragStart}
      className="flex flex-col items-center justify-center p-4 border rounded-md cursor-grab bg-card hover:bg-secondary transition-colors"
    >
      <Icon className="w-8 h-8 mb-2 text-primary" />
      <span className="text-sm">{label}</span>
    </div>
  );
}

export function WidgetPanel() {
  return (
    <div className="grid grid-cols-2 gap-4">
      {WIDGETS.map((widget) => (
        <Widget key={widget.type} {...widget} />
      ))}
    </div>
  );
}
