'use client';

import { useEffect, useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { useEditor } from '@/contexts/editor-context';
import { analyzeSeoAction } from '@/lib/actions';
import { useToast } from '@/hooks/use-toast';
import { BrainCircuit, Loader2 } from 'lucide-react';
import { ScrollArea } from '../ui/scroll-area';

interface SeoAnalysisDialogProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
}

type AnalysisResult = {
  suggestions: string;
  rankingEstimate: string;
  eeatAnalysis: string;
};

export function SeoAnalysisDialog({ isOpen, onOpenChange }: SeoAnalysisDialogProps) {
  const { state } = useEditor();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);

  useEffect(() => {
    const analyze = async () => {
      if (isOpen && !result) {
        setIsLoading(true);
        setResult(null);
        
        const { pageTitle, pageSlug, seoDescription, elements } = state;
        const analysisResult = await analyzeSeoAction({ pageTitle, pageSlug, seoDescription, elements });

        setIsLoading(false);
        if (analysisResult.error) {
          toast({
            variant: 'destructive',
            title: 'Eroare la analiză',
            description: analysisResult.error,
          });
          onOpenChange(false); // Close dialog on error
        } else if (analysisResult.data) {
          setResult(analysisResult.data);
        }
      }
    };
    analyze();
  }, [isOpen, state, toast, onOpenChange, result]);

  const handleOpenChange = (open: boolean) => {
    if (!open) {
        // Reset state when dialog is closed
        setTimeout(() => {
            setResult(null);
            setIsLoading(false);
        }, 300);
    }
    onOpenChange(open);
  }

  return (
    <Dialog open={isOpen} onOpenChange={handleOpenChange}>
      <DialogContent className="max-w-3xl h-[80vh] flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <BrainCircuit className="w-6 h-6 text-primary" />
            Analiză SEO bazată pe AI
          </DialogTitle>
          <DialogDescription>
            Iată o analiză a paginii tale și sugestii pentru a-i îmbunătăți vizibilitatea.
          </DialogDescription>
        </DialogHeader>
        <div className="flex-1 overflow-hidden">
          <ScrollArea className="h-full pr-6">
            {isLoading && (
              <div className="flex flex-col items-center justify-center gap-4 py-16">
                <Loader2 className="w-12 h-12 animate-spin text-primary" />
                <p className="text-muted-foreground">AI-ul analizează pagina... Vă rugăm așteptați.</p>
              </div>
            )}
            {result && (
              <div className="space-y-6">
                <div>
                  <h3 className="font-semibold text-lg mb-2">Sugestii de optimizare</h3>
                  <div className="prose prose-sm dark:prose-invert max-w-none p-4 bg-slate-50 rounded-md whitespace-pre-wrap">{result.suggestions}</div>
                </div>
                
                <div>
                  <h3 className="font-semibold text-lg mb-2">Estimare de clasare pe Google</h3>
                  <div className="prose prose-sm dark:prose-invert max-w-none p-4 bg-slate-50 rounded-md whitespace-pre-wrap">{result.rankingEstimate}</div>
                </div>
                
                <div>
                  <h3 className="font-semibold text-lg mb-2">Analiză Google E-E-A-T</h3>
                   <div className="prose prose-sm dark:prose-invert max-w-none p-4 bg-slate-50 rounded-md whitespace-pre-wrap">{result.eeatAnalysis}</div>
                </div>
              </div>
            )}
          </ScrollArea>
        </div>
      </DialogContent>
    </Dialog>
  );
}
