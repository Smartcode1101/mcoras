
'use client';

import React, { useState } from 'react';
import { useEditor } from '@/contexts/editor-context';
import { WidgetWrapper } from './WidgetWrapper';
import type { WidgetType } from '@/lib/types';
import { cn } from '@/lib/utils';
import {
  ContextMenu,
  ContextMenuContent,
  ContextMenuItem,
  ContextMenuTrigger,
} from '@/components/ui/context-menu';
import { RefreshCw, BrainCircuit } from 'lucide-react';

export function EditorCanvas() {
  const { state, dispatch } = useEditor();
  const [isDraggingOver, setIsDraggingOver] = useState(false);
  const [dropIndex, setDropIndex] = useState<number | null>(null);
  
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDraggingOver(true);

    const dragY = e.clientY;
    const elements = Array.from(
      (e.currentTarget as HTMLElement).querySelectorAll('.widget-wrapper')
    );
    const closest = elements.reduce(
      (
        acc: { offset: number; index: number },
        child: Element,
        index: number
      ) => {
        const box = child.getBoundingClientRect();
        const offset = dragY - box.top - box.height / 2;
        if (offset < 0 && offset > acc.offset) {
          return { offset: offset, index: index };
        } else {
          return acc;
        }
      },
      { offset: Number.NEGATIVE_INFINITY, index: elements.length }
    );
    setDropIndex(closest.index);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation(); // Prevent events from bubbling up
    setIsDraggingOver(false);
    setDropIndex(null);
    const widgetType = e.dataTransfer.getData('widgetType') as WidgetType;
    const widgetId = e.dataTransfer.getData('widgetId');

    console.log(`[EditorCanvas] Drop event - widgetType: ${widgetType}, widgetId: ${widgetId}`);

    const finalDropIndex = dropIndex !== null ? dropIndex : state.elements.length;

    if (widgetType) {
      console.log(`[EditorCanvas] Adding ${widgetType} at index ${finalDropIndex} to root`);
      dispatch({
        type: 'ADD_ELEMENT',
        payload: {
          index: finalDropIndex,
          element: { type: widgetType } as any,
          parentId: null, // Explicitly add to the root
        },
      });
    } else if (widgetId) {
      console.log(`[EditorCanvas] Moving ${widgetId} to index ${finalDropIndex}`);
      const fromIndex = state.elements.findIndex((el) => el.id === widgetId);
      if (fromIndex !== -1) {
        let toIndex = finalDropIndex;
        if (fromIndex < toIndex) {
          toIndex--;
        }
        dispatch({ type: 'MOVE_ELEMENT', payload: { fromIndex, toIndex } });
      }
    }
  };

  const handleDragLeave = () => {
    setIsDraggingOver(false);
    setDropIndex(null);
  };

  const handleClick = (e: React.MouseEvent) => {
    // Check if the click is on the canvas background itself, not on a widget
    if ((e.target as HTMLElement).classList.contains('canvas-background')) {
      dispatch({ type: 'SELECT_ELEMENT', payload: { elementId: null } });
    }
  };

  return (
    <div
      className="flex-1 h-full bg-muted canvas-background overflow-x-hidden"
      onClick={handleClick}
      onDragOver={handleDragOver}
      onDrop={handleDrop}
      onDragLeave={handleDragLeave}
    >
      <div
        className={cn(
          'bg-white text-black min-h-full transition-all duration-300 ease-in-out shadow-lg p-4',
          state.responsiveMode === 'desktop' && 'ml-64 mr-48',
          state.responsiveMode === 'tablet' && 'max-w-2xl mx-auto',
          state.responsiveMode === 'mobile' && 'max-w-sm mx-auto',
          isDraggingOver && 'outline-dashed outline-2 outline-primary'
        )}
        style={{ transform: `scale(${state.zoom / 100})`, transformOrigin: 'top center' }}
      >
        <div className="min-h-full">
            {state.elements.length === 0 ? (
            <div className="flex items-center justify-center min-h-[80vh] text-muted-foreground p-4">
                <p>Trage un widget din bara laterală pentru a începe să construiești pagina.</p>
            </div>
            ) : (
            state.elements.map((element, index) => (
                <React.Fragment key={element.id}>
                {dropIndex === index && (
                    <div className="h-2 my-2 bg-primary rounded-full" />
                )}
                <WidgetWrapper element={element} />
                </React.Fragment>
            ))
            )}
            {dropIndex === state.elements.length && (
            <div className="h-2 my-2 bg-primary rounded-full" />
            )}
        </div>
      </div>
    </div>
  );
}
