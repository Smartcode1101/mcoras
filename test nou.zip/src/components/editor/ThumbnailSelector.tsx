'use client';

import { useState, useEffect } from 'react';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Images, Upload, X } from 'lucide-react';
import { ScrollArea } from '../ui/scroll-area';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogTrigger,
} from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '../ui/progress';
import { uploadImageAction, getImagesAction } from '@/lib/actions';
import { PlaceHolderImages } from '@/lib/placeholder-images';

type UserImage = {
  src: string;
  alt: string;
};

interface ThumbnailSelectorProps {
  currentThumbnail?: string;
  onThumbnailChange: (thumbnail: string | undefined) => void;
}

export function ThumbnailSelector({ currentThumbnail, onThumbnailChange }: ThumbnailSelectorProps) {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [userImages, setUserImages] = useState<UserImage[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const { toast } = useToast();

  useEffect(() => {
    const fetchImages = async () => {
      if (isDialogOpen) {
        const result = await getImagesAction();
        if (result.data) {
          setUserImages(result.data);
        } else if (result.error) {
          toast({
            variant: 'destructive',
            title: 'Eroare la încărcarea imaginilor',
            description: result.error,
          });
        }
      }
    };
    fetchImages();
  }, [isDialogOpen, toast]);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 20 * 1024 * 1024) {
      toast({
        variant: 'destructive',
        title: 'Fișier prea mare',
        description: 'Te rog încarcă o imagine mai mică de 20MB.',
      });
      return;
    }

    setIsUploading(true);
    setUploadProgress(0);

    // Create a local URL and update immediately
    const localUrl = URL.createObjectURL(file);
    onThumbnailChange(localUrl);
    setIsDialogOpen(false);

    // Animate progress bar
    const progressInterval = setInterval(() => {
      setUploadProgress((prev) => (prev < 90 ? prev + 10 : prev));
    }, 200);

    const formData = new FormData();
    formData.append('file', file);

    // Upload to server in the background
    const result = await uploadImageAction(formData);

    clearInterval(progressInterval);
    setUploadProgress(100);

    if (result.error) {
      toast({
        variant: 'destructive',
        title: 'Încărcare Eșuată',
        description: result.error,
      });
      // Revert optimistic update on failure
      onThumbnailChange(currentThumbnail);
    } else if (result.data) {
      const newImage = { src: result.data.src, alt: result.data.alt };
      setUserImages((prev) => [newImage, ...prev]);

      // Update with permanent server URL
      onThumbnailChange(newImage.src);

      toast({ title: 'Încărcare Reușită', description: 'Imaginea ta a fost salvată pe server.' });
    }

    // Clean up local URL to prevent memory leaks
    URL.revokeObjectURL(localUrl);

    setTimeout(() => {
      setIsUploading(false);
      setUploadProgress(0);
    }, 1000);

    e.target.value = '';
  };

  const handleSelectImage = (img: { src: string; alt: string }) => {
    onThumbnailChange(img.src);
    setIsDialogOpen(false);
  };

  const handleRemoveThumbnail = () => {
    onThumbnailChange(undefined);
  };

  return (
    <div className="space-y-2">
      <Label>Miniatură Postare</Label>
      <div className="space-y-2">
        {currentThumbnail ? (
          <div className="relative">
            <img
              src={currentThumbnail}
              alt="Miniatură postare"
              className="w-full h-32 object-cover rounded-md border"
            />
            <Button
              variant="destructive"
              size="sm"
              className="absolute top-2 right-2"
              onClick={handleRemoveThumbnail}
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        ) : (
          <div className="border-2 border-dashed border-muted-foreground/25 rounded-md p-4">
            <div className="flex flex-col items-center justify-center space-y-2">
              <Images className="w-8 h-8 text-muted-foreground" />
              <p className="text-sm text-muted-foreground">Nicio miniatură selectată</p>
            </div>
          </div>
        )}
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="w-full" variant="outline">
              <Images className="w-4 h-4 mr-2" />
              {currentThumbnail ? 'Schimbă Miniatura' : 'Selectează Miniatură'}
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-6xl h-[90vh] flex flex-col p-0">
            <DialogHeader className="p-4 border-b">
              <DialogTitle>Selectează Miniatură</DialogTitle>
              <DialogDescription>
                Alege o imagine din bibliotecă sau încarcă una nouă pentru miniatură.
              </DialogDescription>
            </DialogHeader>
            <Tabs defaultValue="stock" className="flex-1 flex flex-col overflow-hidden">
              <TabsList className="mx-4 mt-4">
                <TabsTrigger value="stock">Imagini Stoc</TabsTrigger>
                <TabsTrigger value="my-images">Imaginile Mele</TabsTrigger>
              </TabsList>
              <TabsContent value="stock" className="flex-1 overflow-hidden mt-0">
                <ScrollArea className="h-full">
                  <div className="grid grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 p-4">
                    {PlaceHolderImages.map((img) => (
                      <div
                        key={img.id}
                        className="relative group aspect-square cursor-pointer rounded-md overflow-hidden ring-offset-background focus-within:ring-2 focus-within:ring-primary"
                        onClick={() => handleSelectImage({ src: img.imageUrl, alt: img.description })}
                        tabIndex={0}
                        onKeyDown={(e) =>
                          e.key === 'Enter' && handleSelectImage({ src: img.imageUrl, alt: img.description })
                        }
                      >
                        <Image
                          src={img.imageUrl}
                          alt={img.description}
                          fill
                          sizes="(max-width: 768px) 33vw, 20vw"
                          className="object-cover"
                          data-ai-hint={img.imageHint}
                          priority={img.id === 'office-space'}
                        />
                        <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                          <span className="text-white text-sm text-center p-2">Selectează</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </TabsContent>
              <TabsContent value="my-images" className="flex-1 flex flex-col overflow-hidden mt-0">
                <div className="p-4 border-b">
                  <div className="relative border-2 border-dashed border-muted rounded-lg p-6 text-center">
                    <Upload className="mx-auto h-12 w-12 text-muted-foreground" />
                    <h3 className="mt-2 text-sm font-medium text-foreground">Încarcă o imagine</h3>
                    <p className="mt-1 text-xs text-muted-foreground">PNG, JPG, GIF, BMP până la 60MB.</p>
                    <input
                      id="file-upload"
                      name="file-upload"
                      type="file"
                      className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                      onChange={handleFileChange}
                      disabled={isUploading}
                      accept="image/png, image/jpeg, image/gif, image/bmp"
                    />
                  </div>
                  {isUploading && (
                    <div className="mt-4 w-full">
                      <Progress value={uploadProgress} />
                      <p className="text-xs text-center mt-1 text-muted-foreground">Se încarcă...</p>
                    </div>
                  )}
                </div>
                <ScrollArea className="flex-1">
                  {userImages.length === 0 ? (
                    <div className="flex items-center justify-center h-full text-muted-foreground">
                      <p>Nu ai încărcat nicio imagine încă.</p>
                    </div>
                  ) : (
                    <div className="grid grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 p-4">
                      {userImages.map((img, index) => (
                        <div
                          key={index}
                          className="relative group aspect-square cursor-pointer rounded-md overflow-hidden ring-offset-background focus-within:ring-2 focus-within:ring-primary"
                          onClick={() => handleSelectImage(img)}
                          tabIndex={0}
                          onKeyDown={(e) => e.key === 'Enter' && handleSelectImage(img)}
                        >
                          <Image
                            src={img.src}
                            alt={img.alt}
                            fill
                            sizes="(max-width: 768px) 33vw, 20vw"
                            className="object-cover"
                          />
                          <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                            <span className="text-white text-sm text-center p-2">Selectează</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </ScrollArea>
              </TabsContent>
            </Tabs>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}