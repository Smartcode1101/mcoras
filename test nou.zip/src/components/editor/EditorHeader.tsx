
'use client';

import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import {
  Eye,
  LayoutTemplate,
  Save,
  Settings,
  Sparkles,
  ArrowLeft,
  RefreshCw,
  BrainCircuit,
  Monitor,
  Tablet,
  Smartphone,
  Maximize,
  Minimize,
  ZoomIn,
  ZoomOut,
  FileText,
  Newspaper,
} from 'lucide-react';
import { useEditor } from '@/contexts/editor-context';
import { useToast } from '@/hooks/use-toast';
import { savePageAction } from '@/lib/actions';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import { SeoAnalysisDialog } from './SeoAnalysisDialog';
import { TemplateDialog } from './TemplateDialog';
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useId } from 'react';
import type { ResponsiveMode, PageType } from '@/lib/types';

// Client-side only wrapper to prevent Radix UI hydration issues
const PageTypeSelect = React.memo(({ value, onValueChange }: { 
  value: PageType; 
  onValueChange: (value: PageType) => void;
}) => {
  const [isClient, setIsClient] = useState(false);
  const id = useId();

  useEffect(() => {
    setIsClient(true);
  }, []);

  // During SSR and initial client render, show a simple placeholder
  if (!isClient) {
    return (
      <div className="w-32 h-10 border rounded-md bg-background px-3 py-2 text-sm flex items-center justify-between">
        <span className="text-muted-foreground">Pagină</span>
        <div className="h-4 w-4 opacity-50" />
      </div>
    );
  }

  return (
    <Select value={value} onValueChange={onValueChange}>
      <SelectTrigger className="w-32">
        <SelectValue />
      </SelectTrigger>
      <SelectContent>
        <SelectItem value="page">
          <div className="flex items-center gap-2">
            <FileText className="w-4 h-4" />
            Pagină
          </div>
        </SelectItem>
        <SelectItem value="post">
          <div className="flex items-center gap-2">
            <Newspaper className="w-4 h-4" />
            Postare
          </div>
        </SelectItem>
      </SelectContent>
    </Select>
  );
});

PageTypeSelect.displayName = 'PageTypeSelect';

export function EditorHeader() {
  const { state, dispatch } = useEditor();
  const { toast } = useToast();
  const params = useParams();
  const router = useRouter();
  const [isSeoDialogOpen, setIsSeoDialogOpen] = useState(false);
  const [isTemplateDialogOpen, setIsTemplateDialogOpen] = useState(false);

  const handlePreview = async () => {
    toast({ title: 'Se generează previzualizarea...', description: 'Pagina ta se pregătește.' });
    const result = await savePageAction(state); // Use save to get fresh CSS
    if (result.error) {
       toast({ variant: 'destructive', title: 'Eroare la Salvare', description: result.error });
       return;
    }
    const pageUrl = result.slug === 'home' ? '/' : `/${result.slug}`;
    window.open(pageUrl, '_blank');
  };

  const handleSave = async () => {
    toast({ title: 'Se salvează...', description: 'Pagina ta este în curs de salvare.' });
    const result = await savePageAction(state);
    if (result.error) {
      toast({ variant: 'destructive', title: 'Eroare', description: result.error });
    } else {
      toast({ title: 'Succes!', description: 'Pagina ta a fost salvată.' });
      if (params.pageId === 'new' && result.id) {
        router.push(`/editor/${result.id}`);
      }
    }
  };
  
  const handleRefresh = () => {
    window.location.reload();
  };

  return (
    <>
      <header className="flex items-center justify-between h-16 px-4 border-b bg-card">
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" asChild>
            <Link href="/admin">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Înapoi la Admin
            </Link>
          </Button>
        </div>
        <div className="flex-1 flex justify-center items-center gap-4">
          <div className="flex items-center gap-1 text-primary font-semibold">
            <Sparkles className="w-5 h-5" />
            <h1>One Smart</h1>
          </div>
          <PageTypeSelect
            value={state.pageType}
            onValueChange={(value: PageType) => {
              dispatch({ type: 'UPDATE_PAGE_SETTINGS', payload: { pageType: value } });
            }}
          />
        </div>
        <div className="flex items-center gap-2">
          <ToggleGroup
            type="single"
            size="sm"
            value={state.responsiveMode}
            onValueChange={(mode: ResponsiveMode) => {
              if (mode) dispatch({ type: 'SET_RESPONSIVE_MODE', payload: { mode } });
            }}
            aria-label="Responsive mode"
            className="border rounded-md"
          >
            <ToggleGroupItem value="desktop" aria-label="Desktop" className="px-3">
              <Monitor className="w-4 h-4" />
            </ToggleGroupItem>
            <ToggleGroupItem value="tablet" aria-label="Tablet" className="px-3">
              <Tablet className="w-4 h-4" />
            </ToggleGroupItem>
            <ToggleGroupItem value="mobile" aria-label="Mobile" className="px-3">
              <Smartphone className="w-4 h-4" />
            </ToggleGroupItem>
          </ToggleGroup>
          <div className="flex items-center gap-1 border rounded-md px-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => dispatch({ type: 'SET_ZOOM', payload: { zoom: Math.max(25, state.zoom - 25) } })}
              className="h-8 w-8 p-0"
            >
              <ZoomOut className="w-4 h-4" />
            </Button>
            <span className="text-sm font-medium min-w-[3rem] text-center">{state.zoom}%</span>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => dispatch({ type: 'SET_ZOOM', payload: { zoom: Math.min(200, state.zoom + 25) } })}
              className="h-8 w-8 p-0"
            >
              <ZoomIn className="w-4 h-4" />
            </Button>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => dispatch({ type: 'SET_ACTIVE_TAB', payload: { tab: 'settings' } })}
          >
            <Settings className="w-4 h-4 mr-2" />
            Setări
          </Button>
          <Button variant="ghost" size="sm" onClick={() => setIsTemplateDialogOpen(true)}>
            <LayoutTemplate className="w-4 h-4 mr-2" />
            Șablon
          </Button>
          <Button variant="ghost" size="sm" onClick={() => setIsSeoDialogOpen(true)}>
            <BrainCircuit className="w-4 h-4 mr-2" />
            Analizează SEO
          </Button>
          <Button variant="ghost" size="sm" onClick={handleRefresh}>
            <RefreshCw className="w-4 h-4 mr-2" />
            Reîmprospătează
          </Button>
          <Button variant="ghost" size="sm" onClick={handlePreview}>
            <Eye className="w-4 h-4 mr-2" />
            Previzualizează
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => dispatch({ type: 'TOGGLE_FULLSCREEN' })}
          >
            {state.isFullScreen ? <Minimize className="w-4 h-4 mr-2" /> : <Maximize className="w-4 h-4 mr-2" />}
            {state.isFullScreen ? 'Ieșire Full Screen' : 'Full Screen'}
          </Button>
           <Button size="sm" onClick={handleSave}>
            <Save className="w-4 h-4 mr-2" />
            Salvează Pagina
          </Button>
        </div>
      </header>

      <SeoAnalysisDialog
        isOpen={isSeoDialogOpen}
        onOpenChange={setIsSeoDialogOpen}
      />
      <TemplateDialog
        isOpen={isTemplateDialogOpen}
        onOpenChange={setIsTemplateDialogOpen}
      />
    </>
  );
}
