'use client';
import { useEditor } from '@/contexts/editor-context';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import { SpacingControl } from '../style-controls/SpacingControl';
import { TypographyControl } from '../style-controls/TypographyControl';
import { ColorControl } from '../style-controls/ColorControl';
import { BorderControl } from '../style-controls/BorderControl';
import { TitleGenerator } from './TitleGenerator';
import { ImageControl } from '../style-controls/ImageControl';
import { ContainerControl } from '../style-controls/ContainerControl';
import { FlexContainerControl } from '../style-controls/FlexContainerControl';
import { PostGridControl } from '../style-controls/PostGridControl';
import type { Widget, ResponsiveValue, ResponsiveMode } from '@/lib/types';
import { HtmlControl } from '../style-controls/HtmlControl';
import { ResponsiveToggle } from '../style-controls/ResponsiveToggle';
import { PostTagsControl } from '../style-controls/PostTagsControl';
import { CSSProperties } from 'react';

export function StylePanel() {
  const { state, dispatch } = useEditor();
  const responsiveMode = state.responsiveMode;

  const findElementRecursive = (elements: Widget[], id: string): Widget | null => {
    for (const el of elements) {
      if (el.id === id) return el;
      if (el.children && el.children.length > 0) {
        const found = findElementRecursive(el.children, id);
        if (found) return found;
      }
    }
    return null;
  };

  const selectedElement = state.selectedElementId
    ? findElementRecursive(state.elements, state.selectedElementId)
    : null;

  if (!selectedElement) {
    return (
      <div className="p-4 text-center text-muted-foreground">
        Selectează un element de pe pânză pentru a-i edita stilurile.
      </div>
    );
  }

  const handleStyleChange = (newStyles: ResponsiveValue<CSSProperties>) => {
    dispatch({
      type: 'UPDATE_ELEMENT',
      payload: { elementId: selectedElement.id, styles: newStyles },
    });
  };

  const handlePropChange = (newProps: { [key: string]: any }) => {
    console.log('StylePanel - handlePropChange called with:', newProps);
    dispatch({
      type: 'UPDATE_ELEMENT',
      payload: { elementId: selectedElement.id, props: newProps },
    });
  };

  const handleModeChange = (mode: ResponsiveMode) => {
    dispatch({ type: 'SET_RESPONSIVE_MODE', payload: { mode } });
  };

  return (
    <div className="w-full">
      <div className="p-4 border-b">
        <h3 className="font-semibold">Stiluri {selectedElement.type}</h3>
        <p className="text-sm text-muted-foreground">ID: {selectedElement.id.slice(0, 6)}</p>
        <div className="mt-2">
          <ResponsiveToggle
            selectedMode={responsiveMode}
            onModeChange={handleModeChange}
          />
        </div>
      </div>

      <Accordion type="multiple" defaultValue={['general', 'content', 'spacing', 'typography', 'color', 'border']} className="w-full">
         {selectedElement.type === 'Container' && (
          <AccordionItem value="general">
            <AccordionTrigger className="px-4">Aspect Grilă</AccordionTrigger>
            <AccordionContent className="px-4">
              <ContainerControl
                props={selectedElement.props}
                onPropsChange={handlePropChange}
                styles={selectedElement.styles}
                onStylesChange={handleStyleChange}
                responsiveMode={responsiveMode}
              />
            </AccordionContent>
          </AccordionItem>
        )}

        {selectedElement.type === 'FlexContainer' && (
          <AccordionItem value="general">
            <AccordionTrigger className="px-4">Aspect FlexGrid</AccordionTrigger>
            <AccordionContent className="px-4">
              <FlexContainerControl
                props={selectedElement.props}
                onPropsChange={handlePropChange}
                styles={selectedElement.styles}
                onStylesChange={handleStyleChange}
                responsiveMode={responsiveMode}
              />
            </AccordionContent>
          </AccordionItem>
        )}

        {selectedElement.type === 'PostGrid' && (
          <AccordionItem value="general">
            <AccordionTrigger className="px-4">Configurare Grilă Postări</AccordionTrigger>
            <AccordionContent className="px-4 pt-2">
              <PostGridControl
                props={selectedElement.props}
                onPropsChange={handlePropChange}
              />
            </AccordionContent>
          </AccordionItem>
        )}

        {selectedElement.type === 'PostTags' && (
          <AccordionItem value="general">
            <AccordionTrigger className="px-4">Configurare Tag-uri Postare</AccordionTrigger>
            <AccordionContent className="px-4 pt-2">
              <PostTagsControl
                props={selectedElement.props}
                onPropsChange={handlePropChange}
              />
            </AccordionContent>
          </AccordionItem>
        )}
        
        {selectedElement.type === 'Html' && (
          <AccordionItem value="content">
            <AccordionTrigger className="px-4">Conținut HTML</AccordionTrigger>
            <AccordionContent className="px-4 pt-2">
              <HtmlControl
                props={selectedElement.props}
                onPropChange={handlePropChange}
              />
            </AccordionContent>
          </AccordionItem>
        )}

        {selectedElement.type === 'Image' && (
           <AccordionItem value="general">
             <AccordionTrigger className="px-4">Setări Imagine</AccordionTrigger>
             <AccordionContent className="px-4 pt-2">
               <ImageControl
                 currentSrc={selectedElement.props.src || ''}
                 currentAlt={selectedElement.props.alt || ''}
                 currentDescription={selectedElement.props.description || ''}
                 currentWidth={selectedElement.props.width}
                 currentHeight={selectedElement.props.height}
                 currentObjectFit={selectedElement.props.objectFit}
                 currentAspectRatio={selectedElement.props.aspectRatio}
                 currentAlignment={selectedElement.props.alignment}
                 onPropChange={handlePropChange}
               />
             </AccordionContent>
           </AccordionItem>
         )}

        {selectedElement.type === 'Heading' && (
          <AccordionItem value="ai-generator">
            <AccordionTrigger className="px-4">Unelte AI</AccordionTrigger>
            <AccordionContent className="px-4">
              <TitleGenerator
                currentTitle={selectedElement.props.text}
                onTitleSelect={(title) => handlePropChange({ text: title })}
              />
            </AccordionContent>
          </AccordionItem>
        )}

        {(selectedElement.type === 'Heading' || selectedElement.type === 'Text' || selectedElement.type === 'Button') && (
            <AccordionItem value="typography">
                <AccordionTrigger className="px-4">Tipografie</AccordionTrigger>
                <AccordionContent className="px-4 pt-2">
                    <TypographyControl
                    styles={selectedElement.styles}
                    onStylesChange={handleStyleChange}
                    responsiveMode={responsiveMode}
                    />
                </AccordionContent>
            </AccordionItem>
        )}

        <AccordionItem value="color">
            <AccordionTrigger className="px-4">Culoare</AccordionTrigger>
            <AccordionContent className="px-4 pt-2">
                <ColorControl
                  styles={selectedElement.styles}
                  onStylesChange={handleStyleChange}
                  responsiveMode={responsiveMode}
                  showBackgroundColor={selectedElement.type !== 'Image'}
                />
            </AccordionContent>
        </AccordionItem>

        <AccordionItem value="spacing">
          <AccordionTrigger className="px-4">Spațiere</AccordionTrigger>
          <AccordionContent className="px-4 pt-2">
            <SpacingControl
              styles={selectedElement.styles}
              onStylesChange={handleStyleChange}
              responsiveMode={responsiveMode}
              elementType={selectedElement.type}
            />
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="border">
          <AccordionTrigger className="px-4">Bordură & Rază</AccordionTrigger>
          <AccordionContent className="px-4 pt-2">
            <BorderControl
              styles={selectedElement.styles}
              onStylesChange={handleStyleChange}
              responsiveMode={responsiveMode}
            />
          </AccordionContent>
        </AccordionItem>
      </Accordion>
    </div>
  );
}
