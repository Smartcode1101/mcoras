
'use client';

import { useEffect, useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { useEditor } from '@/contexts/editor-context';
import { getTemplatesAction, saveTemplateAction } from '@/lib/actions';
import { useToast } from '@/hooks/use-toast';
import { LayoutTemplate, Loader2, Save, Wand2 } from 'lucide-react';
import { ScrollArea } from '../ui/scroll-area';
import type { PageTemplate } from '@/lib/types';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Separator } from '../ui/separator';

interface TemplateDialogProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
}

export function TemplateDialog({ isOpen, onOpenChange }: TemplateDialogProps) {
  const { state, dispatch } = useEditor();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [templates, setTemplates] = useState<PageTemplate[]>([]);
  const [templateName, setTemplateName] = useState('');

  const fetchTemplates = async () => {
    setIsLoading(true);
    const result = await getTemplatesAction();
    if (result.error) {
      toast({ variant: 'destructive', title: 'Eroare', description: result.error });
    } else if (result.data) {
      setTemplates(result.data);
    }
    setIsLoading(false);
  };

  useEffect(() => {
    if (isOpen) {
      fetchTemplates();
    }
  }, [isOpen]);

  const handleSaveTemplate = async () => {
    if (!templateName.trim()) {
      toast({ variant: 'destructive', title: 'Eroare', description: 'Numele șablonului este obligatoriu.' });
      return;
    }
    setIsSaving(true);
    const result = await saveTemplateAction({ name: templateName, elements: state.elements });
    if (result.error) {
      toast({ variant: 'destructive', title: 'Eroare la salvare', description: result.error });
    } else {
      toast({ title: 'Succes', description: 'Șablonul a fost salvat.' });
      setTemplateName('');
      fetchTemplates(); // Refresh list
    }
    setIsSaving(false);
  };

  const handleUseTemplate = (template: PageTemplate) => {
    dispatch({ type: 'SET_ELEMENTS', payload: { elements: template.elements } });
    toast({ title: 'Șablon aplicat', description: `A fost încărcat șablonul "${template.name}".` });
    onOpenChange(false);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl h-[80vh] flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <LayoutTemplate className="w-6 h-6 text-primary" />
            Gestionează Șabloane
          </DialogTitle>
          <DialogDescription>
            Salvează designul curent ca șablon sau încarcă unul existent.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 p-1">
            <h3 className="font-semibold">Salvează Pagina Curentă ca Șablon</h3>
            <div className="flex items-center gap-2">
                <Input
                    placeholder="Nume șablon..."
                    value={templateName}
                    onChange={(e) => setTemplateName(e.target.value)}
                    disabled={isSaving}
                />
                <Button onClick={handleSaveTemplate} disabled={isSaving}>
                    {isSaving ? <Loader2 className="w-4 h-4 animate-spin"/> : <Save className="w-4 h-4" />}
                </Button>
            </div>
        </div>

        <Separator className="my-4" />

        <div className="flex-1 overflow-hidden flex flex-col">
          <h3 className="font-semibold mb-2">Șabloane Existente</h3>
          <ScrollArea className="flex-1 pr-6">
            {isLoading ? (
              <div className="flex items-center justify-center h-full">
                <Loader2 className="w-8 h-8 animate-spin text-primary" />
              </div>
            ) : templates.length > 0 ? (
              <div className="space-y-2">
                {templates.map((template) => (
                  <div key={template.id} className="flex items-center justify-between p-3 border rounded-md">
                    <p className="font-medium">{template.name}</p>
                    <Button variant="outline" size="sm" onClick={() => handleUseTemplate(template)}>
                        <Wand2 className="w-4 h-4 mr-2"/>
                        Folosește Șablonul
                    </Button>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center text-muted-foreground py-8">
                <p>Niciun șablon salvat încă.</p>
              </div>
            )}
          </ScrollArea>
        </div>
      </DialogContent>
    </Dialog>
  );
}
