'use client';

import { useEditor } from '@/contexts/editor-context';
import { ChevronRight, ChevronDown } from 'lucide-react';
import { useState } from 'react';
import type { Widget } from '@/lib/types';

interface TreeNodeProps {
  widget: Widget;
  level: number;
  selectedId: string | null;
  onSelect: (id: string) => void;
}

function TreeNode({ widget, level, selectedId, onSelect }: TreeNodeProps) {
  const [isExpanded, setIsExpanded] = useState(true);
  const hasChildren = widget.children && widget.children.length > 0;

  return (
    <div>
      <div
        className={`flex items-center py-1 px-2 cursor-pointer hover:bg-accent rounded-sm ${
          selectedId === widget.id ? 'bg-accent text-accent-foreground' : ''
        }`}
        style={{ paddingLeft: `${level * 16 + 8}px` }}
        onClick={() => onSelect(widget.id)}
      >
        {hasChildren ? (
          <button
            onClick={(e) => {
              e.stopPropagation();
              setIsExpanded(!isExpanded);
            }}
            className="mr-1 p-0.5 hover:bg-muted rounded"
          >
            {isExpanded ? <ChevronDown size={12} /> : <ChevronRight size={12} />}
          </button>
        ) : (
          <div className="w-4" />
        )}
        <span className="text-sm">{widget.type}</span>
      </div>
      {hasChildren && isExpanded && (
        <div>
          {widget.children!.map((child) => (
            <TreeNode
              key={child.id}
              widget={child}
              level={level + 1}
              selectedId={selectedId}
              onSelect={onSelect}
            />
          ))}
        </div>
      )}
    </div>
  );
}

export function PageStructureSidebar({ className }: { className?: string }) {
  const { state, dispatch } = useEditor();

  const handleSelect = (id: string) => {
    dispatch({ type: 'SELECT_ELEMENT', payload: { elementId: id } });
  };

  return (
    <aside className={`w-48 min-w-48 max-w-64 bg-card border-l border-border flex flex-col ${className || ''}`}>
      <div className="p-4 border-b border-border">
        <h3 className="font-semibold text-sm">Structura Paginii</h3>
      </div>
      <div className="flex-1 overflow-y-auto p-2">
        {state.elements.length === 0 ? (
          <p className="text-sm text-muted-foreground p-2">Niciun element adăugat</p>
        ) : (
          state.elements.map((widget) => (
            <TreeNode
              key={widget.id}
              widget={widget}
              level={0}
              selectedId={state.selectedElementId}
              onSelect={handleSelect}
            />
          ))
        )}
      </div>
    </aside>
  );
}