'use client';

import { useEffect } from 'react';
import { EditorProvider, useEditor } from '@/contexts/editor-context';
import { EditorHeader } from '@/components/editor/EditorHeader';
import { EditorSidebar } from '@/components/editor/EditorSidebar';
import { EditorCanvas } from '@/components/editor/EditorCanvas';
import { PageStructureSidebar } from '@/components/editor/PageStructureSidebar';
import { Toaster } from '@/components/ui/toaster';
import type { PageData } from '@/lib/types';

export function Editor({ initialPageData }: { initialPageData?: PageData }) {
  return (
    <EditorProvider initialData={initialPageData}>
      <EditorContent />
      <Toaster />
    </EditorProvider>
  );
}

function EditorContent() {
  const { state, dispatch } = useEditor();

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape' && state.isFullScreen) {
        dispatch({ type: 'TOGGLE_FULLSCREEN' });
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [state.isFullScreen, dispatch]);

  return (
    <div className="flex flex-col h-screen bg-background text-foreground">
      {!state.isFullScreen && <EditorHeader />}
      <div className="flex flex-1 overflow-hidden relative">
        <main className="flex-1 overflow-y-auto">
          <EditorCanvas />
        </main>
        {!state.isFullScreen && <EditorSidebar className="absolute left-0 top-0 h-full z-10" />}
        {!state.isFullScreen && <PageStructureSidebar className="absolute right-0 top-0 h-full z-10" />}
      </div>
    </div>
  );
}
