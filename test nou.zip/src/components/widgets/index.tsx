'use client';
import { Heading } from './Heading';
import { Text } from './Text';
import { Image } from './Image';
import { Button } from './Button';
import { Spacer } from './Spacer';
import { Container } from './Container';
import { FlexContainer } from './FlexContainer';
import { Video } from './Video';
import { Html } from './Html';
import { PostGrid } from './PostGrid';
import { PostTags } from './PostTags';

export const WIDGET_COMPONENTS = {
  Heading,
  Text,
  Image,
  Video,
  Button,
  Spacer,
  Container,
  FlexContainer,
  Html,
  PostGrid,
  PostTags,
};
