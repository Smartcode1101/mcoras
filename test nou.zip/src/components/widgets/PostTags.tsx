'use client';

import type { CSSProperties } from 'react';
import type { ResponsiveMode } from '@/lib/types';
import Link from 'next/link';

type PostTagsProps = {
  id: string;
  className?: string;
  styles?: CSSProperties;
  responsiveMode?: ResponsiveMode;
  isEditorMode?: boolean;
  pageTags?: string[]; // ID-urile tag-urilor postării curente
  allTags?: { id: string; name: string; slug: string }[]; // Toate tag-urile disponibile
  label?: string;
  showLabel?: boolean;
  buttonStyle?: CSSProperties;
};

export function PostTags({
  id,
  className,
  styles,
  isEditorMode = false,
  pageTags = [],
  allTags = [],
  label = 'Tag-uri:',
  showLabel = true,
  buttonStyle,
}: PostTagsProps) {
  // Filtrăm tag-urile pentru a obține doar cele asociate postării
  const tags = allTags.filter(tag => pageTags.includes(tag.id));

  // Stiluri implicite pentru butoane
  const defaultButtonStyle: CSSProperties = {
    display: 'inline-block',
    padding: '6px 14px',
    marginRight: '8px',
    marginBottom: '8px',
    backgroundColor: '#3b82f6',
    color: '#ffffff',
    borderRadius: '20px',
    fontSize: '0.875rem',
    fontWeight: '500',
    textDecoration: 'none',
    transition: 'background-color 0.2s ease',
  };

  const mergedButtonStyle = { ...defaultButtonStyle, ...buttonStyle };

  // În editor mode, afișăm un placeholder
  if (isEditorMode) {
    return (
      <div id={id} className={className} style={styles}>
        {showLabel && (
          <span style={{ marginRight: '8px', fontWeight: '500' }}>{label}</span>
        )}
        {tags.length > 0 ? (
          tags.map(tag => (
            <span key={tag.id} style={mergedButtonStyle}>
              {tag.name}
            </span>
          ))
        ) : (
          <span style={{ color: '#666', fontStyle: 'italic' }}>
            Adaugă tag-uri postării pentru a le afișa aici
          </span>
        )}
      </div>
    );
  }

  // În frontend, afișăm link-uri către paginile tag-urilor
  if (tags.length === 0) {
    return null;
  }

  return (
    <div id={id} className={className} style={styles}>
      {showLabel && (
        <span style={{ marginRight: '8px', fontWeight: '500' }}>{label}</span>
      )}
      {tags.map(tag => (
        <Link
          key={tag.id}
          href={`/tag/${tag.slug}`}
          style={mergedButtonStyle}
          onMouseEnter={(e) => {
            e.currentTarget.style.backgroundColor = '#2563eb';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.backgroundColor = (buttonStyle?.backgroundColor as string) || '#3b82f6';
          }}
        >
          {tag.name}
        </Link>
      ))}
    </div>
  );
}
