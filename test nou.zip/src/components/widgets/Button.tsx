import type { CSSProperties } from 'react';

type ButtonProps = {
  text: string;
  href: string;
  className: string;
  styles: CSSProperties;
  isEditing: boolean;
  onTextChange: (text: string) => void;
  onStopEditing: () => void;
};

export const Button = ({ text, href, className, styles, isEditing, onTextChange, onStopEditing }: ButtonProps) => {
  
  const handleBlur = (e: React.FocusEvent<HTMLAnchorElement>) => {
    onTextChange(e.currentTarget.textContent || '');
    onStopEditing();
  };

  if (isEditing) {
    return (
      <a 
        href={href} 
        className={className} 
        style={styles}
        contentEditable
        suppressContentEditableWarning
        onBlur={handleBlur}
        dangerouslySetInnerHTML={{ __html: text }}
      />
    );
  }

  return (
    <a href={href} className={className} style={styles}>
      {text}
    </a>
  );
};
