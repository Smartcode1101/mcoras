import type { Widget } from '@/lib/types';
import { getWidgetDefaults } from './defaults';

export const basicTemplate: Widget[] = [
  {
    ...getWidgetDefaults('Heading'),
    id: 'h1',
    props: {
      text: 'Welcome to PageForge',
      level: 1,
    },
    styles: {
      desktop: {
        ...getWidgetDefaults('Heading').styles.desktop,
        textAlign: 'center',
        fontSize: '3rem',
      },
    },
  },
  {
    ...getWidgetDefaults('Text'),
    id: 'p1',
    props: {
      text: 'This is a simple template to get you started. You can drag and drop widgets from the left panel, click on them to edit styles, and build your perfect page.',
    },
    styles: {
      desktop: {
        ...getWidgetDefaults('Text').styles.desktop,
        textAlign: 'center',
        fontSize: '1.125rem',
        maxWidth: '600px',
        margin: '0 auto',
      },
    },
  },
  {
    ...getWidgetDefaults('Spacer'),
    id: 's1',
    styles: {
      desktop: {
        ...getWidgetDefaults('Spacer').styles.desktop,
        height: '40px',
      },
    },
  },
  {
    ...getWidgetDefaults('Image'),
    id: 'i1',
    props: {
      src: 'https://picsum.photos/seed/template/1024/400',
      alt: 'Hero image',
    },
    styles: {
      desktop: {
        ...getWidgetDefaults('Image').styles.desktop,
        borderRadius: '8px',
      },
    },
  },
  {
    ...getWidgetDefaults('Button'),
    id: 'b1',
    props: {
      text: 'Get Started',
      href: '#',
    },
    styles: {
      desktop: {
        ...getWidgetDefaults('Button').styles.desktop,
        margin: '20px auto',
        display: 'block',
        width: 'fit-content'
      },
    },
  },
];
