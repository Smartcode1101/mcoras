'use client';

import { useEffect, useState } from 'react';
import NextImage from 'next/image';
import type { CSSProperties } from 'react';
import type { ResponsiveMode, ResponsiveValue, PageData } from '@/lib/types';
import Link from 'next/link';

interface PerformanceSettings {
  lazyLoadImages: boolean;
  reduceJsExecution: boolean;
}

// Helper function to get responsive value based on current mode
const getResponsiveValue = <T,>(
  value: T | ResponsiveValue<T> | undefined,
  mode: ResponsiveMode
): T | undefined => {
  if (value === undefined || value === null) return undefined;
  if (typeof value === 'object' && value !== null && !Array.isArray(value) && 'desktop' in value) {
    const responsiveValue = value as ResponsiveValue<T>;
    // Return the specific value for this mode, or undefined if not set
    return responsiveValue[mode];
  }
  return value as T;
};

// Helper function to get responsive styles
const getResponsiveStyles = (
  styles: ResponsiveValue<CSSProperties> | CSSProperties | undefined,
  mode: ResponsiveMode
): CSSProperties => {
  if (!styles) return {};
  if (typeof styles === 'object' && 'desktop' in styles) {
    const responsiveStyles = styles as ResponsiveValue<CSSProperties>;
    return responsiveStyles[mode] ?? responsiveStyles.desktop ?? {};
  }
  return styles as CSSProperties;
};

type PostGridProps = {
  className: string;
  styles?: ResponsiveValue<CSSProperties>;
  responsiveMode?: ResponsiveMode;
  // Configurări pentru grid
  postsPerPage?: number;
  showExcerpt?: boolean;
  excerptLength?: number;
  // Mărimea miniaturii (responsive)
  thumbnailWidth?: ResponsiveValue<number>;
  thumbnailHeight?: ResponsiveValue<number>;
  // Configurare responsive pentru coloane
  columns?: ResponsiveValue<number>;
  // Text pentru buton
  buttonText?: string;
  // Stiluri pentru buton
  buttonStyle?: {
    backgroundColor?: string;
    backgroundGradient?: string;
    color?: string;
    borderRadius?: number;
    padding?: { top: number; bottom: number; left: number; right: number };
  };
};

export const PostGrid = ({
  className,
  styles,
  responsiveMode,
  postsPerPage,
  showExcerpt,
  excerptLength,
  thumbnailWidth,
  thumbnailHeight,
  columns,
  buttonText,
  buttonStyle
}: PostGridProps) => {
  const [posts, setPosts] = useState<PageData[]>([]);
  const [loading, setLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const [performanceSettings, setPerformanceSettings] = useState<PerformanceSettings>({
    lazyLoadImages: true,
    reduceJsExecution: true
  });

  // Force re-render when responsiveMode changes
  const [renderKey, setRenderKey] = useState(0);
  const [previousResponsiveMode, setPreviousResponsiveMode] = useState<string | null>(null);

  // Default values for responsive modes
  const defaultColumns = { desktop: 4, tablet: 2, mobile: 1 };
  const defaultThumbnailWidth = { desktop: 300, tablet: 250, mobile: 200 };
  const defaultThumbnailHeight = { desktop: 200, tablet: 180, mobile: 150 };

  // Use props values or defaults
  const actualResponsiveMode = responsiveMode ?? 'desktop';
  const actualPostsPerPage = postsPerPage ?? 12;
  const actualShowExcerpt = showExcerpt ?? true;
  const actualExcerptLength = excerptLength ?? 150;
  const actualColumns = columns ?? defaultColumns;
  const actualThumbnailWidth = thumbnailWidth ?? defaultThumbnailWidth;
  const actualThumbnailHeight = thumbnailHeight ?? defaultThumbnailHeight;
  const actualButtonText = buttonText ?? 'Citește mai mult';

  useEffect(() => {
    setRenderKey(prev => prev + 1);
    
    // Debug logging only when responsive mode actually changes
    if (process.env.NODE_ENV === 'development' && actualResponsiveMode !== previousResponsiveMode) {
      console.log('PostGrid Responsive Mode Change:', {
        previousMode: previousResponsiveMode,
        newMode: actualResponsiveMode,
        affectedProps: {
          columns: columns ? Object.keys(columns).join(', ') : 'default',
          thumbnailWidth: thumbnailWidth ? Object.keys(thumbnailWidth).join(', ') : 'default',
          thumbnailHeight: thumbnailHeight ? Object.keys(thumbnailHeight).join(', ') : 'default'
        }
      });
      setPreviousResponsiveMode(actualResponsiveMode);
    }
  }, [actualResponsiveMode, columns, thumbnailWidth, thumbnailHeight, postsPerPage, showExcerpt, excerptLength, buttonText, previousResponsiveMode]);

  useEffect(() => {
    const fetchPosts = async () => {
      try {
        const response = await fetch('/api/posts');
        if (response.ok) {
          const data = await response.json();
          setPosts(data.filter((post: PageData) => post.type === 'post'));
        }
      } catch (error) {
        console.error('Eroare la încărcarea postărilor:', error);
      } finally {
        setLoading(false);
      }
    };

    // Fetch performance settings
    const fetchPerformanceSettings = async () => {
      try {
        const response = await fetch('/api/admin/performance-settings');
        if (response.ok) {
          const data = await response.json();
          setPerformanceSettings({
            lazyLoadImages: data.lazyLoadImages ?? true,
            reduceJsExecution: data.reduceJsExecution ?? true
          });
        }
      } catch {
        // Use defaults
      }
    };

    fetchPosts();
    fetchPerformanceSettings();
  }, []);

  // Get responsive values for current mode
  const currentStyles = getResponsiveStyles(styles, actualResponsiveMode);
  const currentColumns = getResponsiveValue(actualColumns, actualResponsiveMode) || defaultColumns[actualResponsiveMode] || defaultColumns.mobile || 1;
  const currentThumbnailWidth = getResponsiveValue(actualThumbnailWidth, actualResponsiveMode) || defaultThumbnailWidth[actualResponsiveMode] || defaultThumbnailWidth.mobile || 300;
  const currentThumbnailHeight = getResponsiveValue(actualThumbnailHeight, actualResponsiveMode) || defaultThumbnailHeight[actualResponsiveMode] || defaultThumbnailHeight.mobile || 200;

  // Debug logging for widget and columns (only log when mode or key changes)
  if (process.env.NODE_ENV === 'development' && (actualResponsiveMode !== previousResponsiveMode || renderKey === 0)) {
    console.log('PostGrid Widget Debug:', {
      responsiveMode: actualResponsiveMode,
      renderKey,
      columns: {
        actual: actualColumns,
        current: currentColumns,
        defaults: defaultColumns
      },
      thumbnails: {
        width: { actual: actualThumbnailWidth, current: currentThumbnailWidth },
        height: { actual: actualThumbnailHeight, current: currentThumbnailHeight }
      }
    });
  }

  // Grid container styles
  const gridContainerStyles: CSSProperties = {
    display: 'grid',
    gridTemplateColumns: `repeat(${currentColumns}, 1fr)`,
    gap: '24px',
    padding: '20px',
    maxWidth: '1200px',
    margin: '0 auto',
    ...currentStyles
  };

  // Individual card styles
  const cardStyles: CSSProperties = {
    backgroundColor: '#ffffff',
    borderRadius: '12px',
    boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)',
    overflow: 'hidden',
    transition: 'all 0.3s ease',
    display: 'flex',
    flexDirection: 'column',
    height: '100%'
  };

  const imageContainerStyles: CSSProperties = {
    position: 'relative',
    width: '100%',
    height: currentThumbnailHeight,
    overflow: 'hidden'
  };

  const buttonStyles: CSSProperties = {
    background: buttonStyle?.backgroundGradient || buttonStyle?.backgroundColor || '#2563eb',
    color: buttonStyle?.color || '#ffffff',
    padding: `${buttonStyle?.padding?.top || 12}px ${buttonStyle?.padding?.left || 20}px`,
    borderRadius: `${buttonStyle?.borderRadius || 8}px`,
    border: 'none',
    cursor: 'pointer',
    fontSize: '14px',
    fontWeight: '500',
    textDecoration: 'none',
    display: 'inline-block',
    textAlign: 'center',
    transition: 'background 0.2s ease',
    margin: '16px',
    boxShadow: '0 2px 4px rgba(0,0,0,0.1)', // Add shadow for better visibility
  };

  // Debug logging for button style
  if (process.env.NODE_ENV === 'development') {
    console.log('PostGrid Button Style Debug:', {
      buttonStyle,
      finalStyles: buttonStyles,
      actualButtonText: actualButtonText
    });
  }

  const titleStyles: CSSProperties = {
    fontSize: '18px',
    fontWeight: '600',
    margin: '16px',
    marginBottom: '8px',
    color: '#1f2937',
    lineHeight: '1.4'
  };

  const excerptStyles: CSSProperties = {
    fontSize: '14px',
    color: '#6b7280',
    margin: '0 16px 16px 16px',
    lineHeight: '1.6',
    flexGrow: 1
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('ro-RO', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const truncateText = (text: string, maxLength: number) => {
    if (text.length <= maxLength) return text;
    return text.slice(0, maxLength) + '...';
  };

  if (loading) {
    return (
      <div className={className} style={currentStyles} key={`postgrid-loading-${renderKey}`}>
        <div style={gridContainerStyles}>
          {Array.from({ length: Math.min(actualPostsPerPage, currentColumns * 2) }).map((_, index) => (
            <div key={index} style={cardStyles}>
              <div style={{
                ...imageContainerStyles,
                backgroundColor: '#f3f4f6',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}>
                <span style={{ color: '#9ca3af', fontSize: '14px' }}>Se încarcă...</span>
              </div>
              <div style={titleStyles}>
                <div style={{
                  height: '20px',
                  backgroundColor: '#f3f4f6',
                  borderRadius: '4px',
                  marginBottom: '8px'
                }} />
                <div style={{
                  height: '20px',
                  backgroundColor: '#f3f4f6',
                  borderRadius: '4px',
                  width: '70%'
                }} />
              </div>
              {showExcerpt && (
                <div style={excerptStyles}>
                  <div style={{
                    height: '16px',
                    backgroundColor: '#f3f4f6',
                    borderRadius: '4px',
                    marginBottom: '8px'
                  }} />
                  <div style={{
                    height: '16px',
                    backgroundColor: '#f3f4f6',
                    borderRadius: '4px',
                    width: '80%'
                  }} />
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    );
  }

  const displayedPosts = posts.slice((currentPage - 1) * actualPostsPerPage, currentPage * actualPostsPerPage);

  const totalPages = Math.ceil(posts.length / actualPostsPerPage);

  const goToPage = (page: number) => {
    if (page >= 1 && page <= totalPages) {
      setCurrentPage(page);
    }
  };

  return (
    <div className={className} style={currentStyles} key={`postgrid-${renderKey}`}>
      <div style={gridContainerStyles}>
        {displayedPosts.map((post) => (
          <article key={post.id} style={cardStyles}>
            {/* Miniatura postării */}
            <div style={imageContainerStyles}>
              {post.thumbnail ? (
                <NextImage
                  src={post.thumbnail}
                  alt={post.title}
                  fill
                  loading={performanceSettings.lazyLoadImages ? 'lazy' : 'eager'}
                  style={{
                    objectFit: 'cover'
                  }}
                  sizes={`(max-width: 768px) 100vw, (max-width: 1200px) ${100 / currentColumns}vw, ${100 / currentColumns}vw`}
                />
              ) : (
                <div style={{
                  ...imageContainerStyles,
                  backgroundColor: '#f3f4f6',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center'
                }}>
                  <span style={{ color: '#9ca3af', fontSize: '14px' }}>Fără imagine</span>
                </div>
              )}
            </div>

            {/* Conținutul cardului */}
            <div style={{ flexGrow: 1 }}>
              <h3 style={titleStyles}>{post.title}</h3>
              
              {actualShowExcerpt && post.seoDescription && (
                <p style={excerptStyles}>
                  {truncateText(post.seoDescription, actualExcerptLength)}
                </p>
              )}
              
              <div style={{
                fontSize: '12px',
                color: '#9ca3af',
                margin: '0 16px 16px 16px'
              }}>
                {formatDate(post.updatedAt)}
              </div>
            </div>

            {/* Butonul către postare */}
            <div style={{ margin: '0 16px 16px 16px' }}>
              <Link 
                href={`/${post.slug}`}
                style={buttonStyles}
                onMouseEnter={(e) => {
                  const hoverBackground = buttonStyle?.backgroundColor ? 
                    (buttonStyle.backgroundColor.startsWith('#') ? 
                      buttonStyle.backgroundColor + 'dd' : buttonStyle.backgroundColor) 
                    : '#1d4ed8'; // Darker blue for hover
                  e.currentTarget.style.background = hoverBackground;
                }}
                onMouseLeave={(e) => {
                  const normalBackground = buttonStyle?.backgroundGradient || 
                    buttonStyle?.backgroundColor || '#2563eb';
                  e.currentTarget.style.background = normalBackground;
                }}
              >
                {actualButtonText}
              </Link>
            </div>
          </article>
        ))}
      </div>

      {displayedPosts.length === 0 && (
        <div style={{
          textAlign: 'center',
          padding: '40px 20px',
          color: '#6b7280',
          fontSize: '16px'
        }}>
          Nu există postări disponibile momentan.
        </div>
      )}

      {/* Paginare */}
      {totalPages > 1 && posts.length > actualPostsPerPage && (
        <div style={{ textAlign: 'center', marginTop: '32px' }}>
          {/* Buton Anterior */}
          <button
            onClick={() => goToPage(currentPage - 1)}
            disabled={currentPage === 1}
            style={{
              background: currentPage === 1 ? '#e5e7eb' : (buttonStyle?.backgroundGradient || buttonStyle?.backgroundColor || '#2563eb'),
              color: currentPage === 1 ? '#9ca3af' : (buttonStyle?.color || '#ffffff'),
              padding: '10px 16px',
              borderRadius: `${buttonStyle?.borderRadius || 8}px`,
              border: 'none',
              cursor: currentPage === 1 ? 'not-allowed' : 'pointer',
              fontSize: '14px',
              fontWeight: '500',
              marginRight: '8px',
              transition: 'background 0.2s ease',
            }}
            onMouseEnter={(e) => {
              if (currentPage !== 1) {
                const hoverBackground = buttonStyle?.backgroundColor ? 
                  (buttonStyle.backgroundColor.startsWith('#') ? 
                    buttonStyle.backgroundColor + 'dd' : buttonStyle.backgroundColor) 
                  : '#1d4ed8';
                e.currentTarget.style.background = hoverBackground;
              }
            }}
            onMouseLeave={(e) => {
              const normalBackground = buttonStyle?.backgroundGradient || 
                buttonStyle?.backgroundColor || '#2563eb';
              e.currentTarget.style.background = currentPage === 1 ? '#e5e7eb' : normalBackground;
            }}
          >
            ‹ Înapoi
          </button>

          {/* Numere de pagină */}
          {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
            <button
              key={page}
              onClick={() => goToPage(page)}
              style={{
                background: currentPage === page ? (buttonStyle?.backgroundGradient || buttonStyle?.backgroundColor || '#2563eb') : 'transparent',
                color: currentPage === page ? (buttonStyle?.color || '#ffffff') : '#374151',
                padding: '10px 14px',
                borderRadius: `${buttonStyle?.borderRadius || 8}px`,
                border: currentPage === page ? 'none' : '1px solid #d1d5db',
                cursor: 'pointer',
                fontSize: '14px',
                fontWeight: '500',
                margin: '0 4px',
                transition: 'all 0.2s ease',
              }}
              onMouseEnter={(e) => {
                if (currentPage !== page) {
                  e.currentTarget.style.background = '#f3f4f6';
                }
              }}
              onMouseLeave={(e) => {
                const bg = currentPage === page ? (buttonStyle?.backgroundGradient || buttonStyle?.backgroundColor || '#2563eb') : 'transparent';
                const color = currentPage === page ? (buttonStyle?.color || '#ffffff') : '#374151';
                e.currentTarget.style.background = bg;
                e.currentTarget.style.color = color;
              }}
            >
              {page}
            </button>
          ))}

          {/* Buton Următorul */}
          <button
            onClick={() => goToPage(currentPage + 1)}
            disabled={currentPage === totalPages}
            style={{
              background: currentPage === totalPages ? '#e5e7eb' : (buttonStyle?.backgroundGradient || buttonStyle?.backgroundColor || '#2563eb'),
              color: currentPage === totalPages ? '#9ca3af' : (buttonStyle?.color || '#ffffff'),
              padding: '10px 16px',
              borderRadius: `${buttonStyle?.borderRadius || 8}px`,
              border: 'none',
              cursor: currentPage === totalPages ? 'not-allowed' : 'pointer',
              fontSize: '14px',
              fontWeight: '500',
              marginLeft: '8px',
              transition: 'background 0.2s ease',
            }}
            onMouseEnter={(e) => {
              if (currentPage !== totalPages) {
                const hoverBackground = buttonStyle?.backgroundColor ? 
                  (buttonStyle.backgroundColor.startsWith('#') ? 
                    buttonStyle.backgroundColor + 'dd' : buttonStyle.backgroundColor) 
                  : '#1d4ed8';
                e.currentTarget.style.background = hoverBackground;
              }
            }}
            onMouseLeave={(e) => {
              const normalBackground = buttonStyle?.backgroundGradient || 
                buttonStyle?.backgroundColor || '#2563eb';
              e.currentTarget.style.background = currentPage === totalPages ? '#e5e7eb' : normalBackground;
            }}
          >
            Înainte ›
          </button>
        </div>
      )}
    </div>
  );
};