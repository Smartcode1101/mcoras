'use client';

import { useEditor } from '@/contexts/editor-context';
import type { Widget, ResponsiveValue, ResponsiveMode } from '@/lib/types';
import { cn } from '@/lib/utils';
import { Trash2, GripVertical, Copy } from 'lucide-react';
import { WIDGET_COMPONENTS } from '../widgets';
import {
  ContextMenu,
  ContextMenuContent,
  ContextMenuItem,
  ContextMenuTrigger,
} from '@/components/ui/context-menu';
import type { CSSProperties } from 'react';

export function WidgetWrapper({ element }: { element: Widget }) {
  const { state, dispatch } = useEditor();
  const isSelected = state.selectedElementId === element.id;
  const isEditing = state.inlineEditingElementId === element.id;

  // Get responsive styles
  const getResponsiveStyles = (
    styles: ResponsiveValue<CSSProperties> | CSSProperties | undefined,
    mode: ResponsiveMode
  ): CSSProperties => {
    if (!styles) return {};
    if (typeof styles === 'object' && 'desktop' in styles) {
      const responsiveStyles = styles as ResponsiveValue<CSSProperties>;
      return responsiveStyles[mode] ?? responsiveStyles.desktop ?? {};
    }
    return styles as CSSProperties;
  };

  const currentStyles = getResponsiveStyles(element.styles, state.responsiveMode);

  const handleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isEditing) return;
    dispatch({ type: 'SELECT_ELEMENT', payload: { elementId: element.id } });
  };

  const handleDelete = () => {
    dispatch({ type: 'DELETE_ELEMENT', payload: { elementId: element.id } });
  };

  const handleDuplicate = () => {
    dispatch({ type: 'DUPLICATE_ELEMENT', payload: { elementId: element.id } });
  };

  const handleDragStart = (e: React.DragEvent) => {
    e.stopPropagation();
    e.dataTransfer.setData('widgetId', element.id);
  };

  const handleDoubleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (element.type === 'Heading' || element.type === 'Text' || element.type === 'Button' || element.type === 'Video') {
      dispatch({ type: 'SET_INLINE_EDITING_ELEMENT', payload: { elementId: element.id } });
    }
  };

  const handleTextChange = (text: string) => {
    dispatch({
      type: 'UPDATE_ELEMENT',
      payload: { elementId: element.id, props: { text } },
    });
  };
  
   const handlePropChange = (newProps: { [key: string]: any }) => {
    dispatch({
      type: 'UPDATE_ELEMENT',
      payload: { elementId: element.id, props: newProps },
    });
  };

  const stopEditing = () => {
    dispatch({ type: 'SET_INLINE_EDITING_ELEMENT', payload: { elementId: null } });
  };

  const Component = WIDGET_COMPONENTS[element.type];
  
  const componentProps = {
    ...element.props,
    id: element.id,
    className: `widget-${element.id}`,
    styles: element.styles,
    responsiveMode: state.responsiveMode,
    children: element.children,
    isEditing: isEditing,
    onTextChange: handleTextChange,
    onPropChange: handlePropChange,
    onStopEditing: stopEditing,
  };
  
  return (
    <ContextMenu>
      <ContextMenuTrigger asChild>
        <div
          className={cn(
            'relative group transition-all widget-wrapper',
            isSelected && !isEditing ? 'outline-2 outline-offset-2 outline outline-primary' : '',
            isEditing && 'outline-2 outline-offset-2 outline-ring'
          )}
          style={currentStyles}
          onClick={handleClick}
          onDoubleClick={handleDoubleClick}
          draggable={!isEditing}
          onDragStart={handleDragStart}
        >
          {!isEditing && (
            <>
              <div
                className={cn(
                  'absolute -top-2 -right-2 opacity-0 group-hover:opacity-100 transition-opacity flex gap-1 z-10',
                  isSelected && 'opacity-100'
                )}
              >
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    handleDelete();
                  }}
                  className="p-1 rounded-md bg-destructive text-destructive-foreground hover:bg-destructive/80"
                  aria-label="Delete element"
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              </div>
              <div
                className={cn(
                  'absolute -top-2 -left-2 opacity-0 group-hover:opacity-100 transition-opacity z-10 cursor-move',
                  isSelected && 'opacity-100'
                )}
              >
                <div
                  className="p-1 rounded-md bg-primary text-primary-foreground"
                  aria-label="Drag to move element"
                >
                  <GripVertical className="w-3 h-3" />
                </div>
              </div>
            </>
          )}
          {Component ? (
            <Component {...(componentProps as any)} />
          ) : (
            <div className="text-destructive">Unknown widget type: {element.type}</div>
          )}
        </div>
      </ContextMenuTrigger>
      <ContextMenuContent>
        <ContextMenuItem onSelect={handleDuplicate}>
          <Copy className="w-4 h-4 mr-2" />
          Duplicate
        </ContextMenuItem>
        <ContextMenuItem onSelect={handleDelete} className="text-destructive focus:text-destructive">
          <Trash2 className="w-4 h-4 mr-2" />
          Delete
        </ContextMenuItem>
      </ContextMenuContent>
    </ContextMenu>
  );
}
