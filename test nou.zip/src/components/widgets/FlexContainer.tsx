'use client';

import React, { useState, Fragment } from 'react';
import type { CSSProperties, ComponentType } from 'react';
import type { Widget, WidgetType } from '@/lib/types';
import { useEditor } from '@/contexts/editor-context';
import { WidgetWrapper } from '../editor/WidgetWrapper';
import { WIDGET_COMPONENTS } from '@/components/widgets';
import { Container } from './Container';
import { cn } from '@/lib/utils';

type FlexContainerProps = {
  id: string;
  tag?: 'div' | 'section';
  className?: string;
  styles?: CSSProperties;
  children?: Widget[];
  responsiveMode?: 'desktop' | 'tablet' | 'mobile';
  columns?: { desktop: number; tablet: number; mobile: number };
  direction?: 'row' | 'column';
  justifyContent?: 'flex-start' | 'center' | 'flex-end' | 'space-between' | 'space-around' | 'space-evenly';
  alignItems?: 'flex-start' | 'center' | 'flex-end' | 'stretch' | 'baseline';
  gap?: string | { desktop: string; tablet: string; mobile: string };
  isEditorMode?: boolean;
};

// Helper function to safely get widget type as string
function getWidgetTypeString(typeValue: unknown): string {
  if (typeValue === undefined || typeValue === null) {
    return 'Unknown';
  }
  if (typeof typeValue === 'function') {
    return typeValue.name || 'UnknownFunction';
  }
  return String(typeValue);
}

const FlexColumnDropZone = ({
  column,
  parentId,
  isPlaceholder = false,
  columnIndex,
  responsiveMode,
  isEditorMode,
  dispatch
}: {
  column: Widget;
  parentId: string;
  isPlaceholder?: boolean;
  columnIndex?: number;
  responsiveMode: 'desktop' | 'tablet' | 'mobile';
  isEditorMode: boolean;
  dispatch?: (action: any) => void;
}) => {
  console.log(`[FlexColumnDropZone] Rendering column:`, {
    columnId: column.id,
    columnType: column.type,
    childrenCount: column.children?.length || 0,
    isEditorMode,
    isPlaceholder,
    hasChildren: !!(column.children && column.children.length > 0)
  });

  const [isDraggingOver, setIsDraggingOver] = useState(false);
  const [dropIndex, setDropIndex] = useState<number | null>(null);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingOver(true);

    if (!isPlaceholder) {
      const dragY = e.clientY;
      const elements = Array.from((e.currentTarget as HTMLElement).querySelectorAll(':scope > .widget-wrapper'));

      const closest = elements.reduce((acc: { offset: number, index: number }, child: Element, index: number) => {
        const box = child.getBoundingClientRect();
        const offset = dragY - box.top - box.height / 2;
        if (offset < 0 && offset > acc.offset) {
          return { offset: offset, index: index };
        } else {
          return acc;
        }
      }, { offset: Number.NEGATIVE_INFINITY, index: elements.length });

      setDropIndex(closest.index);
    } else {
      setDropIndex(0);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingOver(false);
    setDropIndex(null);

    const widgetType = e.dataTransfer.getData('widgetType') as WidgetType;
    const widgetId = e.dataTransfer.getData('widgetId');

    if (widgetType && dispatch) {
      const finalDropIndex = isPlaceholder ? 0 : (dropIndex !== null ? dropIndex : (column.children || []).length);

      dispatch({
        type: 'ADD_ELEMENT',
        payload: {
          index: finalDropIndex,
          element: { type: widgetType },
          parentId: column.id,
        },
      });
    } else if (widgetId) {
      // Moving existing widget - not implemented yet
    }
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.stopPropagation();
    setIsDraggingOver(false);
    setDropIndex(null);
  };

  if (isPlaceholder) {
    if (!isEditorMode) {
      return null;
    }

    return (
      <div
        className={cn(
          'transition-all border-2 border-dashed rounded-lg min-h-24 flex items-center justify-center',
          isDraggingOver ? 'border-primary bg-primary/10 border-solid' : 'border-gray-300 hover:border-gray-400'
        )}
        onDragOver={handleDragOver}
        onDrop={handleDrop}
        onDragLeave={handleDragLeave}
      >
        <div className="text-center text-muted-foreground p-4">
          <div className="text-sm font-medium">Coloana {columnIndex! + 1}</div>
          <div className="text-xs mt-1">
            {isDraggingOver ? 'Eliberează pentru a adăuga' : 'Trage widget-uri aici'}
          </div>
        </div>
      </div>
    );
  }

  const columnStyles: CSSProperties = {
    ...(column.styles as CSSProperties || {}),
    display: 'block',
    flexDirection: undefined,
    flex: undefined,
  };

  return (
    <div
      style={columnStyles}
      className={cn(
        'transition-all min-h-24',
        isDraggingOver && 'outline-dashed outline-2 outline-primary bg-primary/5'
      )}
      onDragOver={handleDragOver}
      onDrop={handleDrop}
      onDragLeave={handleDragLeave}
    >
      {(column.children || []).length === 0 ? (
        <>
          {dropIndex === 0 && <div className="h-2 my-2 bg-primary rounded-full" />}
          {isEditorMode && (
            <div className="flex items-center justify-center text-muted-foreground p-4 text-center text-sm h-full min-h-24 border-2 border-dashed border-gray-300 rounded">
              <div>
                <div className="text-xs font-medium">Coloana {columnIndex! + 1}</div>
                <div className="text-xs mt-1">Trage widget-uri aici</div>
              </div>
            </div>
          )}
        </>
      ) : (
        (column.children || []).map((element, index) => (
          <React.Fragment key={element.id}>
            {dropIndex === index && <div className="h-2 my-2 bg-primary rounded-full" />}
            {isEditorMode ? (
              <div className="widget-wrapper">
                <WidgetWrapper element={element} />
              </div>
            ) : (
              <div className="widget-wrapper">
                {(() => {
                  // Cast to any to handle both Widget and React element cases in frontend mode
                  const el = element as any;
                  
                  // Check if element is a React Fragment - render directly without widget processing
                  if (el && typeof el === 'object' && 'type' in el && el.type === Fragment) {
                    console.log(`[FlexColumnDropZone/Frontend] Direct Fragment render`, { index, hasKey: !!el.key });
                    
                    const fragmentChildren = el.props?.children;
                    const keyedChildren = React.Children.map(fragmentChildren, (c: any, i: number) => {
                      if (!c?.key) {
                        return <Fragment key={`child-${i}`}>{c}</Fragment>;
                      }
                      return c;
                    });
                    
                    return <Fragment key={el.key || `fragment-${index}`}>{keyedChildren}</Fragment>;
                  }
                  
                  // Check if element is a valid React element (not a widget) - render directly
                  if (el && typeof el === 'object' && 'type' in el && typeof el.type === 'function') {
                    console.log(`[FlexColumnDropZone/Frontend] Direct React element render`, { index, type: (el.type as any)?.name || 'unknown' });
                    const ElementComponent = el.type as React.ComponentType<any>;
                    return <ElementComponent key={el.key || `element-${index}`} {...el.props} responsiveMode={responsiveMode} isEditorMode={false} />;
                  }
                  
                  const elementType = getWidgetTypeString(element.type);

                  // In frontend mode, if element is a Container, we need to render its children directly
                  // because the element is already a React element from PageRenderer, not a Widget object
                  if (elementType === 'Container') {
                    const containerChildren = element.props?.children;
                    
                    // Wrap containerChildren in Fragments with proper keys if needed
                    const keyedContainerChildren = React.Children.map(containerChildren, (c: any, i: number) => {
                      if (!c?.key) {
                        return <Fragment key={`child-${i}`}>{c}</Fragment>;
                      }
                      return c;
                    });
                    
                    return (
                      <Container
                        key={element.id || `container-${index}`}
                        id={element.id || `container-${index}`}
                        tag={element.props?.tag || 'div'}
                        className={`widget-${element.id || `container-${index}`}`}
                        styles={(element.props?.styles as CSSProperties) ?? {}}
                        responsiveMode={responsiveMode}
                        isEditorMode={false}
                      >
                        {keyedContainerChildren}
                      </Container>
                    );
                  }

                  const Component = WIDGET_COMPONENTS[elementType as keyof typeof WIDGET_COMPONENTS] as ComponentType<any> | undefined;
                  if (!Component) {
                    return <div key={element.id || `unknown-${index}`} className="text-red-500">Unknown widget type: {elementType}</div>;
                  }

                  let componentProps: any = {
                    ...element.props,
                    id: element.id,
                    className: `widget-${element.id}`,
                    styles: (element.props?.styles as CSSProperties) ?? {},
                    responsiveMode,
                    isEditorMode: false,
                  };

                  switch (elementType) {
                    case 'Heading':
                    case 'Text':
                    case 'Button':
                      console.log(`[FlexColumnDropZone/Frontend] Rendering text widget:`, {
                        elementId: element.id,
                        elementType,
                        text: element.props?.text || ''
                      });
                      componentProps.text = element.props?.text || '';
                      break;
                    case 'Image':
                      console.log(`[FlexColumnDropZone/Frontend] Rendering image widget:`, {
                        elementId: element.id,
                        elementType,
                        src: element.props?.src || '',
                        alignment: element.props?.alignment
                      });
                      // Keep all existing props (including alignment) and add specific ones
                      componentProps.src = element.props?.src || '';
                      componentProps.alt = element.props?.alt || '';
                      break;
                  }

                  return <Component {...componentProps} />;
                })()}
              </div>
            )}
          </React.Fragment>
        ))
      )}
      {dropIndex === (column.children || []).length && <div className="h-2 my-2 bg-primary rounded-full" />}
    </div>
  );
};

export const FlexContainer = (props: FlexContainerProps) => {
  // If isEditorMode is explicitly provided, use it; otherwise compute from context
  const isEditorModeProp = props.isEditorMode;
  const isEditorMode = isEditorModeProp !== undefined
    ? isEditorModeProp
    : (() => {
        try {
          const { state } = useEditor();
          return state.selectedElementId !== null;
        } catch {
          return false;
        }
      })();

  console.log(`[FlexContainer] Rendering flex container:`, {
    id: props.id,
    isEditorMode,
    childrenCount: props.children?.length || 0,
    children: props.children?.map((c: Widget) => ({ id: c.id, type: c.type, hasChildren: !!(c.children && c.children.length > 0), childrenCount: c.children?.length || 0 })) || []
  });

  let dispatch: (action: any) => void = () => {};
  if (isEditorMode) {
    try {
      const editorContext = useEditor();
      dispatch = editorContext.dispatch;
    } catch {
      dispatch = () => {};
    }
  }

  const {
    id,
    tag = 'div',
    className = '',
    styles,
    children = [],
    responsiveMode = 'desktop',
    columns = { desktop: 2, tablet: 2, mobile: 1 },
    direction = 'row',
    justifyContent = 'center',
    alignItems = 'center',
    gap = '20px'
  } = props;

  const Tag = tag as keyof JSX.IntrinsicElements;

  const currentColumns = columns?.[responsiveMode] || 1;
  const currentGap = typeof gap === 'string' ? gap : gap?.[responsiveMode] || '20px';
  // Calculate flexBasis accounting for gap
  const gapValue = parseInt(currentGap) || 0;
  const totalGapWidth = gapValue * (currentColumns - 1);
  const flexBasis = `calc(${100 / currentColumns}% - ${totalGapWidth / currentColumns}px)`;

  // On mobile/tablet with 1 column, use column direction for vertical stacking
  const effectiveDirection = currentColumns === 1 ? 'column' : direction;

  const containerStyles: CSSProperties = {
    display: 'flex',
    flexDirection: effectiveDirection,
    flexWrap: 'nowrap',
    justifyContent,
    alignItems,
    gap: currentGap,
    ...styles,
  };

  // FRONTEND MODE - Simple, direct rendering
  if (!isEditorMode) {
    console.log(`[FlexContainer] Frontend mode - rendering children directly`);

    const renderChild = (child: Widget, index: number) => {
      // Cast to any to handle both Widget and React element cases in frontend mode
      const ch = child as any;
      
      console.log(`[FlexContainer/renderChild] START`, {
        index,
        childId: ch?.id,
        childType: ch?.type,
        hasProps: !!ch?.props,
        propsKeys: ch?.props ? Object.keys(ch.props) : [],
        alignment: ch?.props?.alignment,
        responsiveMode,
        isFunctionType: ch && typeof ch === 'object' && 'type' in ch && typeof ch.type === 'function'
      });
      
      // Check if child is a React Fragment - render directly without widget processing
      if (ch && typeof ch === 'object' && 'type' in ch && ch.type === Fragment) {
        console.log(`[FlexContainer/renderChild] Direct Fragment render`, { index, hasKey: !!ch.key });
        
        // Re-wrap Fragment children with keys if needed AND pass responsiveMode
        const fragmentChildren = ch.props?.children;
        const keyedChildren = React.Children.map(fragmentChildren, (c: any, i: number) => {
          if (!c?.key) {
            return <Fragment key={`child-${i}`}>{c}</Fragment>;
          }
          // If child is a valid element, clone it with responsiveMode
          if (React.isValidElement(c) && c.type !== Fragment) {
            return React.cloneElement(c as any, {
              key: c.key || `child-${i}`,
              responsiveMode,
              isEditorMode: false,
            });
          }
          return c;
        });
        
        return <Fragment key={ch.key || `fragment-${index}`}>{keyedChildren}</Fragment>;
      }
      
      // Check if child is a valid React element (not a widget) - render directly
      if (ch && typeof ch === 'object' && 'type' in ch && typeof ch.type === 'function') {
        console.log(`[FlexContainer/renderChild] Direct React element render`, { 
          index, 
          type: (ch.type as any)?.name || 'unknown',
          propsAlignment: ch.props?.alignment,
          responsiveMode
        });
        const ChildComponent = ch.type as React.ComponentType<any>;
        // Pass responsiveMode and isEditorMode to ensure proper rendering
        return <ChildComponent key={ch.key || `element-${index}`} {...ch.props} responsiveMode={responsiveMode} isEditorMode={false} />;
      }
      
      const childType = getWidgetTypeString(child.type);
      console.log(`[FlexContainer/renderChild] Rendering child:`, {
        index,
        childId: child.id,
        childType,
        childIsContainer: childType === 'Container',
        alignment: child.props?.alignment
      });

      // In frontend mode, if child is a Container, we need to render its children directly
      // because the child is already a React element from PageRenderer, not a Widget object
      if (childType === 'Container') {
        // Get the children from the Container's props.children (React elements)
        const containerChildren = child.props?.children;
        
        console.log(`[FlexContainer/renderChild] Container has ${containerChildren?.length || 0} children (React elements)`);
        
        // Wrap containerChildren in Fragments with proper keys if needed
        const keyedContainerChildren = React.Children.map(containerChildren, (c: any, i: number) => {
          if (!c?.key) {
            return <Fragment key={`child-${i}`}>{c}</Fragment>;
          }
          return c;
        });
        
        return (
          <Container
            key={child.id || `container-${index}`}
            id={child.id || `container-${index}`}
            tag={child.props?.tag || 'div'}
            className={`widget-${child.id || `container-${index}`}`}
            styles={(child.props?.styles as CSSProperties) ?? {}}
            responsiveMode={responsiveMode}
            isEditorMode={false}
          >
            {keyedContainerChildren}
          </Container>
        );
      }

      // For other widget types, render directly
      const Component = WIDGET_COMPONENTS[childType as keyof typeof WIDGET_COMPONENTS] as ComponentType<any> | undefined;
      if (!Component) {
        return <div key={child.id || `unknown-${index}`} className="text-red-500">Unknown widget type: {childType}</div>;
      }

      let componentProps: any = {
        ...child.props,
        id: child.id,
        className: `widget-${child.id}`,
        styles: (child.props?.styles as CSSProperties) ?? {},
        responsiveMode,
        isEditorMode: false,
      };

      switch (childType) {
        case 'Heading':
        case 'Text':
        case 'Button':
          console.log(`[FlexContainer/renderChild] Rendering text widget:`, {
            index,
            childId: child.id,
            childType,
            text: child.props?.text || ''
          });
          componentProps.text = child.props?.text || '';
          break;
        case 'Image':
          console.log(`[FlexContainer/renderChild] Rendering image widget:`, {
            index,
            childId: child.id,
            childType,
            src: child.props?.src || '',
            alignment: child.props?.alignment
          });
          // Keep all existing props (including alignment) and add specific ones
          componentProps.src = child.props?.src || '';
          componentProps.alt = child.props?.alt || '';
          break;
      }

      return <Component key={child.id} {...componentProps} />;
    };

    // Column wrapper styles for frontend mode
    // When direction is column, use 100% width instead of flexBasis
    const columnWrapperStyles: CSSProperties = effectiveDirection === 'column'
      ? {
          width: '100%',
          boxSizing: 'border-box',
        }
      : {
          flex: `0 0 ${flexBasis}`,
          maxWidth: flexBasis,
          boxSizing: 'border-box',
        };

    return (
      <Tag
        style={containerStyles}
        className={className}
        data-container-id={id}
      >
        {(children || []).map((child, index) => (
          <div
            key={child.id || `column-${index}`}
            className="flex-container-column"
            style={columnWrapperStyles}
          >
            {renderChild(child, index)}
          </div>
        ))}
      </Tag>
    );
  }

  // EDITOR MODE - Keep the complex logic for drag & drop
  const validChildren = Array.isArray(children) ? children : [];

  // In editor mode, when there are no children, create placeholders
  const displayChildren = validChildren.length > 0 ? validChildren :
    Array.from({ length: Math.max(1, currentColumns) }, (_, index) => ({
      id: `placeholder-${id}-${index}-${currentColumns}-${responsiveMode}`,
      type: 'Container' as const,
      props: {},
      styles: {},
      children: [],
    }));

  const ContainerTag = tag as keyof JSX.IntrinsicElements;

  // Pre-calculate column styles
  // When direction is column, use 100% width instead of flexBasis
  const columnStylesObj: CSSProperties = effectiveDirection === 'column'
    ? {
        width: '100%',
        boxSizing: 'border-box' as const,
        zIndex: 1,
      }
    : {
        flex: `0 0 ${flexBasis}`,
        maxWidth: flexBasis,
        boxSizing: 'border-box' as const,
        zIndex: 1,
      };

  return (
    <ContainerTag
      style={containerStyles}
      className={className}
      data-container-id={id}
    >
      {displayChildren.map((column, index) => {
        const isPlaceholder = column?.id?.startsWith('placeholder-') || false;

        return (
          <div
            key={column?.id || `column-${id}-${index}`}
            className="flex-container-column relative"
            style={columnStylesObj}
          >
            <FlexColumnDropZone
              column={column || { id: `fallback-${id}-${index}`, type: 'Container' as const, props: {}, styles: {}, children: [] }}
              parentId={id}
              isPlaceholder={isPlaceholder}
              columnIndex={index}
              responsiveMode={responsiveMode}
              isEditorMode={isEditorMode}
              dispatch={dispatch}
            />
          </div>
        );
      })}
    </ContainerTag>
  );
};
