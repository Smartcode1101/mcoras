'use client';
import type { CSSProperties } from 'react';

type HtmlProps = {
  html: string;
  className: string;
  styles: CSSProperties;
};

export const Html = ({ html, className, styles }: HtmlProps) => {
  return (
    <div
      style={styles}
      className={className}
      dangerouslySetInnerHTML={{ __html: html }}
    />
  );
};
