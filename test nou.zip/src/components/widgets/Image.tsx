import type { CSSProperties } from 'react';
import NextImage from 'next/image';
import type { ResponsiveMode, ResponsiveValue } from '@/lib/types';

type ImageProps = {
  src: string;
  alt: string;
  description?: string;
  width?: ResponsiveValue<number>;
  height?: ResponsiveValue<number>;
  objectFit?: ResponsiveValue<'cover' | 'contain' | 'fill' | 'none' | 'scale-down'>;
  aspectRatio?: ResponsiveValue<string>;
  alignment?: ResponsiveValue<'left' | 'center' | 'right'>;
  className: string;
  styles?: ResponsiveValue<CSSProperties>;
  responsiveMode?: ResponsiveMode;
  isEditorMode?: boolean; // Explicitly pass editor mode to avoid hydration issues
};

// Helper function to get responsive value based on current mode
const getResponsiveValue = <T,>(
    value: T | ResponsiveValue<T> | undefined,
    mode: ResponsiveMode
  ): T | undefined => {
    if (value === undefined || value === null) return undefined;
    if (typeof value === 'object' && value !== null && !Array.isArray(value) && 'desktop' in value) {
      const responsiveValue = value as ResponsiveValue<T>;
      // Try current mode first, then fallback to desktop, then return undefined if neither exists
      return responsiveValue[mode] ?? responsiveValue.desktop ?? undefined;
    }
    return value as T;
  };

// Helper function to get responsive styles
const getResponsiveStyles = (
  styles: ResponsiveValue<CSSProperties> | CSSProperties | undefined,
  mode: ResponsiveMode
): CSSProperties => {
  if (!styles) return {};
  if (typeof styles === 'object' && 'desktop' in styles) {
    const responsiveStyles = styles as ResponsiveValue<CSSProperties>;
    return responsiveStyles[mode] ?? responsiveStyles.desktop ?? {};
  }
  return styles as CSSProperties;
};

export const Image = ({
   src,
   alt,
   description,
   width,
   height,
   objectFit,
   aspectRatio,
   alignment,
   className,
   styles,
   responsiveMode = 'desktop',
   isEditorMode = false
  }: ImageProps) => {

   console.log(`[Image] Rendering with props:`, {
     src,
     alignment,
     alignmentType: typeof alignment,
     alignmentValue: alignment && typeof alignment === 'object' ? JSON.stringify(alignment) : alignment,
     responsiveMode,
     isEditorMode
   });

   // Get responsive styles
   const currentStyles = getResponsiveStyles(styles, responsiveMode);

   // The figure element handles background color and shadow for robustness
   const figureStyles: CSSProperties = {
     backgroundColor: currentStyles.backgroundColor,
     margin: 0, // Reset default figure margin
     boxShadow: currentStyles.boxShadow,
     borderRadius: `${currentStyles.borderTopLeftRadius || 0} ${currentStyles.borderTopRightRadius || 0} ${currentStyles.borderBottomRightRadius || 0} ${currentStyles.borderBottomLeftRadius || 0}`,
   };

   // Get responsive values for current mode
   const currentWidth = getResponsiveValue(width, responsiveMode);
   const currentHeight = getResponsiveValue(height, responsiveMode);
   const currentObjectFit = getResponsiveValue(objectFit, responsiveMode) || 'cover';
   const currentAspectRatio = getResponsiveValue(aspectRatio, responsiveMode);
   const currentAlignment = getResponsiveValue(alignment, responsiveMode) || 'center';

   // Container styles for alignment
   const containerStyles: CSSProperties = {
     display: 'flex',
     justifyContent: currentAlignment === 'center' ? 'center' : currentAlignment === 'right' ? 'flex-end' : 'flex-start',
     width: '100%',
     contain: 'layout style', // Prevent layout shifts but allow paint overflow for shadows
   };

   const captionStyles: CSSProperties = {
     fontSize: responsiveMode === 'mobile' ? '0.75rem' : responsiveMode === 'tablet' ? '0.8rem' : '0.875rem',
     color: currentStyles.color || '#666',
     textAlign: currentStyles.textAlign || 'center',
     marginTop: '8px',
     fontWeight: currentStyles.fontWeight,
     fontFamily: currentStyles.fontFamily,
     fontStyle: currentStyles.fontStyle,
     textDecoration: currentStyles.textDecoration,
     lineHeight: currentStyles.lineHeight,
     letterSpacing: currentStyles.letterSpacing,
   };


   // Determine if we should use Next.js Image or regular img
   const isExternalImage = src.startsWith('http') || src.startsWith('//');

   // For editor mode or external images, use regular img tag
   if (isEditorMode || isExternalImage) {
     // The img tag itself gets the border-radius and fit, shadow moved to figure
     const imageStyles: CSSProperties = {
       display: 'block',
       // Apply responsive sizing for all modes
       width: currentWidth ? `${currentWidth}px` : '100%',
       height: currentHeight ? `${currentHeight}px` : currentAspectRatio ? 'auto' : 'auto',
       aspectRatio: currentAspectRatio,
       objectFit: currentObjectFit,
       maxWidth: '100%', // Prevent overflow
       borderTopLeftRadius: currentStyles.borderTopLeftRadius,
       borderTopRightRadius: currentStyles.borderTopRightRadius,
       borderBottomLeftRadius: currentStyles.borderBottomLeftRadius,
       borderBottomRightRadius: currentStyles.borderBottomRightRadius,
     };

     return (
       <div key={`image-${currentAlignment}`} style={containerStyles}>
         <figure style={figureStyles} className={className}>
           {/* eslint-disable-next-line @next/next/no-img-element */}
           <img
             src={src}
             alt={alt}
             style={imageStyles}
           />
           {description && <figcaption style={captionStyles}>{description}</figcaption>}
         </figure>
       </div>
     );
   }

   // For frontend pages with local images, use Next.js Image for responsive optimization
   const imageProps = {
     src,
     alt,
     width: currentWidth || 800, // Default width if not specified
     height: currentHeight || 600, // Default height if not specified
     style: {
       borderTopLeftRadius: currentStyles.borderTopLeftRadius,
       borderTopRightRadius: currentStyles.borderTopRightRadius,
       borderBottomLeftRadius: currentStyles.borderBottomLeftRadius,
       borderBottomRightRadius: currentStyles.borderBottomRightRadius,
       objectFit: currentObjectFit,
       width: '100%',
       height: 'auto',
       aspectRatio: currentAspectRatio,
     },
     sizes: "(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw",
     loading: 'lazy' as const,
     priority: false, // Prevent priority loading for better LCP control
     placeholder: 'blur' as const,
     blurDataURL: 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCAAIAAoDASIAAhEBAAD/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCAAIAAoDASIAAhEBAxEB/8QAFQABAQAAAAAAAAAAAAAAAAAAAAv/xAAhEAACAQMDBQAAAAAAAAAAAAABAgMABAUGIWGRkqGx0f/EABUBAQEAAAAAAAAAAAAAAAAAAAMF/8QAGhEAAgIDAAAAAAAAAAAAAAAAAAECEgMRkf/aAAwDAQACEQMRAD8AltJagyeH0AthI5xdrLcNM91BF5pX2HaH9bcfaSXWGaRmknyJckliyjqTzSlT54b6bk+h0R+IRjWjBqO6O2mhP//Z',
     className,
   };

   return (
     <div key={`image-${currentAlignment}`} style={containerStyles}>
       <figure style={figureStyles}>
         <NextImage {...imageProps} />
         {description && <figcaption style={captionStyles}>{description}</figcaption>}
       </figure>
     </div>
   );
};
