import type { Widget, WidgetType, ResponsiveValue } from '@/lib/types';
import type { CSSProperties } from 'react';
import { generateId } from '@/lib/utils';

const createColumns = (count: number): Widget[] => {
  return Array.from({ length: count }, () => ({
    id: generateId(),
    type: 'Container', // We can treat columns as special containers
    props: {},
    styles: {
      desktop: {
        display: 'flex',
        flexDirection: 'column',
        gap: '0px',
        padding: '10px',
      },
    },
    children: [],
  }));
};

export const getWidgetDefaults = (type: WidgetType): Omit<Widget, 'id'> => {
  switch (type) {
    case 'Heading':
      return {
        type: 'Heading',
        props: {
          text: 'Acesta este un Titlu',
          level: 1,
        },
        styles: {
          desktop: {
            color: '#000000',
            textAlign: 'left',
            fontSize: '2.25rem',
            fontWeight: 'bold',
          },
        },
      };
    case 'Text':
      return {
        type: 'Text',
        props: {
          text: 'Acesta este un paragraf. Poți edita acest text pentru a adăuga propriul conținut. Spune-ți povestea și lasă vizitatorii să afle mai multe despre brandul tău.',
        },
        styles: {
          desktop: {
            color: '#333333',
            textAlign: 'left',
            fontSize: '1rem',
            whiteSpace: 'pre-wrap',
          },
        },
      };
    case 'Image':
      return {
        type: 'Image',
        props: {
          src: 'https://picsum.photos/seed/placeholder/600/400',
          alt: 'Imagine substituent',
          description: '',
          width: 600,
          height: 400,
          alignment: { desktop: 'center', tablet: 'center', mobile: 'center' },
          objectFit: { desktop: 'cover', tablet: 'cover', mobile: 'cover' },
        },
        styles: {
          desktop: {},
        },
      };
    case 'Video':
      return {
        type: 'Video',
        props: {
          src: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
        },
        styles: {
          desktop: {},
        },
      };
    case 'Button':
      return {
        type: 'Button',
        props: {
          text: 'Apasă Aici',
          href: '#',
        },
        styles: {
          desktop: {
            backgroundColor: '#7CB9E8',
            color: '#112233',
            paddingTop: '10px',
            paddingBottom: '10px',
            paddingLeft: '20px',
            paddingRight: '20px',
            borderRadius: '8px',
            textAlign: 'center',
            fontSize: '1rem',
            fontWeight: '500',
            textDecoration: 'none',
            display: 'inline-block',
          },
        },
      };
    case 'Spacer':
      return {
        type: 'Spacer',
        props: {},
        styles: {
          desktop: {
            height: '32px',
          },
        },
      };
    case 'Container':
      return {
        type: 'Container',
        props: {
          tag: 'div',
          columns: 1,
        },
        styles: {
          desktop: {
            display: 'grid',
            gridTemplateColumns: 'repeat(1, 1fr)',
            gap: '0px',
            padding: '10px',
          },
        },
        children: createColumns(1),
      };
    case 'FlexContainer':
      const columnCount = 2;
      return {
        type: 'FlexContainer',
        props: {
          tag: 'div',
          columns: { desktop: columnCount, tablet: 2, mobile: 1 },
          direction: 'row',
          justifyContent: 'flex-start',
          alignItems: 'flex-start',
          gap: { desktop: '20px', tablet: '15px', mobile: '10px' },
        },
        styles: {
          desktop: {
            display: 'flex',
            flexWrap: 'wrap',
            justifyContent: 'flex-start',
            alignItems: 'flex-start',
            gap: '20px',
            padding: '10px',
          },
          tablet: {
            display: 'flex',
            flexWrap: 'wrap',
            justifyContent: 'flex-start',
            alignItems: 'flex-start',
            gap: '15px',
            padding: '10px',
          },
          mobile: {
            display: 'flex',
            flexDirection: 'column',
            gap: '10px',
            padding: '10px',
          },
        },
        children: createColumns(columnCount),
      };
    case 'Html':
      return {
        type: 'Html',
        props: {
          html: '<div style="padding: 20px; border: 2px dashed #ccc;">\n  <h3>Bloc HTML Personalizat</h3>\n  <p>Poți edita acest conținut în editor.</p>\n</div>',
        },
        styles: {
          desktop: {},
        },
      };
    case 'PostGrid':
      return {
        type: 'PostGrid',
        props: {
          postsPerPage: 12,
          showExcerpt: true,
          excerptLength: 150,
          thumbnailWidth: { desktop: 300, tablet: 250, mobile: 200 },
          thumbnailHeight: { desktop: 200, tablet: 180, mobile: 150 },
          columns: { desktop: 4, tablet: 2, mobile: 1 },
          buttonText: 'Citește mai mult',
        },
        styles: {
          desktop: {
            padding: '20px',
          },
        },
      };
    case 'PostTags':
      return {
        type: 'PostTags',
        props: {
          label: 'Tag-uri:',
          showLabel: true,
          buttonStyle: {
            backgroundColor: '#3b82f6',
            color: '#ffffff',
            borderRadius: '20px',
            padding: '6px 14px',
            fontSize: '0.875rem',
            fontWeight: '500',
          },
        },
        styles: {
          desktop: {
            padding: '10px',
          },
        },
      };
    default:
      throw new Error(`Tip de widget necunoscut: ${type}`);
  }
};
