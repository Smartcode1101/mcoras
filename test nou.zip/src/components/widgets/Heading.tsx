import type { CSSProperties } from 'react';
import type { ResponsiveMode, ResponsiveValue } from '@/lib/types';
import { useEffect, useRef } from 'react';

type HeadingProps = {
  id: string;
  text: string;
  level?: 1 | 2 | 3 | 4 | 5 | 6;
  className: string;
  styles: ResponsiveValue<CSSProperties>;
  responsiveMode?: ResponsiveMode;
  isEditing: boolean;
  onTextChange: (text: string) => void;
  onStopEditing: () => void;
};

export const Heading = ({
  text,
  level = 1,
  className,
  styles,
  responsiveMode = 'desktop',
  isEditing,
  onTextChange,
  onStopEditing,
}: HeadingProps) => {
  const Tag = `h${level}` as any;
  const ref = useRef<HTMLHeadingElement>(null);

  useEffect(() => {
    if (isEditing && ref.current) {
      ref.current.focus();
      const range = document.createRange();
      range.selectNodeContents(ref.current);
      const sel = window.getSelection();
      sel?.removeAllRanges();
      sel?.addRange(range);
    }
  }, [isEditing]);

  const handleBlur = (e: React.FocusEvent<HTMLHeadingElement>) => {
    onTextChange(e.currentTarget.textContent || '');
    onStopEditing();
  };

  // Get responsive styles
  const getResponsiveStyles = (
    styles: ResponsiveValue<CSSProperties> | CSSProperties | undefined,
    mode: ResponsiveMode
  ): CSSProperties => {
    if (!styles) return {};
    if (typeof styles === 'object' && 'desktop' in styles) {
      const responsiveStyles = styles as ResponsiveValue<CSSProperties>;
      return responsiveStyles[mode] ?? responsiveStyles.desktop ?? {};
    }
    return styles as CSSProperties;
  };

  const currentStyles = getResponsiveStyles(styles, responsiveMode);

  const combinedProps = {
    style: currentStyles,
    className: className,
    ref: isEditing ? ref : undefined,
  };

  if (isEditing) {
    return (
      <Tag
        {...combinedProps}
        contentEditable
        suppressContentEditableWarning
        onBlur={handleBlur}
        dangerouslySetInnerHTML={{ __html: text }}
      />
    );
  }

  return <Tag {...combinedProps}>{text}</Tag>;
};
