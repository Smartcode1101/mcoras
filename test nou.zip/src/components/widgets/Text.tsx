import type { CSSProperties } from 'react';
import type { ResponsiveMode, ResponsiveValue } from '@/lib/types';
import { useEffect, useRef } from 'react';

type TextProps = {
  text: string;
  className: string;
  styles?: ResponsiveValue<CSSProperties>;
  responsiveMode?: ResponsiveMode;
  isEditing?: boolean;
  onTextChange?: (text: string) => void;
  onStopEditing?: () => void;
};

export const Text = ({ text, className, styles, responsiveMode, isEditing, onTextChange, onStopEditing }: TextProps) => {
  const ref = useRef<HTMLParagraphElement>(null);

  useEffect(() => {
    if (isEditing && ref.current) {
      ref.current.focus();
      // Move cursor to end
      const range = document.createRange();
      const sel = window.getSelection();
      if (ref.current.childNodes.length > 0) {
        range.selectNodeContents(ref.current);
        range.collapse(false); // Move to end
      } else {
        range.setStart(ref.current, 0);
        range.collapse(true);
      }
      sel?.removeAllRanges();
      sel?.addRange(range);
    }
  }, [isEditing]);

  const handleBlur = (e: React.FocusEvent<HTMLParagraphElement>) => {
    const newText = e.currentTarget.innerText || '';
    onTextChange?.(newText);
    onStopEditing?.();
  };

  // Get responsive styles if styles are provided (editor mode)
  let style: CSSProperties | undefined;
  if (styles) {
    const getResponsiveStyles = (
      styles: ResponsiveValue<CSSProperties> | CSSProperties | undefined,
      mode: ResponsiveMode
    ): CSSProperties => {
      if (!styles) return {};
      if (typeof styles === 'object' && 'desktop' in styles) {
        const responsiveStyles = styles as ResponsiveValue<CSSProperties>;
        return responsiveStyles[mode] ?? responsiveStyles.desktop ?? {};
      }
      return styles as CSSProperties;
    };

    const currentStyles = getResponsiveStyles(styles, responsiveMode || 'desktop');
    style = {
      ...currentStyles,
      whiteSpace: 'pre-wrap',
    };
  }

  const combinedProps = {
    className: className,
    style: style,
    ref: isEditing ? ref : undefined,
  };

  if (isEditing) {
    return (
      <p
        {...combinedProps}
        contentEditable
        suppressContentEditableWarning
        onBlur={handleBlur}
        dangerouslySetInnerHTML={{ __html: text.replace(/\n/g, '<br />') }}
      />
    );
  }

  return <p {...combinedProps} dangerouslySetInnerHTML={{ __html: text.replace(/\n/g, '<br />') }} />;
};