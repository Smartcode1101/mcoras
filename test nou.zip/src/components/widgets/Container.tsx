'use client';

import React, { useState, isValidElement, ReactNode, Fragment } from 'react';
import type { CSSProperties, ComponentType } from 'react';
import type { Widget, WidgetType } from '@/lib/types';
import { useEditor } from '@/contexts/editor-context';
import { WidgetWrapper } from '../editor/WidgetWrapper';
import { WIDGET_COMPONENTS } from '@/components/widgets';
import { cn } from '@/lib/utils';

type ContainerProps = {
  id: string;
  tag?: 'div' | 'section';
  className: string;
  styles?: CSSProperties;
  children?: Widget[] | ReactNode;
  responsiveMode?: 'desktop' | 'tablet' | 'mobile';
  isEditorMode?: boolean;
};

const ColumnDropZone = ({ column, parentId, isEditorMode, responsiveMode = 'desktop' }: { column: Widget; parentId: string; isEditorMode: boolean; responsiveMode?: 'desktop' | 'tablet' | 'mobile' }) => {
  console.log(`[Container/ColumnDropZone] Rendering column:`, {
    columnId: column.id,
    columnType: column.type,
    childrenCount: column.children?.length || 0,
    isEditorMode,
    hasChildren: !!(column.children && column.children.length > 0)
  });

  // Only get dispatch in editor mode
  let dispatch: ((action: any) => void) | undefined;
  if (isEditorMode) {
    try {
      const editorContext = useEditor();
      dispatch = editorContext.dispatch;
    } catch (error) {
      dispatch = undefined;
    }
  }

  const [isDraggingOver, setIsDraggingOver] = useState(false);
  const [dropIndex, setDropIndex] = useState<number | null>(null);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingOver(true);

    const dragY = e.clientY;
    const elements = Array.from((e.currentTarget as HTMLElement).querySelectorAll(':scope > .widget-wrapper'));

    const closest = elements.reduce((acc: { offset: number, index: number }, child: Element, index: number) => {
      const box = child.getBoundingClientRect();
      const offset = dragY - box.top - box.height / 2;
      if (offset < 0 && offset > acc.offset) {
        return { offset: offset, index: index };
      } else {
        return acc;
      }
    }, { offset: Number.NEGATIVE_INFINITY, index: elements.length });

    setDropIndex(closest.index);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDraggingOver(false);
    setDropIndex(null);
    const widgetType = e.dataTransfer.getData('widgetType') as WidgetType;
    const widgetId = e.dataTransfer.getData('widgetId');

    const finalDropIndex = dropIndex !== null ? dropIndex : (column.children || []).length;

    if (widgetType && dispatch) {
      dispatch({
        type: 'ADD_ELEMENT',
        payload: {
          index: finalDropIndex,
          element: { type: widgetType } as any,
          parentId: column.id,
        },
      });
    } else if (widgetId) {
      // Note: Moving elements would need a more complex implementation
    }
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.stopPropagation();
    setIsDraggingOver(false);
    setDropIndex(null);
  };

  const columnStyles: CSSProperties = {
    ...column.styles,
    display: 'block',
    flexDirection: undefined,
  };

  return (
    <div
      style={columnStyles}
      className={cn(
        'transition-all',
        isDraggingOver && 'outline-dashed outline-2 outline-primary'
      )}
      onDragOver={handleDragOver}
      onDrop={handleDrop}
      onDragLeave={handleDragLeave}
    >
      {(column.children || []).length === 0 ? (
        <>
          {dropIndex === 0 && <div className="h-2 my-2 bg-primary rounded-full" />}
          {isEditorMode && (
            <div className="flex items-center justify-center text-muted-foreground p-4 text-center text-sm h-full min-h-24">
              Trage un widget aici
            </div>
          )}
        </>
      ) : (
        (column.children || []).map((element, index) => (
          <React.Fragment key={element.id}>
            {dropIndex === index && <div className="h-2 my-2 bg-primary rounded-full" />}
            {isEditorMode ? (
              <div className="widget-wrapper">
                <WidgetWrapper element={element} />
              </div>
            ) : (
              // In frontend mode, render component directly without editor wrapper
              (() => {
                const elementType = String(element.type);
                
                const Component = WIDGET_COMPONENTS[elementType as keyof typeof WIDGET_COMPONENTS] as ComponentType<any> | undefined;
                if (!Component) {
                  return <div key={element.id || `unknown-${index}`} className="text-red-500">Unknown widget type: {elementType}</div>;
                }
                
                // Create component props based on widget type
                let componentProps: any = {
                  ...element.props,
                  id: element.id,
                  className: `widget-${element.id}`,
                  styles: element.styles,
                  responsiveMode,
                  isEditorMode: false,
                  children: element.children,
                };

                // Handle component-specific props for frontend mode
                switch (elementType) {
                  case 'Heading':
                  case 'Text':
                  case 'Button':
                    console.log(`[Container/Frontend] Rendering text widget:`, {
                      elementId: element.id,
                      elementType,
                      text: element.props.text || ''
                    });
                    componentProps = {
                      ...componentProps,
                      text: element.props.text || '',
                      isEditing: false,
                      onTextChange: () => {},
                      onStopEditing: () => {},
                    };
                    break;
                  case 'Image':
                    console.log(`[Container/Frontend] Rendering image widget:`, {
                      elementId: element.id,
                      elementType,
                      src: element.props.src || '',
                      alignment: element.props.alignment
                    });
                    // Keep all existing props (including alignment) and add specific ones
                    componentProps.src = element.props.src || '';
                    componentProps.alt = element.props.alt || '';
                    componentProps.isEditorMode = false;
                    break;
                  case 'Spacer':
                  case 'PostGrid':
                  case 'FlexContainer':
                    break;
                }
                
                return <Component {...componentProps} />;
              })()
            )}
          </React.Fragment>
        ))
      )}
      {dropIndex === (column.children || []).length && <div className="h-2 my-2 bg-primary rounded-full" />}
    </div>
  );
};

export const Container = ({ id, tag = 'div', className, styles, children, responsiveMode = 'desktop', isEditorMode: propIsEditorMode }: ContainerProps): JSX.Element => {
  const Tag = tag as keyof JSX.IntrinsicElements;

  // If isEditorMode is explicitly provided, use it; otherwise compute from context
  const isEditorMode = propIsEditorMode !== undefined 
    ? propIsEditorMode 
    : (() => {
        try {
          const { state } = useEditor();
          // Check if element is selected - this indicates we're in editor mode
          return state.selectedElementId !== null;
        } catch {
          return false;
        }
      })();

  console.log(`[Container] Rendering container:`, {
    id,
    isEditorMode,
    childrenType: Array.isArray(children) ? 'Widget[]' : 'ReactNode',
    childrenCount: Array.isArray(children) ? children?.length || 0 : 'N/A'
  });

  // Check if children are React elements (from FlexContainer) or Widget objects
  const childrenArray = children as any[];
  const hasWidgetChildren = childrenArray.length > 0 && typeof childrenArray[0] === 'object' && 'type' in childrenArray[0];
  const hasReactChildren = childrenArray.length > 0 && isValidElement(childrenArray[0]);

  // In frontend mode, if children are React elements (from FlexContainer), render them directly
  if (!isEditorMode && hasReactChildren) {
    console.log(`[Container] Frontend mode - rendering React children directly`, {
      id,
      responsiveMode,
      childrenCount: childrenArray.length,
      firstChildType: childrenArray[0]?.type,
      firstChildProps: childrenArray[0]?.props ? Object.keys(childrenArray[0].props) : []
    });
    return (
      <Tag style={styles} className={className} data-container-id={id}>
        {React.Children.map(childrenArray, (child: any, index: number) => {
          console.log(`[Container/child] Processing child`, {
            index,
            isFragment: isValidElement(child) && child.type === Fragment,
            isValidElement: isValidElement(child),
            childType: child?.type,
            propsAlignment: child?.props?.alignment,
            responsiveMode
          });
          
          // Check if child is a Fragment - process its children with responsiveMode
          if (isValidElement(child) && child.type === Fragment) {
            const fragmentChildren = (child.props as any)?.children;
            return React.Children.map(fragmentChildren, (c: any, i: number) => {
              if (React.isValidElement(c) && c.type !== Fragment) {
                return React.cloneElement(c as any, {
                  key: c.key || `fragment-child-${i}`,
                  responsiveMode,
                  isEditorMode: false,
                });
              }
              return c;
            });
          }
          // Clone the child element and pass responsiveMode and isEditorMode
          if (isValidElement(child)) {
            return React.cloneElement(child as any, {
              key: child.key || `child-${index}`,
              responsiveMode,
              isEditorMode: false,
            });
          }
          // Check if child is already keyed, if not add a key
          if (!child?.key) {
            return <Fragment key={`child-${index}`}>{child}</Fragment>;
          }
          return child;
        })}
      </Tag>
    );
  }

  // For Widget[] children (editor mode or nested Container columns)
  const widgetChildren = hasWidgetChildren ? childrenArray : [];
  
  return (
    <Tag style={styles} className={className} data-container-id={id}>
      {(widgetChildren || []).map((column) => (
        <ColumnDropZone key={column.id} column={column} parentId={id} isEditorMode={isEditorMode} responsiveMode={responsiveMode} />
      ))}
    </Tag>
  );
};
