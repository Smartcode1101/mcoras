import type { CSSProperties } from 'react';
import type { ResponsiveValue } from '@/lib/types';

type SpacerProps = {
  className: string;
  styles: ResponsiveValue<CSSProperties>;
  responsiveMode: 'desktop' | 'tablet' | 'mobile';
};

export const Spacer = ({ className, styles, responsiveMode }: SpacerProps) => {
  const currentStyles = styles?.[responsiveMode] || styles?.desktop || {};
  return (
    <div
      className={`${className} relative`}
      style={currentStyles}
    >
      <div className="absolute inset-0 flex items-center justify-center text-muted-foreground text-sm font-medium">
        Spațiu
      </div>
    </div>
  );
};
