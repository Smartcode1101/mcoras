'use client';
import type { CSSProperties } from 'react';
import { Input } from '../ui/input';

type VideoProps = {
  src: string;
  className: string;
  styles: CSSProperties;
  isEditing: boolean;
  onPropChange: (props: { src: string }) => void;
};

const getEmbedUrl = (url: string) => {
  if (!url) return '';
  let videoId = '';
  try {
    const urlObj = new URL(url);
    if (urlObj.hostname === 'youtu.be') {
      videoId = urlObj.pathname.slice(1);
    } else if (
      urlObj.hostname === 'www.youtube.com' ||
      urlObj.hostname === 'youtube.com'
    ) {
      videoId = urlObj.searchParams.get('v') || '';
    }
  } catch (error) {
    return '';
  }
  return videoId ? `https://www.youtube.com/embed/${videoId}` : '';
};

export const Video = ({ src, className, styles, isEditing, onPropChange }: VideoProps) => {
  const embedUrl = getEmbedUrl(src);

  if (isEditing) {
    return (
      <div style={styles} className={`${className} p-4 bg-muted rounded-md`}>
        <label className="text-sm font-medium">URL YouTube</label>
        <Input
          type="text"
          value={src}
          onChange={(e) => onPropChange({ src: e.target.value })}
          placeholder="https://www.youtube.com/watch?v=..."
          className="mt-1"
        />
      </div>
    );
  }

  const wrapperStyles: CSSProperties = {
    ...styles,
    position: 'relative',
    paddingBottom: '56.25%',
    height: 0,
    overflow: 'hidden',
    contain: 'layout style paint', // Prevent layout shifts
  };
  
  const iframeStyles: CSSProperties = {
    position: 'absolute',
    top: 0,
    left: 0,
    width: '100%',
    height: '100%',
  };

  return (
    <div
      style={wrapperStyles}
      className={className}
    >
      {embedUrl ? (
        <iframe
          src={`${embedUrl}?modestbranding=1&rel=0`}
          title="Player video YouTube"
          frameBorder="0"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
          loading="lazy"
          style={iframeStyles}
        ></iframe>
      ) : (
        <div style={iframeStyles} className="flex items-center justify-center bg-muted text-muted-foreground text-center p-4">
          <p>Te rog furnizează un URL YouTube valid în editor.</p>
        </div>
      )}
    </div>
  );
};
