'use client';
import { useState, useEffect, useRef } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { Search, Check, Upload, Loader2 } from 'lucide-react';

export interface MediaItem {
  id: string;
  src: string;
  alt: string;
  filename: string;
  createdAt: string;
}

interface MediaSelectorProps {
  isOpen: boolean;
  onClose: () => void;
  onSelect: (mediaItem: MediaItem) => void;
  selectedMedia?: MediaItem | null;
}

export function MediaSelector({ isOpen, onClose, onSelect, selectedMedia }: MediaSelectorProps) {
  const [mediaItems, setMediaItems] = useState<MediaItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [uploading, setUploading] = useState(false);
  const [activeTab, setActiveTab] = useState('library');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  useEffect(() => {
    if (isOpen) {
      fetchMediaItems();
    }
  }, [isOpen]);

  const fetchMediaItems = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/admin/media');
      const result = await response.json();
      
      if (result.success) {
        setMediaItems(result.data);
      }
    } catch (error) {
      console.error('Error fetching media:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith('image/')) {
      toast({ variant: 'destructive', title: 'Eroare', description: 'Te rugăm să selectezi doar fișiere de tip imagine.' });
      return;
    }

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast({ variant: 'destructive', title: 'Eroare', description: 'Fișierul este prea mare. Mărimea maximă este 5MB.' });
      return;
    }

    setUploading(true);
    try {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('alt', file.name.split('.')[0]);
      formData.append('filename', file.name);

      const response = await fetch('/api/admin/media/upload', {
        method: 'POST',
        body: formData,
      });

      const result = await response.json();
      
      if (result.success) {
        // Refresh media list
        await fetchMediaItems();
        // Auto-select the newly uploaded image
        onSelect(result.data);
        onClose();
        toast({ title: 'Succes!', description: 'Imaginea a fost încărcată și selectată ca logo.' });
      } else {
        toast({ variant: 'destructive', title: 'Eroare', description: 'Eroare la încărcarea fișierului: ' + result.error });
      }
    } catch (error) {
      console.error('Error uploading file:', error);
      toast({ variant: 'destructive', title: 'Eroare', description: 'Eroare la încărcarea fișierului.' });
    } finally {
      setUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const filteredMediaItems = mediaItems.filter(item =>
    item.alt.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.filename.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSelect = (item: MediaItem) => {
    onSelect(item);
    onClose();
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('ro-RO');
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[80vh]">
        <DialogHeader>
          <DialogTitle>Selectează sau Încarcă Logo</DialogTitle>
          <DialogDescription>
            Alege o imagine din bibliotecă sau încarcă un logo nou.
          </DialogDescription>
        </DialogHeader>
        
        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col overflow-hidden">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="library">Bibliotecă Media</TabsTrigger>
            <TabsTrigger value="upload">Încarcă Logo Nou</TabsTrigger>
          </TabsList>
          
          <TabsContent value="library" className="flex-1 overflow-hidden mt-4">
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <Search className="w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Caută în galeria media..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="flex-1"
                />
              </div>

              <ScrollArea className="h-80 w-full rounded-md border">
                {loading ? (
                  <div className="flex items-center justify-center h-full">
                    <div className="text-muted-foreground">Se încarcă galeria media...</div>
                  </div>
                ) : filteredMediaItems.length === 0 ? (
                  <div className="flex items-center justify-center h-full">
                    <div className="text-muted-foreground text-center">
                      {searchTerm ? 'Nu s-au găsit imagini care să corespundă căutării.' : 'Nu există imagini în galeria media.'}
                      <br />
                      {!searchTerm && (
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="mt-2"
                          onClick={() => setActiveTab('upload')}
                        >
                          <Upload className="w-4 h-4 mr-2" />
                          Încarcă primul logo
                        </Button>
                      )}
                    </div>
                  </div>
                ) : (
                  <div className="grid grid-cols-3 gap-4 p-4">
                    {filteredMediaItems.map((item) => (
                      <div
                        key={item.id}
                        className={`relative group cursor-pointer border-2 rounded-lg overflow-hidden transition-all ${
                          selectedMedia?.id === item.id
                            ? 'border-primary ring-2 ring-primary ring-offset-2'
                            : 'border-border hover:border-primary'
                        }`}
                        onClick={() => handleSelect(item)}
                      >
                        <div className="aspect-square relative">
                          <img
                            src={item.src}
                            alt={item.alt}
                            className="w-full h-full object-cover"
                            onError={(e) => {
                              const target = e.target as HTMLImageElement;
                              target.src = '/placeholder-image.png';
                            }}
                          />
                          {selectedMedia?.id === item.id && (
                            <div className="absolute top-2 right-2 bg-primary rounded-full p-1">
                              <Check className="w-3 h-3 text-primary-foreground" />
                            </div>
                          )}
                        </div>
                        <div className="p-2">
                          <p className="text-xs font-medium truncate">{item.alt}</p>
                          <p className="text-xs text-muted-foreground truncate">{item.filename}</p>
                          <Badge variant="secondary" className="mt-1 text-xs">
                            {formatDate(item.createdAt)}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </ScrollArea>
            </div>
          </TabsContent>
          
          <TabsContent value="upload" className="flex-1 overflow-hidden mt-4">
            <div className="space-y-4 h-full flex flex-col">
              <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-8 text-center">
                <Upload className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <Label htmlFor="file-upload" className="cursor-pointer">
                  <span className="text-lg font-medium">Fă clic pentru a încărca o imagine</span>
                  <br />
                  <span className="text-sm text-muted-foreground">
                    sau trage și aruncă fișierul aici
                  </span>
                </Label>
                <Input
                  ref={fileInputRef}
                  id="file-upload"
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleFileUpload}
                  disabled={uploading}
                />
                {uploading && (
                  <div className="mt-4 flex items-center justify-center gap-2">
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span className="text-sm">Se încarcă imaginea...</span>
                  </div>
                )}
              </div>
              <div className="text-xs text-muted-foreground text-center">
                <p>Formate suportate: JPG, PNG, GIF, WebP</p>
                <p>Mărimea maximă: 5MB</p>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}