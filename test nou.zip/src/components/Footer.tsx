'use client';
import type { CSSProperties } from 'react';
import type { SiteSettings } from '@/lib/types';

type FooterProps = {
  siteTitle?: string;
  styleSettings: SiteSettings['footerSettings'];
};

export function Footer({ siteTitle, styleSettings }: FooterProps) {
  const footerStyle: CSSProperties = {
      backgroundColor: styleSettings.backgroundColor,
      backdropFilter: `blur(${styleSettings.backdropBlur}px)`,
      borderTop: `1px solid ${styleSettings.borderColor}`,
  };

  const currentYear = new Date().getFullYear();

  return (
    <footer
      style={footerStyle}
      className="fixed bottom-0 left-0 right-0 z-50 transition-all duration-300"
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-center h-12">
          {styleSettings.showCopyright && (
            <p className="text-white text-sm">
              © {currentYear} {siteTitle || 'My Site'}. Toate drepturile rezervate.
            </p>
          )}
        </div>
      </div>
    </footer>
  );
}