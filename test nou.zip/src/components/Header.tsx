
'use client';
import { useState, type CSSProperties } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { Menu, X, User, LogOut, ChevronDown } from 'lucide-react';
import { usePathname, useRouter } from 'next/navigation';
import { cn } from '@/lib/utils';
import type { SiteSettings } from '@/lib/types';
import { useAuth } from '@/contexts/auth-context';
import { Button } from '@/components/ui/button';

type HeaderMenuItem = {
  title: string;
  slug: string;
  children?: HeaderMenuItem[];
  isSubmenu?: boolean;
};

type HeaderProps = {
   logoUrl?: string;
   siteTitle?: string;
   menuItems: HeaderMenuItem[];
   menuAlignment: 'left' | 'center' | 'right';
   styleSettings: SiteSettings['headerSettings'];
};

const alignmentClasses = {
  left: 'justify-start',
  center: 'justify-center',
  right: 'justify-end',
};

export function Header({ logoUrl, siteTitle, menuItems, menuAlignment, styleSettings }: HeaderProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [openSubmenu, setOpenSubmenu] = useState<string | null>(null);
  const pathname = usePathname();
  const router = useRouter();
  const { user, logout } = useAuth();

  const handleLogout = () => {
    logout();
    router.push('/');
  };

  const getLinkPath = (slug: string) => (slug === 'home' ? '/' : `/${slug}`);
  
  const headerStyle: CSSProperties = {
      backgroundColor: styleSettings.backgroundColor,
      backdropFilter: `blur(${styleSettings.backdropBlur}px)`,
      borderBottom: `1px solid ${styleSettings.borderColor}`,
  };

  const renderNavItem = (item: HeaderMenuItem, isMobile = false) => {
    const hasChildren = item.isSubmenu || (item.children && item.children.length > 0);
    const isActive = pathname === getLinkPath(item.slug);
    
    if (hasChildren) {
      // Mobile: click to toggle
      if (isMobile) {
        return (
          <div key={item.slug} className="w-full">
            <button
              className={cn(
                'w-full px-3 py-2 rounded-md text-sm font-medium transition-colors flex items-center justify-between',
                'text-white hover:bg-white/10'
              )}
              onClick={() => setOpenSubmenu(openSubmenu === item.slug ? null : item.slug)}
            >
              {item.title}
              <ChevronDown className={cn('h-4 w-4 transition-transform', openSubmenu === item.slug && 'rotate-180')} />
            </button>
            {openSubmenu === item.slug && (
              <div className="pl-4 mt-1 space-y-1 border-l-2 border-white/20 ml-2">
                {item.children?.map((child) => (
                  <Link
                    key={child.slug}
                    href={getLinkPath(child.slug)}
                    className={cn(
                      'block px-3 py-2 rounded-md text-sm font-medium text-white/80 hover:text-white hover:bg-white/10',
                      pathname === getLinkPath(child.slug) && 'bg-white/20 text-white'
                    )}
                    onClick={() => { setIsOpen(false); setOpenSubmenu(null); }}
                  >
                    {child.title}
                  </Link>
                ))}
              </div>
            )}
          </div>
        );
      }
      
      // Desktop: hover to show
      return (
        <div key={item.slug} className="relative group">
          <button
            className={cn(
              'px-3 py-2 rounded-md text-sm font-medium transition-colors flex items-center gap-1',
              'text-white hover:bg-white/10'
            )}
          >
            {item.title}
            <ChevronDown className="h-4 w-4 transition-transform group-hover:rotate-180" />
          </button>
          <div 
            className="absolute top-full left-0 pt-2 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200"
          >
            <div 
              className="min-w-[180px] rounded-lg shadow-xl py-2 border"
              style={{
                backgroundColor: styleSettings.backgroundColor,
                backdropFilter: `blur(${styleSettings.backdropBlur}px)`,
                borderColor: styleSettings.borderColor,
              }}
            >
              {item.children?.map((child) => (
                <Link
                  key={child.slug}
                  href={getLinkPath(child.slug)}
                  className={cn(
                    'block px-4 py-2 text-sm text-white/80 hover:text-white hover:bg-white/10 transition-colors',
                    pathname === getLinkPath(child.slug) && 'bg-white/20 text-white'
                  )}
                  onClick={() => setIsOpen(false)}
                >
                  {child.title}
                </Link>
              ))}
            </div>
          </div>
        </div>
      );
    }

    return (
      <Link
        key={item.slug}
        href={getLinkPath(item.slug)}
        className={cn(
          'px-3 py-2 rounded-md text-sm font-medium transition-colors',
          isActive
            ? 'text-white bg-white/20'
            : 'text-white hover:bg-white/10'
        )}
        onClick={() => setIsOpen(false)}
      >
        {item.title}
      </Link>
    );
  };

  const navLinks = (
    <>
      {menuItems.map((item) => renderNavItem(item, false))}
    </>
  );

  const mobileNavLinks = (
    <>
      {menuItems.map((item) => renderNavItem(item, true))}
    </>
  );

  return (
    <header
      style={headerStyle}
      className="fixed top-0 left-0 right-0 z-50 transition-all duration-300"
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex-shrink-0">
            <Link href="/" className="text-white text-xl font-bold">
              {logoUrl ? (
                <Image src={logoUrl} alt="Site Logo" width={120} height={40} className="h-10 w-auto" />
              ) : (
                siteTitle || 'My Site'
              )}
            </Link>
          </div>
          <div className="hidden md:flex md:flex-1 items-center" >
            <nav className={cn('flex-1 flex items-center space-x-4', alignmentClasses[menuAlignment])}>
                {navLinks}
            </nav>
          </div>
          <div className="flex items-center space-x-4">
            {user ? (
              <div className="hidden md:flex items-center space-x-4">
                <div className="flex items-center space-x-2 text-white">
                  <User className="h-4 w-4" />
                  <span className="text-sm">{user.role === 'admin' ? 'Admin' : 'User'}: {user.username}</span>
                </div>
                {user.role === 'admin' && (
                  <Link href="/admin">
                    <Button variant="outline" size="sm" className="bg-white/10 backdrop-blur-sm border-white/20 text-white hover:bg-white/20 hover:text-white">
                      Panou Admin
                    </Button>
                  </Link>
                )}
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleLogout}
                  className="bg-white/10 backdrop-blur-sm border-white/20 text-white hover:bg-white/20 hover:text-white"
                >
                  <LogOut className="h-4 w-4 mr-2" />
                  Logout
                </Button>
              </div>
            ) : (
              <div className="hidden md:flex items-center space-x-2">
                <Link href="/autentificare">
                  <Button variant="outline" size="sm" className="bg-white/10 backdrop-blur-sm border-white/20 text-white hover:bg-white/20 hover:text-white">
                    Autentificare
                  </Button>
                </Link>
                <Link href="/creare-cont">
                  <Button size="sm" className="bg-white/20 backdrop-blur-sm border-white/30 text-white hover:bg-white/30 hover:text-white">
                    Creează Cont
                  </Button>
                </Link>
              </div>
            )}
            <div className="md:hidden">
              <button
                onClick={() => setIsOpen(!isOpen)}
                className="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-white hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-white"
              >
                {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </button>
            </div>
          </div>
        </div>
      </div>
      {isOpen && (
        <div className="md:hidden">
          <nav className="px-2 pt-2 pb-3 space-y-1 sm:px-3 flex flex-col items-center">
            {mobileNavLinks}
            <div className="border-t border-white/20 mt-2 pt-2 w-full flex flex-col items-center space-y-2">
              {user ? (
                <>
                  <div className="flex items-center space-x-2 text-white">
                    <User className="h-4 w-4" />
                    <span className="text-sm">{user.role === 'admin' ? 'Admin' : 'User'}: {user.username}</span>
                  </div>
                  {user.role === 'admin' && (
                    <Link href="/admin" onClick={() => setIsOpen(false)}>
                      <Button variant="outline" size="sm" className="bg-white/10 backdrop-blur-sm border-white/20 text-white hover:bg-white/20 hover:text-white w-full">
                        Panou Admin
                      </Button>
                    </Link>
                  )}
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => { handleLogout(); setIsOpen(false); }}
                    className="bg-white/10 backdrop-blur-sm border-white/20 text-white hover:bg-white/20 hover:text-white w-full"
                  >
                    <LogOut className="h-4 w-4 mr-2" />
                    Logout
                  </Button>
                </>
              ) : (
                <>
                  <Link href="/autentificare" onClick={() => setIsOpen(false)}>
                    <Button variant="outline" size="sm" className="bg-white/10 backdrop-blur-sm border-white/20 text-white hover:bg-white/20 hover:text-white w-full">
                      Autentificare
                    </Button>
                  </Link>
                  <Link href="/creare-cont" onClick={() => setIsOpen(false)}>
                    <Button size="sm" className="bg-white/20 backdrop-blur-sm border-white/30 text-white hover:bg-white/30 hover:text-white w-full">
                      Creează Cont
                    </Button>
                  </Link>
                </>
              )}
            </div>
          </nav>
        </div>
      )}
    </header>
  );
}
