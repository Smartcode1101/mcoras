'use client';

import NextImage from 'next/image';
import { useState, useEffect } from 'react';
import type { ImageProps } from 'next/image';

interface OptimizedImageProps extends Omit<ImageProps, 'onLoad'> {
  lazy?: boolean;
  fadeIn?: boolean;
  placeholderColor?: string;
}

/**
 * Componentă pentru imagini optimizate cu lazy loading și efecte de fade-in
 */
export default function OptimizedImage({
  src,
  alt,
  lazy = true,
  fadeIn = true,
  placeholderColor = '#f3f4f6',
  className,
  style,
  ...props
}: OptimizedImageProps) {
  const [isLoaded, setIsLoaded] = useState(false);
  const [settings, setSettings] = useState({
    lazyLoadImages: true,
    reduceJsExecution: true
  });

  useEffect(() => {
    fetch('/api/admin/performance-settings')
      .then(res => res.json())
      .then(data => {
        setSettings({
          lazyLoadImages: data.lazyLoadImages ?? true,
          reduceJsExecution: data.reduceJsExecution ?? true
        });
      })
      .catch(() => {});
  }, []);

  const shouldLazyLoad = lazy && settings.lazyLoadImages;

  return (
    <div
      className={className}
      style={{
        position: 'relative',
        overflow: 'hidden',
        backgroundColor: placeholderColor,
        ...style
      }}
    >
      <NextImage
        src={src}
        alt={alt}
        loading={shouldLazyLoad ? 'lazy' : 'eager'}
        onLoad={() => setIsLoaded(true)}
        style={{
          transition: fadeIn ? 'opacity 0.3s ease-in-out' : 'none',
          opacity: fadeIn && !isLoaded ? 0 : 1,
        }}
        {...props}
      />
      {!isLoaded && (
        <div
          style={{
            position: 'absolute',
            inset: 0,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            backgroundColor: placeholderColor,
          }}
        >
          <div
            style={{
              width: '24px',
              height: '24px',
              border: '2px solid #e5e7eb',
              borderTopColor: '#3b82f6',
              borderRadius: '50%',
              animation: 'spin 1s linear infinite',
            }}
          />
        </div>
      )}
      <style jsx>{`
        @keyframes spin {
          to {
            transform: rotate(360deg);
          }
        }
      `}</style>
    </div>
  );
}
