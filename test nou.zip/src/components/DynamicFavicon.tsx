'use client';

import { useEffect } from 'react';

export function DynamicFavicon() {
  useEffect(() => {
    const updateFavicon = async () => {
      try {
        const response = await fetch('/api/site-settings');
        if (response.ok) {
          const data = await response.json();
          if (data.logoUrl) {
            // Update all favicon links
            const iconLink = document.querySelector("link[rel='icon']") || document.createElement('link');
            iconLink.setAttribute('rel', 'icon');
            iconLink.setAttribute('href', data.logoUrl);
            document.head.appendChild(iconLink);

            const shortcutLink = document.querySelector("link[rel='shortcut icon']") || document.createElement('link');
            shortcutLink.setAttribute('rel', 'shortcut icon');
            shortcutLink.setAttribute('href', data.logoUrl);
            document.head.appendChild(shortcutLink);

            const appleLink = document.querySelector("link[rel='apple-touch-icon']") || document.createElement('link');
            appleLink.setAttribute('rel', 'apple-touch-icon');
            appleLink.setAttribute('href', data.logoUrl);
            document.head.appendChild(appleLink);
          }
        }
      } catch (error) {
        console.error('Error updating favicon:', error);
      }
    };

    updateFavicon();
  }, []);

  return null;
}
