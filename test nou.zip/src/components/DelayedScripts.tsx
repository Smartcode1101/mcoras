'use client';

import Script from 'next/script';
import { useEffect, useState } from 'react';

interface DelayedScriptsProps {
  timeout?: number;
}

/**
 * Componentă pentru încărcarea întârziată a scripturilor non-critice
 * Îmbunătățește Core Web Vitals prin amânarea scripturilor care nu sunt esențiale
 */
export default function DelayedScripts({ timeout = 2000 }: DelayedScriptsProps) {
  const [loadScripts, setLoadScripts] = useState(false);
  const [settings, setSettings] = useState<{
    delayedJs: boolean;
    delayedJsTimeout: number;
    reduceJsExecution: boolean;
  }>({
    delayedJs: true,
    delayedJsTimeout: 2000,
    reduceJsExecution: true
  });

  useEffect(() => {
    // Încarcă setările de performanță
    fetch('/api/admin/performance-settings')
      .then(res => res.json())
      .then(data => {
        setSettings({
          delayedJs: data.delayedJs ?? true,
          delayedJsTimeout: data.delayedJsTimeout ?? 2000,
          reduceJsExecution: data.reduceJsExecution ?? true
        });
      })
      .catch(() => {
        // Folosește valorile default în caz de eroare
      });
  }, []);

  useEffect(() => {
    if (!settings.delayedJs) {
      setLoadScripts(true);
      return;
    }

    const actualTimeout = timeout || settings.delayedJsTimeout;
    
    // Folosește requestIdleCallback pentru a nu bloca interacțiunea utilizatorului
    if (settings.reduceJsExecution && 'requestIdleCallback' in window) {
      const idleCallback = requestIdleCallback(() => {
        setTimeout(() => setLoadScripts(true), actualTimeout);
      });
      return () => cancelIdleCallback(idleCallback);
    }

    const timer = setTimeout(() => {
      setLoadScripts(true);
    }, actualTimeout);

    return () => clearTimeout(timer);
  }, [settings.delayedJs, settings.delayedJsTimeout, settings.reduceJsExecution, timeout]);

  if (!loadScripts) {
    return null;
  }

  return (
    <>
      {/* Aici pot fi adăugate scripturi non-critice */}
      {/* Exemplu: Facebook Pixel, etc. */}
    </>
  );
}
