'use client';

import { useAnalytics } from '@/hooks/useAnalytics';

export function AnalyticsClient() {
  useAnalytics();
  return null;
}