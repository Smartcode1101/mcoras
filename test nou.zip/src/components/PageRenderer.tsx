'use client'

import { Fragment, useEffect, useState } from 'react';
import type { PageData, ResponsiveMode, Tag } from '@/lib/types';
import { WIDGET_COMPONENTS } from '@/components/widgets';
import { notFound } from 'next/navigation';
import { useEditor } from '@/contexts/editor-context';

export function PageRenderer({ page, allTags }: { page: PageData | null; allTags?: Tag[] }) {
  if (!page) {
    notFound();
  }

  // State pentru tag-uri în frontend
  const [tags, setTags] = useState<Tag[]>(allTags || []);

  // Încarcă tag-urile dacă nu sunt pasate ca prop
  useEffect(() => {
    if (!allTags) {
      fetch('/api/tags')
        .then(res => res.json())
        .then(data => setTags(data))
        .catch(err => console.error('Eroare la încărcarea tag-urilor:', err));
    }
  }, [allTags]);

  // Try to use editor context if available (for editor mode), otherwise use default responsive mode
  let responsiveMode: ResponsiveMode = 'desktop';
  try {
    const { state, dispatch } = useEditor();

    // Update responsive mode based on window size
    useEffect(() => {
      const updateMode = () => {
        const width = window.innerWidth;
        let mode: ResponsiveMode = 'desktop';
        if (width < 768) mode = 'mobile';
        else if (width < 1024) mode = 'tablet';
        dispatch({ type: 'SET_RESPONSIVE_MODE', payload: { mode } });
      };

      updateMode();
      window.addEventListener('resize', updateMode);
      return () => window.removeEventListener('resize', updateMode);
    }, [dispatch]);

    responsiveMode = state.responsiveMode;
  } catch (error) {
    // Not in editor context, use default desktop mode
    responsiveMode = 'desktop';
  }

  // Core Web Vitals logging
  useEffect(() => {
    if (typeof window !== 'undefined' && 'performance' in window) {
      // Log Largest Contentful Paint (LCP)
      const observer = new PerformanceObserver((list) => {
        const entries = list.getEntries();
        const lastEntry = entries[entries.length - 1];
        console.log('LCP:', lastEntry.startTime, 'ms');
      });
      observer.observe({ entryTypes: ['largest-contentful-paint'] });

      // Log First Input Delay (FID)
      const fidObserver = new PerformanceObserver((list) => {
        const entries = list.getEntries();
        entries.forEach((entry: any) => {
          console.log('FID:', entry.processingStart - entry.startTime, 'ms');
        });
      });
      fidObserver.observe({ entryTypes: ['first-input'] });

      // Log Cumulative Layout Shift (CLS)
      let clsValue = 0;
      const clsObserver = new PerformanceObserver((list) => {
        const entries = list.getEntries();
        entries.forEach((entry: any) => {
          if (!entry.hadRecentInput) {
            clsValue += entry.value;
          }
        });
        console.log('CLS:', clsValue);
      });
      clsObserver.observe({ entryTypes: ['layout-shift'] });

      // Log First Contentful Paint (FCP)
      const fcpObserver = new PerformanceObserver((list) => {
        const entries = list.getEntries();
        entries.forEach((entry) => {
          console.log('FCP:', entry.startTime, 'ms');
        });
      });
      fcpObserver.observe({ entryTypes: ['paint'] });

      return () => {
        observer.disconnect();
        fidObserver.disconnect();
        clsObserver.disconnect();
        fcpObserver.disconnect();
      };
    }
  }, []);

  const renderWidget = (element: any) => {
    console.log(`[PageRenderer] Rendering widget:`, {
      id: element.id,
      type: element.type,
      hasChildren: !!element.children,
      childrenCount: element.children?.length || 0,
      responsiveMode,
      childrenTypes: element.children?.map((child: any) => child.type) || []
    });

    const Component = WIDGET_COMPONENTS[element.type as keyof typeof WIDGET_COMPONENTS];
    if (!Component) {
      console.error(`[PageRenderer] Unknown widget type: ${element.type}`);
      return <div className="text-red-500">Unknown widget type: {String(element.type)}</div>;
    }

    // Additional validation to prevent rendering issues
    if (typeof Component !== 'function') {
      console.error(`[PageRenderer] Invalid component for type: ${element.type}`);
      return <div className="text-red-500">Invalid component for type: {String(element.type)}</div>;
    }

    let componentProps: any = {
      ...element.props,
      id: element.id,
      className: `widget-${element.id}`,
      responsiveMode: responsiveMode,
      children: element.children?.map((child: any, index: number) => (
        <Fragment key={child.id || `child-${index}`}>
          {renderWidget(child)}
        </Fragment>
      )),
    };

    // Handle component-specific props for frontend mode
    switch (element.type) {
      case 'Heading':
      case 'Text':
      case 'Button':
        componentProps = {
          ...componentProps,
          text: element.props.text || '',
          isEditing: false,
          onTextChange: () => {},
          onStopEditing: () => {},
        };
        break;
      case 'Image':
        console.log(`[PageRenderer] Image props before render:`, {
          elementId: element.id,
          src: element.props.src,
          alt: element.props.alt,
          alignment: element.props.alignment,
          width: element.props.width,
          height: element.props.height,
          objectFit: element.props.objectFit,
          responsiveMode
        });
        componentProps = {
          ...componentProps,
          src: element.props.src || '',
          alt: element.props.alt || '',
          alignment: element.props.alignment, // Preserve alignment
          width: element.props.width,
          height: element.props.height,
          objectFit: element.props.objectFit,
          isEditorMode: false,
        };
        break;
      case 'Spacer':
      case 'PostGrid':
      case 'FlexContainer':
        componentProps = {
          ...componentProps,
          isEditorMode: false,
        };
        break;
      case 'Container':
        componentProps = {
          ...componentProps,
          isEditorMode: false,
        };
        break;
      case 'Video':
      case 'Html':
        // These components don't need special handling
        break;
      case 'PostTags':
        componentProps = {
          ...componentProps,
          isEditorMode: false,
          pageTags: page.tags || [],
          allTags: tags,
        };
        break;
    }

    console.log(`[PageRenderer] Component ${element.type} will receive:`, {
      hasProps: !!componentProps,
      propsKeys: Object.keys(componentProps),
      childrenCount: element.children?.length || 0
    });
    
    try {
      const rendered = <Component {...componentProps} />;
      console.log(`[PageRenderer] Successfully rendered ${element.type} with id ${element.id}`);
      return rendered;
    } catch (error) {
      console.error(`[PageRenderer] Error rendering ${element.type}:`, error);
      return <div className="text-red-500">Error rendering {String(element.type)}</div>;
    }
  };

  console.log(`[PageRenderer] Page rendering started:`, {
    pageTitle: page.title,
    elementsCount: page.elements.length,
    elements: page.elements.map(el => ({ id: el.id, type: el.type, hasChildren: !!el.children }))
  });

  return (
    <>
      <style>{page.css}</style>
      <main className="pt-16" style={{ minHeight: '100vh', overflow: 'visible' }}>
        {page.elements.map(element => {
          console.log(`[PageRenderer] Processing element:`, element);
          return (
            <Fragment key={element.id}>
              {renderWidget(element)}
            </Fragment>
          );
        })}
      </main>
    </>
  );
}
