'use client';

import { useEffect } from 'react';
import { usePathname } from 'next/navigation';

// Extend window interface for gtag
declare global {
  interface Window {
    gtag?: (...args: any[]) => void;
  }
}

export function AnalyticsTracker() {
  const pathname = usePathname();

  useEffect(() => {
    // Simple Google Analytics-like tracking
    const trackPageView = () => {
      // Send page view to Google Analytics (if available)
      if (typeof window !== 'undefined' && window.gtag && process.env.NEXT_PUBLIC_GA4_MEASUREMENT_ID) {
        window.gtag('config', process.env.NEXT_PUBLIC_GA4_MEASUREMENT_ID, {
          page_path: pathname,
          page_title: document.title,
          page_location: window.location.href,
        });
      }

      // Track locally for our dashboard
      fetch('/api/analytics/track', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          page: pathname,
          timestamp: new Date().toISOString(),
          referrer: document.referrer,
        }),
      }).catch(err => console.log('Local analytics tracking failed:', err));
    };

    // Track on page load and path changes
    if (!pathname?.startsWith('/admin') && !pathname?.startsWith('/auth')) {
      trackPageView();
    }
  }, [pathname]);

  return null;
}