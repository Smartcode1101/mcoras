'use client';

import { useState, useEffect, useCallback } from 'react';
import type { AnalyticsData } from '@/lib/analytics';

export function useRealtimeAnalytics() {
  const [analyticsData, setAnalyticsData] = useState<AnalyticsData | null>(null);
  const [realtimeData, setRealtimeData] = useState<{ timestamp: string; views: number }[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Fetch main analytics data
  const fetchAnalytics = useCallback(async () => {
    try {
      const response = await fetch('/api/admin/analytics');
      if (response.ok) {
        const data = await response.json();
        setAnalyticsData(data);
        setError(null);
      } else {
        setError('Failed to fetch analytics data');
      }
    } catch (err) {
      setError('Network error while fetching analytics');
      console.error('Analytics fetch error:', err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Fetch realtime data (last 60 seconds)
  const fetchRealtimeData = useCallback(async () => {
    try {
      const response = await fetch('/api/admin/analytics?type=realtime');
      if (response.ok) {
        const data = await response.json();
        setRealtimeData(data.data || []);
      }
    } catch (err) {
      console.error('Realtime data fetch error:', err);
    }
  }, []);

  // Initial load
  useEffect(() => {
    fetchAnalytics();
    fetchRealtimeData();
  }, [fetchAnalytics, fetchRealtimeData]);

  // Set up periodic updates
  useEffect(() => {
    // Update main analytics every 30 seconds
    const analyticsInterval = setInterval(fetchAnalytics, 30000);

    // Update realtime data every 5 seconds
    const realtimeInterval = setInterval(fetchRealtimeData, 5000);

    return () => {
      clearInterval(analyticsInterval);
      clearInterval(realtimeInterval);
    };
  }, [fetchAnalytics, fetchRealtimeData]);

  // Manual refresh functions
  const refreshAnalytics = useCallback(() => {
    setIsLoading(true);
    fetchAnalytics();
  }, [fetchAnalytics]);

  const refreshRealtime = useCallback(() => {
    fetchRealtimeData();
  }, [fetchRealtimeData]);

  return {
    analyticsData,
    realtimeData,
    isLoading,
    error,
    refreshAnalytics,
    refreshRealtime,
  };
}

// Hook for tracking custom events
export function useAnalyticsEvent() {
  const trackEvent = useCallback(async (eventName: string, eventData?: any) => {
    try {
      await fetch('/api/analytics/track', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          event: eventName,
          data: eventData,
          timestamp: new Date().toISOString(),
        }),
      });
    } catch (error) {
      console.error('Failed to track event:', error);
    }
  }, []);

  return { trackEvent };
}

// Hook for page view tracking with custom data
export function usePageTracking(customData?: any) {
  const [isTracking, setIsTracking] = useState(false);

  const trackPageView = useCallback(async (pagePath?: string) => {
    if (isTracking) return;

    setIsTracking(true);
    try {
      const currentPath = pagePath || window.location.pathname;

      await fetch('/api/analytics/track', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          page: currentPath,
          referrer: document.referrer || undefined,
          customData,
          timestamp: new Date().toISOString(),
        }),
      });
    } catch (error) {
      console.error('Failed to track page view:', error);
    } finally {
      setIsTracking(false);
    }
  }, [customData, isTracking]);

  return { trackPageView, isTracking };
}