'use client';

import { useCallback } from 'react';
import { useGA4 } from '@/lib/google-analytics';
import { type GA4Event, type GA4PageView } from '@/lib/google-analytics';

/**
 * Hook personalizat pentru tracking-ul Google Analytics 4
 * Oferă funcții simple pentru urmărirea evenimentelor și interacțiunilor
 */
export function useGA4Tracking() {
  const {
    trackPageView,
    trackEvent,
    trackButtonClick,
    trackFileDownload,
    trackSearch,
    trackFormSubmission,
    trackScroll,
    isActive,
    measurementId,
  } = useGA4();

  // Urmărește page view cu date complete
  const trackPageViewWithData = useCallback((pageData: GA4PageView) => {
    if (isActive) {
      trackPageView(pageData);
    }
  }, [isActive, trackPageView]);

  // Urmărește eveniment custom
  const trackEventWithData = useCallback((event: GA4Event) => {
    if (isActive) {
      trackEvent(event);
    }
  }, [isActive, trackEvent]);

  // Urmărește click pe buton cu date automate
  const trackButtonClickWithData = useCallback((
    buttonName: string, 
    buttonLocation: string,
    additionalData?: Record<string, any>
  ) => {
    if (isActive) {
      trackButtonClick(buttonName, buttonLocation);
      
      // Dacă sunt date suplimentare, urmărește-le ca eveniment custom
      if (additionalData) {
        trackEvent({
          action: 'button_click_with_data',
          category: 'engagement',
          label: `${buttonName} - ${buttonLocation}`,
          custom_parameters: {
            button_name: buttonName,
            button_location: buttonLocation,
            ...additionalData,
            timestamp: new Date().toISOString(),
          },
        });
      }
    }
  }, [isActive, trackButtonClick, trackEvent]);

  // Urmărește scroll cu tracking progresiv
  const trackScrollProgress = useCallback((elementId: string, threshold: number = 25) => {
    if (!isActive) return;

    let trackedThresholds: number[] = [];

    const checkScroll = () => {
      const element = document.getElementById(elementId);
      if (!element) return;

      const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
      const scrollHeight = document.documentElement.scrollHeight - window.innerHeight;
      const scrollPercent = Math.round((scrollTop / scrollHeight) * 100);

      // Urmărește doar noile thresholds (25%, 50%, 75%, 100%)
      const newThresholds = [25, 50, 75, 100].filter(
        threshold => scrollPercent >= threshold && !trackedThresholds.includes(threshold)
      );

      newThresholds.forEach(threshold => {
        trackedThresholds.push(threshold);
        trackScroll(threshold);
        
        // Urmărește și un eveniment custom pentru detalii
        trackEvent({
          action: 'scroll_milestone',
          category: 'engagement',
          label: `${elementId} - ${threshold}%`,
          custom_parameters: {
            element_id: elementId,
            scroll_percentage: threshold,
            scroll_top: scrollTop,
            timestamp: new Date().toISOString(),
          },
        });
      });
    };

    const throttledCheckScroll = throttle(checkScroll, 1000);
    window.addEventListener('scroll', throttledCheckScroll);
    
    return () => {
      window.removeEventListener('scroll', throttledCheckScroll);
    };
  }, [isActive, trackScroll, trackEvent]);

  // Urmărește timpul petrecut pe pagină
  const trackTimeOnPage = useCallback(() => {
    if (!isActive) return;

    const startTime = Date.now();
    
    const trackTimeLeave = () => {
      const timeSpent = Math.round((Date.now() - startTime) / 1000); // în secunde
      if (timeSpent > 5) { // Doar dacă a petrecut mai mult de 5 secunde
        trackEvent({
          action: 'page_time',
          category: 'engagement',
          label: window.location.pathname,
          value: timeSpent,
          custom_parameters: {
            page_path: window.location.pathname,
            time_spent_seconds: timeSpent,
            timestamp: new Date().toISOString(),
          },
        });
      }
    };

    // Urmărește la părăsirea paginii
    window.addEventListener('beforeunload', trackTimeLeave);
    
    return () => {
      window.removeEventListener('beforeunload', trackTimeLeave);
    };
  }, [isActive, trackEvent]);

  // Urmărește erori JavaScript
  const trackJavaScriptError = useCallback((error: Error) => {
    if (isActive) {
      trackEvent({
        action: 'exception',
        category: 'error',
        label: error.message,
        custom_parameters: {
          error_message: error.message,
          error_stack: error.stack,
          error_url: window.location.href,
          timestamp: new Date().toISOString(),
        },
      });
    }
  }, [isActive, trackEvent]);

  // Urmărește căutări
  const trackSearchWithQuery = useCallback((searchTerm: string, resultsCount: number) => {
    if (isActive) {
      trackSearch(searchTerm, resultsCount);
    }
  }, [isActive, trackSearch]);

  // Urmărește trimiteri de formulare
  const trackFormSubmit = useCallback((formName: string, success: boolean, additionalData?: Record<string, any>) => {
    if (isActive) {
      trackFormSubmission(formName, success);
      
      if (additionalData) {
        trackEvent({
          action: success ? 'form_submit_with_data_success' : 'form_submit_with_data_error',
          category: 'lead_generation',
          label: formName,
          custom_parameters: {
            form_name: formName,
            success: success,
            ...additionalData,
            timestamp: new Date().toISOString(),
          },
        });
      }
    }
  }, [isActive, trackFormSubmission, trackEvent]);

  // Urmărește descărcări de fișiere
  const trackFileDownloadWithData = useCallback((fileName: string, fileType: string, additionalData?: Record<string, any>) => {
    if (isActive) {
      trackFileDownload(fileName, fileType);
      
      if (additionalData) {
        trackEvent({
          action: 'file_download_with_data',
          category: 'engagement',
          label: `${fileName}.${fileType}`,
          custom_parameters: {
            file_name: fileName,
            file_type: fileType,
            ...additionalData,
            timestamp: new Date().toISOString(),
          },
        });
      }
    }
  }, [isActive, trackFileDownload, trackEvent]);

  return {
    // Funcții de tracking de bază
    trackPageView: trackPageViewWithData,
    trackEvent: trackEventWithData,
    
    // Funcții de tracking specializate
    trackButtonClick: trackButtonClickWithData,
    trackScrollProgress,
    trackTimeOnPage,
    trackJavaScriptError,
    trackSearch: trackSearchWithQuery,
    trackFormSubmit,
    trackFileDownload: trackFileDownloadWithData,
    
    // Informații despre GA4
    isActive,
    measurementId,
  };
}

// Funcție utilitară pentru throttling
function throttle<T extends (...args: any[]) => void>(func: T, limit: number): T {
  let inThrottle: boolean;
  return ((...args: any[]) => {
    if (!inThrottle) {
      func(...args);
      inThrottle = true;
      setTimeout(() => inThrottle = false, limit);
    }
  }) as T;
}

export default useGA4Tracking;