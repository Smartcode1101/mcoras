'use client';

import { useEffect } from 'react';
import { usePathname } from 'next/navigation';

export function useAnalytics() {
  const pathname = usePathname();

  useEffect(() => {
    // Track page view when component mounts or pathname changes
    const trackPageView = async () => {
      try {
        await fetch('/api/analytics/track', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            page: pathname,
            referrer: document.referrer || undefined,
          }),
        });
      } catch (error) {
        console.error('Failed to track page view:', error);
      }
    };

    // Only track if we're on a frontend page (not admin)
    if (!pathname?.startsWith('/admin') && !pathname?.startsWith('/auth')) {
      trackPageView();
    }
  }, [pathname]);
}