'use client';

import { useState, useEffect } from 'react';
import NextImage from 'next/image';
import Link from 'next/link';
import type { PageData } from '@/lib/types';

type ArchivePostGridProps = {
  posts: PageData[];
};

interface PerformanceSettings {
  lazyLoadImages: boolean;
  reduceJsExecution: boolean;
}

export default function ArchivePostGrid({ posts: initialPosts }: ArchivePostGridProps) {
  const [posts, setPosts] = useState<PageData[]>(initialPosts);
  const [displayedPosts, setDisplayedPosts] = useState<PageData[]>([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [isMobile, setIsMobile] = useState(false);
  const [isTablet, setIsTablet] = useState(false);
  const [performanceSettings, setPerformanceSettings] = useState<PerformanceSettings>({
    lazyLoadImages: true,
    reduceJsExecution: true
  });
  const POSTS_PER_PAGE = 9;

  // Initialize displayed posts
  useEffect(() => {
    setDisplayedPosts(initialPosts.slice(0, POSTS_PER_PAGE));
    setCurrentPage(1);
  }, [initialPosts]);

  const loadMorePosts = () => {
    const nextPage = currentPage + 1;
    const startIndex = (nextPage - 1) * POSTS_PER_PAGE;
    const endIndex = nextPage * POSTS_PER_PAGE;
    setDisplayedPosts(initialPosts.slice(startIndex, endIndex));
    setCurrentPage(nextPage);
  };

  const goToPage = (page: number) => {
    if (page >= 1 && page <= totalPages) {
      const startIndex = (page - 1) * POSTS_PER_PAGE;
      const endIndex = page * POSTS_PER_PAGE;
      setDisplayedPosts(initialPosts.slice(startIndex, endIndex));
      setCurrentPage(page);
    }
  };

  const totalPages = Math.ceil(initialPosts.length / POSTS_PER_PAGE);
  const hasMore = currentPage < totalPages;

  useEffect(() => {
    // Fetch performance settings
    fetch('/api/admin/performance-settings')
      .then(res => res.json())
      .then(data => {
        setPerformanceSettings({
          lazyLoadImages: data.lazyLoadImages ?? true,
          reduceJsExecution: data.reduceJsExecution ?? true
        });
      })
      .catch(() => {});
  }, []);

  useEffect(() => {
    const checkResponsive = () => {
      setIsMobile(window.innerWidth < 768);
      setIsTablet(window.innerWidth >= 768 && window.innerWidth < 1024);
    };

    checkResponsive();
    window.addEventListener('resize', checkResponsive);
    return () => window.removeEventListener('resize', checkResponsive);
  }, []);

  // Determină numărul de coloane
  const columns = isMobile ? 1 : isTablet ? 2 : 3;

  // Stiluri pentru containerul grid
  const gridStyles: React.CSSProperties = {
    display: 'grid',
    gridTemplateColumns: `repeat(${columns}, 1fr)`,
    gap: '24px',
    padding: '20px 0',
  };

  // Stiluri pentru card
  const cardStyles: React.CSSProperties = {
    backgroundColor: '#ffffff',
    borderRadius: '12px',
    boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)',
    overflow: 'hidden',
    transition: 'all 0.3s ease',
    display: 'flex',
    flexDirection: 'column',
    height: '100%',
  };

  // Stiluri pentru imagine
  const imageContainerStyles: React.CSSProperties = {
    position: 'relative',
    width: '100%',
    height: isMobile ? '180px' : '200px',
    overflow: 'hidden',
  };

  // Stiluri pentru buton
  const buttonStyles: React.CSSProperties = {
    background: '#2563eb',
    color: '#ffffff',
    padding: '12px 20px',
    borderRadius: '8px',
    border: 'none',
    cursor: 'pointer',
    fontSize: '14px',
    fontWeight: '500',
    textDecoration: 'none',
    display: 'inline-block',
    textAlign: 'center',
    transition: 'background 0.2s ease',
    margin: '16px',
  };

  // Stiluri pentru titlu
  const titleStyles: React.CSSProperties = {
    fontSize: isMobile ? '16px' : '18px',
    fontWeight: '600',
    margin: '16px',
    marginBottom: '8px',
    color: '#1f2937',
    lineHeight: '1.4',
  };

  // Stiluri pentru descriere
  const excerptStyles: React.CSSProperties = {
    fontSize: '14px',
    color: '#6b7280',
    margin: '0 16px 16px 16px',
    lineHeight: '1.6',
    flexGrow: 1,
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('ro-RO', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const truncateText = (text: string, maxLength: number) => {
    if (text.length <= maxLength) return text;
    return text.slice(0, maxLength) + '...';
  };

  if (displayedPosts.length === 0) {
    return (
      <div className="text-center py-16">
        <div className="text-gray-400 text-6xl mb-4">📭</div>
        <h2 className="text-xl font-semibold text-gray-600 mb-2">
          Nu există postări cu acest tag
        </h2>
        <p className="text-gray-500">
          Verificați mai târziu pentru conținut nou.
        </p>
      </div>
    );
  }

  return (
    <>
      <div style={gridStyles}>
        {displayedPosts.map((post) => (
        <article key={post.id} style={cardStyles}>
          {/* Miniatura postării */}
          <div style={imageContainerStyles}>
            {post.thumbnail ? (
              <NextImage
                src={post.thumbnail}
                alt={post.title}
                fill
                loading={performanceSettings.lazyLoadImages ? 'lazy' : 'eager'}
                style={{ objectFit: 'cover' }}
                sizes={`(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw`}
              />
            ) : (
              <div style={{
                ...imageContainerStyles,
                backgroundColor: '#f3f4f6',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}>
                <span style={{ color: '#9ca3af', fontSize: '14px' }}>Fără imagine</span>
              </div>
            )}
          </div>

          {/* Conținutul cardului */}
          <div style={{ flexGrow: 1 }}>
            <h3 style={titleStyles}>{post.title}</h3>
            
            {post.seoDescription && (
              <p style={excerptStyles}>
                {truncateText(post.seoDescription, 120)}
              </p>
            )}
            
            <div style={{
              fontSize: '12px',
              color: '#9ca3af',
              margin: '0 16px 16px 16px'
            }}>
              {formatDate(post.updatedAt)}
            </div>
          </div>

          {/* Butonul către postare */}
          <div style={{ margin: '0 16px 16px 16px' }}>
            <Link 
              href={`/${post.slug}`}
              style={buttonStyles}
              onMouseEnter={(e) => {
                e.currentTarget.style.background = '#1d4ed8';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = '#2563eb';
              }}
            >
              Vezi postarea →
            </Link>
          </div>
        </article>
      ))}
      </div>

      {/* Paginare */}
      {totalPages > 1 && initialPosts.length > POSTS_PER_PAGE && (
        <div style={{ textAlign: 'center', marginTop: '32px' }}>
          {/* Buton Anterior */}
          <button
            onClick={() => goToPage(currentPage - 1)}
            disabled={currentPage === 1}
            style={{
              background: currentPage === 1 ? '#e5e7eb' : '#2563eb',
              color: currentPage === 1 ? '#9ca3af' : '#ffffff',
              padding: '10px 16px',
              borderRadius: '8px',
              border: 'none',
              cursor: currentPage === 1 ? 'not-allowed' : 'pointer',
              fontSize: '14px',
              fontWeight: '500',
              marginRight: '8px',
              transition: 'background 0.2s ease',
            }}
            onMouseEnter={(e) => {
              if (currentPage !== 1) {
                e.currentTarget.style.background = '#1d4ed8';
              }
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.background = currentPage === 1 ? '#e5e7eb' : '#2563eb';
            }}
          >
            ‹ Înapoi
          </button>

          {/* Numere de pagină */}
          {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
            <button
              key={page}
              onClick={() => goToPage(page)}
              style={{
                background: currentPage === page ? '#2563eb' : 'transparent',
                color: currentPage === page ? '#ffffff' : '#374151',
                padding: '10px 14px',
                borderRadius: '8px',
                border: currentPage === page ? 'none' : '1px solid #d1d5db',
                cursor: 'pointer',
                fontSize: '14px',
                fontWeight: '500',
                margin: '0 4px',
                transition: 'all 0.2s ease',
              }}
              onMouseEnter={(e) => {
                if (currentPage !== page) {
                  e.currentTarget.style.background = '#f3f4f6';
                }
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = currentPage === page ? '#2563eb' : 'transparent';
                e.currentTarget.style.color = currentPage === page ? '#ffffff' : '#374151';
              }}
            >
              {page}
            </button>
          ))}

          {/* Buton Următorul */}
          <button
            onClick={() => goToPage(currentPage + 1)}
            disabled={currentPage === totalPages}
            style={{
              background: currentPage === totalPages ? '#e5e7eb' : '#2563eb',
              color: currentPage === totalPages ? '#9ca3af' : '#ffffff',
              padding: '10px 16px',
              borderRadius: '8px',
              border: 'none',
              cursor: currentPage === totalPages ? 'not-allowed' : 'pointer',
              fontSize: '14px',
              fontWeight: '500',
              marginLeft: '8px',
              transition: 'background 0.2s ease',
            }}
            onMouseEnter={(e) => {
              if (currentPage !== totalPages) {
                e.currentTarget.style.background = '#1d4ed8';
              }
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.background = currentPage === totalPages ? '#e5e7eb' : '#2563eb';
            }}
          >
            Înainte ›
          </button>
        </div>
      )}
    </>
  );
}
