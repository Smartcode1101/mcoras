import { Metadata } from 'next';
import { notFound } from 'next/navigation';
import fs from 'fs';
import path from 'path';
import type { Tag, PageData } from '@/lib/types';
import ArchivePostGrid from '@/app/(frontend)/tag/[slug]/ArchivePostGrid';
import StructuredData, {
  generateCollectionPageSchema,
  generateBreadcrumbSchema
} from '@/components/StructuredData';
import { getSiteSettings } from '@/lib/settings-data';
import { headers } from 'next/headers';

const tagsPath = path.join(process.cwd(), 'db', 'tags.json');
const pagesPath = path.join(process.cwd(), 'db', 'pages.json');
const STRUCTURED_DATA_PATH = path.join(process.cwd(), 'db', 'structured-data.json');

// Funcție pentru a obține datele structurate personalizate pentru un tag
async function getTagStructuredData(tagId: string): Promise<{ customSchemas: Array<{ id: string; name: string; schema: Record<string, unknown> }> }> {
  try {
    const data = await fs.promises.readFile(STRUCTURED_DATA_PATH, 'utf-8');
    const structuredData = JSON.parse(data);
    const pageSchema = structuredData.pageSchemas?.[`tag-${tagId}`];
    return {
      customSchemas: pageSchema?.customSchemas || []
    };
  } catch {
    return { customSchemas: [] };
  }
}

async function getTagBySlug(slug: string): Promise<Tag | null> {
  try {
    const data = await fs.promises.readFile(tagsPath, 'utf-8');
    const tags: Tag[] = JSON.parse(data);
    return tags.find(tag => tag.slug === slug) || null;
  } catch {
    return null;
  }
}

async function getPostsByTag(tagId: string): Promise<PageData[]> {
  try {
    const data = await fs.promises.readFile(pagesPath, 'utf-8');
    const pages: PageData[] = JSON.parse(data);
    return pages
      .filter(page => 
        page.type === 'post' && 
        page.tags && 
        page.tags.includes(tagId)
      )
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  } catch {
    return [];
  }
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const tag = await getTagBySlug(slug);
  
  if (!tag) {
    return { title: 'Tag negăsit' };
  }

  return {
    title: tag.metaTitle || `${tag.name} | Arhivă`,
    description: tag.metaDescription || tag.description || `Postări cu tag-ul ${tag.name}`,
    keywords: tag.metaKeywords,
  };
}

export default async function TagArchivePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const tag = await getTagBySlug(slug);
  const siteSettings = await getSiteSettings();
  const headersList = await headers();
  const host = headersList.get('host') || 'localhost';
  const protocol = headersList.get('x-forwarded-proto') || (host.includes('localhost') ? 'http' : 'https');
  
  if (!tag) {
    notFound();
  }

  const posts = await getPostsByTag(tag.id);

  // Obține datele structurate personalizate pentru tag
  const tagStructuredData = await getTagStructuredData(tag.id);

  // Generează date structurate
  const siteUrl = siteSettings.siteUrl || `${protocol}://${host}`;
  const tagUrl = `${siteUrl}/tag/${slug}`;
  const schemas: Record<string, unknown>[] = [];
  
  // CollectionPage schema pentru tag
  schemas.push(generateCollectionPageSchema({
    title: tag.metaTitle || tag.name,
    description: tag.metaDescription || tag.description,
    url: tagUrl,
    siteUrl
  }));
  
  // Breadcrumb schema
  schemas.push(generateBreadcrumbSchema({
    items: [
      { name: 'Acasă', url: siteUrl },
      { name: tag.name, url: tagUrl }
    ]
  }));
  
  // Adaugă schemele personalizate create de utilizator
  if (tagStructuredData.customSchemas && tagStructuredData.customSchemas.length > 0) {
    tagStructuredData.customSchemas.forEach((customSchema) => {
      schemas.push(customSchema.schema);
    });
  }

  return (
    <>
      <StructuredData schemas={schemas} />
      <div className="min-h-screen pt-16">
        <div className="max-w-7xl mx-auto px-4 py-8">
          {/* Header secțiune */}
          <header className="mb-8 text-center">
            <div className="inline-block bg-blue-100 text-blue-800 px-4 py-1 rounded-full text-sm font-medium mb-4">
              Tag
            </div>
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              {tag.name}
            </h1>
            {tag.description && (
              <p className="text-black max-w-2xl mx-auto">
                {tag.description}
              </p>
            )}
          </header>

          {/* Grila de postări */}
          <ArchivePostGrid posts={posts} />
        </div>
      </div>
    </>
  );
}
