import { getPageBySlug, updatePageViews } from '@/lib/page-data';
import { notFound } from 'next/navigation';
import { PageRenderer } from '@/components/PageRenderer';
import { Metadata } from 'next';
import { getSiteSettings } from '@/lib/settings-data';
import { trackVisitedPage } from '@/lib/visited-pages';
import { headers } from 'next/headers';
import { getTags } from '@/lib/tags-data';
import StructuredData, { 
  generateNewsArticleSchema, 
  generateWebPageSchema, 
  generateBreadcrumbSchema 
} from '@/components/StructuredData';
import fs from 'fs';
import path from 'path';

const STRUCTURED_DATA_PATH = path.join(process.cwd(), 'db', 'structured-data.json');

// Funcție pentru a obține datele structurate personalizate ale unei pagini
async function getPageStructuredData(pageId: string): Promise<{ customSchemas: Array<{ id: string; name: string; schema: Record<string, unknown> }> }> {
  try {
    const data = await fs.promises.readFile(STRUCTURED_DATA_PATH, 'utf-8');
    const structuredData = JSON.parse(data);
    const pageSchema = structuredData.pageSchemas?.[pageId];
    return {
      customSchemas: pageSchema?.customSchemas || []
    };
  } catch {
    return { customSchemas: [] };
  }
}

type Props = {
  params: Promise<{ slug: string }>;
};

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const page = await getPageBySlug(slug);
  const siteSettings = await getSiteSettings();

  if (!page) {
    return {
      title: 'Page Not Found',
    };
  }

  const pageTitle = page?.title;
  const siteTitle = siteSettings.siteTitle;

  return {
    title: pageTitle || siteTitle,
    description: page?.seoDescription,
    keywords: page?.seoKeywords,
  };
}
 
export default async function Page({ params }: Props) {
  const { slug } = await params;
  const page = await getPageBySlug(slug);
  const siteSettings = await getSiteSettings();

  if (!page) {
    notFound();
  }

  // Track page view asynchronously (don't await to avoid blocking render)
  updatePageViews(slug).catch(console.error);

  // Track visited page for any slug/page regardless of existence
  const headersList = await headers();
  const userAgent = headersList.get('user-agent') || '';
  const forwarded = headersList.get('x-forwarded-for');
  const ip = forwarded ? forwarded.split(',')[0] : '127.0.0.1';
  const referrer = headersList.get('referer') || undefined;
  const host = headersList.get('host') || 'localhost';
  const protocol = headersList.get('x-forwarded-proto') || (host.includes('localhost') ? 'http' : 'https');
  const url = `${protocol}://${host}/${slug}`;

  // Track this visit in the unified system
  trackVisitedPage({
    slug,
    url,
    userAgent,
    ip,
    referrer,
  }).catch(console.error);

  // Obține toate tag-urile pentru widget-ul PostTags
  const allTags = await getTags();
  
  // Obține datele structurate personalizate ale paginii
  const pageStructuredData = await getPageStructuredData(page.id);

  // Generează date structurate
  const siteUrl = siteSettings.siteUrl || `${protocol}://${host}`;
  const pageUrl = slug === 'home' ? siteUrl : `${siteUrl}/${slug}`;
  const pageType = page.type || 'page';
  
  const schemas: Record<string, unknown>[] = [];
  
  // Generează schema principală bazată pe tip
  if (pageType === 'post') {
    schemas.push(generateNewsArticleSchema({
      title: page.title,
      description: page.seoDescription,
      image: page.thumbnail,
      datePublished: page.createdAt,
      dateModified: page.updatedAt,
      author: siteSettings.siteName,
      publisherName: siteSettings.siteName,
      publisherLogo: siteSettings.logo,
      url: pageUrl,
      siteUrl
    }));
  } else {
    schemas.push(generateWebPageSchema({
      title: page.title,
      description: page.seoDescription,
      url: pageUrl,
      datePublished: page.createdAt,
      dateModified: page.updatedAt,
      author: siteSettings.siteName,
      publisherName: siteSettings.siteName,
      siteUrl
    }));
  }
  
  // Adaugă breadcrumb
  schemas.push(generateBreadcrumbSchema({
    items: [
      { name: 'Acasă', url: siteUrl },
      ...(slug !== 'home' ? [{ name: page.title, url: pageUrl }] : [])
    ]
  }));
  
  // Adaugă schemele personalizate create de utilizator
  if (pageStructuredData.customSchemas && pageStructuredData.customSchemas.length > 0) {
    pageStructuredData.customSchemas.forEach((customSchema) => {
      schemas.push(customSchema.schema);
    });
  }

  return (
    <>
      <StructuredData schemas={schemas} />
      <PageRenderer page={page} allTags={allTags} />
    </>
  );
}
