import { Metadata } from 'next';
import { notFound } from 'next/navigation';
import fs from 'fs';
import path from 'path';
import type { Category, PageData } from '@/lib/types';
import ArchivePostGrid from '@/app/(frontend)/categorie/[slug]/ArchivePostGrid';
import StructuredData, {
  generateCollectionPageSchema,
  generateBreadcrumbSchema
} from '@/components/StructuredData';
import { getSiteSettings } from '@/lib/settings-data';
import { headers } from 'next/headers';

const categoriesPath = path.join(process.cwd(), 'db', 'categories.json');
const pagesPath = path.join(process.cwd(), 'db', 'pages.json');
const STRUCTURED_DATA_PATH = path.join(process.cwd(), 'db', 'structured-data.json');

// Funcție pentru a obține datele structurate personalizate pentru o categorie
async function getCategoryStructuredData(categoryId: string): Promise<{ customSchemas: Array<{ id: string; name: string; schema: Record<string, unknown> }> }> {
  try {
    const data = await fs.promises.readFile(STRUCTURED_DATA_PATH, 'utf-8');
    const structuredData = JSON.parse(data);
    const pageSchema = structuredData.pageSchemas?.[`category-${categoryId}`];
    return {
      customSchemas: pageSchema?.customSchemas || []
    };
  } catch {
    return { customSchemas: [] };
  }
}

async function getCategoryBySlug(slug: string): Promise<Category | null> {
  try {
    const data = await fs.promises.readFile(categoriesPath, 'utf-8');
    const categories: Category[] = JSON.parse(data);
    return categories.find(cat => cat.slug === slug) || null;
  } catch {
    return null;
  }
}

async function getPostsByCategory(categoryId: string): Promise<PageData[]> {
  try {
    const data = await fs.promises.readFile(pagesPath, 'utf-8');
    const pages: PageData[] = JSON.parse(data);
    return pages
      .filter(page => page.type === 'post' && page.categoryId === categoryId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  } catch {
    return [];
  }
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const category = await getCategoryBySlug(slug);
  
  if (!category) {
    return { title: 'Categorie negăsită' };
  }

  return {
    title: category.metaTitle || `${category.name} | Arhivă`,
    description: category.metaDescription || category.description || `Postări din categoria ${category.name}`,
    keywords: category.metaKeywords,
  };
}

export default async function CategoryArchivePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const category = await getCategoryBySlug(slug);
  const siteSettings = await getSiteSettings();
  const headersList = await headers();
  const host = headersList.get('host') || 'localhost';
  const protocol = headersList.get('x-forwarded-proto') || (host.includes('localhost') ? 'http' : 'https');
  
  if (!category) {
    notFound();
  }

  const posts = await getPostsByCategory(category.id);

  // Obține datele structurate personalizate pentru categorie
  const categoryStructuredData = await getCategoryStructuredData(category.id);

  // Generează date structurate
  const siteUrl = siteSettings.siteUrl || `${protocol}://${host}`;
  const categoryUrl = `${siteUrl}/categorie/${slug}`;
  const schemas: Record<string, unknown>[] = [];
  
  // CollectionPage schema pentru categorie
  schemas.push(generateCollectionPageSchema({
    title: category.metaTitle || category.name,
    description: category.metaDescription || category.description,
    url: categoryUrl,
    siteUrl
  }));
  
  // Breadcrumb schema
  schemas.push(generateBreadcrumbSchema({
    items: [
      { name: 'Acasă', url: siteUrl },
      { name: category.name, url: categoryUrl }
    ]
  }));
  
  // Adaugă schemele personalizate create de utilizator
  if (categoryStructuredData.customSchemas && categoryStructuredData.customSchemas.length > 0) {
    categoryStructuredData.customSchemas.forEach((customSchema) => {
      schemas.push(customSchema.schema);
    });
  }

  return (
    <>
      <StructuredData schemas={schemas} />
      <div className="min-h-screen pt-16">
        <div className="max-w-7xl mx-auto px-4 py-8">
          {/* Header secțiune */}
          <header className="mb-8 text-center">
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              {category.name}
            </h1>
            {category.description && (
              <p className="text-black max-w-2xl mx-auto">
                {category.description}
              </p>
            )}
          </header>

          {/* Grila de postări */}
          <ArchivePostGrid posts={posts} />
        </div>
      </div>
    </>
  );
}
