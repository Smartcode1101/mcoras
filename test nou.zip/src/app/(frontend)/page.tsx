import { getPageBySlug, updatePageViews } from '@/lib/page-data';
import { notFound } from 'next/navigation';
import { PageRenderer } from '@/components/PageRenderer';
import { Metadata } from 'next';
import { getSiteSettings } from '@/lib/settings-data';
import StructuredData, { 
  generateWebPageSchema, 
  generateBreadcrumbSchema,
  generateOrganizationSchema 
} from '@/components/StructuredData';
import { headers } from 'next/headers';
import fs from 'fs';
import path from 'path';

const STRUCTURED_DATA_PATH = path.join(process.cwd(), 'db', 'structured-data.json');

// Funcție pentru a obține datele structurate personalizate ale unei pagini
async function getPageStructuredData(pageId: string): Promise<{ customSchemas: Array<{ id: string; name: string; schema: Record<string, unknown> }> }> {
  try {
    const data = await fs.promises.readFile(STRUCTURED_DATA_PATH, 'utf-8');
    const structuredData = JSON.parse(data);
    const pageSchema = structuredData.pageSchemas?.[pageId];
    return {
      customSchemas: pageSchema?.customSchemas || []
    };
  } catch {
    return { customSchemas: [] };
  }
}

export async function generateMetadata(): Promise<Metadata> {
  const page = await getPageBySlug('home');
  const siteSettings = await getSiteSettings();

  if (!page) {
    return {
      title: siteSettings.siteTitle,
    };
  }

  const pageTitle = page?.title;
  const siteTitle = siteSettings.siteTitle;

  return {
    title: pageTitle || siteTitle,
    description: page?.seoDescription,
    keywords: page?.seoKeywords,
  };
}

export default async function Home() {
  const page = await getPageBySlug('home');
  const siteSettings = await getSiteSettings();
  const headersList = await headers();
  const host = headersList.get('host') || 'localhost';
  const protocol = headersList.get('x-forwarded-proto') || (host.includes('localhost') ? 'http' : 'https');

  if (!page) {
    return (
        <main className="flex flex-col items-center justify-center min-h-screen text-center p-4">
            <h1 className="text-4xl font-bold mb-4">Bun venit la One Smart</h1>
            <p className="text-xl text-muted-foreground">
                Se pare că nu ai setat încă o pagină principală.
            </p>
            <p className="mt-2 text-muted-foreground">
                Mergi la <a href="/admin" className="text-primary underline">panoul de administrare</a> pentru a crea o pagină cu slug-ul &quot;home&quot;.
            </p>
        </main>
    );
  }

  // Track page view asynchronously (don't await to avoid blocking render)
  updatePageViews('home').catch(console.error);

  // Obține datele structurate personalizate ale paginii
  const pageStructuredData = await getPageStructuredData(page.id);

  // Generează date structurate pentru pagina principală
  const siteUrl = siteSettings.siteUrl || `${protocol}://${host}`;
  const schemas: Record<string, unknown>[] = [];
  
  // WebPage schema
  schemas.push(generateWebPageSchema({
    title: page.title,
    description: page.seoDescription,
    url: siteUrl,
    datePublished: page.createdAt,
    dateModified: page.updatedAt,
    author: siteSettings.siteName,
    publisherName: siteSettings.siteName,
    siteUrl
  }));
  
  // Organization schema pentru homepage
  schemas.push(generateOrganizationSchema({
    name: siteSettings.siteName || siteSettings.siteTitle || 'Website',
    url: siteUrl,
    logo: siteSettings.logo || siteSettings.logoUrl
  }));
  
  // Breadcrumb
  schemas.push(generateBreadcrumbSchema({
    items: [{ name: 'Acasă', url: siteUrl }]
  }));
  
  // Adaugă schemele personalizate create de utilizator
  if (pageStructuredData.customSchemas && pageStructuredData.customSchemas.length > 0) {
    pageStructuredData.customSchemas.forEach((customSchema) => {
      schemas.push(customSchema.schema);
    });
  }

  return (
    <>
      <StructuredData schemas={schemas} />
      <PageRenderer page={page} />
    </>
  );
}
