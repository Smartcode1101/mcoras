
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import DelayedScripts from '@/components/DelayedScripts';
import { getSiteSettings } from '@/lib/settings-data';
import { getPages } from '@/lib/page-data';
import fs from 'fs';
import path from 'path';
import type { Category, MenuItem } from '@/lib/types';

// Define the shape of the menu items the Header component expects
type HeaderMenuItem = {
  title: string;
  slug: string;
  children?: HeaderMenuItem[];
  isSubmenu?: boolean;
};

async function getCategories(): Promise<Category[]> {
  try {
    const categoriesPath = path.join(process.cwd(), 'db', 'categories.json');
    const data = await fs.promises.readFile(categoriesPath, 'utf-8');
    return JSON.parse(data);
  } catch {
    return [];
  }
}

function convertToHeaderMenuItems(
  items: MenuItem[], 
  allPages: { id: string; title: string; slug: string }[],
  allCategories: { id: string; name: string; slug: string }[]
): HeaderMenuItem[] {
  const result: HeaderMenuItem[] = [];
  
  for (const item of items) {
      if (item.pageId) {
        const page = allPages.find(p => p.id === item.pageId);
        if (!page) continue;
        const title = (item.title && item.title.trim() !== '') ? item.title : page.title;
        result.push({ title, slug: page.slug });
        continue;
      }
      if (item.categoryId) {
        const category = allCategories.find(c => c.id === item.categoryId);
        if (!category) continue;
        const title = (item.title && item.title.trim() !== '') ? item.title : category.name;
        result.push({ title, slug: `categorie/${category.slug}` });
        continue;
      }
      // Submenu - check for isSubmenu flag or children
      if (item.isSubmenu || item.children) {
        const title = item.title || 'Submeniu';
        result.push({ 
          title, 
          slug: `submenu-${Date.now()}-${Math.random()}`,
          isSubmenu: true,
          children: item.children ? convertToHeaderMenuItems(item.children, allPages, allCategories) : []
        });
        continue;
      }
  }
  
  return result;
}

export default async function FrontendLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const settings = await getSiteSettings();
  const allPages = await getPages();
  const allCategories = await getCategories();
  
  const menuItems = convertToHeaderMenuItems(settings.menu.items, allPages, allCategories);

  return (
    <>
      <Header
          logoUrl={settings.logoUrl}
          siteTitle={settings.siteTitle}
          menuItems={menuItems}
          menuAlignment={settings.menu.alignment}
          styleSettings={settings.headerSettings}
      />
      {children}
      <Footer
          siteTitle={settings.siteTitle}
          styleSettings={settings.footerSettings}
      />
      <DelayedScripts />
    </>
  );
}
