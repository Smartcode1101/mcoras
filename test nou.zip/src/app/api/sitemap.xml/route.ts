import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';

export const dynamic = 'force-dynamic';

function getSiteUrl(request: NextRequest): string {
  // Try to get the host from the request headers for dynamic URL
  const host = request.headers.get('host');
  if (host) {
    const protocol = process.env.NODE_ENV === 'production' ? 'https' : 'http';
    return `${protocol}://${host}`;
  }
  // Fallback to site settings
  try {
    const siteSettingsPath = path.join(process.cwd(), 'db', 'site-settings.json');
    const data = JSON.parse(fs.readFileSync(siteSettingsPath, 'utf-8'));
    return data.siteUrl || 'https://smartit.ro';
  } catch {
    return 'https://smartit.ro';
  }
}

function getSitemapSettings(): any {
  try {
    const settingsPath = path.join(process.cwd(), 'db', 'sitemap-settings.json');
    return JSON.parse(fs.readFileSync(settingsPath, 'utf-8'));
  } catch {
    return {
      enabled: true,
      sitemaps: {
        posts: { enabled: true, filename: 'posts.xml' },
        pages: { enabled: true, filename: 'pages.xml' },
        categories: { enabled: true, filename: 'categories.xml' },
        tags: { enabled: true, filename: 'tags.xml' },
        news: { enabled: true, filename: 'news.xml' }
      }
    };
  }
}

export async function GET(request: NextRequest) {
  const siteUrl = getSiteUrl(request);
  const settings = getSitemapSettings();
  const now = new Date().toISOString();

  if (!settings.enabled) {
    return new NextResponse('Sitemaps are disabled', { status: 503 });
  }

  const sitemaps: string[] = [];

  if (settings.sitemaps.posts?.enabled) {
    sitemaps.push(`  <sitemap>
    <loc>${siteUrl}/sitemap-posts.xml</loc>
    <lastmod>${now}</lastmod>
  </sitemap>`);
  }

  if (settings.sitemaps.pages?.enabled) {
    sitemaps.push(`  <sitemap>
    <loc>${siteUrl}/sitemap-pages.xml</loc>
    <lastmod>${now}</lastmod>
  </sitemap>`);
  }

  if (settings.sitemaps.categories?.enabled) {
    sitemaps.push(`  <sitemap>
    <loc>${siteUrl}/sitemap-categories.xml</loc>
    <lastmod>${now}</lastmod>
  </sitemap>`);
  }

  if (settings.sitemaps.tags?.enabled) {
    sitemaps.push(`  <sitemap>
    <loc>${siteUrl}/sitemap-tags.xml</loc>
    <lastmod>${now}</lastmod>
  </sitemap>`);
  }

  if (settings.sitemaps.news?.enabled) {
    sitemaps.push(`  <sitemap>
    <loc>${siteUrl}/sitemap-news.xml</loc>
    <lastmod>${now}</lastmod>
  </sitemap>`);
  }

  const sitemapIndex = `<?xml version="1.0" encoding="UTF-8"?>
<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
  xmlns:news="http://www.google.com/schemas/sitemap-news/0.9"
  xmlns:xhtml="http://www.w3.org/1999/xhtml"
  xmlns:mobile="http://www.google.com/schemas/sitemap-mobile/1.0"
  xmlns:image="http://www.google.com/schemas/sitemap-image/1.1"
  xmlns:video="http://www.google.com/schemas/sitemap-video/1.1">
${sitemaps.join('\n')}
</sitemapindex>`;

  return new NextResponse(sitemapIndex, {
    headers: {
      'Content-Type': 'application/xml',
      'Cache-Control': 'public, max-age=3600, s-maxage=86400'
    }
  });
}
