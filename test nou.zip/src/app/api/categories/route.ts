import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';
import type { Category } from '@/lib/types';

const categoriesPath = path.join(process.cwd(), 'db', 'categories.json');

// Funcție pentru a citi categoriile
const getCategories = async (): Promise<Category[]> => {
  try {
    const data = await fs.promises.readFile(categoriesPath, 'utf-8');
    return JSON.parse(data);
  } catch {
    return [];
  }
};

// Funcție pentru a salva categoriile
const saveCategories = async (categories: Category[]): Promise<void> => {
  await fs.promises.writeFile(categoriesPath, JSON.stringify(categories, null, 2));
};

// GET - Obține toate categoriile
export async function GET() {
  try {
    const categories = await getCategories();
    return NextResponse.json(categories);
  } catch (error) {
    console.error('Eroare la încărcarea categoriilor:', error);
    return NextResponse.json(
      { error: 'Nu s-au putut încărca categoriile' },
      { status: 500 }
    );
  }
}

// POST - Creează o categorie nouă
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { name, slug, description, metaTitle, metaDescription, metaKeywords } = body;

    if (!name || !slug) {
      return NextResponse.json(
        { error: 'Numele și slug-ul sunt obligatorii' },
        { status: 400 }
      );
    }

    const categories = await getCategories();

    // Verificăm dacă slug-ul există deja
    if (categories.some(cat => cat.slug === slug)) {
      return NextResponse.json(
        { error: 'O categorie cu acest slug există deja' },
        { status: 400 }
      );
    }

    const newCategory: Category = {
      id: `cat-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      name,
      slug,
      description: description || '',
      metaTitle: metaTitle || '',
      metaDescription: metaDescription || '',
      metaKeywords: metaKeywords || '',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    categories.push(newCategory);
    await saveCategories(categories);

    return NextResponse.json(newCategory);
  } catch (error) {
    console.error('Eroare la crearea categoriei:', error);
    return NextResponse.json(
      { error: 'Nu s-a putut crea categoria' },
      { status: 500 }
    );
  }
}
