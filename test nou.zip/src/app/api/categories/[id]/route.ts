import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';
import type { Category } from '@/lib/types';

const categoriesPath = path.join(process.cwd(), 'db', 'categories.json');

const getCategories = async (): Promise<Category[]> => {
  try {
    const data = await fs.promises.readFile(categoriesPath, 'utf-8');
    return JSON.parse(data);
  } catch {
    return [];
  }
};

const saveCategories = async (categories: Category[]): Promise<void> => {
  await fs.promises.writeFile(categoriesPath, JSON.stringify(categories, null, 2));
};

// GET - Obține o categorie după ID
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const categories = await getCategories();
    const category = categories.find(cat => cat.id === id);
    
    if (!category) {
      return NextResponse.json(
        { error: 'Categoria nu a fost găsită' },
        { status: 404 }
      );
    }
    
    return NextResponse.json(category);
  } catch (error) {
    console.error('Eroare la încărcarea categoriei:', error);
    return NextResponse.json(
      { error: 'Nu s-a putut încărca categoria' },
      { status: 500 }
    );
  }
}

// PUT - Actualizează o categorie
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const { name, slug, description, metaTitle, metaDescription, metaKeywords } = body;

    const categories = await getCategories();
    const index = categories.findIndex(cat => cat.id === id);
    
    if (index === -1) {
      return NextResponse.json(
        { error: 'Categoria nu a fost găsită' },
        { status: 404 }
      );
    }

    // Verificăm dacă noul slug există deja la altă categorie
    if (slug && slug !== categories[index].slug) {
      if (categories.some(cat => cat.slug === slug)) {
        return NextResponse.json(
          { error: 'O categorie cu acest slug există deja' },
          { status: 400 }
        );
      }
    }

    categories[index] = {
      ...categories[index],
      name: name || categories[index].name,
      slug: slug || categories[index].slug,
      description: description !== undefined ? description : categories[index].description,
      metaTitle: metaTitle !== undefined ? metaTitle : categories[index].metaTitle,
      metaDescription: metaDescription !== undefined ? metaDescription : categories[index].metaDescription,
      metaKeywords: metaKeywords !== undefined ? metaKeywords : categories[index].metaKeywords,
      updatedAt: new Date().toISOString()
    };

    await saveCategories(categories);
    return NextResponse.json(categories[index]);
  } catch (error) {
    console.error('Eroare la actualizarea categoriei:', error);
    return NextResponse.json(
      { error: 'Nu s-a putut actualiza categoria' },
      { status: 500 }
    );
  }
}

// DELETE - Șterge o categorie
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const categories = await getCategories();
    const index = categories.findIndex(cat => cat.id === id);
    
    if (index === -1) {
      return NextResponse.json(
        { error: 'Categoria nu a fost găsită' },
        { status: 404 }
      );
    }

    categories.splice(index, 1);
    await saveCategories(categories);
    
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Eroare la ștergerea categoriei:', error);
    return NextResponse.json(
      { error: 'Nu s-a putut șterge categoria' },
      { status: 500 }
    );
  }
}
