import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';

export const dynamic = 'force-dynamic';

interface Category {
  id: string;
  slug: string;
  name: string;
  updatedAt: string;
  createdAt: string;
}

function getSiteUrl(request: NextRequest): string {
  const host = request.headers.get('host');
  if (host) {
    const protocol = process.env.NODE_ENV === 'production' ? 'https' : 'http';
    return `${protocol}://${host}`;
  }
  try {
    const siteSettingsPath = path.join(process.cwd(), 'db', 'site-settings.json');
    const data = JSON.parse(fs.readFileSync(siteSettingsPath, 'utf-8'));
    return data.siteUrl || 'https://smartit.ro';
  } catch {
    return 'https://smartit.ro';
  }
}

function getSitemapSettings(): any {
  try {
    const settingsPath = path.join(process.cwd(), 'db', 'sitemap-settings.json');
    return JSON.parse(fs.readFileSync(settingsPath, 'utf-8'));
  } catch {
    return {
      sitemaps: {
        categories: { enabled: true, changefreq: 'weekly', priority: 0.7 }
      }
    };
  }
}

function formatDate(dateString: string): string {
  const date = new Date(dateString);
  return date.toISOString().split('T')[0];
}

export async function GET(request: NextRequest) {
  const siteUrl = getSiteUrl(request);
  const settings = getSitemapSettings();
  const categoriesConfig = settings.sitemaps?.categories || { changefreq: 'weekly', priority: 0.7 };

  try {
    const categoriesPath = path.join(process.cwd(), 'db', 'categories.json');
    const categories: Category[] = JSON.parse(fs.readFileSync(categoriesPath, 'utf-8'));

    const urlEntries = categories.map(category => {
      const lastmod = formatDate(category.updatedAt || category.createdAt);
      const priority = categoriesConfig.priority || 0.7;
      
      return `  <url>
    <loc>${siteUrl}/categorie/${category.slug}</loc>
    <lastmod>${lastmod}</lastmod>
    <changefreq>${categoriesConfig.changefreq || 'weekly'}</changefreq>
    <priority>${priority}</priority>
  </url>`;
    });

    const sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
  xmlns:image="http://www.google.com/schemas/sitemap-image/1.1"
  xmlns:video="http://www.google.com/schemas/sitemap-video/1.1"
  xmlns:xhtml="http://www.w3.org/1999/xhtml">
${urlEntries.join('\n')}
</urlset>`;

    return new NextResponse(sitemap, {
      headers: {
        'Content-Type': 'application/xml',
        'Cache-Control': 'public, max-age=3600, s-maxage=86400'
      }
    });
  } catch (error) {
    console.error('Error generating categories sitemap:', error);
    return new NextResponse('Error generating sitemap', { status: 500 });
  }
}
