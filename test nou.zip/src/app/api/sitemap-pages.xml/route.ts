import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';

export const dynamic = 'force-dynamic';

interface PageData {
  id: string;
  slug: string;
  title: string;
  type: string;
  updatedAt: string;
  createdAt: string;
}

function getSiteUrl(request: NextRequest): string {
  const host = request.headers.get('host');
  if (host) {
    const protocol = process.env.NODE_ENV === 'production' ? 'https' : 'http';
    return `${protocol}://${host}`;
  }
  try {
    const siteSettingsPath = path.join(process.cwd(), 'db', 'site-settings.json');
    const data = JSON.parse(fs.readFileSync(siteSettingsPath, 'utf-8'));
    return data.siteUrl || 'https://smartit.ro';
  } catch {
    return 'https://smartit.ro';
  }
}

function getSitemapSettings(): any {
  try {
    const settingsPath = path.join(process.cwd(), 'db', 'sitemap-settings.json');
    return JSON.parse(fs.readFileSync(settingsPath, 'utf-8'));
  } catch {
    return {
      sitemaps: {
        pages: { enabled: true, changefreq: 'monthly', priority: 0.6 }
      }
    };
  }
}

function formatDate(dateString: string): string {
  const date = new Date(dateString);
  return date.toISOString().split('T')[0];
}

export async function GET(request: NextRequest) {
  const siteUrl = getSiteUrl(request);
  const settings = getSitemapSettings();
  const pagesConfig = settings.sitemaps?.pages || { changefreq: 'monthly', priority: 0.6 };

  try {
    const pagesPath = path.join(process.cwd(), 'db', 'pages.json');
    const pagesData: PageData[] = JSON.parse(fs.readFileSync(pagesPath, 'utf-8'));
    
    // Filter only static pages (type === 'page'), exclude homepage
    const pages = pagesData.filter(page => page.type === 'page' && page.slug !== 'home');

    const urlEntries = pages.map(page => {
      const lastmod = formatDate(page.updatedAt);
      const priority = pagesConfig.priority || 0.6;
      
      return `  <url>
    <loc>${siteUrl}/${page.slug}</loc>
    <lastmod>${lastmod}</lastmod>
    <changefreq>${pagesConfig.changefreq || 'monthly'}</changefreq>
    <priority>${priority}</priority>
  </url>`;
    });

    // Add homepage
    const now = new Date().toISOString().split('T')[0];
    urlEntries.unshift(`  <url>
    <loc>${siteUrl}</loc>
    <lastmod>${now}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>1.0</priority>
  </url>`);

    const sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
  xmlns:image="http://www.google.com/schemas/sitemap-image/1.1"
  xmlns:video="http://www.google.com/schemas/sitemap-video/1.1"
  xmlns:xhtml="http://www.w3.org/1999/xhtml">
${urlEntries.join('\n')}
</urlset>`;

    return new NextResponse(sitemap, {
      headers: {
        'Content-Type': 'application/xml',
        'Cache-Control': 'public, max-age=3600, s-maxage=86400'
      }
    });
  } catch (error) {
    console.error('Error generating pages sitemap:', error);
    return new NextResponse('Error generating sitemap', { status: 500 });
  }
}
