import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';

export const dynamic = 'force-dynamic';

// Unsafe/malicious bots to block (NOT including legitimate search engine bots)
const BLOCKED_BOTS = [
  // SEO Audit Tools
  'SemrushBot',
  'AhrefsBot',
  'MJ12bot',
  'Screaming Frog',
  
  // Search Engines (non-major)
  'Baiduspider', // Baidu
  'Exabot', // Exalead
  'DuckDuckBot', // Keep for privacy reasons - you can remove if desired
  
  // Scrapers & Downloaders
  'curl',
  'wget',
  'Python-urllib',
  'Apache-HttpClient',
  'Jakarta Commons',
  'Go-http-client',
  'PostmanRuntime',
  'Insomnia',
  'Anarchie',
  'ASPSeek',
  'CherryPicker',
  'ChinaClaw',
  'Custo',
  'DIIbot',
  'DISCo',
  'Download Demon',
  'eCatch',
  'EirGrabber',
  'EmailCollector',
  'EmailSiphon',
  'EmailWolf',
  'ExtractorPro',
  'EyeTribe',
  'FlashGet',
  'GetRight',
  'GetWeb!',
  'Go!Zilla',
  'GrabNet',
  'Grafula',
  'Harvest',
  'HTTrack',
  'Image Stripper',
  'Image Sucker',
  'Indy Library',
  'InterGET',
  'Internet Ninja',
  'JetCar',
  'JOC',
  'kmbot',
  'LeechFTP',
  'Mass Downloader',
  'MIDown',
  'Missaugust',
  'Missouri',
  'NearSite',
  'NetAnts',
  'NetSpider',
  'NetVampire',
  'Offline Explorer',
  'Offline Navigator',
  'PageGrabber',
  'Papa Photo',
  'pcBrowser',
  'ProPowerBot',
  'ProWebWalker',
  'PyCurl',
  'RealDownload',
  'ReGet',
  'SiteSnagger',
  'SmartDownload',
  'SuperBot',
  'SuperHTTP',
  'Surfbot',
  'tAkeOut',
  'Teleport Pro',
  'VoidEYE',
  'WebAuto',
  'WebBandit',
  'WebCopier',
  'WebDAV',
  'WebFetch',
  'WebGo IS',
  'WebLeacher',
  'WebMirror',
  'WebReaper',
  'WebSauger',
  'Website eXtractor',
  'Website Quester',
  'WebStripper',
  'WebWhacker',
  'WebZIP',
  'Wget',
  'Widow',
  'Xaldon',
  'Zeus',
  'Zmeu',
  
  // AI/LLM Bots (blocking these is optional - some sites allow them)
  'GPTBot',
  'claudebot',
  'Bytespider',
  'anthropic-ai',
  'claudia-web',
  'diffbot',
  
  // Social Media Bots (optional - usually allowed for sharing)
  'facebookexternalhit',
  'Twitterbot',
  'LinkedInBot',
  'Pinterestbot',
  'Slackbot',
  'TelegramBot',
  
  // Misc
  'Nutch',
  'Gigabot',
  'ia_archiver',
  'SpiderBot',
  'Applebot-Extended', // Apple's AI (optional)
  'OAI-SearchBot',
  'Amazonbot',
  'MetaExBot',
  'Yeti'
];

function getSiteUrl(request: NextRequest): string {
  const host = request.headers.get('host');
  if (host) {
    const protocol = process.env.NODE_ENV === 'production' ? 'https' : 'http';
    return `${protocol}://${host}`;
  }
  try {
    const siteSettingsPath = path.join(process.cwd(), 'db', 'site-settings.json');
    const data = JSON.parse(fs.readFileSync(siteSettingsPath, 'utf-8'));
    return data.siteUrl || 'https://smartit.ro';
  } catch {
    return 'https://smartit.ro';
  }
}

function getSitemapSettings(): any {
  try {
    const settingsPath = path.join(process.cwd(), 'db', 'sitemap-settings.json');
    return JSON.parse(fs.readFileSync(settingsPath, 'utf-8'));
  } catch {
    return {
      enabled: true,
      sitemaps: {
        posts: { enabled: true, filename: 'posts.xml' },
        pages: { enabled: true, filename: 'pages.xml' },
        categories: { enabled: true, filename: 'categories.xml' },
        tags: { enabled: true, filename: 'tags.xml' },
        news: { enabled: true, filename: 'news.xml' }
      }
    };
  }
}

function getRobotsSettings(): any {
  try {
    const settingsPath = path.join(process.cwd(), 'db', 'robots-settings.json');
    return JSON.parse(fs.readFileSync(settingsPath, 'utf-8'));
  } catch {
    return {
      enabled: true,
      blockUnsafeBots: true,
      excludeAdmin: true,
      excludePagination: true,
      excludeArchives: true,
      customRules: ''
    };
  }
}

function generateRobotsTxt(siteUrl: string, sitemapSettings: any, robotsSettings: any): string {
  const lines: string[] = [];

  // Start with header
  lines.push('# === MCORAS Robots.txt ===');
  lines.push('# Dynamic robots.txt with sitemap management');
  lines.push(`# Generated: ${new Date().toISOString()}`);
  lines.push('');

  // === ALLOW MAJOR SEARCH ENGINES FIRST ===
  lines.push('# --- Allow Major Search Engine Bots ---');
  
  // Google
  lines.push('User-agent: Googlebot');
  lines.push('Allow: /');
  lines.push('');
  
  // Google News
  lines.push('User-agent: Googlebot-News');
  lines.push('Allow: /');
  lines.push('');
  
  // Google Images
  lines.push('User-agent: Googlebot-Image');
  lines.push('Allow: /');
  lines.push('');
  
  // Google Video
  lines.push('User-agent: Googlebot-Video');
  lines.push('Allow: /');
  lines.push('');
  
  // Google Extended (AI)
  lines.push('User-agent: Google-Extended');
  lines.push('Allow: /');
  lines.push('');
  
  // Google Other
  lines.push('User-agent: GoogleOther');
  lines.push('Allow: /');
  lines.push('');
  
  // Google Web Light
  lines.push('User-agent: GoogleWebLightPreview');
  lines.push('Allow: /');
  lines.push('');
  
  // Bing
  lines.push('User-agent: bingbot');
  lines.push('Allow: /');
  lines.push('');
  
  lines.push('User-agent: msnbot');
  lines.push('Allow: /');
  lines.push('');
  
  // Bing News
  lines.push('User-agent: Bingbot-News');
  lines.push('Allow: /');
  lines.push('');
  
  // Yandex
  lines.push('User-agent: Yandex');
  lines.push('Allow: /');
  lines.push('');
  
  // Yandex Images
  lines.push('User-agent: YandexImages');
  lines.push('Allow: /');
  lines.push('');
  
  // Yahoo
  lines.push('User-agent: Slurp');
  lines.push('Allow: /');
  lines.push('');
  
  // DuckDuckGo
  lines.push('User-agent: DuckDuckBot');
  lines.push('Allow: /');
  lines.push('');
  
  // Baidu (allowed for Chinese search)
  lines.push('User-agent: Baiduspider');
  lines.push('Allow: /');
  lines.push('');
  
  // Apple
  lines.push('User-agent: Applebot');
  lines.push('Allow: /');
  lines.push('');

  // Block unsafe bots if enabled (after allowing search engines)
  if (robotsSettings.blockUnsafeBots) {
    lines.push('# --- Block Malicious/Unsafe Bots ---');
    for (const bot of BLOCKED_BOTS) {
      lines.push(`User-agent: ${bot}`);
      lines.push('Disallow: /');
      lines.push('');
    }
  }

  // General rules for all other bots
  lines.push('# --- General Rules (All Other Bots) ---');
  lines.push('User-agent: *');
  lines.push('Allow: /');
  lines.push('');

  // Disallow admin pages if enabled
  if (robotsSettings.excludeAdmin) {
    lines.push('# --- Admin Pages ---');
    lines.push('Disallow: /admin');
    lines.push('Disallow: /api/admin');
    lines.push('');
    
    lines.push('# --- Editor ---');
    lines.push('Disallow: /editor');
    lines.push('');
    
    lines.push('# --- Auth Routes ---');
    lines.push('Disallow: /api/auth');
    lines.push('');
  }

  // Disallow pagination for postgrid widget if enabled
  if (robotsSettings.excludePagination) {
    lines.push('# --- PostGrid Widget Pagination ---');
    lines.push('Disallow: /?page=');
    lines.push('Disallow: /&page=');
    lines.push('');
  }

  // Disallow category/tag archive pagination if enabled
  if (robotsSettings.excludeArchives) {
    lines.push('# --- Category Archive Pagination ---');
    lines.push('Disallow: /categorie/*/page/');
    lines.push('Disallow: /categorie/*?page=');
    lines.push('Disallow: /categorie/*&page=');
    lines.push('');
    
    lines.push('# --- Tag Archive Pagination ---');
    lines.push('Disallow: /tag/*/page/');
    lines.push('Disallow: /tag/*?page=');
    lines.push('Disallow: /tag/*&page=');
    lines.push('');
  }

  // Always include search disallow
  lines.push('# --- Search & Filter ---');
  lines.push('Disallow: /search');
  lines.push('Disallow: /?s=');
  lines.push('Disallow: /api/search');
  lines.push('');

  // Disallow media uploads directory (but allow search engine image bots)
  lines.push('# --- Media ---');
  lines.push('Disallow: /api/media/');
  lines.push('# Allow image search engines to access uploads');
  lines.push('User-agent: Googlebot-Image');
  lines.push('Allow: /imageuploads/');
  lines.push('User-agent: YandexImages');
  lines.push('Allow: /imageuploads/');
  lines.push('User-agent: *');
  lines.push('Disallow: /imageuploads/');
  lines.push('');

  // Disallow static files and config
  lines.push('# --- Config & Static Files ---');
  lines.push('Disallow: /*.json$');
  lines.push('Disallow: /*.xml$');
  lines.push('Disallow: /*.txt$');
  lines.push('Disallow: /*.map$');
  lines.push('Disallow: /_next/');
  lines.push('');

  // Custom rules from admin
  if (robotsSettings.customRules && robotsSettings.customRules.trim()) {
    lines.push('# --- Custom Rules ---');
    lines.push(robotsSettings.customRules);
    lines.push('');
  }

  // Sitemap URLs
  lines.push('# --- Sitemaps ---');
  
  // Add main sitemap index
  lines.push(`Sitemap: ${siteUrl}/api/sitemap.xml`);
  
  // Add individual sitemaps based on settings
  if (sitemapSettings.sitemaps?.posts?.enabled) {
    lines.push(`Sitemap: ${siteUrl}/sitemap-posts.xml`);
  }
  if (sitemapSettings.sitemaps?.pages?.enabled) {
    lines.push(`Sitemap: ${siteUrl}/sitemap-pages.xml`);
  }
  if (sitemapSettings.sitemaps?.categories?.enabled) {
    lines.push(`Sitemap: ${siteUrl}/sitemap-categories.xml`);
  }
  if (sitemapSettings.sitemaps?.tags?.enabled) {
    lines.push(`Sitemap: ${siteUrl}/sitemap-tags.xml`);
  }
  if (sitemapSettings.sitemaps?.news?.enabled) {
    lines.push(`Sitemap: ${siteUrl}/sitemap-news.xml`);
  }
  
  lines.push('');

  return lines.join('\n');
}

export async function GET(request: NextRequest) {
  const siteUrl = getSiteUrl(request);
  const sitemapSettings = getSitemapSettings();
  const robotsSettings = getRobotsSettings();

  // If robots.txt is disabled, return blocking robots.txt
  if (!robotsSettings.enabled) {
    const robotsTxt = [
      'User-agent: *',
      'Disallow: /',
      '',
      `# Robots.txt este dezactivat de administrator`
    ].join('\n');

    return new NextResponse(robotsTxt, {
      headers: {
        'Content-Type': 'text/plain',
        'Cache-Control': 'public, max-age=3600'
      }
    });
  }

  // If sitemaps are disabled, still show robots but without sitemaps
  if (!sitemapSettings.enabled) {
    const robotsTxt = [
      '# === MCORAS Robots.txt ===',
      '# Sitemaps dezactivate',
      '',
      'User-agent: *',
      'Disallow: /',
      '',
      `# Sitemaps sunt dezactivate de administrator`
    ].join('\n');

    return new NextResponse(robotsTxt, {
      headers: {
        'Content-Type': 'text/plain',
        'Cache-Control': 'public, max-age=3600'
      }
    });
  }

  const robotsTxt = generateRobotsTxt(siteUrl, sitemapSettings, robotsSettings);

  return new NextResponse(robotsTxt, {
    headers: {
      'Content-Type': 'text/plain',
      'Cache-Control': 'public, max-age=86400, s-maxage=86400'
    }
  });
}
