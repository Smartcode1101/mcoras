import { NextRequest, NextResponse } from 'next/server';
import { authenticateUser } from '@/lib/user-data';
import { generateToken } from '@/lib/jwt';

export async function POST(request: NextRequest) {
  try {
    const { usernameOrEmail, password } = await request.json();
    console.log('Login API: Attempting login for:', usernameOrEmail);

    if (!usernameOrEmail || !password) {
      console.log('Login API: Missing credentials');
      return NextResponse.json(
        { error: 'Username/email and password are required' },
        { status: 400 }
      );
    }

    const user = await authenticateUser(usernameOrEmail, password);
    console.log('Login API: Authentication result:', user ? { id: user.id, username: user.username, role: user.role } : null);

    if (!user) {
      console.log('Login API: Invalid credentials for:', usernameOrEmail);
      return NextResponse.json(
        { error: 'Invalid credentials' },
        { status: 401 }
      );
    }

    console.log('Login API: Login successful for user:', user.username, 'with role:', user.role);

    // Generate JWT token
    const token = generateToken({
      userId: user.id,
      email: user.email,
      username: user.username,
      role: user.role,
    });

    console.log('Login API: JWT token generated for user:', user.username);

    return NextResponse.json({
      message: 'Login successful',
      user: {
        id: user.id,
        email: user.email,
        username: user.username,
        role: user.role,
        createdAt: user.createdAt,
      },
      token,
    });
  } catch (error: any) {
    console.error('Login error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}