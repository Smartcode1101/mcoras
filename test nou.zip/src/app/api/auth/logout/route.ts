import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  try {
    // For JWT-based authentication, logout is primarily handled client-side
    // Server-side we could implement token blacklisting if needed
    // For now, we just return success and let client handle cleanup

    console.log('Logout API: User logged out successfully');

    return NextResponse.json({
      message: 'Logout successful',
    });
  } catch (error: any) {
    console.error('Logout error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}