import { NextResponse } from 'next/server';
import { getSiteSettings } from '@/lib/settings-data';

export async function GET() {
  try {
    const settings = await getSiteSettings();
    return NextResponse.json({
      logoUrl: settings.logoUrl,
      siteTitle: settings.siteTitle,
    });
  } catch (error) {
    console.error('Error fetching site settings:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
