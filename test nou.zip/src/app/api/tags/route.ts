import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';
import type { Tag } from '@/lib/types';

const tagsPath = path.join(process.cwd(), 'db', 'tags.json');

// Funcție pentru a citi tag-urile
const getTags = async (): Promise<Tag[]> => {
  try {
    const data = await fs.promises.readFile(tagsPath, 'utf-8');
    return JSON.parse(data);
  } catch {
    return [];
  }
};

// Funcție pentru a salva tag-urile
const saveTags = async (tags: Tag[]): Promise<void> => {
  await fs.promises.writeFile(tagsPath, JSON.stringify(tags, null, 2));
};

// GET - Obține toate tag-urile
export async function GET() {
  try {
    const tags = await getTags();
    return NextResponse.json(tags);
  } catch (error) {
    console.error('Eroare la încărcarea tag-urilor:', error);
    return NextResponse.json(
      { error: 'Nu s-au putut încărca tag-urile' },
      { status: 500 }
    );
  }
}

// POST - Creează un tag nou
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { name, slug, description, metaTitle, metaDescription, metaKeywords } = body;

    if (!name || !slug) {
      return NextResponse.json(
        { error: 'Numele și slug-ul sunt obligatorii' },
        { status: 400 }
      );
    }

    const tags = await getTags();

    // Verificăm dacă slug-ul există deja
    if (tags.some(tag => tag.slug === slug)) {
      return NextResponse.json(
        { error: 'Un tag cu acest slug există deja' },
        { status: 400 }
      );
    }

    const newTag: Tag = {
      id: `tag-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      name,
      slug,
      description: description || '',
      metaTitle: metaTitle || '',
      metaDescription: metaDescription || '',
      metaKeywords: metaKeywords || '',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    tags.push(newTag);
    await saveTags(tags);

    return NextResponse.json(newTag);
  } catch (error) {
    console.error('Eroare la crearea tag-ului:', error);
    return NextResponse.json(
      { error: 'Nu s-a putut crea tag-ul' },
      { status: 500 }
    );
  }
}
