import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';
import type { Tag } from '@/lib/types';

const tagsPath = path.join(process.cwd(), 'db', 'tags.json');

const getTags = async (): Promise<Tag[]> => {
  try {
    const data = await fs.promises.readFile(tagsPath, 'utf-8');
    return JSON.parse(data);
  } catch {
    return [];
  }
};

const saveTags = async (tags: Tag[]): Promise<void> => {
  await fs.promises.writeFile(tagsPath, JSON.stringify(tags, null, 2));
};

// GET - Obține un tag după ID
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const tags = await getTags();
    const tag = tags.find(t => t.id === id);
    
    if (!tag) {
      return NextResponse.json(
        { error: 'Tag-ul nu a fost găsit' },
        { status: 404 }
      );
    }
    
    return NextResponse.json(tag);
  } catch (error) {
    console.error('Eroare la încărcarea tag-ului:', error);
    return NextResponse.json(
      { error: 'Nu s-a putut încărca tag-ul' },
      { status: 500 }
    );
  }
}

// PUT - Actualizează un tag
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const { name, slug, description, metaTitle, metaDescription, metaKeywords } = body;

    const tags = await getTags();
    const index = tags.findIndex(t => t.id === id);
    
    if (index === -1) {
      return NextResponse.json(
        { error: 'Tag-ul nu a fost găsit' },
        { status: 404 }
      );
    }

    // Verificăm dacă noul slug există deja la alt tag
    if (slug && slug !== tags[index].slug) {
      if (tags.some(t => t.slug === slug)) {
        return NextResponse.json(
          { error: 'Un tag cu acest slug există deja' },
          { status: 400 }
        );
      }
    }

    tags[index] = {
      ...tags[index],
      name: name || tags[index].name,
      slug: slug || tags[index].slug,
      description: description !== undefined ? description : tags[index].description,
      metaTitle: metaTitle !== undefined ? metaTitle : tags[index].metaTitle,
      metaDescription: metaDescription !== undefined ? metaDescription : tags[index].metaDescription,
      metaKeywords: metaKeywords !== undefined ? metaKeywords : tags[index].metaKeywords,
      updatedAt: new Date().toISOString()
    };

    await saveTags(tags);
    return NextResponse.json(tags[index]);
  } catch (error) {
    console.error('Eroare la actualizarea tag-ului:', error);
    return NextResponse.json(
      { error: 'Nu s-a putut actualiza tag-ul' },
      { status: 500 }
    );
  }
}

// DELETE - Șterge un tag
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const tags = await getTags();
    const index = tags.findIndex(t => t.id === id);
    
    if (index === -1) {
      return NextResponse.json(
        { error: 'Tag-ul nu a fost găsit' },
        { status: 404 }
      );
    }

    tags.splice(index, 1);
    await saveTags(tags);
    
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Eroare la ștergerea tag-ului:', error);
    return NextResponse.json(
      { error: 'Nu s-a putut șterge tag-ul' },
      { status: 500 }
    );
  }
}
