import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';

export const dynamic = 'force-dynamic';

interface PageData {
  id: string;
  slug: string;
  title: string;
  type: string;
  updatedAt: string;
  createdAt: string;
  thumbnail?: string;
  categoryId?: string;
  tags?: string[];
}

function getSiteUrl(request: NextRequest): string {
  const host = request.headers.get('host');
  if (host) {
    const protocol = process.env.NODE_ENV === 'production' ? 'https' : 'http';
    return `${protocol}://${host}`;
  }
  try {
    const siteSettingsPath = path.join(process.cwd(), 'db', 'site-settings.json');
    const data = JSON.parse(fs.readFileSync(siteSettingsPath, 'utf-8'));
    return data.siteUrl || 'https://smartit.ro';
  } catch {
    return 'https://smartit.ro';
  }
}

function getSitemapSettings(): any {
  try {
    const settingsPath = path.join(process.cwd(), 'db', 'sitemap-settings.json');
    return JSON.parse(fs.readFileSync(settingsPath, 'utf-8'));
  } catch {
    return {
      sitemaps: {
        posts: { enabled: true, changefreq: 'weekly', priority: 0.8 }
      }
    };
  }
}

function formatDate(dateString: string): string {
  const date = new Date(dateString);
  return date.toISOString().split('T')[0];
}

function escapeXml(unsafe: string): string {
  return unsafe
    .split('&').join('&amp;')
    .split('<').join('&lt;')
    .split('>').join('&gt;')
    .split('"').join('&quot;');
}

export async function GET(request: NextRequest) {
  const siteUrl = getSiteUrl(request);
  const settings = getSitemapSettings();
  const postsConfig = settings.sitemaps?.posts || { changefreq: 'weekly', priority: 0.8 };

  try {
    const pagesPath = path.join(process.cwd(), 'db', 'pages.json');
    const pagesData: PageData[] = JSON.parse(fs.readFileSync(pagesPath, 'utf-8'));
    
    // Filter only posts (type === 'post')
    const posts = pagesData.filter(page => page.type === 'post');

    const urlEntries = posts.map(post => {
      const lastmod = formatDate(post.updatedAt);
      const priority = postsConfig.priority || 0.8;
      
      let url = `  <url>
    <loc>${siteUrl}/${post.slug}</loc>
    <lastmod>${lastmod}</lastmod>
    <changefreq>${postsConfig.changefreq || 'weekly'}</changefreq>
    <priority>${priority}</priority>`;

      // Add image if available
      if (post.thumbnail) {
        url += `
    <image:image>
      <image:loc>${siteUrl}${post.thumbnail}</image:loc>
      <image:title>${escapeXml(post.title)}</image:title>
    </image:image>`;
      }

      url += `
  </url>`;
      
      return url;
    });

    const sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
  xmlns:image="http://www.google.com/schemas/sitemap-image/1.1"
  xmlns:video="http://www.google.com/schemas/sitemap-video/1.1"
  xmlns:xhtml="http://www.w3.org/1999/xhtml">
${urlEntries.join('\n')}
</urlset>`;

    return new NextResponse(sitemap, {
      headers: {
        'Content-Type': 'application/xml',
        'Cache-Control': 'public, max-age=3600, s-maxage=86400'
      }
    });
  } catch (error) {
    console.error('Error generating posts sitemap:', error);
    return new NextResponse('Error generating sitemap', { status: 500 });
  }
}
