import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';

export const dynamic = 'force-dynamic';

interface PageData {
  id: string;
  slug: string;
  title: string;
  type: string;
  updatedAt: string;
  createdAt: string;
  seoDescription?: string;
  thumbnail?: string;
}

function getSiteUrl(request: NextRequest): string {
  const host = request.headers.get('host');
  if (host) {
    const protocol = process.env.NODE_ENV === 'production' ? 'https' : 'http';
    return `${protocol}://${host}`;
  }
  try {
    const siteSettingsPath = path.join(process.cwd(), 'db', 'site-settings.json');
    const data = JSON.parse(fs.readFileSync(siteSettingsPath, 'utf-8'));
    return data.siteUrl || 'https://smartit.ro';
  } catch {
    return 'https://smartit.ro';
  }
}

function getSitemapSettings(): any {
  try {
    const settingsPath = path.join(process.cwd(), 'db', 'sitemap-settings.json');
    return JSON.parse(fs.readFileSync(settingsPath, 'utf-8'));
  } catch {
    return {
      sitemaps: {
        news: { 
          enabled: true, 
          publicationName: 'Smartit Minecraft Server',
          publicationLanguage: 'ro',
          daysOld: 2 
        }
      }
    };
  }
}

function formatDate(dateString: string): string {
  const date = new Date(dateString);
  // Google News requires publication date in W3C format with hours, minutes, seconds
  return date.toISOString().replace(/\.\d{3}Z$/, 'Z');
}

function formatPublicationDate(dateString: string): string {
  const date = new Date(dateString);
  // Google News requires publication date in W3C format with timezone
  // Format: YYYY-MM-DDTHH:MM:SS+HH:MM
  const offset = date.getTimezoneOffset();
  const sign = offset > 0 ? '-' : '+';
  const hours = String(Math.floor(Math.abs(offset) / 60)).padStart(2, '0');
  const minutes = String(Math.abs(offset) % 60).padStart(2, '0');
  const tz = `${sign}${hours}:${minutes}`;
  return date.toISOString().replace(/\.\d{3}Z$/, tz);
}

function isRecent(dateString: string, daysOld: number): boolean {
  const date = new Date(dateString);
  const now = new Date();
  const diffTime = Math.abs(now.getTime() - date.getTime());
  const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
  return diffDays <= daysOld;
}

function escapeXml(unsafe: string): string {
  return unsafe
    .split('&').join('&')
    .split('<').join('<')
    .split('>').join('>')
    .split('"').join('"');
}

export async function GET(request: NextRequest) {
  const siteUrl = getSiteUrl(request);
  const settings = getSitemapSettings();
  const newsConfig = settings.sitemaps?.news || { 
    publicationName: 'Smartit Minecraft Server',
    publicationLanguage: 'ro',
    daysOld: 2
  };

  try {
    const pagesPath = path.join(process.cwd(), 'db', 'pages.json');
    const pagesData: PageData[] = JSON.parse(fs.readFileSync(pagesPath, 'utf-8'));
    
    // Filter only posts that are recent (within daysOld days)
    const recentPosts = pagesData.filter(page => 
      page.type === 'post' && isRecent(page.createdAt, newsConfig.daysOld || 2)
    );

    // Sort by creation date, newest first
    recentPosts.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    const urlEntries = recentPosts.map(post => {
      const publicationDate = formatPublicationDate(post.createdAt);
      
      return `  <url>
    <loc>${siteUrl}/${post.slug}</loc>
    <news:news>
      <news:publication>
        <news:name>${escapeXml(newsConfig.publicationName || 'Smartit Minecraft Server')}</news:name>
        <news:language>${newsConfig.publicationLanguage || 'ro'}</news:language>
      </news:publication>
      <news:publication_date>${publicationDate}</news:publication_date>
      <news:title>${escapeXml(post.title)}</news:title>
      <news:keywords>${escapeXml(post.seoDescription || '')}</news:keywords>
    </news:news>
  </url>`;
    });

    const sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
  xmlns:news="http://www.google.com/schemas/sitemap-news/0.9"
  xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">
${urlEntries.join('\n')}
</urlset>`;

    return new NextResponse(sitemap, {
      headers: {
        'Content-Type': 'application/xml',
        'Cache-Control': 'public, max-age=3600, s-maxage=86400'
      }
    });
  } catch (error) {
    console.error('Error generating news sitemap:', error);
    return new NextResponse('Error generating sitemap', { status: 500 });
  }
}
