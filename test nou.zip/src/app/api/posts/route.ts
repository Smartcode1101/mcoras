import { NextRequest, NextResponse } from 'next/server';
import { getPages } from '@/lib/page-data';
import type { PageData } from '@/lib/types';

export async function GET(request: NextRequest) {
  try {
    const pages: PageData[] = await getPages();
    
    // Filtrăm doar postările (type: 'post') și sortăm după cel mai nou
    const posts = pages
      .filter((page: PageData) => page.type === 'post')
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    
    return NextResponse.json(posts);
  } catch (error) {
    console.error('Eroare la încărcarea postărilor:', error);
    return NextResponse.json(
      { error: 'Nu s-au putut încărca postările' },
      { status: 500 }
    );
  }
}