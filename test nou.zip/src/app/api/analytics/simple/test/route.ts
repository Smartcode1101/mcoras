// API Route pentru testarea tracking-ului simplu Google Analytics
import { NextRequest, NextResponse } from 'next/server';
import { promises as fs } from 'fs';
import path from 'path';

export async function POST(request: NextRequest) {
  try {
    // Încarcă configurația simplă
    const configPath = path.join(process.cwd(), 'db', 'analytics-simple.json');
    
    let config = {
      measurementId: '',
      enabled: false
    };

    try {
      const data = await fs.readFile(configPath, 'utf8');
      const existingConfig = JSON.parse(data);
      config = { ...config, ...existingConfig };
    } catch (error) {
      return NextResponse.json(
        { 
          success: false,
          error: 'Google Analytics is not configured. Please set up your Measurement ID first.' 
        },
        { status: 400 }
      );
    }

    if (!config.enabled || !config.measurementId) {
      return NextResponse.json(
        { 
          success: false,
          error: 'Google Analytics is not enabled or Measurement ID is missing' 
        },
        { status: 400 }
      );
    }

    // Simulează trimiterea unui eveniment de test
    // În implementarea reală, aici ai trimite către Google Analytics
    console.log(`Test Analytics Event for ${config.measurementId}:`, {
      eventName: 'test_event',
      timestamp: new Date().toISOString(),
      page: '/admin/analytics',
      userAgent: request.headers.get('user-agent')
    });

    // Salvează log-ul testului
    const testLogPath = path.join(process.cwd(), 'db', 'analytics-test-log.json');
    const testLog = {
      lastTest: new Date().toISOString(),
      measurementId: config.measurementId,
      success: true,
      testData: {
        eventName: 'test_event',
        page: '/admin/analytics',
        timestamp: new Date().toISOString()
      }
    };

    try {
      await fs.writeFile(testLogPath, JSON.stringify(testLog, null, 2));
    } catch (error) {
      console.warn('Failed to save test log:', error);
    }

    return NextResponse.json({
      success: true,
      message: `Test event sent successfully for ${config.measurementId}! Check Google Analytics Real-time to see the result.`,
      testData: {
        measurementId: config.measurementId,
        timestamp: testLog.testData.timestamp
      }
    });
  } catch (error) {
    console.error('Error testing analytics:', error);
    return NextResponse.json(
      { 
        success: false,
        error: 'Failed to test analytics tracking' 
      },
      { status: 500 }
    );
  }
}