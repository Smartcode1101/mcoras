// API Route pentru configurarea simplă Google Analytics (fără OAuth)
import { NextRequest, NextResponse } from 'next/server';
import { promises as fs } from 'fs';
import path from 'path';

export async function GET() {
  try {
    const configPath = path.join(process.cwd(), 'db', 'analytics-simple.json');
    
    let config = {
      measurementId: '',
      enabled: false,
      updatedAt: null
    };

    try {
      const data = await fs.readFile(configPath, 'utf8');
      const existingConfig = JSON.parse(data);
      config = { ...config, ...existingConfig };
    } catch (error) {
      // Fișierul nu există încă, folosim configurația default
    }

    return NextResponse.json({
      success: true,
      config
    });
  } catch (error) {
    console.error('Error loading simple analytics config:', error);
    return NextResponse.json(
      { 
        success: false,
        error: 'Failed to load configuration' 
      },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const { measurementId, enabled } = await request.json();

    // Validare Measurement ID
    if (enabled && !measurementId) {
      return NextResponse.json(
        { 
          success: false,
          error: 'Measurement ID is required when enabling analytics' 
        },
        { status: 400 }
      );
    }

    if (measurementId && !/^G-[A-Z0-9]+$/.test(measurementId)) {
      return NextResponse.json(
        { 
          success: false,
          error: 'Invalid Measurement ID format. Must be like G-XXXXXXXXXX' 
        },
        { status: 400 }
      );
    }

    const configPath = path.join(process.cwd(), 'db', 'analytics-simple.json');
    
    const config = {
      measurementId: measurementId || '',
      enabled: Boolean(enabled),
      updatedAt: new Date().toISOString()
    };

    await fs.writeFile(configPath, JSON.stringify(config, null, 2));

    console.log('Simple Analytics config saved:', config);

    return NextResponse.json({
      success: true,
      message: enabled ? 'Google Analytics activated successfully!' : 'Google Analytics disabled',
      config
    });
  } catch (error) {
    console.error('Error saving simple analytics config:', error);
    return NextResponse.json(
      { 
        success: false,
        error: 'Failed to save configuration' 
      },
      { status: 500 }
    );
  }
}