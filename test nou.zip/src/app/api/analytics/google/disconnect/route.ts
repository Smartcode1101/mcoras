// API Route pentru deconectarea Google Analytics
import { NextRequest, NextResponse } from 'next/server';
import { googleAnalyticsOAuth } from '@/lib/google-analytics-oauth';

export async function POST(request: NextRequest) {
  try {
    const result = await googleAnalyticsOAuth.disconnectAnalytics();

    if (result.success) {
      // Resetează variabilele de mediu
      if (process.env.NEXT_PUBLIC_GA4_MEASUREMENT_ID) {
        delete process.env.NEXT_PUBLIC_GA4_MEASUREMENT_ID;
      }

      return NextResponse.json({
        success: true,
        message: result.message,
      });
    } else {
      return NextResponse.json({
        success: false,
        error: result.message,
      }, { status: 400 });
    }
  } catch (error) {
    console.error('Error disconnecting analytics:', error);
    return NextResponse.json(
      { error: 'Failed to disconnect Google Analytics' },
      { status: 500 }
    );
  }
}