// API Route pentru inițierea fluxului Google OAuth
import { NextRequest, NextResponse } from 'next/server';
import { googleAnalyticsOAuth } from '@/lib/google-analytics-oauth';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const state = searchParams.get('state') || 'analytics_setup';

    // Verifică dacă credentialele Google OAuth sunt configurate
    if (!process.env.GOOGLE_CLIENT_ID || !process.env.GOOGLE_CLIENT_SECRET) {
      console.error('Google OAuth credentials missing:', {
        hasClientId: !!process.env.GOOGLE_CLIENT_ID,
        hasClientSecret: !!process.env.GOOGLE_CLIENT_SECRET,
      });
      
      return NextResponse.json(
        { 
          error: 'Google OAuth credentials not configured',
          message: 'Please configure GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET in .env.local',
          instructions: 'See OAUTH-SETUP-GUIDE.md for detailed setup instructions'
        },
        { status: 400 }
      );
    }

    // Generează URL-ul pentru autentificarea Google
    const authUrl = googleAnalyticsOAuth.getAuthUrl(state);
    
    // Redirect către Google pentru autentificare
    return NextResponse.redirect(authUrl);
  } catch (error) {
    console.error('Error initiating Google OAuth:', error);
    return NextResponse.json(
      { 
        error: 'Failed to initiate Google OAuth flow',
        message: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    );
  }
}