// API Route pentru callback-ul Google OAuth
import { NextRequest, NextResponse } from 'next/server';
import { googleAnalyticsOAuth } from '@/lib/google-analytics-oauth';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const code = searchParams.get('code');
    const state = searchParams.get('state');
    const error = searchParams.get('error');

    // Gestionează erorile de la Google
    if (error) {
      console.error('Google OAuth error:', error);
      const errorUrl = new URL('/admin/analytics?error=oauth_failed', request.url);
      return NextResponse.redirect(errorUrl);
    }

    if (!code) {
      console.error('No authorization code received');
      const errorUrl = new URL('/admin/analytics?error=no_code', request.url);
      return NextResponse.redirect(errorUrl);
    }

    // Schimbă codul cu token-uri
    const tokens = await googleAnalyticsOAuth.getTokens(code);

    // Obține proprietățile Google Analytics
    const properties = await googleAnalyticsOAuth.getAnalyticsProperties(tokens);

    // Salvează proprietățile în configurație
    const config = await googleAnalyticsOAuth.loadAnalyticsConfig();
    const updatedConfig = {
      ...config,
      google: {
        ...config.google,
        connected: true,
        properties: properties,
        tokens: tokens, // Salvează token-urile (doar pentru sesiunea curentă)
        updatedAt: new Date().toISOString(),
      }
    };

    // Salvează configurația actualizată
    const fs = require('fs').promises;
    const path = require('path');
    const configPath = path.join(process.cwd(), 'db', 'analytics-config.json');
    await fs.writeFile(configPath, JSON.stringify(updatedConfig, null, 2));

    // Redirect către pagina de selectare a proprietății
    const successUrl = new URL('/admin/analytics?success=connected', request.url);
    return NextResponse.redirect(successUrl);
  } catch (error) {
    console.error('Error handling Google OAuth callback:', error);
    const errorUrl = new URL('/admin/analytics?error=callback_failed', request.url);
    return NextResponse.redirect(errorUrl);
  }
}