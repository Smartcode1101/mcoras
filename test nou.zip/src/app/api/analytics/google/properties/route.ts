// API Route pentru obținerea proprietăților Google Analytics
import { NextRequest, NextResponse } from 'next/server';
import { googleAnalyticsOAuth } from '@/lib/google-analytics-oauth';

export async function GET(request: NextRequest) {
  try {
    // Încarcă configurația pentru a obține proprietățile salvate
    const config = await googleAnalyticsOAuth.loadAnalyticsConfig();
    
    if (!config.google?.connected || !config.google?.properties) {
      return NextResponse.json({
        success: false,
        message: 'Nu este conectat niciun cont Google Analytics',
        properties: []
      });
    }

    return NextResponse.json({
      success: true,
      properties: config.google.properties,
      selected: config.google.selected,
      connected: config.google.connected,
      connectedAt: config.google.updatedAt
    });
  } catch (error) {
    console.error('Error fetching properties:', error);
    return NextResponse.json(
      { error: 'Failed to fetch Google Analytics properties' },
      { status: 500 }
    );
  }
}