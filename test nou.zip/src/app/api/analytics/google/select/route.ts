// API Route pentru selectarea unei proprietăți Google Analytics
import { NextRequest, NextResponse } from 'next/server';
import { googleAnalyticsOAuth } from '@/lib/google-analytics-oauth';

export async function POST(request: NextRequest) {
  try {
    const { propertyId } = await request.json();

    if (!propertyId) {
      return NextResponse.json(
        { error: 'Property ID is required' },
        { status: 400 }
      );
    }

    // Încarcă configurația pentru a obține token-urile
    const config = await googleAnalyticsOAuth.loadAnalyticsConfig();
    
    if (!config.google?.tokens) {
      return NextResponse.json(
        { error: 'No valid tokens found. Please reconnect your Google account.' },
        { status: 401 }
      );
    }

    // Selectează proprietatea
    const result = await googleAnalyticsOAuth.selectProperty(
      config.google.tokens,
      propertyId
    );

    if (result.success) {
      // Actualizează și environment variables
      await updateEnvironmentVariables(result.measurementId!);

      return NextResponse.json({
        success: true,
        message: result.message,
        measurementId: result.measurementId,
      });
    } else {
      return NextResponse.json({
        success: false,
        error: result.message,
      }, { status: 400 });
    }
  } catch (error) {
    console.error('Error selecting property:', error);
    return NextResponse.json(
      { error: 'Failed to select Google Analytics property' },
      { status: 500 }
    );
  }
}

/**
 * Actualizează variabilele de mediu pentru GA4
 */
async function updateEnvironmentVariables(measurementId: string): Promise<void> {
  try {
    // Într-un mediu real, acest lucru ar fi gestionat printr-un sistem de configurare
    // Pentru dezvoltare, poți actualiza manual fișierul .env.local
    
    console.log(`📊 Google Analytics 4 Activat cu Measurement ID: ${measurementId}`);
    console.log('✅ Tracking-ul va începe automat pentru toate paginile');
    
    // Actualizare în memoria aplicației pentru sesiunea curentă
    // process.env.NEXT_PUBLIC_GA4_MEASUREMENT_ID = measurementId;
    // Note: Environment variables cannot be set dynamically in serverless environments
    console.log('Environment variable would be set to:', measurementId);
  } catch (error) {
    console.error('Error updating environment variables:', error);
    throw error;
  }
}