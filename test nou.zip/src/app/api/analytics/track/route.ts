import { NextRequest, NextResponse } from 'next/server';
import { trackPageView } from '@/lib/analytics';

export async function POST(request: NextRequest) {
  try {
    const { page, referrer, timestamp } = await request.json();

    // Get client information
    const userAgent = request.headers.get('user-agent') || '';
    const forwarded = request.headers.get('x-forwarded-for');
    const ip = forwarded ? forwarded.split(',')[0] : '127.0.0.1';

    // Track the page view
    trackPageView({
      page,
      userAgent,
      ip,
      referrer,
    });

    return NextResponse.json({
      success: true,
      tracked: page,
      timestamp: new Date().toISOString()
    });
  } catch (error: any) {
    console.error('Analytics tracking error:', error);
    return NextResponse.json(
      { error: 'Failed to track page view', details: error.message },
      { status: 500 }
    );
  }
}