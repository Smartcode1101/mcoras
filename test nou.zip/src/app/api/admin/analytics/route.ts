import { NextRequest, NextResponse } from 'next/server';
import { 
  getAnalyticsData, 
  getLast24HoursViews, 
  getRealtimeViews, 
  resetAnalyticsData,
  getLiveTrafficData,
  getTrafficTypeStats,
  getCountryStats
} from '@/lib/analytics';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const type = searchParams.get('type');

    switch (type) {
      case 'realtime':
        const realtimeData = getRealtimeViews();
        return NextResponse.json({
          success: true,
          data: realtimeData,
          timestamp: new Date().toISOString()
        });

      case '24hours':
        const last24HoursData = getLast24HoursViews();
        return NextResponse.json({
          success: true,
          data: last24HoursData,
          timestamp: new Date().toISOString()
        });

      case 'live':
        // Return current live stats
        const liveData = getAnalyticsData();
        return NextResponse.json({
          success: true,
          data: {
            totalViews: liveData.totalViews,
            uniqueVisitors: liveData.uniqueVisitors,
            topPages: liveData.topPages.slice(0, 5)
          },
          timestamp: new Date().toISOString()
        });

      case 'traffic':
        // Return traffic type stats (direct, organic, referral, crawlers)
        const trafficStats = getTrafficTypeStats();
        return NextResponse.json({
          success: true,
          data: trafficStats,
          timestamp: new Date().toISOString()
        });

      case 'countries':
        // Return country statistics
        const countryStats = getCountryStats();
        return NextResponse.json({
          success: true,
          data: countryStats,
          timestamp: new Date().toISOString()
        });

      case 'livetraffic':
        // Return live traffic entries (last 100)
        const liveTraffic = getLiveTrafficData();
        return NextResponse.json({
          success: true,
          data: liveTraffic,
          timestamp: new Date().toISOString()
        });

      default:
        const analyticsData = getAnalyticsData();
        return NextResponse.json({
          success: true,
          data: analyticsData,
          timestamp: new Date().toISOString()
        });
    }
  } catch (error: any) {
    console.error('Analytics API error:', error);
    return NextResponse.json(
      {
        success: false,
        error: 'Internal server error',
        timestamp: new Date().toISOString()
      },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const { action } = await request.json();

    if (action === 'reset') {
      resetAnalyticsData();
      return NextResponse.json({
        success: true,
        message: 'Analytics data reset successfully',
        timestamp: new Date().toISOString()
      });
    }

    return NextResponse.json(
      {
        success: false,
        error: 'Invalid action',
        timestamp: new Date().toISOString()
      },
      { status: 400 }
    );
  } catch (error: any) {
    console.error('Analytics reset API error:', error);
    return NextResponse.json(
      {
        success: false,
        error: 'Internal server error',
        timestamp: new Date().toISOString()
      },
      { status: 500 }
    );
  }
}