import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';

export const dynamic = 'force-dynamic';

function getRobotsSettingsPath(): string {
  return path.join(process.cwd(), 'db', 'robots-settings.json');
}

function getDefaultRobotsSettings() {
  return {
    enabled: true,
    blockUnsafeBots: true,
    excludeAdmin: true,
    excludePagination: true,
    excludeArchives: true,
    customRules: '',
    lastmod: new Date().toISOString()
  };
}

function getRobotsSettings(): any {
  try {
    const settingsPath = getRobotsSettingsPath();
    return JSON.parse(fs.readFileSync(settingsPath, 'utf-8'));
  } catch {
    return getDefaultRobotsSettings();
  }
}

function saveRobotsSettings(settings: any): boolean {
  try {
    const settingsPath = getRobotsSettingsPath();
    fs.writeFileSync(settingsPath, JSON.stringify(settings, null, 2), 'utf-8');
    return true;
  } catch (error) {
    console.error('Error saving robots settings:', error);
    return false;
  }
}

export async function GET() {
  try {
    const settings = getRobotsSettings();
    return NextResponse.json(settings);
  } catch (error) {
    console.error('Error getting robots settings:', error);
    return NextResponse.json({ error: 'Failed to get robots settings' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const currentSettings = getRobotsSettings();
    
    // Merge current settings with new ones
    const updatedSettings = {
      ...currentSettings,
      ...body,
      lastmod: new Date().toISOString()
    };

    const success = saveRobotsSettings(updatedSettings);
    
    if (success) {
      return NextResponse.json({ success: true, settings: updatedSettings });
    } else {
      return NextResponse.json({ error: 'Failed to save settings' }, { status: 500 });
    }
  } catch (error) {
    console.error('Error saving robots settings:', error);
    return NextResponse.json({ error: 'Failed to save robots settings' }, { status: 500 });
  }
}
