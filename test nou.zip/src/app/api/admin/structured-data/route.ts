import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';

const STRUCTURED_DATA_PATH = path.join(process.cwd(), 'db', 'structured-data.json');
const PAGES_PATH = path.join(process.cwd(), 'db', 'pages.json');
const SITE_SETTINGS_PATH = path.join(process.cwd(), 'db', 'site-settings.json');

interface StructuredDataConfig {
  schemas: Record<string, SchemaDefinition>;
  pageSchemas: Record<string, PageStructuredData>;
}

interface SchemaDefinition {
  type: string;
  name: string;
  description: string;
  fields: string[];
  required: string[];
}

interface PageStructuredData {
  pageId: string;
  schemas: SchemaConfig[];
  customSchemas: CustomSchema[];
}

interface SchemaConfig {
  type: string;
  enabled: boolean;
  customFields?: Record<string, unknown>;
}

interface CustomSchema {
  id: string;
  name: string;
  schema: Record<string, unknown>;
}

function readStructuredData(): StructuredDataConfig {
  try {
    const data = fs.readFileSync(STRUCTURED_DATA_PATH, 'utf-8');
    return JSON.parse(data);
  } catch {
    return { schemas: {}, pageSchemas: {} };
  }
}

function writeStructuredData(data: StructuredDataConfig): void {
  fs.writeFileSync(STRUCTURED_DATA_PATH, JSON.stringify(data, null, 2));
}

function readPages() {
  try {
    const data = fs.readFileSync(PAGES_PATH, 'utf-8');
    return JSON.parse(data);
  } catch {
    return [];
  }
}

function readSiteSettings() {
  try {
    const data = fs.readFileSync(SITE_SETTINGS_PATH, 'utf-8');
    return JSON.parse(data);
  } catch {
    return { siteName: 'Website', siteUrl: '' };
  }
}

// Generează automat schema NewsArticle pentru postări
function generateNewsArticleSchema(page: Record<string, unknown>, siteSettings: Record<string, unknown>): Record<string, unknown> {
  const siteUrl = (siteSettings.siteUrl as string) || '';
  const pageSlug = page.slug as string;
  const pageUrl = `${siteUrl}/${pageSlug}`;
  const thumbnail = page.thumbnail as string | undefined;
  const createdAt = page.createdAt as string;
  const updatedAt = page.updatedAt as string;
  const title = page.title as string;
  const seoDescription = page.seoDescription as string | undefined;
  const siteName = (siteSettings.siteName as string) || "Admin";
  const logo = siteSettings.logo as string | undefined;
  
  return {
    "@context": "https://schema.org",
    "@type": "NewsArticle",
    "headline": title,
    "image": thumbnail ? [`${siteUrl}${thumbnail}`] : [],
    "datePublished": createdAt,
    "dateModified": updatedAt,
    "author": {
      "@type": "Person",
      "name": siteName
    },
    "publisher": {
      "@type": "Organization",
      "name": siteName,
      "url": siteUrl,
      "logo": {
        "@type": "ImageObject",
        "url": logo ? `${siteUrl}${logo}` : ''
      }
    },
    "description": seoDescription || '',
    "mainEntityOfPage": {
      "@type": "WebPage",
      "@id": pageUrl
    }
  };
}

// Generează automat schema WebPage pentru pagini
function generateWebPageSchema(page: Record<string, unknown>, siteSettings: Record<string, unknown>): Record<string, unknown> {
  const siteUrl = (siteSettings.siteUrl as string) || '';
  const pageSlug = page.slug as string;
  const pageUrl = pageSlug === 'home' ? siteUrl : `${siteUrl}/${pageSlug}`;
  const title = page.title as string;
  const seoDescription = page.seoDescription as string | undefined;
  const createdAt = page.createdAt as string;
  const updatedAt = page.updatedAt as string;
  const siteName = (siteSettings.siteName as string) || "Admin";
  
  return {
    "@context": "https://schema.org",
    "@type": "WebPage",
    "name": title,
    "description": seoDescription || '',
    "url": pageUrl,
    "datePublished": createdAt,
    "dateModified": updatedAt,
    "author": {
      "@type": "Person",
      "name": siteName
    },
    "publisher": {
      "@type": "Organization",
      "name": siteName,
      "url": siteUrl
    }
  };
}

// Generează schema BreadcrumbList
function generateBreadcrumbSchema(page: Record<string, unknown>, siteSettings: Record<string, unknown>): Record<string, unknown> {
  const siteUrl = (siteSettings.siteUrl as string) || '';
  const pageSlug = page.slug as string;
  const pageUrl = pageSlug === 'home' ? siteUrl : `${siteUrl}/${pageSlug}`;
  const title = page.title as string;
  
  const items = [
    {
      "@type": "ListItem",
      "position": 1,
      "name": "Acasă",
      "item": siteUrl
    }
  ];
  
  if (pageSlug !== 'home') {
    items.push({
      "@type": "ListItem",
      "position": 2,
      "name": title,
      "item": pageUrl
    });
  }
  
  return {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    "itemListElement": items
  };
}

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const pageId = searchParams.get('pageId');
  const generate = searchParams.get('generate');
  
  const structuredData = readStructuredData();
  const pages = readPages();
  const siteSettings = readSiteSettings();
  
  // Dacă se cere generarea automată pentru o pagină
  if (pageId && generate === 'auto') {
    const page = pages.find((p: Record<string, unknown>) => p.id === pageId);
    if (!page) {
      return NextResponse.json({ error: 'Pagina nu a fost găsită' }, { status: 404 });
    }
    
    const schemas: Record<string, unknown>[] = [];
    const pageType = page.type || 'page';
    
    // Generează schema potrivită în funcție de tip
    if (pageType === 'post') {
      schemas.push(generateNewsArticleSchema(page, siteSettings));
    } else {
      schemas.push(generateWebPageSchema(page, siteSettings));
    }
    
    // Adaugă întotdeauna breadcrumb
    schemas.push(generateBreadcrumbSchema(page, siteSettings));
    
    return NextResponse.json({ schemas, pageType });
  }
  
  // Returnează datele structurate pentru o pagină specifică
  if (pageId) {
    const pageSchema = structuredData.pageSchemas[pageId] || null;
    const page = pages.find((p: Record<string, unknown>) => p.id === pageId);
    
    return NextResponse.json({
      pageSchema,
      page,
      availableSchemas: structuredData.schemas,
      siteSettings
    });
  }
  
  // Returnează toate schemele disponibile
  return NextResponse.json({
    schemas: structuredData.schemas,
    pageSchemas: structuredData.pageSchemas
  });
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { pageId, schemas, customSchemas } = body;
    
    if (!pageId) {
      return NextResponse.json({ error: 'ID pagină necesar' }, { status: 400 });
    }
    
    const structuredData = readStructuredData();
    
    structuredData.pageSchemas[pageId] = {
      pageId,
      schemas: schemas || [],
      customSchemas: customSchemas || []
    };
    
    writeStructuredData(structuredData);
    
    return NextResponse.json({ success: true, message: 'Date structurate salvate' });
  } catch (error) {
    console.error('Eroare la salvare:', error);
    return NextResponse.json({ error: 'Eroare la salvare' }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { pageId, schemaId, enabled, customFields } = body;
    
    if (!pageId || !schemaId) {
      return NextResponse.json({ error: 'Parametri lipsă' }, { status: 400 });
    }
    
    const structuredData = readStructuredData();
    
    if (!structuredData.pageSchemas[pageId]) {
      structuredData.pageSchemas[pageId] = {
        pageId,
        schemas: [],
        customSchemas: []
      };
    }
    
    const existingSchema = structuredData.pageSchemas[pageId].schemas.find(
      (s: SchemaConfig) => s.type === schemaId
    );
    
    if (existingSchema) {
      existingSchema.enabled = enabled;
      if (customFields) {
        existingSchema.customFields = customFields;
      }
    } else {
      structuredData.pageSchemas[pageId].schemas.push({
        type: schemaId,
        enabled,
        customFields: customFields || {}
      });
    }
    
    writeStructuredData(structuredData);
    
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Eroare la actualizare:', error);
    return NextResponse.json({ error: 'Eroare la actualizare' }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const pageId = searchParams.get('pageId');
  const schemaId = searchParams.get('schemaId');
  const customSchemaId = searchParams.get('customSchemaId');
  
  if (!pageId) {
    return NextResponse.json({ error: 'ID pagină necesar' }, { status: 400 });
  }
  
  const structuredData = readStructuredData();
  
  if (!structuredData.pageSchemas[pageId]) {
    return NextResponse.json({ error: 'Nu există date pentru această pagină' }, { status: 404 });
  }
  
  if (schemaId) {
    structuredData.pageSchemas[pageId].schemas = structuredData.pageSchemas[pageId].schemas.filter(
      (s: SchemaConfig) => s.type !== schemaId
    );
  }
  
  if (customSchemaId) {
    structuredData.pageSchemas[pageId].customSchemas = structuredData.pageSchemas[pageId].customSchemas.filter(
      (s: CustomSchema) => s.id !== customSchemaId
    );
  }
  
  writeStructuredData(structuredData);
  
  return NextResponse.json({ success: true });
}