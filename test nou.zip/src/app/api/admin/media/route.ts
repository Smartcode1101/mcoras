import { NextRequest, NextResponse } from 'next/server';
import { getMediaItems } from '@/lib/media-data';

export async function GET(request: NextRequest) {
  try {
    const mediaItems = await getMediaItems();
    
    return NextResponse.json({ 
      success: true, 
      data: mediaItems 
    });
  } catch (error) {
    console.error('Error fetching media:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to fetch media' },
      { status: 500 }
    );
  }
}