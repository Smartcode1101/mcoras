import { NextRequest, NextResponse } from 'next/server';
import { deleteMediaItem } from '@/lib/media-data';

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    
    console.log('Delete request received for media ID:', id);
    
    if (!id) {
      console.error('No ID provided in params:', params);
      return NextResponse.json(
        { success: false, error: 'Media ID is required' },
        { status: 400 }
      );
    }

    const deleted = await deleteMediaItem(id);
    
    if (deleted) {
      return NextResponse.json({ 
        success: true, 
        message: 'Media item deleted successfully' 
      });
    } else {
      return NextResponse.json(
        { success: false, error: 'Media item not found' },
        { status: 404 }
      );
    }
  } catch (error) {
    console.error('Error deleting media:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to delete media item' },
      { status: 500 }
    );
  }
}