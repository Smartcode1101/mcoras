import { NextRequest, NextResponse } from 'next/server';
import { getMediaItems, saveMediaItem } from '@/lib/media-data';
import { generateId } from '@/lib/utils';
import fs from 'fs/promises';
import path from 'path';

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData();
    const file = formData.get('file') as File;
    const alt = formData.get('alt') as string;
    const filename = formData.get('filename') as string;

    if (!file) {
      return NextResponse.json(
        { success: false, error: 'Niciun fișier furnizat' },
        { status: 400 }
      );
    }

    // Validate file type
    if (!file.type.startsWith('image/')) {
      return NextResponse.json(
        { success: false, error: 'Doar fișierele de tip imagine sunt acceptate' },
        { status: 400 }
      );
    }

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      return NextResponse.json(
        { success: false, error: 'Fișierul este prea mare. Mărimea maximă este 5MB.' },
        { status: 400 }
      );
    }

    // Generate SEO-friendly filename (without timestamp prefix)
    const fileExtension = path.extname(filename) || '.jpg';
    const baseName = path.basename(filename, fileExtension);
    // Convert to SEO-friendly format: lowercase, replace spaces and special chars with hyphens
    const seoName = baseName
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-|-$/g, '');
    let seoFilename = `${seoName}${fileExtension}`;
    
    // Create upload directory if it doesn't exist
    const uploadDir = path.join(process.cwd(), 'public', 'imageuploads');
    await fs.mkdir(uploadDir, { recursive: true });
    
    // Check if file exists and add suffix if needed
    let filePath = path.join(uploadDir, seoFilename);
    let counter = 1;
    while (true) {
      try {
        await fs.access(filePath);
        // File exists, try with suffix
        seoFilename = `${seoName}-${counter}${fileExtension}`;
        filePath = path.join(uploadDir, seoFilename);
        counter++;
      } catch {
        // File doesn't exist, we can use this name
        break;
      }
    }

    // Save file
    const fileBuffer = Buffer.from(await file.arrayBuffer());
    await fs.writeFile(filePath, fileBuffer);

    // Create media item
    const mediaItem = {
      id: generateId(),
      src: `/imageuploads/${seoFilename}`,
      alt: alt || filename.split('.')[0],
      filename: seoFilename,
      createdAt: new Date().toISOString(),
    };

    // Save to database
    await saveMediaItem(mediaItem);

    return NextResponse.json({ 
      success: true, 
      data: mediaItem,
      message: 'Fișierul a fost încărcat cu succes' 
    });

  } catch (error) {
    console.error('Error uploading file:', error);
    return NextResponse.json(
      { success: false, error: 'Eroare la încărcarea fișierului' },
      { status: 500 }
    );
  }
}