import { NextRequest, NextResponse } from 'next/server';
import { getUsers, deleteUser, getUserById } from '@/lib/user-data';
import { verifyToken } from '@/lib/jwt';

export async function GET(request: NextRequest) {
  try {
    console.log('🔐 Verificare autentificare pentru API utilizatori...');
    
    // Check Authorization header for JWT token
    const authHeader = request.headers.get('authorization');
    const token = authHeader?.replace('Bearer ', '');
    
    if (!token) {
      console.log('❌ Token JWT lipsă');
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const decoded = verifyToken(token);
    if (!decoded) {
      console.log('❌ Token JWT invalid sau expirat');
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const currentUser = getUserById(decoded.userId);

    if (!currentUser) {
      console.log('❌ Utilizator inexistent în baza de date');
      return NextResponse.json(
        { error: 'Forbidden' },
        { status: 403 }
      );
    }

    if (currentUser.role !== 'admin') {
      console.log(`❌ Utilizator ${currentUser.username} nu are rol de admin`);
      return NextResponse.json(
        { error: 'Forbidden' },
        { status: 403 }
      );
    }

    console.log(`✅ Admin ${currentUser.username} accesează lista utilizatori`);
    const users = getUsers();
    console.log(`📊 Returnare ${users.length} utilizatori`);
    return NextResponse.json({ users });
  } catch (error) {
    console.error('❌ Eroare internă server la obținerea utilizatorilor:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function DELETE(request: NextRequest) {
  try {
    console.log('🔐 Verificare autentificare pentru ștergere utilizator...');
    
    // Check Authorization header for JWT token
    const authHeader = request.headers.get('authorization');
    const token = authHeader?.replace('Bearer ', '');
    
    if (!token) {
      console.log('❌ Token JWT lipsă');
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const decoded = verifyToken(token);
    if (!decoded) {
      console.log('❌ Token JWT invalid sau expirat');
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const currentUser = getUserById(decoded.userId);

    if (!currentUser) {
      console.log('❌ Utilizator inexistent în baza de date');
      return NextResponse.json(
        { error: 'Forbidden' },
        { status: 403 }
      );
    }

    if (currentUser.role !== 'admin') {
      console.log(`❌ Utilizator ${currentUser.username} nu are rol de admin`);
      return NextResponse.json(
        { error: 'Forbidden' },
        { status: 403 }
      );
    }

    const { userId } = await request.json();
    console.log(`🗑️ Admin ${currentUser.username} șterge utilizatorul ${userId}`);

    if (!userId) {
      console.log('❌ ID utilizator lipsă');
      return NextResponse.json(
        { error: 'User ID is required' },
        { status: 400 }
      );
    }

    const success = deleteUser(userId);

    if (!success) {
      console.log(`❌ Utilizator ${userId} negăsit`);
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }

    console.log(`✅ Utilizator ${userId} șters cu succes`);
    return NextResponse.json({ message: 'User deleted successfully' });
  } catch (error) {
    console.error('❌ Eroare internă server la ștergerea utilizatorului:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}