import { NextRequest, NextResponse } from 'next/server';
import { updateUserRole, getUserById } from '@/lib/user-data';
import { verifyToken } from '@/lib/jwt';

export async function PATCH(request: NextRequest) {
  try {
    console.log('🔐 Verificare autentificare pentru schimbare rol...');
    
    // Check Authorization header for JWT token
    const authHeader = request.headers.get('authorization');
    const token = authHeader?.replace('Bearer ', '');
    
    if (!token) {
      console.log('❌ Token JWT lipsă');
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const decoded = verifyToken(token);
    if (!decoded) {
      console.log('❌ Token JWT invalid sau expirat');
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const currentUser = getUserById(decoded.userId);

    if (!currentUser) {
      console.log('❌ Utilizator inexistent în baza de date');
      return NextResponse.json(
        { error: 'Forbidden' },
        { status: 403 }
      );
    }

    if (currentUser.role !== 'admin') {
      console.log(`❌ Utilizator ${currentUser.username} nu are rol de admin`);
      return NextResponse.json(
        { error: 'Forbidden' },
        { status: 403 }
      );
    }

    const { userId, role } = await request.json();
    console.log(`🔄 Admin ${currentUser.username} schimbă rolul utilizatorului ${userId} în ${role}`);

    if (!userId || !role) {
      console.log('❌ Date lipsă: userId sau role');
      return NextResponse.json(
        { error: 'User ID and role are required' },
        { status: 400 }
      );
    }

    if (!['admin', 'subscriber'].includes(role)) {
      console.log(`❌ Rol invalid: ${role}`);
      return NextResponse.json(
        { error: 'Invalid role. Must be admin or subscriber' },
        { status: 400 }
      );
    }

    const success = updateUserRole(userId, role);

    if (!success) {
      console.log(`❌ Utilizator ${userId} negăsit`);
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }

    console.log(`✅ Rol schimbat cu succes pentru utilizatorul ${userId}`);
    return NextResponse.json({ message: 'User role updated successfully' });
  } catch (error) {
    console.error('❌ Eroare internă server la schimbarea rolului:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}