import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';

export const dynamic = 'force-dynamic';

function getSitemapSettingsPath(): string {
  return path.join(process.cwd(), 'db', 'sitemap-settings.json');
}

function getSitemapSettings(): any {
  try {
    const settingsPath = getSitemapSettingsPath();
    return JSON.parse(fs.readFileSync(settingsPath, 'utf-8'));
  } catch {
    return {
      enabled: true,
      autoGenerate: true,
      includeNews: true,
      lastmod: new Date().toISOString(),
      sitemaps: {
        posts: { enabled: true, filename: 'posts.xml', changefreq: 'weekly', priority: 0.8 },
        pages: { enabled: true, filename: 'pages.xml', changefreq: 'monthly', priority: 0.6 },
        categories: { enabled: true, filename: 'categories.xml', changefreq: 'weekly', priority: 0.7 },
        tags: { enabled: true, filename: 'tags.xml', changefreq: 'weekly', priority: 0.6 },
        news: { 
          enabled: true, 
          filename: 'news.xml', 
          publicationName: 'Smartit Minecraft Server',
          publicationLanguage: 'ro',
          daysOld: 2 
        }
      }
    };
  }
}

function saveSitemapSettings(settings: any): boolean {
  try {
    const settingsPath = getSitemapSettingsPath();
    fs.writeFileSync(settingsPath, JSON.stringify(settings, null, 2), 'utf-8');
    return true;
  } catch (error) {
    console.error('Error saving sitemap settings:', error);
    return false;
  }
}

export async function GET() {
  try {
    const settings = getSitemapSettings();
    return NextResponse.json(settings);
  } catch (error) {
    console.error('Error getting sitemap settings:', error);
    return NextResponse.json({ error: 'Failed to get sitemap settings' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const currentSettings = getSitemapSettings();
    
    // Merge current settings with new ones
    const updatedSettings = {
      ...currentSettings,
      ...body,
      sitemaps: {
        ...currentSettings.sitemaps,
        ...(body.sitemaps || {})
      }
    };

    // Update individual sitemap settings
    if (body.sitemaps?.posts) {
      updatedSettings.sitemaps.posts = { ...currentSettings.sitemaps.posts, ...body.sitemaps.posts };
    }
    if (body.sitemaps?.pages) {
      updatedSettings.sitemaps.pages = { ...currentSettings.sitemaps.pages, ...body.sitemaps.pages };
    }
    if (body.sitemaps?.categories) {
      updatedSettings.sitemaps.categories = { ...currentSettings.sitemaps.categories, ...body.sitemaps.categories };
    }
    if (body.sitemaps?.tags) {
      updatedSettings.sitemaps.tags = { ...currentSettings.sitemaps.tags, ...body.sitemaps.tags };
    }
    if (body.sitemaps?.news) {
      updatedSettings.sitemaps.news = { ...currentSettings.sitemaps.news, ...body.sitemaps.news };
    }

    const success = saveSitemapSettings(updatedSettings);
    
    if (success) {
      return NextResponse.json({ success: true, settings: updatedSettings });
    } else {
      return NextResponse.json({ error: 'Failed to save settings' }, { status: 500 });
    }
  } catch (error) {
    console.error('Error saving sitemap settings:', error);
    return NextResponse.json({ error: 'Failed to save sitemap settings' }, { status: 500 });
  }
}
