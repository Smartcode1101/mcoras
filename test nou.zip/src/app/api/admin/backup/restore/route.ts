import { NextRequest, NextResponse } from 'next/server';
import * as fs from 'fs';
import * as path from 'path';

// Dynamic import for adm-zip
const AdmZip = require('adm-zip');

export async function POST(request: NextRequest) {
  try {
    const projectRoot = process.cwd();

    // Get the uploaded file
    const formData = await request.formData();
    const file = formData.get('backup') as File;

    if (!file) {
      return NextResponse.json(
        { error: 'Nu s-a încărcat niciun fișier' },
        { status: 400 }
      );
    }

    // Create temp directory
    const tempDir = path.join(projectRoot, 'tmp', 'restore-' + Date.now());
    fs.mkdirSync(tempDir, { recursive: true });

    // Save uploaded file
    const arrayBuffer = await file.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);
    const zipPath = path.join(tempDir, 'backup.zip');
    fs.writeFileSync(zipPath, buffer);

    // Extract the zip
    const zip = new AdmZip(zipPath);
    zip.extractAllTo(tempDir, true);

    // Get the extracted folder (might have a root folder)
    const extractedFolders = fs.readdirSync(tempDir).filter(f => {
      const fullPath = path.join(tempDir, f);
      return fs.statSync(fullPath).isDirectory();
    });

    let restoreBase = tempDir;
    
    // If there's a single folder, use it as base
    if (extractedFolders.length === 1) {
      restoreBase = path.join(tempDir, extractedFolders[0]);
    }

    // Debug: Log what folders exist in the extracted backup
    console.log('Extracted folders:', extractedFolders);
    console.log('Restore base:', restoreBase);
    
    // Check what's in restoreBase
    if (fs.existsSync(restoreBase)) {
      const restoreBaseContents = fs.readdirSync(restoreBase);
      console.log('Contents in restoreBase:', restoreBaseContents);
    }

    // Helper function to find a folder recursively
    function findFolder(baseDir: string, targetFolder: string): string | null {
      if (!fs.existsSync(baseDir)) return null;
      
      const items = fs.readdirSync(baseDir);
      
      for (const item of items) {
        const fullPath = path.join(baseDir, item);
        const stat = fs.statSync(fullPath);
        
        if (stat.isDirectory()) {
          if (item === targetFolder) {
            return fullPath;
          }
          // Search recursively
          const found = findFolder(fullPath, targetFolder);
          if (found) return found;
        }
      }
      return null;
    }

    // Restore folders that exist in backup
    const foldersToRestore = ['db', 'src', 'public', 'scripts', 'docs'];
    const filesToRestore = [
      'package.json', 'package-lock.json', 'next.config.ts', 
      'tsconfig.json', 'tailwind.config.ts', 'postcss.config.mjs',
      'middleware.ts', 'components.json', 'apphosting.yaml',
      '.gitignore', '.swcrc', '.browserslistrc', 'README.md'
    ];

    let restoredFiles = 0;
    let restoredFolders = 0;

    // Restore folders - search for each folder recursively in tempDir
    for (const folder of foldersToRestore) {
      // First try direct path
      let backupFolder = path.join(restoreBase, folder);
      
      // If not found, search recursively in tempDir
      if (!fs.existsSync(backupFolder)) {
        console.log(`  Searching recursively for ${folder}...`);
        const foundPath = findFolder(tempDir, folder);
        if (foundPath) {
          backupFolder = foundPath;
          console.log(`  Found ${folder} at: ${backupFolder}`);
        }
      }
      
      const targetFolder = path.join(projectRoot, folder);

      console.log(`Checking for folder: ${folder}`);
      console.log(`  backupFolder: ${backupFolder}`);
      console.log(`  backupFolder exists: ${fs.existsSync(backupFolder)}`);

      if (fs.existsSync(backupFolder)) {
        // Remove existing folder
        if (fs.existsSync(targetFolder)) {
          fs.rmSync(targetFolder, { recursive: true, force: true });
        }
        
        // Copy folder (with recursive option for Windows)
        fs.cpSync(backupFolder, targetFolder, { recursive: true });
        console.log(`  Restored folder: ${folder}`);
        restoredFolders++;
      } else {
        console.log(`  Folder ${folder} NOT FOUND in backup, skipping...`);
      }
    }

    // Helper function to find a file in subdirectories
    function findFile(baseDir: string, targetFile: string): string | null {
      if (!fs.existsSync(baseDir)) return null;
      
      const items = fs.readdirSync(baseDir);
      
      for (const item of items) {
        const fullPath = path.join(baseDir, item);
        const stat = fs.statSync(fullPath);
        
        if (stat.isFile()) {
          if (item === targetFile) {
            return fullPath;
          }
        } else if (stat.isDirectory()) {
          // Search recursively
          const found = findFile(fullPath, targetFile);
          if (found) return found;
        }
      }
      return null;
    }

    // Restore root files - search recursively if not found directly
    for (const file of filesToRestore) {
      let backupFile = path.join(restoreBase, file);
      
      // If not found, search recursively
      if (!fs.existsSync(backupFile)) {
        const foundPath = findFile(tempDir, file);
        if (foundPath) {
          backupFile = foundPath;
          console.log(`  Found ${file} at: ${backupFile}`);
        }
      }
      
      const targetFile = path.join(projectRoot, file);

      if (fs.existsSync(backupFile)) {
        // For next.config.ts, remove swcMinify option if present (not valid in Next.js 15+)
        if (file === 'next.config.ts') {
          let content = fs.readFileSync(backupFile, 'utf8');
          // Remove swcMinify: true or swcMinify:false
          content = content.replace(/\s*swcMinify:\s*(true|false)\s*,?\n?/g, '');
          fs.writeFileSync(targetFile, content);
        } else {
          fs.copyFileSync(backupFile, targetFile);
        }
        restoredFiles++;
      }
    }

    // Try to restore .env files - search recursively
    const envFiles = ['.env.local', '.env'];
    for (const envFile of envFiles) {
      let backupEnv = path.join(restoreBase, envFile);
      
      // If not found, search recursively
      if (!fs.existsSync(backupEnv)) {
        const foundPath = findFile(tempDir, envFile);
        if (foundPath) {
          backupEnv = foundPath;
          console.log(`  Found ${envFile} at: ${backupEnv}`);
        }
      }
      
      if (fs.existsSync(backupEnv)) {
        const targetEnv = path.join(projectRoot, envFile);
        fs.copyFileSync(backupEnv, targetEnv);
      }
    }

    // Cleanup temp files
    fs.rmSync(tempDir, { recursive: true });

    return NextResponse.json({
      success: true,
      message: `Restaurare completă! ${restoredFolders} foldere și ${restoredFiles} fișiere restaurate. Folderul db a fost inclus.`,
      restoredFolders,
      restoredFiles,
      restoredDetails: {
        db: foldersToRestore.includes('db'),
        src: foldersToRestore.includes('src'),
        public: foldersToRestore.includes('public'),
        scripts: foldersToRestore.includes('scripts'),
        docs: foldersToRestore.includes('docs')
      }
    });

  } catch (error) {
    console.error('Restore error:', error);
    return NextResponse.json(
      { error: 'Nu s-a putut restaura backup-ul' },
      { status: 500 }
    );
  }
}
