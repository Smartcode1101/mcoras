import { NextRequest, NextResponse } from 'next/server';
import * as fs from 'fs';
import * as path from 'path';

// Dynamic import for adm-zip to avoid TypeScript issues
const AdmZip = require('adm-zip');

export async function GET(request: NextRequest) {
  try {
    const projectRoot = process.cwd();
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    const backupFileName = `site-backup-${timestamp}.zip`;

    // Create a temporary directory for the backup
    const tempDir = path.join(projectRoot, 'tmp');
    if (!fs.existsSync(tempDir)) {
      fs.mkdirSync(tempDir, { recursive: true });
    }
    const tempFilePath = path.join(tempDir, backupFileName);

    // Create the zip archive using adm-zip
    const zip = new AdmZip();

    // Add entire project structure
    
    // 1. Database folder (db/)
    const dbPath = path.join(projectRoot, 'db');
    if (fs.existsSync(dbPath)) {
      addFolderToZip(zip, dbPath, 'db');
    }

    // 2. Source code (src/)
    const srcPath = path.join(projectRoot, 'src');
    if (fs.existsSync(srcPath)) {
      addFolderToZip(zip, srcPath, 'src');
    }

    // 3. Public folder (public/)
    const publicPath = path.join(projectRoot, 'public');
    if (fs.existsSync(publicPath)) {
      addFolderToZip(zip, publicPath, 'public');
    }

    // 4. Scripts folder (scripts/)
    const scriptsPath = path.join(projectRoot, 'scripts');
    if (fs.existsSync(scriptsPath)) {
      addFolderToZip(zip, scriptsPath, 'scripts');
    }

    // 5. Docs folder (docs/)
    const docsPath = path.join(projectRoot, 'docs');
    if (fs.existsSync(docsPath)) {
      addFolderToZip(zip, docsPath, 'docs');
    }

    // 6. Root configuration files
    const rootFiles = [
      'package.json',
      'package-lock.json',
      'next.config.ts',
      'tsconfig.json',
      'tailwind.config.ts',
      'postcss.config.mjs',
      '.env.example',
      '.env.local',
      '.env',
      'middleware.ts',
      'components.json',
      'apphosting.yaml',
      '.gitignore',
      '.swcrc',
      '.browserslistrc',
      'README.md',
    ];

    for (const file of rootFiles) {
      const filePath = path.join(projectRoot, file);
      if (fs.existsSync(filePath)) {
        zip.addLocalFile(filePath);
      }
    }

    // Write the zip file
    zip.writeZip(tempFilePath);

    // Read the created archive
    const archiveBuffer = fs.readFileSync(tempFilePath);
    
    // Delete the temporary file
    fs.unlinkSync(tempFilePath);

    // Return the zip file
    return new NextResponse(archiveBuffer, {
      headers: {
        'Content-Type': 'application/zip',
        'Content-Disposition': `attachment; filename="${backupFileName}"`,
        'Content-Length': archiveBuffer.length.toString(),
      },
    });
  } catch (error) {
    console.error('Backup error:', error);
    return NextResponse.json(
      { error: 'Nu s-a putut crea backup-ul' },
      { status: 500 }
    );
  }
}

function addFolderToZip(zip: any, folderPath: string, baseName: string): void {
  if (!fs.existsSync(folderPath)) return;

  const items = fs.readdirSync(folderPath);
  
  // Exclude node_modules and .next from any folder
  const excludeDirs = ['node_modules', '.next', '.git', 'tmp'];
  
  for (const item of items) {
    // Skip excluded directories
    if (excludeDirs.includes(item)) continue;
    
    const fullPath = path.join(folderPath, item);
    const stat = fs.statSync(fullPath);
    
    if (stat.isDirectory()) {
      addFolderToZip(zip, fullPath, path.join(baseName, item));
    } else {
      zip.addLocalFile(fullPath, baseName);
    }
  }
}
