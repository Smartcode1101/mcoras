import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';

const settingsPath = path.join(process.cwd(), 'db', 'site-settings.json');

interface PerformanceSettings {
  minifyHtml: boolean;
  minifyCss: boolean;
  minifyJs: boolean;
  delayedJs: boolean;
  delayedJsTimeout: number;
  lazyLoadImages: boolean;
  reduceJsExecution: boolean;
}

interface SiteSettings {
  performanceSettings?: PerformanceSettings;
  [key: string]: unknown;
}

export async function GET() {
  try {
    const data = fs.readFileSync(settingsPath, 'utf-8');
    const settings: SiteSettings = JSON.parse(data);
    
    const defaultSettings: PerformanceSettings = {
      minifyHtml: true,
      minifyCss: true,
      minifyJs: true,
      delayedJs: true,
      delayedJsTimeout: 2000,
      lazyLoadImages: true,
      reduceJsExecution: true
    };

    return NextResponse.json(settings.performanceSettings || defaultSettings);
  } catch (error) {
    console.error('Eroare la citirea setărilor de performanță:', error);
    return NextResponse.json(
      { error: 'Nu s-au putut încărca setările' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const newSettings: PerformanceSettings = await request.json();
    
    const data = fs.readFileSync(settingsPath, 'utf-8');
    const settings: SiteSettings = JSON.parse(data);
    
    settings.performanceSettings = {
      minifyHtml: Boolean(newSettings.minifyHtml),
      minifyCss: Boolean(newSettings.minifyCss),
      minifyJs: Boolean(newSettings.minifyJs),
      delayedJs: Boolean(newSettings.delayedJs),
      delayedJsTimeout: Number(newSettings.delayedJsTimeout) || 2000,
      lazyLoadImages: Boolean(newSettings.lazyLoadImages),
      reduceJsExecution: Boolean(newSettings.reduceJsExecution)
    };
    
    fs.writeFileSync(settingsPath, JSON.stringify(settings, null, 2));
    
    return NextResponse.json({ 
      success: true, 
      message: 'Setările de performanță au fost salvate',
      settings: settings.performanceSettings 
    });
  } catch (error) {
    console.error('Eroare la salvarea setărilor de performanță:', error);
    return NextResponse.json(
      { error: 'Nu s-au putut salva setările' },
      { status: 500 }
    );
  }
}
