import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import './globals.css';
import { Toaster } from '@/components/ui/toaster';
import { AuthProvider } from '@/contexts/auth-context';
import { EditorProvider } from '@/contexts/editor-context';
import { AnalyticsProvider } from '@/components/analytics/AnalyticsProvider';
import { AnalyticsTracker } from '@/components/AnalyticsTracker';
import { DynamicFavicon } from '@/components/DynamicFavicon';
import siteSettings from '../../db/site-settings.json';
import { promises as fs } from 'fs';
import path from 'path';

// Funcție pentru a obține configurația GA4
async function getGA4Config() {
  try {
    const configPath = path.join(process.cwd(), 'db', 'analytics-simple.json');
    const data = await fs.readFile(configPath, 'utf8');
    const config = JSON.parse(data);
    return {
      measurementId: config.measurementId || process.env.NEXT_PUBLIC_GA4_MEASUREMENT_ID || '',
      enabled: config.enabled ?? true
    };
  } catch (error) {
    // Dacă fișierul nu există, folosește variabila de mediu
    return {
      measurementId: process.env.NEXT_PUBLIC_GA4_MEASUREMENT_ID || '',
      enabled: !!process.env.NEXT_PUBLIC_GA4_MEASUREMENT_ID
    };
  }
}

const inter = Inter({
  subsets: ['latin'],
  display: 'swap',
  variable: '--font-inter',
});

// Obține limba din setări
const siteLanguage = siteSettings.language || 'ro';
const siteName = siteSettings.siteName || 'One Smart';
const siteDescription = siteSettings.siteDescription || 'Build Beautiful Pages Instantly';
const ogImage = siteSettings.ogImage || 'https://picsum.photos/seed/og-image/1200/630';
const twitterImage = siteSettings.twitterImage || 'https://picsum.photos/seed/twitter-image/1200/630';

// Mappare limba -> locale pentru OpenGraph
const languageLocales: Record<string, string> = {
  'ro': 'ro_RO',
  'en': 'en_US',
  'de': 'de_DE',
  'fr': 'fr_FR',
  'es': 'es_ES',
  'it': 'it_IT',
};

export const metadata: Metadata = {
  metadataBase: new URL('http://localhost:9002'), // Replace with your actual domain
  title: {
    default: `${siteName} - ${siteDescription}`,
    template: '%s',
  },
  description: siteDescription,
  keywords: ['page builder', 'website builder', 'drag and drop', 'no-code', 'web design', 'landing page'],
  openGraph: {
    title: `${siteName} - ${siteDescription}`,
    description: siteDescription,
    type: 'website',
    locale: languageLocales[siteLanguage] || 'ro_RO',
    url: 'http://localhost:9002', // Replace with your actual domain
    siteName: siteName,
    images: [
      {
        url: ogImage,
        width: 1200,
        height: 630,
        alt: siteName,
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: `${siteName} - ${siteDescription}`,
    description: siteDescription,
    images: [twitterImage],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  icons: {
    icon: siteSettings.logoUrl || '/favicon.ico',
    shortcut: siteSettings.logoUrl || '/favicon-16x16.png',
    apple: siteSettings.logoUrl || '/apple-touch-icon.png',
  },
  other: {
    'theme-color': '#000000',
  },
};

export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  // Obține configurația GA4 din setările salvate
  const ga4Config = await getGA4Config();
  const ga4MeasurementId = ga4Config.measurementId;
  const ga4Enabled = ga4Config.enabled && !!ga4MeasurementId;

  return (
    <html lang={siteSettings.language || 'ro'} suppressHydrationWarning className={inter.variable}>
      <head>
        {/* Google Analytics 4 - GA4 - only load on non-admin pages */}
        {ga4Enabled && ga4MeasurementId && (
          <script
            dangerouslySetInnerHTML={{
              __html: `
                (function() {
                  // Don't load GA4 on admin pages
                  if (window.location.pathname.startsWith('/admin')) {
                    return;
                  }
                  // Load gtag.js dynamically
                  var script = document.createElement('script');
                  script.src = 'https://www.googletagmanager.com/gtag/js?id=${ga4MeasurementId}';
                  script.async = true;
                  document.head.appendChild(script);
                  
                  window.dataLayer = window.dataLayer || [];
                  function gtag(){dataLayer.push(arguments);}
                  gtag('js', new Date());
                  gtag('config', '${ga4MeasurementId}', {
                    page_title: document.title,
                    page_location: window.location.href,
                    send_page_view: true,
                    anonymize_ip: true,
                    allow_google_signals: true,
                    allow_ad_personalization_signals: true,
                  });
                })();
              `,
            }}
          />
        )}
      </head>
      <body className="font-body antialiased" style={{ overflow: 'visible' }}>
        <AuthProvider>
          <EditorProvider>
            <AnalyticsProvider>
              <DynamicFavicon />
              <AnalyticsTracker />
              {children}
            </AnalyticsProvider>
          </EditorProvider>
        </AuthProvider>
        <Toaster />
      </body>
    </html>
  );
}
