import { getPageBySlug, updatePageViews } from '@/lib/page-data';
import { notFound } from 'next/navigation';
import { PageRenderer } from '@/components/PageRenderer';
import { Metadata } from 'next';
import { getSiteSettings } from '@/lib/settings-data';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { getPages } from '@/lib/page-data';
import fs from 'fs';
import path from 'path';
import type { Category, MenuItem } from '@/lib/types';

async function getCategories(): Promise<Category[]> {
  try {
    const categoriesPath = path.join(process.cwd(), 'db', 'categories.json');
    const data = await fs.promises.readFile(categoriesPath, 'utf-8');
    return JSON.parse(data);
  } catch {
    return [];
  }
}

type HeaderMenuItem = {
  title: string;
  slug: string;
  children?: HeaderMenuItem[];
  isSubmenu?: boolean;
};

function convertToHeaderMenuItems(
  items: MenuItem[], 
  allPages: { id: string; title: string; slug: string }[],
  allCategories: { id: string; name: string; slug: string }[]
): HeaderMenuItem[] {
  const result: HeaderMenuItem[] = [];
  
  for (const item of items) {
      if (item.pageId) {
        const page = allPages.find(p => p.id === item.pageId);
        if (!page) continue;
        const title = (item.title && item.title.trim() !== '') ? item.title : page.title;
        result.push({ title, slug: page.slug });
        continue;
      }
      if (item.categoryId) {
        const category = allCategories.find(c => c.id === item.categoryId);
        if (!category) continue;
        const title = (item.title && item.title.trim() !== '') ? item.title : category.name;
        result.push({ title, slug: `categorie/${category.slug}` });
        continue;
      }
      // Submenu - check for isSubmenu flag or children
      if (item.isSubmenu || item.children) {
        const title = item.title || 'Submeniu';
        result.push({ 
          title, 
          slug: `submenu-${Date.now()}-${Math.random()}`,
          isSubmenu: true,
          children: item.children ? convertToHeaderMenuItems(item.children, allPages, allCategories) : []
        });
        continue;
      }
  }
  
  return result;
}

export async function generateMetadata(): Promise<Metadata> {
  const page = await getPageBySlug('home');
  const siteSettings = await getSiteSettings();

  if (!page) {
    return {
      title: siteSettings.siteTitle,
    };
  }

  const pageTitle = page?.title;
  const siteTitle = siteSettings.siteTitle;

  return {
    title: pageTitle || siteTitle,
    description: page?.seoDescription,
    keywords: page?.seoKeywords,
  };
}

export default async function Home() {
  const page = await getPageBySlug('home');
  const settings = await getSiteSettings();
  const allPages = await getPages();
  const allCategories = await getCategories();

  const menuItems = convertToHeaderMenuItems(settings.menu.items, allPages, allCategories);

  if (!page) {
    return (
      <>
        <Header
          logoUrl={settings.logoUrl}
          siteTitle={settings.siteTitle}
          menuItems={menuItems}
          menuAlignment={settings.menu.alignment}
          styleSettings={settings.headerSettings}
        />
        <main className="flex flex-col items-center justify-center min-h-screen text-center p-4">
            <h1 className="text-4xl font-bold mb-4">Bun venit la One Smart</h1>
            <p className="text-xl text-muted-foreground">
                Se pare că nu ai setat încă o pagină principală.
            </p>
            <p className="mt-2 text-muted-foreground">
                Mergi la <a href="/admin" className="text-primary underline">panoul de administrare</a> pentru a crea o pagină cu slug-ul "home".
            </p>
        </main>
        <Footer
          siteTitle={settings.siteTitle}
          styleSettings={settings.footerSettings}
        />
      </>
    );
  }

  // Track page view asynchronously (don't await to avoid blocking render)
  updatePageViews('home').catch(console.error);

  return (
    <>
      <Header
        logoUrl={settings.logoUrl}
        siteTitle={settings.siteTitle}
        menuItems={menuItems}
        menuAlignment={settings.menu.alignment}
        styleSettings={settings.headerSettings}
      />
      <PageRenderer page={page} />
      <Footer
        siteTitle={settings.siteTitle}
        styleSettings={settings.footerSettings}
      />
    </>
  );
}