'use client';

import Link from 'next/link';
import { useState, useMemo, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { getPagesAction } from '@/lib/actions';
import { DeletePageButton } from './DeletePageButton';
import { SetHomepageButton } from './SetHomepageButton';
import { Badge } from '@/components/ui/badge';
import { FileText, Newspaper, Search, Eye, Edit, Trash2, Code } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

export function PageList() {
  const [pages, setPages] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState<'all' | 'page' | 'post'>('all');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  useEffect(() => {
    const fetchPages = async () => {
      try {
        const result = await getPagesAction();
        if (result.error) {
          console.error('Error fetching pages:', result.error);
          return;
        }
        const data = result.data || [];
        setPages(data);
      } catch (error) {
        console.error('Error fetching pages:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchPages();
  }, []);

  const filteredPages = useMemo(() => {
    return pages.filter(page => {
      const matchesSearch = page.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           page.slug.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesType = typeFilter === 'all' || page.type === typeFilter;
      return matchesSearch && matchesType;
    });
  }, [pages, searchTerm, typeFilter]);

  const totalPages = Math.ceil(filteredPages.length / itemsPerPage);
  const paginatedPages = filteredPages.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  if (loading) {
    return (
      <div className="space-y-4">
        {[...Array(5)].map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardContent className="p-6">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-gray-200 rounded"></div>
                <div className="flex-1 space-y-2">
                  <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (pages.length === 0) {
    return (
      <Card className="text-center py-12">
        <CardContent>
          <FileText className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
          <h2 className="text-xl font-medium text-muted-foreground">Nicio pagină încă.</h2>
          <p className="text-muted-foreground mt-2">
            Apasă pe "Creează Pagină Nouă" pentru a începe.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4 md:space-y-6">
      {/* Filters and Search */}
      <Card>
        <CardHeader className="p-4 md:p-6">
          <CardTitle className="text-lg md:text-xl">Filtre și Căutare</CardTitle>
          <CardDescription className="text-sm">Găsește rapid paginile dorite</CardDescription>
        </CardHeader>
        <CardContent className="p-4 md:p-6 pt-0">
          <div className="flex flex-col sm:flex-row gap-3 md:gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Caută..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={typeFilter} onValueChange={(value: any) => setTypeFilter(value)}>
              <SelectTrigger className="w-full sm:w-40 md:w-48">
                <SelectValue placeholder="Tip" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Toate</SelectItem>
                <SelectItem value="page">Pagini</SelectItem>
                <SelectItem value="post">Postări</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Results Summary */}
      <div className="flex items-center justify-between px-1">
        <p className="text-sm text-muted-foreground">
          {filteredPages.length} {filteredPages.length === 1 ? 'pagină' : 'pagini'}
        </p>
      </div>

      {/* Pages Grid */}
      <div className="grid gap-3 md:gap-4">
        {paginatedPages.map((page) => (
          <Card key={page.id} className="hover:shadow-md transition-shadow">
            <CardContent className="p-3 md:p-4 lg:p-6">
              <div className="flex flex-col sm:flex-row sm:items-start gap-3 md:gap-4">
                {/* Thumbnail - hide on small mobile */}
                <div className="hidden sm:block">
                  <Avatar className="w-12 h-12 md:w-16 md:h-16">
                    {page.type === 'post' && page.thumbnail ? (
                      <AvatarImage src={page.thumbnail} alt={page.title} />
                    ) : null}
                    <AvatarFallback>
                      {page.type === 'post' ? (
                        <Newspaper className="w-5 h-5 md:w-6 md:h-6" />
                      ) : (
                        <FileText className="w-5 h-5 md:w-6 md:h-6" />
                      )}
                    </AvatarFallback>
                  </Avatar>
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex flex-wrap items-center gap-1 md:gap-2 mb-1">
                    <h3 className="font-semibold text-base md:text-lg truncate max-w-[150px] md:max-w-none">{page.title}</h3>
                    {page.slug === 'home' && (
                      <Badge variant="secondary" className="text-xs">Acasă</Badge>
                    )}
                    <Badge variant={page.type === 'post' ? 'default' : 'outline'} className="text-xs">
                      {page.type === 'post' ? 'Post' : 'Pagină'}
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground mb-1 md:mb-2 truncate">
                    /{page.slug === 'home' ? '' : page.slug}/
                  </p>
                  <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted-foreground">
                    <span>Viz: {page.viewsLast24h || 0}</span>
                    <span>{new Date(page.createdAt).toLocaleDateString('ro-RO')}</span>
                  </div>
                </div>

                {/* Actions - wrap on mobile */}
                <div className="flex flex-wrap items-center gap-1 md:gap-2 w-full sm:w-auto mt-2 sm:mt-0">
                  <SetHomepageButton pageId={page.id} isHomepage={page.slug === 'home'} />
                  <Button asChild variant="outline" size="sm" className="text-xs px-2">
                    <Link href={`/admin/structured-data/${page.id}`}>
                      <Code className="w-3 h-3 md:w-4 md:h-4" />
                    </Link>
                  </Button>
                  <Button asChild variant="outline" size="sm" className="text-xs px-2">
                    <Link href={page.slug === 'home' ? '/' : `/${page.slug}`} target="_blank">
                      <Eye className="w-3 h-3 md:w-4 md:h-4" />
                    </Link>
                  </Button>
                  <Button asChild variant="outline" size="sm" className="text-xs px-2">
                    <Link href={`/admin/editor/${page.id}`}>
                      <Edit className="w-3 h-3 md:w-4 md:h-4" />
                    </Link>
                  </Button>
                  <DeletePageButton pageId={page.id} />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-2 mt-8">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
            disabled={currentPage === 1}
          >
            Anterior
          </Button>

          {/* Page Numbers */}
          <div className="flex items-center gap-1">
            {(() => {
              const pages = [];
              const maxVisiblePages = 8;
              let startPage = Math.max(1, currentPage - Math.floor(maxVisiblePages / 2));
              let endPage = Math.min(totalPages, startPage + maxVisiblePages - 1);

              // Adjust start page if we're near the end
              if (endPage - startPage + 1 < maxVisiblePages) {
                startPage = Math.max(1, endPage - maxVisiblePages + 1);
              }

              // Always show page 1 if not in range
              if (startPage > 1) {
                pages.push(
                  <Button
                    key={1}
                    variant={currentPage === 1 ? "default" : "outline"}
                    size="sm"
                    onClick={() => setCurrentPage(1)}
                    className="w-10 h-10 p-0"
                  >
                    1
                  </Button>
                );
                if (startPage > 2) {
                  pages.push(
                    <span key="ellipsis-start" className="px-2 text-muted-foreground">
                      ...
                    </span>
                  );
                }
              }

              // Show page numbers in range
              for (let i = startPage; i <= endPage; i++) {
                pages.push(
                  <Button
                    key={i}
                    variant={currentPage === i ? "default" : "outline"}
                    size="sm"
                    onClick={() => setCurrentPage(i)}
                    className="w-10 h-10 p-0"
                  >
                    {i}
                  </Button>
                );
              }

              // Always show last page if not in range
              if (endPage < totalPages) {
                if (endPage < totalPages - 1) {
                  pages.push(
                    <span key="ellipsis-end" className="px-2 text-muted-foreground">
                      ...
                    </span>
                  );
                }
                pages.push(
                  <Button
                    key={totalPages}
                    variant={currentPage === totalPages ? "default" : "outline"}
                    size="sm"
                    onClick={() => setCurrentPage(totalPages)}
                    className="w-10 h-10 p-0"
                  >
                    {totalPages}
                  </Button>
                );
              }

              return pages;
            })()}
          </div>

          <Button
            variant="outline"
            size="sm"
            onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
            disabled={currentPage === totalPages}
          >
            Următor
          </Button>
        </div>
      )}
    </div>
  );
}
