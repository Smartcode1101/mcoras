'use client';

import { useState, useRef } from 'react';
import { Download, Database, Image, FileJson, AlertCircle, CheckCircle, Loader2, Upload, Archive } from 'lucide-react';

interface BackupStatus {
  isCreating: boolean;
  isRestoring: boolean;
  message: string;
  success: boolean;
}

export default function BackupPage() {
  const [status, setStatus] = useState<BackupStatus>({
    isCreating: false,
    isRestoring: false,
    message: '',
    success: false,
  });
  const fileInputRef = useRef<HTMLInputElement>(null);

  const createBackup = async () => {
    setStatus({ isCreating: true, isRestoring: false, message: 'Se creează backup-ul...', success: false });

    try {
      const response = await fetch('/api/admin/backup', {
        method: 'GET',
      });

      if (!response.ok) {
        throw new Error('Nu s-a putut crea backup-ul');
      }

      // Get the blob from response
      const blob = await response.blob();
      
      // Create a download link
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      
      // Get filename from content-disposition header
      const contentDisposition = response.headers.get('Content-Disposition');
      const filename = contentDisposition 
        ? contentDisposition.split('filename=')[1]?.replace(/"/g, '')
        : `site-backup-${new Date().toISOString().slice(0, 10)}.zip`;
      
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      
      // Cleanup
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);

      setStatus({
        isCreating: false,
        isRestoring: false,
        message: 'Backup-ul a fost creat și descărcat cu succes!',
        success: true,
      });
    } catch (error) {
      console.error('Backup error:', error);
      setStatus({
        isCreating: false,
        isRestoring: false,
        message: 'A apărut o eroare la crearea backup-ului. Încearcă din nou.',
        success: false,
      });
    }
  };

  const handleRestore = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setStatus({ isCreating: false, isRestoring: true, message: 'Se restaurează backup-ul...', success: false });

    try {
      const formData = new FormData();
      formData.append('backup', file);

      const response = await fetch('/api/admin/backup/restore', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Nu s-a putut restaura backup-ul');
      }

      const result = await response.json();

      setStatus({
        isCreating: false,
        isRestoring: false,
        message: result.message || 'Backup-ul a fost restaurat cu succes!',
        success: true,
      });
    } catch (error: any) {
      console.error('Restore error:', error);
      setStatus({
        isCreating: false,
        isRestoring: false,
        message: error.message || 'A apărut o eroare la restaurarea backup-ului.',
        success: false,
      });
    }

    // Reset file input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Create Backup Section */}
      <div className="bg-card border rounded-lg p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 bg-primary/10 rounded-lg">
            <Database className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h2 className="text-xl font-semibold">Creare Backup</h2>
            <p className="text-sm text-muted-foreground">
              Descarcă o arhivă ZIP cu întregul site
            </p>
          </div>
        </div>

        <div className="space-y-4 mb-6">
          <div className="flex items-start gap-3 p-4 bg-muted/50 rounded-lg">
            <Database className="w-5 h-5 text-muted-foreground mt-0.5" />
            <div>
              <p className="font-medium text-sm">Baza de date</p>
              <p className="text-sm text-muted-foreground">Toate fișierele JSON din folderul db/</p>
            </div>
          </div>
          
          <div className="flex items-start gap-3 p-4 bg-muted/50 rounded-lg">
            <Image className="w-5 h-5 text-muted-foreground mt-0.5" />
            <div>
              <p className="font-medium text-sm">Fișiere Media</p>
              <p className="text-sm text-muted-foreground">Toate imaginile din public/</p>
            </div>
          </div>
          
          <div className="flex items-start gap-3 p-4 bg-muted/50 rounded-lg">
            <FileJson className="w-5 h-5 text-muted-foreground mt-0.5" />
            <div>
              <p className="font-medium text-sm">Cod Sursă și Configurație</p>
              <p className="text-sm text-muted-foreground">
                src/, scripts/, docs/, package.json, etc.
              </p>
            </div>
          </div>
        </div>

        {status.message && !status.isRestoring && (
          <div
            className={`flex items-center gap-2 p-4 rounded-lg mb-4 ${
              status.success 
                ? 'bg-green-50 text-green-800 dark:bg-green-900/20 dark:text-green-400' 
                : 'bg-red-50 text-red-800 dark:bg-red-900/20 dark:text-red-400'
            }`}
          >
            {status.success ? (
              <CheckCircle className="w-5 h-5" />
            ) : (
              <AlertCircle className="w-5 h-5" />
            )}
            <p className="text-sm">{status.message}</p>
          </div>
        )}

        <button
          onClick={createBackup}
          disabled={status.isCreating}
          className="w-full flex items-center justify-center gap-2 py-3 px-4 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
        >
          {status.isCreating ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin" />
              <span>Se creează backup-ul...</span>
            </>
          ) : (
            <>
              <Download className="w-5 h-5" />
              <span>Descarcă Backup</span>
            </>
          )}
        </button>

        <p className="text-xs text-muted-foreground mt-4 text-center">
          Backup-ul va fi descărcat ca fișier ZIP și poate fi restaurat oricând.
        </p>
      </div>

      {/* Restore Backup Section */}
      <div className="bg-card border rounded-lg p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 bg-amber-500/10 rounded-lg">
            <Archive className="w-6 h-6 text-amber-500" />
          </div>
          <div>
            <h2 className="text-xl font-semibold">Restaurare Backup</h2>
            <p className="text-sm text-muted-foreground">
              Restaurează site-ul dintr-o arhivă ZIP
            </p>
          </div>
        </div>

        <div className="space-y-4 mb-6">
          <div className="p-4 bg-amber-50 dark:bg-amber-900/20 rounded-lg">
            <p className="text-sm text-amber-800 dark:text-amber-200">
              <strong>Atenție!</strong> Restaurarea va suprascrie toate fișierele existente: 
              baza de date, pagini, imagini, setări, etc.
            </p>
          </div>
          
          <div className="p-4 bg-muted/50 rounded-lg">
            <p className="text-sm text-muted-foreground">
              După restaurare, rulează <code>npm install</code> pentru a reinstala dependințele.
            </p>
          </div>
        </div>

        {status.message && status.isRestoring && (
          <div
            className={`flex items-center gap-2 p-4 rounded-lg mb-4 ${
              status.success 
                ? 'bg-green-50 text-green-800 dark:bg-green-900/20 dark:text-green-400' 
                : 'bg-red-50 text-red-800 dark:bg-red-900/20 dark:text-red-400'
            }`}
          >
            {status.isRestoring && !status.message.includes('succes') ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : status.success ? (
              <CheckCircle className="w-5 h-5" />
            ) : (
              <AlertCircle className="w-5 h-5" />
            )}
            <p className="text-sm">{status.message}</p>
          </div>
        )}

        <input
          type="file"
          accept=".zip"
          ref={fileInputRef}
          onChange={handleRestore}
          disabled={status.isRestoring}
          className="hidden"
          id="restore-upload"
        />

        <label
          htmlFor="restore-upload"
          className={`w-full flex items-center justify-center gap-2 py-3 px-4 rounded-lg cursor-pointer transition-colors ${
            status.isRestoring
              ? 'bg-amber-500/50 text-white cursor-not-allowed'
              : 'bg-amber-500 text-white hover:bg-amber-600'
          }`}
        >
          {status.isRestoring ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin" />
              <span>Se restaurează...</span>
            </>
          ) : (
            <>
              <Upload className="w-5 h-5" />
              <span>Încarcă Backup</span>
            </>
          )}
        </label>
      </div>
    </div>
  );
}
