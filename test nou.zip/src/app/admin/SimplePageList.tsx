'use client';

import { useState, useEffect } from 'react';
import { getPagesAction, getActivePagesAction } from '@/lib/actions';
import { Badge } from '@/components/ui/badge';
import { FileText, Newspaper, Eye } from 'lucide-react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

export function SimplePageList() {
  const [pages, setPages] = useState<any[]>([]);
  const [activePagesCount, setActivePagesCount] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const pagesResult = await getPagesAction();
        const pagesData = pagesResult.error ? [] : (pagesResult.data || []);
        setPages(pagesData);

        const activeResult = await getActivePagesAction();
        if (activeResult.data !== undefined) {
          setActivePagesCount(activeResult.data);
        }
      } catch (error) {
        console.error('Error fetching data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();

    // Update active pages count every 5 seconds
    const interval = setInterval(async () => {
      try {
        const activeResult = await getActivePagesAction();
        if (activeResult.data !== undefined) {
          setActivePagesCount(activeResult.data);
        }
      } catch (error) {
        console.error('Error fetching active pages:', error);
      }
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  // Calculate statistics for last 24 hours
  const now = new Date();
  const last24h = new Date(now.getTime() - 24 * 60 * 60 * 1000);

  const recentPages = pages.filter(page => new Date(page.createdAt) > last24h);
  const totalViewsLast24h = pages.reduce((sum, page) => sum + (page.viewsLast24h || 0), 0);
  const totalPages = pages.length;
  const totalPosts = pages.filter(page => page.type === 'post').length;

  if (loading) {
    return (
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        {[...Array(4)].map((_, i) => (
          <Card key={i}>
            <CardContent className="p-6">
              <div className="animate-pulse space-y-2">
                <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                <div className="h-8 bg-gray-200 rounded w-1/2"></div>
                <div className="h-3 bg-gray-200 rounded w-full"></div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
      {/* Statistics Cards */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Total Pagini</CardTitle>
          <FileText className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{totalPages}</div>
          <p className="text-xs text-muted-foreground">
            +{recentPages.length} în ultimele 24h
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Postări</CardTitle>
          <Newspaper className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{totalPosts}</div>
          <p className="text-xs text-muted-foreground">
            {totalPages > 0 ? Math.round((totalPosts / totalPages) * 100) : 0}% din total
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Vizualizări (24h)</CardTitle>
          <Eye className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{totalViewsLast24h}</div>
          <p className="text-xs text-muted-foreground">
            Total vizualizări recente
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Pagini Active</CardTitle>
          <FileText className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">
            {activePagesCount}
          </div>
          <p className="text-xs text-muted-foreground">
            Utilizatori activi acum (12 secunde)
          </p>
        </CardContent>
      </Card>

      {/* Recent Pages Table */}
      <div className="md:col-span-2 lg:col-span-4">
        <Card>
          <CardHeader>
            <CardTitle>Pagini Recente</CardTitle>
          </CardHeader>
          <CardContent>
            {pages.length === 0 ? (
              <div className="text-center py-12 border-2 border-dashed rounded-lg">
                <h2 className="text-xl font-medium text-muted-foreground">Nicio pagină încă.</h2>
                <p className="text-muted-foreground mt-2">
                  Mergi la secțiunea "Pagini" pentru a crea una.
                </p>
              </div>
            ) : (
              <div className="border rounded-lg">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Titlu</TableHead>
                      <TableHead>Tip</TableHead>
                      <TableHead>Vizualizări (24h)</TableHead>
                      <TableHead>Cale URL</TableHead>
                      <TableHead>Data Creării</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {pages.slice(0, 5).map((page) => (
                      <TableRow key={page.id}>
                        <TableCell className="font-medium flex items-center gap-2">
                          {page.title}
                          {page.slug === 'home' && (
                            <Badge variant="secondary">Acasă</Badge>
                          )}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            {page.type === 'post' ? (
                              <>
                                <Newspaper className="w-4 h-4 text-muted-foreground" />
                                <span className="text-sm">Postare</span>
                              </>
                            ) : (
                              <>
                                <FileText className="w-4 h-4 text-muted-foreground" />
                                <span className="text-sm">Pagină</span>
                              </>
                            )}
                          </div>
                        </TableCell>
                        <TableCell>
                          <span className="font-medium">{page.viewsLast24h || 0}</span>
                        </TableCell>
                        <TableCell className="text-muted-foreground">
                          <a href={page.slug === 'home' ? '/' : `/${page.slug}/`} target="_blank" rel="noopener noreferrer" className="hover:underline">
                              /{page.slug === 'home' ? '' : page.slug}/
                          </a>
                        </TableCell>
                        <TableCell>
                          {new Date(page.createdAt).toLocaleDateString('ro-RO', {
                            year: 'numeric',
                            month: 'long',
                            day: 'numeric',
                          })}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
