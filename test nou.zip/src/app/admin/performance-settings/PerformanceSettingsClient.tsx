'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Zap, FileCode, Palette, Code, Clock, Save, RefreshCw, Image, Gauge } from 'lucide-react';

interface PerformanceSettings {
  minifyHtml: boolean;
  minifyCss: boolean;
  minifyJs: boolean;
  delayedJs: boolean;
  delayedJsTimeout: number;
  lazyLoadImages: boolean;
  reduceJsExecution: boolean;
}

export default function PerformanceSettingsClient() {
  const [settings, setSettings] = useState<PerformanceSettings>({
    minifyHtml: true,
    minifyCss: true,
    minifyJs: true,
    delayedJs: true,
    delayedJsTimeout: 2000,
    lazyLoadImages: true,
    reduceJsExecution: true
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    try {
      const response = await fetch('/api/admin/performance-settings');
      if (response.ok) {
        const data = await response.json();
        setSettings(data);
      }
    } catch (error) {
      console.error('Eroare la încărcarea setărilor:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    setMessage(null);
    
    try {
      const response = await fetch('/api/admin/performance-settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settings)
      });
      
      if (response.ok) {
        setMessage({ type: 'success', text: 'Setările au fost salvate cu succes!' });
      } else {
        setMessage({ type: 'error', text: 'Eroare la salvarea setărilor.' });
      }
    } catch {
      setMessage({ type: 'error', text: 'Eroare la salvarea setărilor.' });
    } finally {
      setSaving(false);
    }
  };

  const handleToggle = (key: keyof PerformanceSettings) => {
    setSettings(prev => ({
      ...prev,
      [key]: !prev[key]
    }));
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <RefreshCw className="h-8 w-8 animate-spin text-gray-400" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Setări Performanță</h1>
          <p className="text-gray-600 mt-1">Configurează optimizările pentru viteza site-ului</p>
        </div>
        <Button onClick={handleSave} disabled={saving} className="bg-green-600 hover:bg-green-700">
          {saving ? (
            <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
          ) : (
            <Save className="h-4 w-4 mr-2" />
          )}
          Salvează Setările
        </Button>
      </div>

      {message && (
        <div className={`p-4 rounded-lg ${message.type === 'success' ? 'bg-green-50 text-green-800' : 'bg-red-50 text-red-800'}`}>
          {message.text}
        </div>
      )}

      {/* Minify Settings */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <Zap className="h-5 w-5 text-yellow-500" />
            <CardTitle>Minificare Resurse</CardTitle>
          </div>
          <CardDescription>
            Reduce dimensiunea fișierelor HTML, CSS și JavaScript pentru încărcare mai rapidă
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Minify HTML */}
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div className="flex items-center gap-3">
              <FileCode className="h-5 w-5 text-blue-500" />
              <div>
                <Label htmlFor="minifyHtml" className="font-medium">Minificare HTML</Label>
                <p className="text-sm text-gray-500">Elimină spațiile și comentariile din HTML</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant={settings.minifyHtml ? "default" : "secondary"}>
                {settings.minifyHtml ? 'Activat' : 'Dezactivat'}
              </Badge>
              <Switch
                id="minifyHtml"
                checked={settings.minifyHtml}
                onCheckedChange={() => handleToggle('minifyHtml')}
              />
            </div>
          </div>

          {/* Minify CSS */}
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div className="flex items-center gap-3">
              <Palette className="h-5 w-5 text-purple-500" />
              <div>
                <Label htmlFor="minifyCss" className="font-medium">Minificare CSS</Label>
                <p className="text-sm text-gray-500">Comprimă fișierele CSS eliminând spațiile</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant={settings.minifyCss ? "default" : "secondary"}>
                {settings.minifyCss ? 'Activat' : 'Dezactivat'}
              </Badge>
              <Switch
                id="minifyCss"
                checked={settings.minifyCss}
                onCheckedChange={() => handleToggle('minifyCss')}
              />
            </div>
          </div>

          {/* Minify JS */}
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div className="flex items-center gap-3">
              <Code className="h-5 w-5 text-orange-500" />
              <div>
                <Label htmlFor="minifyJs" className="font-medium">Minificare JavaScript</Label>
                <p className="text-sm text-gray-500">Comprimă fișierele JS pentru dimensiune redusă</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant={settings.minifyJs ? "default" : "secondary"}>
                {settings.minifyJs ? 'Activat' : 'Dezactivat'}
              </Badge>
              <Switch
                id="minifyJs"
                checked={settings.minifyJs}
                onCheckedChange={() => handleToggle('minifyJs')}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Delayed JavaScript */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <Clock className="h-5 w-5 text-blue-500" />
            <CardTitle>JavaScript Diferit (Delayed JS)</CardTitle>
          </div>
          <CardDescription>
            Încarcă JavaScript-ul după ce pagina a fost randată pentru performanță mai bună
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div className="flex items-center gap-3">
              <Clock className="h-5 w-5 text-green-500" />
              <div>
                <Label htmlFor="delayedJs" className="font-medium">Activează JavaScript Diferit</Label>
                <p className="text-sm text-gray-500">Încarcă scripturile non-critice cu întârziere</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant={settings.delayedJs ? "default" : "secondary"}>
                {settings.delayedJs ? 'Activat' : 'Dezactivat'}
              </Badge>
              <Switch
                id="delayedJs"
                checked={settings.delayedJs}
                onCheckedChange={() => handleToggle('delayedJs')}
              />
            </div>
          </div>

          {settings.delayedJs && (
            <div className="p-4 bg-blue-50 rounded-lg">
              <Label htmlFor="delayedJsTimeout" className="font-medium">
                Timpul de întârziere (ms)
              </Label>
              <p className="text-sm text-gray-500 mb-3">
                Câte milisecunde să aștepte înainte de a încărca JavaScript-ul
              </p>
              <Input
                id="delayedJsTimeout"
                type="number"
                min={0}
                max={10000}
                value={settings.delayedJsTimeout}
                onChange={(e) => setSettings(prev => ({
                  ...prev,
                  delayedJsTimeout: parseInt(e.target.value) || 2000
                }))}
                className="max-w-xs"
              />
              <p className="text-xs text-gray-400 mt-2">
                Recomandat: 2000-5000ms pentru echilibru între performanță și funcționalitate
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Lazy Load Images */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <Image className="h-5 w-5 text-green-500" />
            <CardTitle>Lazy Loading Imagini</CardTitle>
          </div>
          <CardDescription>
            Încarcă imaginile doar când sunt vizibile în viewport pentru încărcare mai rapidă
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div className="flex items-center gap-3">
              <Image className="h-5 w-5 text-blue-500" />
              <div>
                <Label htmlFor="lazyLoadImages" className="font-medium">Activează Lazy Loading</Label>
                <p className="text-sm text-gray-500">Încarcă imaginile la scroll, nu la încărcarea paginii</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant={settings.lazyLoadImages ? "default" : "secondary"}>
                {settings.lazyLoadImages ? 'Activat' : 'Dezactivat'}
              </Badge>
              <Switch
                id="lazyLoadImages"
                checked={settings.lazyLoadImages}
                onCheckedChange={() => handleToggle('lazyLoadImages')}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Reduce JS Execution */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <Gauge className="h-5 w-5 text-red-500" />
            <CardTitle>Reducere Timp Execuție JavaScript</CardTitle>
          </div>
          <CardDescription>
            Optimizează execuția JavaScript pentru performanță mai bună
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div className="flex items-center gap-3">
              <Gauge className="h-5 w-5 text-orange-500" />
              <div>
                <Label htmlFor="reduceJsExecution" className="font-medium">Reduce Execuția JS</Label>
                <p className="text-sm text-gray-500">Optimizează și amână scripturile non-critice</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant={settings.reduceJsExecution ? "default" : "secondary"}>
                {settings.reduceJsExecution ? 'Activat' : 'Dezactivat'}
              </Badge>
              <Switch
                id="reduceJsExecution"
                checked={settings.reduceJsExecution}
                onCheckedChange={() => handleToggle('reduceJsExecution')}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Info Card */}
      <Card className="bg-blue-50 border-blue-200">
        <CardContent className="pt-6">
          <div className="flex gap-3">
            <Zap className="h-5 w-5 text-blue-500 flex-shrink-0 mt-0.5" />
            <div>
              <h3 className="font-medium text-blue-900">Despre optimizările de performanță</h3>
              <ul className="text-sm text-blue-700 mt-2 space-y-1">
                <li>• <strong>Minificare:</strong> Reduce dimensiunea fișierelor cu 20-60%</li>
                <li>• <strong>JS Diferit:</strong> Îmbunătățește scorul Core Web Vitals</li>
                <li>• Setările se aplică automat după salvare</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}