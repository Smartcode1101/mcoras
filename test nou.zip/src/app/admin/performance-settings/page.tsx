import PerformanceSettingsClient from './PerformanceSettingsClient';

export default function PerformanceSettingsPage() {
  return <PerformanceSettingsClient />;
}
