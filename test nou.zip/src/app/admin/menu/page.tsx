import { getPages } from '@/lib/page-data';
import Head from 'next/head';
import { getSiteSettings } from '@/lib/settings-data';
import { MenuClient } from './MenuClient';
import fs from 'fs';
import path from 'path';
import type { Category } from '@/lib/types';

export const dynamic = 'force-dynamic';

async function getCategories(): Promise<Category[]> {
    try {
        const categoriesPath = path.join(process.cwd(), 'db', 'categories.json');
        const data = await fs.promises.readFile(categoriesPath, 'utf-8');
        return JSON.parse(data);
    } catch {
        return [];
    }
}

export default async function MenuSettingsPage() {
    const pages = await getPages();
    const settings = await getSiteSettings();
    const categories = await getCategories();

    return (
        <>
            <Head>
                <title>Setări Meniu - One Smart</title>
                <meta name="description" content="Configurează meniul principal și logo-ul site-ului One Smart" />
            </Head>
            <div className="p-4 md:p-8">
            <div className="mb-6">
                <h1 className="text-xl md:text-3xl font-bold">Gestionează Meniul Principal</h1>
                <p className="text-muted-foreground mt-1 text-sm md:text-base">
                    Setează logo-ul site-ului și configurează meniul de navigare.
                </p>
            </div>
            <MenuClient initialSettings={settings} allPages={pages} allCategories={categories} />
        </div>
        </>
    )
}
