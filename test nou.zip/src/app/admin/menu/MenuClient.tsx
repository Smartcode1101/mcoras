'use client';
import { useState, useEffect } from 'react';
import type { SiteSettings, PageData, MenuItem, Category } from '@/lib/types';
import { useToast } from '@/hooks/use-toast';
import { saveSiteSettingsAction } from '@/lib/actions';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import { GripVertical, PlusCircle, Trash2, Loader2, FileText, FolderOpen, ChevronDown, ChevronRight, Menu } from 'lucide-react';

type MenuPage = Pick<PageData, 'id' | 'title'>;
type MenuCategory = Pick<Category, 'id' | 'name' | 'slug'>;

type EditableMenuItem = { 
    id: string; 
    type: 'page' | 'category' | 'submenu'; 
    title: string; 
    customTitle: string;
    children?: EditableMenuItem[];
};

export function MenuClient({ initialSettings, allPages, allCategories }: { initialSettings: SiteSettings; allPages: PageData[]; allCategories: Category[] }) {
    const [settings, setSettings] = useState<SiteSettings>(initialSettings);
    const [isSaving, setIsSaving] = useState(false);
    const { toast } = useToast();

    const [menuItems, setMenuItems] = useState<EditableMenuItem[]>([]);
    const [availablePages, setAvailablePages] = useState<MenuPage[]>([]);
    const [availableCategories, setAvailableCategories] = useState<MenuCategory[]>([]);
    const [expandedSubmenus, setExpandedSubmenus] = useState<Set<string>>(new Set());
    
    useEffect(() => {
        const convertToEditable = (items: MenuItem[]): EditableMenuItem[] => {
            return items.map((item, index) => {
                if (item.pageId) {
                    const page = allPages.find(p => p.id === item.pageId);
                    if (!page) return null;
                    return { 
                        id: `page-${page.id}-${index}`, 
                        type: 'page' as const, 
                        title: page.title, 
                        customTitle: item.title || page.title 
                    };
                }
                if (item.categoryId) {
                    const category = allCategories.find(c => c.id === item.categoryId);
                    if (!category) return null;
                    return { 
                        id: `category-${category.id}-${index}`, 
                        type: 'category' as const, 
                        title: category.name, 
                        customTitle: item.title || category.name 
                    };
                }
                // Submenu - check for isSubmenu flag or children
                if (item.isSubmenu || item.children) {
                    return {
                        id: `submenu-${Date.now()}-${index}`,
                        type: 'submenu' as const,
                        title: item.title || 'Submeniu',
                        customTitle: item.title || 'Submeniu',
                        children: item.children ? convertToEditable(item.children) : []
                    };
                }
                return null;
            }).filter(Boolean) as EditableMenuItem[];
        };

        const initialMenuItems = convertToEditable(initialSettings.menu.items);
        setMenuItems(initialMenuItems);

        const pageIdsInMenu = new Set<string>();
        const categoryIdsInMenu = new Set<string>();
        
        const collectIds = (items: MenuItem[]) => {
            items.forEach(item => {
                if (item.pageId) pageIdsInMenu.add(item.pageId);
                if (item.categoryId) categoryIdsInMenu.add(item.categoryId);
                if (item.children) collectIds(item.children);
            });
        };
        collectIds(initialSettings.menu.items);

        const available = allPages.filter(p => !pageIdsInMenu.has(p.id));
        setAvailablePages(available.map(({ id, title }) => ({ id, title })));

        const availableCats = allCategories.filter(c => !categoryIdsInMenu.has(c.id));
        setAvailableCategories(availableCats.map(({ id, name, slug }) => ({ id, name, slug })));

    }, [initialSettings, allPages, allCategories]);
    
    const convertToSettings = (items: EditableMenuItem[]): MenuItem[] => {
        return items.map(item => {
            if (item.type === 'page') {
                const pageId = item.id.replace(/^page-/, '').replace(/-\d+$/, '');
                return { pageId, title: item.customTitle };
            }
            if (item.type === 'category') {
                const categoryId = item.id.replace(/^category-/, '').replace(/-\d+$/, '');
                return { categoryId, title: item.customTitle };
            }
            if (item.type === 'submenu') {
                return { 
                    isSubmenu: true,
                    title: item.customTitle, 
                    children: item.children ? convertToSettings(item.children) : [] 
                };
            }
            return {};
        });
    };

    useEffect(() => {
        const newItems = convertToSettings(menuItems);
        setSettings(s => ({...s, menu: {...s.menu, items: newItems}}));
    }, [menuItems]);

    const handleSave = async () => {
        setIsSaving(true);
        const result = await saveSiteSettingsAction(settings);
        if (result.error) {
            toast({ variant: 'destructive', title: 'Eroare', description: result.error });
        } else {
            toast({ title: 'Succes!', description: 'Setările meniului au fost salvate.' });
        }
        setIsSaving(false);
    };
    
    const handleMenuItemTitleChange = (id: string, newTitle: string) => {
        const updateTitle = (items: EditableMenuItem[]): EditableMenuItem[] => {
            return items.map(item => {
                if (item.id === id) {
                    return { ...item, customTitle: newTitle };
                }
                if (item.children) {
                    return { ...item, children: updateTitle(item.children) };
                }
                return item;
            });
        };
        setMenuItems(updateTitle(menuItems));
    };

    const toggleSubmenu = (id: string) => {
        setExpandedSubmenus(prev => {
            const newSet = new Set(prev);
            if (newSet.has(id)) {
                newSet.delete(id);
            } else {
                newSet.add(id);
            }
            return newSet;
        });
    };

    const createSubmenu = () => {
        const newSubmenu: EditableMenuItem = {
            id: `submenu-${Date.now()}`,
            type: 'submenu',
            title: 'Submeniu nou',
            customTitle: 'Submeniu nou',
            children: []
        };
        setMenuItems([...menuItems, newSubmenu]);
        setExpandedSubmenus(prev => new Set([...prev, newSubmenu.id]));
    };

    const handleDragEnd = (result: any) => {
        if (!result.destination) return;

        const { source, destination } = result;

        // Handle reordering within menu items
        if (source.droppableId === 'menuItems' && destination.droppableId === 'menuItems') {
            const items = Array.from(menuItems);
            const [reorderedItem] = items.splice(source.index, 1);
            items.splice(destination.index, 0, reorderedItem);
            setMenuItems(items);
        }
        // Add page to menu
        else if (source.droppableId === 'availablePages' && destination.droppableId === 'menuItems') {
            const sourceClone = Array.from(availablePages);
            const destClone = Array.from(menuItems);
            const [movedItem] = sourceClone.splice(source.index, 1);
            
            const newMenuItem: EditableMenuItem = { 
                id: `page-${movedItem.id}-${Date.now()}`, 
                type: 'page', 
                title: movedItem.title, 
                customTitle: movedItem.title 
            };
            destClone.splice(destination.index, 0, newMenuItem);

            setAvailablePages(sourceClone);
            setMenuItems(destClone);
        }
        // Add category to menu
        else if (source.droppableId === 'availableCategories' && destination.droppableId === 'menuItems') {
            const sourceClone = Array.from(availableCategories);
            const destClone = Array.from(menuItems);
            const [movedItem] = sourceClone.splice(source.index, 1);
            
            const newMenuItem: EditableMenuItem = { 
                id: `category-${movedItem.id}-${Date.now()}`, 
                type: 'category', 
                title: movedItem.name, 
                customTitle: movedItem.name 
            };
            destClone.splice(destination.index, 0, newMenuItem);

            setAvailableCategories(sourceClone);
            setMenuItems(destClone);
        }
        // Add to submenu
        else if (destination.droppableId.startsWith('submenu-')) {
            const submenuId = destination.droppableId;
            
            // Move from menu items to submenu
            if (source.droppableId === 'menuItems') {
                const items = Array.from(menuItems);
                const [movedItem] = items.splice(source.index, 1);
                
                const addToSubmenu = (itemsList: EditableMenuItem[]): EditableMenuItem[] => {
                    return itemsList.map(item => {
                        if (item.id === submenuId) {
                            const newChildren = [...(item.children || [])];
                            newChildren.splice(destination.index, 0, movedItem);
                            return { ...item, children: newChildren };
                        }
                        if (item.children) {
                            return { ...item, children: addToSubmenu(item.children) };
                        }
                        return item;
                    });
                };
                
                setMenuItems(addToSubmenu(items));
            }
            // Move from available pages/categories to submenu
            else {
                const addToSubmenu = (items: EditableMenuItem[]): EditableMenuItem[] => {
                    return items.map(item => {
                        if (item.id === submenuId) {
                            let newChild: EditableMenuItem;
                            
                            if (source.droppableId === 'availablePages') {
                                const [movedItem] = availablePages.splice(source.index, 1);
                                newChild = { 
                                    id: `page-${movedItem.id}-${Date.now()}`, 
                                    type: 'page', 
                                    title: movedItem.title, 
                                    customTitle: movedItem.title 
                                };
                                setAvailablePages([...availablePages]);
                            } else if (source.droppableId === 'availableCategories') {
                                const [movedItem] = availableCategories.splice(source.index, 1);
                                newChild = { 
                                    id: `category-${movedItem.id}-${Date.now()}`, 
                                    type: 'category', 
                                    title: movedItem.name, 
                                    customTitle: movedItem.name 
                                };
                                setAvailableCategories([...availableCategories]);
                            } else {
                                return item;
                            }
                            
                            return { 
                                ...item, 
                                children: [...(item.children || []), newChild] 
                            };
                        }
                        if (item.children) {
                            return { ...item, children: addToSubmenu(item.children) };
                        }
                        return item;
                    });
                };
                
                setMenuItems(addToSubmenu(menuItems));
            }
        }
        // Reorder within submenu
        else if (source.droppableId.startsWith('submenu-') && destination.droppableId.startsWith('submenu-')) {
            const sourceSubmenuId = source.droppableId;
            const destSubmenuId = destination.droppableId;
            
            let movedItem: EditableMenuItem | null = null;
            
            // Find and remove from source submenu
            const removeFromSubmenu = (items: EditableMenuItem[]): EditableMenuItem[] => {
                return items.map(item => {
                    if (item.id === sourceSubmenuId && item.children) {
                        const children = [...item.children];
                        [movedItem] = children.splice(source.index, 1);
                        return { ...item, children };
                    }
                    if (item.children) {
                        return { ...item, children: removeFromSubmenu(item.children) };
                    }
                    return item;
                });
            };
            
            let newItems = removeFromSubmenu(menuItems);
            
            if (movedItem) {
                // Add to destination submenu
                const addToSubmenu = (items: EditableMenuItem[]): EditableMenuItem[] => {
                    return items.map(item => {
                        if (item.id === destSubmenuId) {
                            const children = [...(item.children || [])];
                            children.splice(destination.index, 0, movedItem!);
                            return { ...item, children };
                        }
                        if (item.children) {
                            return { ...item, children: addToSubmenu(item.children) };
                        }
                        return item;
                    });
                };
                
                newItems = addToSubmenu(newItems);
                setMenuItems(newItems);
            }
        }
        // Move from submenu back to main menu
        else if (source.droppableId.startsWith('submenu-') && destination.droppableId === 'menuItems') {
            let movedItem: EditableMenuItem | null = null;
            
            const removeFromSubmenu = (items: EditableMenuItem[]): EditableMenuItem[] => {
                return items.map(item => {
                    if (item.id === source.droppableId && item.children) {
                        const children = [...item.children];
                        [movedItem] = children.splice(source.index, 1);
                        return { ...item, children };
                    }
                    if (item.children) {
                        return { ...item, children: removeFromSubmenu(item.children) };
                    }
                    return item;
                });
            };
            
            const newItems = removeFromSubmenu(menuItems);
            
            if (movedItem) {
                const destItems = [...newItems];
                destItems.splice(destination.index, 0, movedItem);
                setMenuItems(destItems);
            }
        }
    };
    
    const removeFromMenu = (itemId: string) => {
        const removeItem = (items: EditableMenuItem[]): EditableMenuItem[] => {
            return items.filter(item => {
                if (item.id === itemId) {
                    // Return page/category to available lists
                    if (item.type === 'page') {
                        const pageId = item.id.replace(/^page-/, '').replace(/-\d+$/, '');
                        setAvailablePages(prev => [...prev, { id: pageId, title: item.title }]);
                    } else if (item.type === 'category') {
                        const categoryId = item.id.replace(/^category-/, '').replace(/-\d+$/, '');
                        setAvailableCategories(prev => [...prev, { id: categoryId, name: item.title, slug: item.title.toLowerCase() }]);
                    }
                    return false;
                }
                if (item.children) {
                    item.children = removeItem(item.children);
                }
                return true;
            });
        };
        setMenuItems(removeItem(menuItems));
    };

    const addPageToMenu = (page: MenuPage) => {
        setMenuItems([...menuItems, { 
            id: `page-${page.id}-${Date.now()}`, 
            type: 'page', 
            title: page.title, 
            customTitle: page.title 
        }]);
        setAvailablePages(availablePages.filter(p => p.id !== page.id));
    };

    const addCategoryToMenu = (category: MenuCategory) => {
        setMenuItems([...menuItems, { 
            id: `category-${category.id}-${Date.now()}`, 
            type: 'category', 
            title: category.name, 
            customTitle: category.name 
        }]);
        setAvailableCategories(availableCategories.filter(c => c.id !== category.id));
    };

    const renderMenuItem = (item: EditableMenuItem, index: number, isChild = false) => {
        const isExpanded = expandedSubmenus.has(item.id);
        const isSubmenu = item.type === 'submenu';

        return (
            <Draggable key={item.id} draggableId={item.id} index={index}>
                {(provided) => (
                    <div
                        ref={provided.innerRef}
                        {...provided.draggableProps}
                        className={`p-2 mb-2 bg-card border rounded-md ${isChild ? 'ml-4 bg-muted/50' : ''}`}
                    >
                        <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2" {...provided.dragHandleProps}>
                                <GripVertical className="h-5 w-5 text-muted-foreground" />
                                {item.type === 'page' && <FileText className="h-4 w-4 text-blue-500" />}
                                {item.type === 'category' && <FolderOpen className="h-4 w-4 text-green-500" />}
                                {item.type === 'submenu' && <Menu className="h-4 w-4 text-purple-500" />}
                                <span className="font-medium">{item.title}</span>
                                <span className="text-xs text-muted-foreground">
                                    ({item.type === 'page' ? 'Pagină' : item.type === 'category' ? 'Categorie' : 'Submeniu'})
                                </span>
                            </div>
                            <div className="flex items-center gap-1">
                                {isSubmenu && (
                                    <Button variant="ghost" size="sm" onClick={() => toggleSubmenu(item.id)}>
                                        {isExpanded ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
                                    </Button>
                                )}
                                <Button variant="ghost" size="sm" onClick={() => removeFromMenu(item.id)}>
                                    <Trash2 className="h-4 w-4" />
                                </Button>
                            </div>
                        </div>
                        <div className="mt-2 pl-7">
                            <Label className="text-xs text-muted-foreground">Nume afișat în meniu</Label>
                            <Input
                                value={item.customTitle}
                                onChange={(e) => handleMenuItemTitleChange(item.id, e.target.value)}
                                className="mt-1 h-8"
                            />
                        </div>
                        {isSubmenu && isExpanded && (
                            <div className="mt-3 pl-4 border-l-2 border-purple-300">
                                <Droppable droppableId={item.id}>
                                    {(provided, snapshot) => (
                                        <div
                                            ref={provided.innerRef}
                                            {...provided.droppableProps}
                                            className={`p-2 rounded-lg border-2 min-h-[60px] transition-colors ${snapshot.isDraggingOver ? 'border-primary bg-primary/10' : 'border-dashed'}`}
                                        >
                                            {(!item.children || item.children.length === 0) && (
                                                <p className="text-sm text-muted-foreground text-center py-2">
                                                    Trage pagini sau categorii aici
                                                </p>
                                            )}
                                            {item.children?.map((child, childIndex) => renderMenuItem(child, childIndex, true))}
                                            {provided.placeholder}
                                        </div>
                                    )}
                                </Droppable>
                            </div>
                        )}
                    </div>
                )}
            </Draggable>
        );
    };

    return (
        <DragDropContext onDragEnd={handleDragEnd}>
            <div className="grid gap-6">
                 <Card>
                     <CardHeader>
                         <CardTitle>Setări Generale</CardTitle>
                         <CardDescription>Configurează logo-ul și alinierea meniului.</CardDescription>
                     </CardHeader>
                     <CardContent className="space-y-6">
                         <div className="space-y-2">
                             <Label htmlFor="logo-url">URL Logo</Label>
                             <Input
                                 id="logo-url"
                                 placeholder="https://exemplu.com/logo.png"
                                 value={settings.logoUrl}
                                 onChange={(e) => setSettings({ ...settings, logoUrl: e.target.value })}
                             />
                             <p className="text-sm text-muted-foreground">Lăsați gol pentru a afișa numele site-ului.</p>
                         </div>
                         <div className="space-y-2">
                             <Label>Aliniere Meniu</Label>
                             <RadioGroup
                                 value={settings.menu.alignment}
                                 onValueChange={(val: 'left' | 'center' | 'right') => setSettings({ ...settings, menu: { ...settings.menu, alignment: val } })}
                                 className="flex space-x-4"
                             >
                                 <div className="flex items-center space-x-2">
                                     <RadioGroupItem value="left" id="align-left" />
                                     <Label htmlFor="align-left">Stânga</Label>
                                 </div>
                                 <div className="flex items-center space-x-2">
                                     <RadioGroupItem value="center" id="align-center" />
                                     <Label htmlFor="align-center">Centru</Label>
                                 </div>
                                 <div className="flex items-center space-x-2">
                                     <RadioGroupItem value="right" id="align-right" />
                                     <Label htmlFor="align-right">Dreapta</Label>
                                 </div>
                             </RadioGroup>
                         </div>
                     </CardContent>
                 </Card>

                <Separator />

                <div className="grid md:grid-cols-2 gap-6">
                    <Card>
                        <CardHeader>
                            <CardTitle>Elemente Meniu</CardTitle>
                            <CardDescription>Trageți paginile și categoriile aici pentru a le adăuga în meniu.</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <div className="mb-4">
                                <Button onClick={createSubmenu} variant="outline" className="w-full">
                                    <PlusCircle className="h-4 w-4 mr-2" />
                                    Creează Submeniu
                                </Button>
                            </div>
                            <Droppable droppableId="menuItems">
                                {(provided, snapshot) => (
                                    <div
                                        ref={provided.innerRef}
                                        {...provided.droppableProps}
                                        className={`p-2 rounded-lg border-2 min-h-[200px] transition-colors ${snapshot.isDraggingOver ? 'border-primary bg-primary/10' : 'border-dashed'}`}
                                    >
                                        {menuItems.length === 0 && (
                                            <p className="text-sm text-muted-foreground text-center py-10">Meniul este gol.</p>
                                        )}
                                        {menuItems.map((item, index) => renderMenuItem(item, index))}
                                        {provided.placeholder}
                                    </div>
                                )}
                            </Droppable>
                        </CardContent>
                    </Card>
                    <Card>
                        <CardHeader>
                            <CardTitle>Elemente Disponibile</CardTitle>
                            <CardDescription>Trageți de aici în stânga pentru a adăuga în meniu.</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <Tabs defaultValue="pages">
                                <TabsList className="mb-4">
                                    <TabsTrigger value="pages" className="flex items-center gap-1">
                                        <FileText className="h-4 w-4" />
                                        Pagini
                                    </TabsTrigger>
                                    <TabsTrigger value="categories" className="flex items-center gap-1">
                                        <FolderOpen className="h-4 w-4" />
                                        Categorii
                                    </TabsTrigger>
                                </TabsList>
                                <TabsContent value="pages">
                                    <Droppable droppableId="availablePages">
                                        {(provided, snapshot) => (
                                            <div
                                                ref={provided.innerRef}
                                                {...provided.droppableProps}
                                                className={`p-2 rounded-lg border-2 min-h-[150px] transition-colors ${snapshot.isDraggingOver ? 'border-primary bg-primary/10' : 'border-dashed'}`}
                                            >
                                                {availablePages.length === 0 && (
                                                    <p className="text-sm text-muted-foreground text-center py-8">Toate paginile sunt în meniu.</p>
                                                )}
                                                {availablePages.map((page, index) => (
                                                    <Draggable key={`avail-page-${page.id}`} draggableId={`page-${page.id}`} index={index}>
                                                        {(provided) => (
                                                            <div
                                                                ref={provided.innerRef}
                                                                {...provided.draggableProps}
                                                                {...provided.dragHandleProps}
                                                                className="flex items-center justify-between p-2 mb-2 bg-card border rounded-md"
                                                            >
                                                                <div className="flex items-center gap-2">
                                                                    <GripVertical className="h-5 w-5 text-muted-foreground" />
                                                                    <FileText className="h-4 w-4 text-blue-500" />
                                                                    <span>{page.title}</span>
                                                                </div>
                                                                <Button variant="ghost" size="sm" onClick={() => addPageToMenu(page)}>
                                                                    <PlusCircle className="h-4 w-4" />
                                                                </Button>
                                                            </div>
                                                        )}
                                                    </Draggable>
                                                ))}
                                                {provided.placeholder}
                                            </div>
                                        )}
                                    </Droppable>
                                </TabsContent>
                                <TabsContent value="categories">
                                    <Droppable droppableId="availableCategories">
                                        {(provided, snapshot) => (
                                            <div
                                                ref={provided.innerRef}
                                                {...provided.droppableProps}
                                                className={`p-2 rounded-lg border-2 min-h-[150px] transition-colors ${snapshot.isDraggingOver ? 'border-primary bg-primary/10' : 'border-dashed'}`}
                                            >
                                                {availableCategories.length === 0 && (
                                                    <p className="text-sm text-muted-foreground text-center py-8">Toate categoriile sunt în meniu.</p>
                                                )}
                                                {availableCategories.map((category, index) => (
                                                    <Draggable key={`avail-cat-${category.id}`} draggableId={`category-${category.id}`} index={index}>
                                                        {(provided) => (
                                                            <div
                                                                ref={provided.innerRef}
                                                                {...provided.draggableProps}
                                                                {...provided.dragHandleProps}
                                                                className="flex items-center justify-between p-2 mb-2 bg-card border rounded-md"
                                                            >
                                                                <div className="flex items-center gap-2">
                                                                    <GripVertical className="h-5 w-5 text-muted-foreground" />
                                                                    <FolderOpen className="h-4 w-4 text-green-500" />
                                                                    <span>{category.name}</span>
                                                                </div>
                                                                <Button variant="ghost" size="sm" onClick={() => addCategoryToMenu(category)}>
                                                                    <PlusCircle className="h-4 w-4" />
                                                                </Button>
                                                            </div>
                                                        )}
                                                    </Draggable>
                                                ))}
                                                {provided.placeholder}
                                            </div>
                                        )}
                                    </Droppable>
                                </TabsContent>
                            </Tabs>
                        </CardContent>
                    </Card>
                </div>

                <div className="flex justify-end">
                    <Button onClick={handleSave} disabled={isSaving}>
                        {isSaving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                        Salvează Setările
                    </Button>
                </div>
            </div>
        </DragDropContext>
    );
}
