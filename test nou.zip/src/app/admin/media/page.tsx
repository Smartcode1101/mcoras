'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/contexts/auth-context';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Trash2, Upload, Image as ImageIcon, AlertCircle } from 'lucide-react';
import Link from 'next/link';
import Head from 'next/head';

interface MediaItem {
  id: string;
  src: string;
  alt: string;
  filename: string;
  createdAt: string;
}

export default function MediaManagement() {
  const { user, isLoading } = useAuth();
  const router = useRouter();
  const [mediaItems, setMediaItems] = useState<MediaItem[]>([]);
  const [isLoadingMedia, setIsLoadingMedia] = useState(true);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!isLoading && !user) {
      router.push('/auth/login?redirect=/admin/media');
    }
  }, [user, isLoading, router]);

  useEffect(() => {
    if (user) {
      fetchMediaItems();
    }
  }, [user]);

  const fetchMediaItems = async () => {
    try {
      setIsLoadingMedia(true);
      setError(null);
      const response = await fetch('/api/admin/media');
      const data = await response.json();
      
      if (data.success) {
        setMediaItems(data.data);
      } else {
        setError('Failed to fetch media items');
      }
    } catch (error) {
      console.error('Error fetching media:', error);
      setError('Failed to fetch media items');
    } finally {
      setIsLoadingMedia(false);
    }
  };

  const handleDelete = async (id: string, filename: string) => {
    if (!confirm(`Sigur doriți să ștergeți imaginea "${filename}"?`)) {
      return;
    }

    try {
      setDeletingId(id);
      console.log('Attempting to delete media with ID:', id);
      
      const response = await fetch(`/api/admin/media/${id}`, {
        method: 'DELETE',
      });
      
      console.log('Response status:', response.status);
      const data = await response.json();
      console.log('Response data:', data);
      
      if (data.success) {
        setMediaItems(items => items.filter(item => item.id !== id));
        console.log('Media item deleted successfully');
      } else {
        alert('Eroare la ștergerea imaginii: ' + data.error);
      }
    } catch (error) {
      console.error('Error deleting media:', error);
      alert('Eroare la ștergerea imaginii');
    } finally {
      setDeletingId(null);
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('ro-RO', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!user) {
    return null; // Will redirect
  }

  return (
    <>
      <Head>
        <title>Media Management - One Smart Admin</title>
        <meta name="description" content="Gestionează galeria media și imaginile încărcate" />
      </Head>
      
      <div className="p-4 md:p-8">
        <div className="mb-6 md:mb-8">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-4">
            <div>
              <h1 className="text-xl md:text-3xl font-bold mb-2">Galerie Media</h1>
              <p className="text-muted-foreground text-sm md:text-base">
                Gestionează imaginile și fișierele încărcate pe site
              </p>
            </div>
            <Link href="/admin/media/upload" className="w-full sm:w-auto">
              <Button className="w-full sm:w-auto">
                <Upload className="w-4 h-4 mr-2" />
                Încărcare
              </Button>
            </Link>
          </div>
        </div>

        {error && (
          <Card className="mb-6 border-destructive">
            <CardContent className="pt-6">
              <div className="flex items-center space-x-2 text-destructive">
                <AlertCircle className="w-5 h-5" />
                <span>{error}</span>
              </div>
            </CardContent>
          </Card>
        )}

        {isLoadingMedia ? (
          <div className="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 md:gap-6">
            {[...Array(8)].map((_, i) => (
              <Card key={i} className="animate-pulse">
                <div className="aspect-square bg-muted"></div>
                <CardContent className="p-4">
                  <div className="h-4 bg-muted rounded mb-2"></div>
                  <div className="h-3 bg-muted rounded w-2/3"></div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : mediaItems.length === 0 ? (
          <Card>
            <CardContent className="pt-6">
              <div className="text-center py-8 md:py-12">
                <ImageIcon className="w-12 h-12 md:w-16 md:h-16 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">Nu există imagini încărcate</h3>
                <p className="text-muted-foreground mb-4 text-sm md:text-base">
                  Încărcați prima imagine pentru a începe să vă gestionați galeria media
                </p>
                <Link href="/admin/media/upload">
                  <Button>
                    <Upload className="w-4 h-4 mr-2" />
                    Încărcare Fișiere
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        ) : (
          <>
            <div className="mb-4 text-sm text-muted-foreground">
              {mediaItems.length} {mediaItems.length === 1 ? 'imagine găsită' : 'imagini găsite'}
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 md:gap-6">
              {mediaItems.map((item) => (
                <Card key={item.id} className="group hover:shadow-lg transition-shadow">
                  <div className="aspect-square relative overflow-hidden rounded-t-lg">
                    <img
                      src={item.src}
                      alt={item.alt}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                      loading="lazy"
                    />
                    <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 transition-all duration-200 flex items-center justify-center">
                      <Button
                        variant="destructive"
                        size="sm"
                        className="opacity-0 group-hover:opacity-100 transition-opacity duration-200"
                        onClick={() => handleDelete(item.id, item.filename)}
                        disabled={deletingId === item.id}
                      >
                        {deletingId === item.id ? (
                          <div className="w-4 h-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
                        ) : (
                          <Trash2 className="w-4 h-4" />
                        )}
                      </Button>
                    </div>
                  </div>
                  <CardContent className="p-4">
                    <CardTitle className="text-sm font-medium truncate mb-1">
                      {item.filename}
                    </CardTitle>
                    <CardDescription className="text-xs">
                      {formatDate(item.createdAt)}
                    </CardDescription>
                    <div className="mt-2 text-xs text-muted-foreground break-all">
                      {item.src}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </>
        )}
      </div>
    </>
  );
}