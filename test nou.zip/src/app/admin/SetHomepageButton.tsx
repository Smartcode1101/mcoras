'use client';

import { Button } from '@/components/ui/button';
import { setHomepageAction } from '@/lib/actions';
import { useToast } from '@/hooks/use-toast';
import { Star } from 'lucide-react';
import { useTransition } from 'react';

export function SetHomepageButton({ pageId, isHomepage }: { pageId: string, isHomepage: boolean }) {
  const { toast } = useToast();
  const [isPending, startTransition] = useTransition();

  const handleSetHome = () => {
    startTransition(async () => {
      const result = await setHomepageAction(pageId);
      if (result.error) {
        toast({
          variant: 'destructive',
          title: 'Eroare',
          description: result.error,
        });
      } else {
        toast({
          title: 'Succes',
          description: 'Pagina principală a fost actualizată.',
        });
      }
    });
  };

  return (
    <Button
      variant="ghost"
      size="sm"
      disabled={isPending || isHomepage}
      onClick={handleSetHome}
      aria-label="Setează ca pagină principală"
    >
      <Star className={`h-4 w-4 ${isHomepage ? 'text-yellow-400 fill-current' : ''}`} />
    </Button>
  );
}
