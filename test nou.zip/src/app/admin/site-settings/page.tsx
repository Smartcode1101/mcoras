import { getSiteSettings } from '@/lib/settings-data';
import Head from 'next/head';
import { SiteSettingsClient } from './SiteSettingsClient';

export const dynamic = 'force-dynamic';

export default async function SiteSettingsPage() {
    const settings = await getSiteSettings();

    return (
        <>
            <Head>
                <title>Setări Site - One Smart</title>
                <meta name="description" content="Configurează setările generale ale site-ului One Smart" />
            </Head>
            <div className="p-4 md:p-8">
            <div className="mb-6">
                <h1 className="text-xl md:text-3xl font-bold">Setări Site</h1>
                <p className="text-muted-foreground mt-1 text-sm md:text-base">
                    Configurează setările generale ale site-ului.
                </p>
            </div>
            <SiteSettingsClient initialSettings={settings} />
        </div>
        </>
    )
}
