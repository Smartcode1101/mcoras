'use client';
import { useState } from 'react';
import type { SiteSettings } from '@/lib/types';
import { useToast } from '@/hooks/use-toast';
import { saveSiteSettingsAction } from '@/lib/actions';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { Loader2 } from 'lucide-react';

// Helper to convert hex and opacity to rgba
const hexToRgba = (hex: string, opacity: number) => {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    if (!result) return `rgba(0,0,0,${opacity})`;
    const r = parseInt(result[1], 16);
    const g = parseInt(result[2], 16);
    const b = parseInt(result[3], 16);
    return `rgba(${r}, ${g}, ${b}, ${opacity})`;
};

// Helper to parse rgba to hex and opacity
const rgbaToHexOpacity = (rgba: string) => {
    const match = rgba.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?\)/);
    if (!match) return { hex: '#000000', opacity: 0.3 };
    const r = parseInt(match[1]).toString(16).padStart(2, '0');
    const g = parseInt(match[2]).toString(16).padStart(2, '0');
    const b = parseInt(match[3]).toString(16).padStart(2, '0');
    return {
        hex: `#${r}${g}${b}`,
        opacity: match[4] !== undefined ? parseFloat(match[4]) : 1,
    };
};

export default function FooterSettingsClient({ initialSettings }: { initialSettings: SiteSettings }) {
    const [settings, setSettings] = useState<SiteSettings>(initialSettings);
    const [isSaving, setIsSaving] = useState(false);
    const { toast } = useToast();

    const handleSave = async () => {
        setIsSaving(true);
        const result = await saveSiteSettingsAction(settings);
        if (result.error) {
            toast({ variant: 'destructive', title: 'Eroare', description: result.error });
        } else {
            toast({ title: 'Succes!', description: 'Setările footer-ului au fost salvate.' });
        }
        setIsSaving(false);
    };

    const handleFooterStyleChange = (prop: keyof SiteSettings['footerSettings'], value: any) => {
        setSettings(s => ({
            ...s,
            footerSettings: {
                ...s.footerSettings,
                [prop]: value,
            }
        }));
    };

    const bgColor = rgbaToHexOpacity(settings.footerSettings.backgroundColor);
    const borderColor = rgbaToHexOpacity(settings.footerSettings.borderColor);

    return (
        <div className="grid gap-6">
            <Card>
                <CardHeader>
                    <CardTitle>Stil Footer</CardTitle>
                    <CardDescription>Personalizează aspectul footer-ului.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div>
                        <Label>Culoare Fundal & Opacitate</Label>
                        <div className="flex items-center gap-2 mt-1">
                            <input
                                type="color"
                                value={bgColor.hex}
                                onChange={(e) => handleFooterStyleChange('backgroundColor', hexToRgba(e.target.value, bgColor.opacity))}
                                className="w-10 h-10 p-1 border rounded"
                            />
                            <Slider
                                min={0} max={1} step={0.01}
                                value={[bgColor.opacity]}
                                onValueChange={(v) => handleFooterStyleChange('backgroundColor', hexToRgba(bgColor.hex, v[0]))}
                            />
                        </div>
                    </div>
                    <div>
                        <Label>Estompare Fundal (Blur)</Label>
                        <div className="flex items-center gap-2 mt-1">
                            <Slider
                                min={0} max={32} step={1}
                                value={[settings.footerSettings.backdropBlur]}
                                onValueChange={(v) => handleFooterStyleChange('backdropBlur', v[0])}
                            />
                            <span className="text-xs w-8 text-right">{settings.footerSettings.backdropBlur}px</span>
                        </div>
                    </div>
                    <div>
                        <Label>Culoare Bordură & Opacitate</Label>
                        <div className="flex items-center gap-2 mt-1">
                            <input
                                type="color"
                                value={borderColor.hex}
                                onChange={(e) => handleFooterStyleChange('borderColor', hexToRgba(e.target.value, borderColor.opacity))}
                                className="w-10 h-10 p-1 border rounded"
                            />
                            <Slider
                                min={0} max={1} step={0.01}
                                value={[borderColor.opacity]}
                                onValueChange={(v) => handleFooterStyleChange('borderColor', hexToRgba(borderColor.hex, v[0]))}
                            />
                        </div>
                    </div>
                    <div className="flex items-center space-x-2">
                        <Switch
                            id="show-copyright"
                            checked={settings.footerSettings.showCopyright}
                            onCheckedChange={(checked) => handleFooterStyleChange('showCopyright', checked)}
                        />
                        <Label htmlFor="show-copyright">Afișează copyright</Label>
                    </div>
                </CardContent>
            </Card>

            <div className="flex justify-end">
                <Button onClick={handleSave} disabled={isSaving}>
                    {isSaving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    Salvează Setările
                </Button>
            </div>
        </div>
    );
}