import { getSiteSettings } from '@/lib/settings-data';
import Head from 'next/head';
import FooterSettingsClient from './FooterSettingsClient';

export const dynamic = 'force-dynamic';

export default async function FooterSettingsPage() {
    const settings = await getSiteSettings();

    return (
        <>
            <Head>
                <title>Setări Footer - One Smart</title>
                <meta name="description" content="Personalizează aspectul footer-ului site-ului One Smart" />
            </Head>
            <div className="p-4 md:p-8">
            <div className="mb-6">
                <h1 className="text-xl md:text-3xl font-bold">Setări Footer</h1>
                <p className="text-muted-foreground mt-1 text-sm md:text-base">
                    Personalizează aspectul footer-ului site-ului.
                </p>
            </div>
            <FooterSettingsClient initialSettings={settings} />
        </div>
        </>
    )
}