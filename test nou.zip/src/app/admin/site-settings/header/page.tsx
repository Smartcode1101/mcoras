import { getSiteSettings } from '@/lib/settings-data';
import Head from 'next/head';
import { HeaderSettingsClient } from './HeaderSettingsClient';

export const dynamic = 'force-dynamic';

export default async function HeaderSettingsPage() {
    const settings = await getSiteSettings();

    return (
        <>
            <Head>
                <title>Setări Header - One Smart</title>
                <meta name="description" content="Personalizează aspectul header-ului site-ului One Smart" />
            </Head>
            <div className="p-4 md:p-8">
            <div className="mb-6">
                <h1 className="text-xl md:text-3xl font-bold">Setări Header</h1>
                <p className="text-muted-foreground mt-1 text-sm md:text-base">
                    Personalizează aspectul header-ului site-ului.
                </p>
            </div>
            <HeaderSettingsClient initialSettings={settings} />
        </div>
        </>
    )
}