'use client';
import { useState, useEffect } from 'react';
import type { SiteSettings } from '@/lib/types';
import { useToast } from '@/hooks/use-toast';
import { saveSiteSettingsAction } from '@/lib/actions';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { MediaSelector, type MediaItem } from '@/components/MediaSelector';
import { Loader2, Image as ImageIcon, Trash2 } from 'lucide-react';

// Helper to convert hex and opacity to rgba
const hexToRgba = (hex: string, opacity: number) => {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    if (!result) return `rgba(0,0,0,${opacity})`;
    const r = parseInt(result[1], 16);
    const g = parseInt(result[2], 16);
    const b = parseInt(result[3], 16);
    return `rgba(${r}, ${g}, ${b}, ${opacity})`;
};

// Helper to parse rgba to hex and opacity
const rgbaToHexOpacity = (rgba: string) => {
    const match = rgba.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?\)/);
    if (!match) return { hex: '#000000', opacity: 0.3 };
    const r = parseInt(match[1]).toString(16).padStart(2, '0');
    const g = parseInt(match[2]).toString(16).padStart(2, '0');
    const b = parseInt(match[3]).toString(16).padStart(2, '0');
    return {
        hex: `#${r}${g}${b}`,
        opacity: match[4] !== undefined ? parseFloat(match[4]) : 1,
    };
};

export function HeaderSettingsClient({ initialSettings }: { initialSettings: SiteSettings }) {
    const [settings, setSettings] = useState<SiteSettings>(initialSettings);
    const [isSaving, setIsSaving] = useState(false);
    const [showMediaSelector, setShowMediaSelector] = useState(false);
    const [selectedMedia, setSelectedMedia] = useState<MediaItem | null>(null);
    const { toast } = useToast();

    const handleSave = async () => {
        setIsSaving(true);
        const result = await saveSiteSettingsAction(settings);
        if (result.error) {
            toast({ variant: 'destructive', title: 'Eroare', description: result.error });
        } else {
            toast({ title: 'Succes!', description: 'Setările header-ului au fost salvate.' });
        }
        setIsSaving(false);
    };

    const handleHeaderStyleChange = (prop: keyof SiteSettings['headerSettings'], value: any) => {
        setSettings(s => ({
            ...s,
            headerSettings: {
                ...s.headerSettings,
                [prop]: value,
            }
        }));
    };

    const handleSiteTitleChange = (value: string) => {
        setSettings(s => ({ ...s, siteTitle: value }));
    };

    const handleLogoUrlChange = (value: string) => {
        setSettings(s => ({ ...s, logoUrl: value }));
    };

    const handleMediaSelect = (mediaItem: MediaItem) => {
        setSelectedMedia(mediaItem);
        setSettings(s => ({ ...s, logoUrl: mediaItem.src }));
        toast({ title: 'Logo selectat!', description: `Ai selectat ${mediaItem.filename} ca logo.` });
    };

    const handleRemoveLogo = () => {
        setSelectedMedia(null);
        setSettings(s => ({ ...s, logoUrl: '' }));
        toast({ title: 'Logo eliminat', description: 'Logo-ul a fost eliminat.' });
    };

    const bgColor = rgbaToHexOpacity(settings.headerSettings.backgroundColor);
    const borderColor = rgbaToHexOpacity(settings.headerSettings.borderColor);

    return (
        <div className="grid gap-6">
            <div className="grid md:grid-cols-2 gap-6">
                <Card>
                    <CardHeader>
                        <CardTitle>Setări Generale Header</CardTitle>
                        <CardDescription>Configurează logo-ul și numele site-ului.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                        <div className="space-y-2">
                            <Label htmlFor="site-title">Nume Site</Label>
                            <Input
                                id="site-title"
                                placeholder="Numele site-ului tău"
                                value={settings.siteTitle || ''}
                                onChange={(e) => handleSiteTitleChange(e.target.value)}
                            />
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="logo-url">Logo</Label>
                            <div className="space-y-3">
                                {settings.logoUrl && (
                                    <div className="flex items-center gap-3 p-3 border rounded-lg bg-muted/50">
                                        <div className="w-12 h-12 border rounded bg-background flex items-center justify-center overflow-hidden">
                                            <img
                                                src={settings.logoUrl}
                                                alt="Logo preview"
                                                className="max-w-full max-h-full object-contain"
                                                onError={(e) => {
                                                    const target = e.target as HTMLImageElement;
                                                    target.style.display = 'none';
                                                }}
                                            />
                                        </div>
                                        <div className="flex-1 min-w-0">
                                            <p className="text-sm font-medium truncate">
                                                {selectedMedia?.filename || 'Logo personalizat'}
                                            </p>
                                            <p className="text-xs text-muted-foreground">
                                                Logo selectat din galeria media
                                            </p>
                                        </div>
                                        <Button
                                            variant="ghost"
                                            size="sm"
                                            onClick={handleRemoveLogo}
                                            className="h-8 w-8 p-0"
                                        >
                                            <Trash2 className="w-4 h-4" />
                                        </Button>
                                    </div>
                                )}
                                <div className="flex gap-2">
                                    <Button
                                        variant="outline"
                                        onClick={() => setShowMediaSelector(true)}
                                        className="flex-1"
                                    >
                                        <ImageIcon className="w-4 h-4 mr-2" />
                                        Selectează din Galeria Media
                                    </Button>
                                </div>
                                <Input
                                    id="logo-url"
                                    placeholder="sau introdu URL-ul manual..."
                                    value={settings.logoUrl}
                                    onChange={(e) => handleLogoUrlChange(e.target.value)}
                                />
                                <p className="text-sm text-muted-foreground">
                                    Selectează o imagine din galeria ta sau introduce URL-ul manual.
                                </p>
                            </div>
                        </div>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader>
                        <CardTitle>Stil Header</CardTitle>
                        <CardDescription>Personalizează efectul de sticlă al header-ului.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <div>
                            <Label>Culoare Fundal & Opacitate</Label>
                            <div className="flex items-center gap-2 mt-1">
                                <Input
                                    type="color"
                                    value={bgColor.hex}
                                    onChange={(e) => handleHeaderStyleChange('backgroundColor', hexToRgba(e.target.value, bgColor.opacity))}
                                    className="w-10 h-10 p-1"
                                />
                                <Slider
                                    min={0} max={1} step={0.01}
                                    value={[bgColor.opacity]}
                                    onValueChange={(v) => handleHeaderStyleChange('backgroundColor', hexToRgba(bgColor.hex, v[0]))}
                                />
                            </div>
                        </div>
                        <div>
                            <Label>Estompare Fundal (Blur)</Label>
                            <div className="flex items-center gap-2 mt-1">
                                <Slider
                                    min={0} max={32} step={1}
                                    value={[settings.headerSettings.backdropBlur]}
                                    onValueChange={(v) => handleHeaderStyleChange('backdropBlur', v[0])}
                                />
                                <span className="text-xs w-8 text-right">{settings.headerSettings.backdropBlur}px</span>
                            </div>
                        </div>
                        <div>
                            <Label>Culoare Bordură & Opacitate</Label>
                            <div className="flex items-center gap-2 mt-1">
                                <Input
                                    type="color"
                                    value={borderColor.hex}
                                    onChange={(e) => handleHeaderStyleChange('borderColor', hexToRgba(e.target.value, borderColor.opacity))}
                                    className="w-10 h-10 p-1"
                                />
                                <Slider
                                    min={0} max={1} step={0.01}
                                    value={[borderColor.opacity]}
                                    onValueChange={(v) => handleHeaderStyleChange('borderColor', hexToRgba(borderColor.hex, v[0]))}
                                />
                            </div>
                        </div>
                    </CardContent>
                </Card>
            </div>

            <MediaSelector
                isOpen={showMediaSelector}
                onClose={() => setShowMediaSelector(false)}
                onSelect={handleMediaSelect}
                selectedMedia={selectedMedia}
            />

            <div className="flex justify-end">
                <Button onClick={handleSave} disabled={isSaving}>
                    {isSaving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    Salvează Setările
                </Button>
            </div>
        </div>
    );
}