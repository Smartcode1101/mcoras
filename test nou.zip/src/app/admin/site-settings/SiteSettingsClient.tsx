'use client';

import { useState } from 'react';
import type { SiteSettings } from '@/lib/types';
import { useToast } from '@/hooks/use-toast';
import { saveSiteSettingsAction } from '@/lib/actions';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Loader2 } from 'lucide-react';

const languages = [
  { code: 'ro', name: 'Română' },
  { code: 'en', name: 'English' },
  { code: 'de', name: 'Deutsch' },
  { code: 'fr', name: 'Français' },
  { code: 'es', name: 'Español' },
  { code: 'it', name: 'Italiano' },
];

interface SiteSettingsClientProps {
    initialSettings: SiteSettings;
}

export function SiteSettingsClient({ initialSettings }: SiteSettingsClientProps) {
    const [settings, setSettings] = useState<SiteSettings>(initialSettings);
    const [isSaving, setIsSaving] = useState(false);
    const { toast } = useToast();

    const handleSave = async () => {
        setIsSaving(true);
        const result = await saveSiteSettingsAction(settings);
        if (result.error) {
            toast({ variant: 'destructive', title: 'Eroare', description: result.error });
        } else {
            toast({ title: 'Succes!', description: 'Setările au fost salvate.' });
            // Refresh to apply language change
            window.location.reload();
        }
        setIsSaving(false);
    };

    const handleLanguageChange = (value: string) => {
        setSettings(s => ({ ...s, language: value }));
    };

    return (
        <div className="container mx-auto py-6 space-y-6">
            <h1 className="text-3xl font-bold">Setări Site</h1>
            
            <Card>
                <CardHeader>
                    <CardTitle>Limba și Localizare</CardTitle>
                    <CardDescription>Configurează limba site-ului și setările SEO</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                            <Label htmlFor="language">Limba site-ului</Label>
                            <Select
                                value={settings.language || 'ro'}
                                onValueChange={handleLanguageChange}
                            >
                                <SelectTrigger id="language">
                                    <SelectValue placeholder="Selectează limba" />
                                </SelectTrigger>
                                <SelectContent>
                                    {languages.map((lang) => (
                                        <SelectItem key={lang.code} value={lang.code}>
                                            {lang.name}
                                        </SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="siteName">Numele site-ului (Site Name)</Label>
                            <Input
                                id="siteName"
                                value={settings.siteName || ''}
                                onChange={(e) => setSettings(s => ({ ...s, siteName: e.target.value }))}
                                placeholder="One Smart"
                            />
                        </div>
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="siteDescription">Descrierea site-ului (Meta Description)</Label>
                        <Input
                            id="siteDescription"
                            value={settings.siteDescription || ''}
                            onChange={(e) => setSettings(s => ({ ...s, siteDescription: e.target.value }))}
                            placeholder="Build Beautiful Pages Instantly"
                        />
                    </div>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>OpenGraph & Twitter</CardTitle>
                    <CardDescription>Imagini și metadata pentru Facebook și Twitter</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="space-y-2">
                        <Label htmlFor="ogImage">URL OpenGraph Image (1200x630)</Label>
                        <Input
                            id="ogImage"
                            value={settings.ogImage || ''}
                            onChange={(e) => setSettings(s => ({ ...s, ogImage: e.target.value }))}
                            placeholder="https://exemplu.ro/og-image.jpg"
                        />
                        <p className="text-sm text-muted-foreground">
                            Imaginea care apare când distribuiești link-ul pe Facebook
                        </p>
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="twitterImage">URL Twitter Image (1200x630)</Label>
                        <Input
                            id="twitterImage"
                            value={settings.twitterImage || ''}
                            onChange={(e) => setSettings(s => ({ ...s, twitterImage: e.target.value }))}
                            placeholder="https://exemplu.ro/twitter-image.jpg"
                        />
                        <p className="text-sm text-muted-foreground">
                            Imaginea care apare când distribuiești link-ul pe Twitter/X
                        </p>
                    </div>
                </CardContent>
            </Card>

            <div className="flex justify-end">
                <Button onClick={handleSave} disabled={isSaving}>
                    {isSaving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    Salvează Setările
                </Button>
            </div>
        </div>
    );
}
