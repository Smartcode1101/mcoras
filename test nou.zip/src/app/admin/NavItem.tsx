'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { SidebarItem } from '@/components/ui/sidebar';

export function NavItem({ href, children }: { href: string, children: React.ReactNode }) {
  const pathname = usePathname();
  const isActive = pathname === href || (href !== '/admin' && pathname.startsWith(href));

  return (
    <SidebarItem asChild variant={isActive ? 'active' : 'default'}>
      <Link href={href}>
        {children}
      </Link>
    </SidebarItem>
  );
}
