'use client';

import { useEffect, useState } from 'react';
import { Save, RefreshCw, ExternalLink, Eye, CheckCircle, XCircle, Bot, Settings, Shield, FileText, Globe } from 'lucide-react';

interface SitemapConfig {
  enabled: boolean;
  filename: string;
  changefreq?: string;
  priority?: number;
  publicationName?: string;
  publicationLanguage?: string;
  daysOld?: number;
}

interface SitemapSettings {
  enabled: boolean;
  autoGenerate: boolean;
  includeNews: boolean;
  sitemaps: {
    posts: SitemapConfig;
    pages: SitemapConfig;
    categories: SitemapConfig;
    tags: SitemapConfig;
    news: SitemapConfig;
  };
}

export default function SitemapSettingsClient() {
  const [settings, setSettings] = useState<SitemapSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [previewXml, setPreviewXml] = useState<string | null>(null);
  const [previewType, setPreviewType] = useState<string>('');
  const [siteUrl, setSiteUrl] = useState('');
  const [robotsTxt, setRobotsTxt] = useState<string | null>(null);
  const [robotsSettings, setRobotsSettings] = useState({
    enabled: true,
    blockUnsafeBots: true,
    excludeAdmin: true,
    excludePagination: true,
    excludeArchives: true,
    customRules: ''
  });
  const [activeTab, setActiveTab] = useState<'sitemap' | 'robots'>('sitemap');

  useEffect(() => {
    loadSettings();
    loadSiteUrl();
    loadRobotsSettings();
    loadRobotsTxt();
  }, []);

  const loadSiteUrl = () => {
    // Use current browser host for dynamic URL in admin
    const protocol = window.location.protocol;
    const host = window.location.host;
    setSiteUrl(`${protocol}//${host}`);
  };

  const loadRobotsSettings = async () => {
    try {
      const response = await fetch('/api/admin/robots-settings');
      const data = await response.json();
      setRobotsSettings(data);
    } catch (error) {
      console.error('Error loading robots settings:', error);
    }
  };

  const loadRobotsTxt = async () => {
    try {
      const response = await fetch('/api/robots.txt');
      const text = await response.text();
      setRobotsTxt(text);
    } catch (error) {
      console.error('Error loading robots.txt:', error);
    }
  };

  const loadSettings = async () => {
    try {
      const response = await fetch('/api/admin/sitemap-settings');
      const data = await response.json();
      setSettings(data);
    } catch (error) {
      console.error('Error loading sitemap settings:', error);
    } finally {
      setLoading(false);
    }
  };

  const saveSettings = async () => {
    if (!settings) return;
    setSaving(true);
    try {
      const response = await fetch('/api/admin/sitemap-settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settings)
      });
      if (response.ok) {
        setSaved(true);
        setTimeout(() => setSaved(false), 3000);
        
        // Also save robots settings
        await saveRobotsSettings();
      }
    } catch (error) {
      console.error('Error saving sitemap settings:', error);
    } finally {
      setSaving(false);
    }
  };

  const saveRobotsSettings = async () => {
    try {
      await fetch('/api/admin/robots-settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(robotsSettings)
      });
      // Reload robots.txt preview after saving
      await loadRobotsTxt();
    } catch (error) {
      console.error('Error saving robots settings:', error);
    }
  };

  const updateSitemap = (key: string, updates: Partial<SitemapConfig>) => {
    if (!settings) return;
    setSettings({
      ...settings,
      sitemaps: {
        ...settings.sitemaps,
        [key]: {
          ...settings.sitemaps[key as keyof typeof settings.sitemaps],
          ...updates
        }
      }
    });
  };

  const viewSitemap = async (type: string) => {
    try {
      let url = '';
      switch (type) {
        case 'index':
          url = '/sitemap.xml';
          break;
        case 'posts':
          url = '/sitemap-posts.xml';
          break;
        case 'pages':
          url = '/sitemap-pages.xml';
          break;
        case 'categories':
          url = '/sitemap-categories.xml';
          break;
        case 'tags':
          url = '/sitemap-tags.xml';
          break;
        case 'news':
          url = '/sitemap-news.xml';
          break;
        default:
          return;
      }
      const response = await fetch(`/api${url}`);
      const xml = await response.text();
      setPreviewXml(xml);
      setPreviewType(type);
    } catch (error) {
      console.error('Error fetching sitemap:', error);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!settings) return null;

  return (
    <div className="p-4 md:p-6 space-y-6">
      {/* General Settings */}
      <div className="bg-card rounded-lg border p-4 md:p-6">
        <h2 className="text-lg font-semibold mb-4">Setari Generale Sitemap</h2>
        <div className="space-y-4">
          <label className="flex items-center gap-3">
            <input
              type="checkbox"
              checked={settings.enabled}
              onChange={(e) => setSettings({ ...settings, enabled: e.target.checked })}
              className="w-4 h-4"
            />
            <span className="text-sm font-medium">Activeaza sitemap-urile</span>
          </label>
          <label className="flex items-center gap-3">
            <input
              type="checkbox"
              checked={settings.autoGenerate}
              onChange={(e) => setSettings({ ...settings, autoGenerate: e.target.checked })}
              className="w-4 h-4"
            />
            <span className="text-sm font-medium">Generare automata</span>
          </label>
          <label className="flex items-center gap-3">
            <input
              type="checkbox"
              checked={settings.includeNews}
              onChange={(e) => setSettings({ ...settings, includeNews: e.target.checked })}
              className="w-4 h-4"
            />
            <span className="text-sm font-medium">Include sitemap pentru stiri</span>
          </label>
        </div>
      </div>

      {/* Sitemap URLs */}
      <div className="bg-card rounded-lg border p-4 md:p-6">
        <h2 className="text-lg font-semibold mb-4">URL-uri Sitemap</h2>
        <div className="grid gap-3">
          {[
            { type: 'index', name: 'Sitemap Index', url: '/sitemap.xml' },
            { type: 'posts', name: 'Postari', url: '/sitemap-posts.xml' },
            { type: 'pages', name: 'Pagini', url: '/sitemap-pages.xml' },
            { type: 'categories', name: 'Categorii', url: '/sitemap-categories.xml' },
            { type: 'tags', name: 'Tag-uri', url: '/sitemap-tags.xml' },
            { type: 'news', name: 'Stiri (News)', url: '/sitemap-news.xml' },
          ].map((sitemap) => (
            <div key={sitemap.type} className="flex flex-col sm:flex-row sm:items-center justify-between p-3 bg-muted rounded-lg gap-2">
              <div className="min-w-0">
                <p className="font-medium">{sitemap.name}</p>
                <p className="text-sm text-muted-foreground truncate">{siteUrl}{sitemap.url}</p>
              </div>
              <div className="flex gap-2 flex-shrink-0">
                <button
                  onClick={() => viewSitemap(sitemap.type)}
                  className="p-2 hover:bg-secondary rounded-md"
                  title="Vizualizeaza"
                >
                  <Eye className="w-4 h-4" />
                </button>
                <a
                  href={`${siteUrl}${sitemap.url}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2 hover:bg-secondary rounded-md"
                  title="Deschide in tab nou"
                >
                  <ExternalLink className="w-4 h-4" />
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Individual Sitemap Settings */}
      <div className="space-y-4">
        {/* Posts Sitemap */}
        <div className="bg-card rounded-lg border p-4 md:p-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-4 gap-2">
            <h3 className="font-semibold">Sitemap Postari</h3>
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={settings.sitemaps.posts.enabled}
                onChange={(e) => updateSitemap('posts', { enabled: e.target.checked })}
                className="w-4 h-4"
              />
              <span className="text-sm">Activ</span>
            </label>
          </div>
          {settings.sitemaps.posts.enabled && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium">Frecventa schimbare</label>
                <select
                  value={settings.sitemaps.posts.changefreq || 'weekly'}
                  onChange={(e) => updateSitemap('posts', { changefreq: e.target.value })}
                  className="w-full mt-1 p-2 border rounded-md"
                >
                  <option value="always">Intotdeauna</option>
                  <option value="hourly">Orar</option>
                  <option value="daily">Zilnic</option>
                  <option value="weekly">Saptamanal</option>
                  <option value="monthly">Lunar</option>
                  <option value="yearly">Anual</option>
                </select>
              </div>
              <div>
                <label className="text-sm font-medium">Prioritate (0-1)</label>
                <input
                  type="number"
                  step="0.1"
                  min="0"
                  max="1"
                  value={settings.sitemaps.posts.priority || 0.8}
                  onChange={(e) => updateSitemap('posts', { priority: parseFloat(e.target.value) })}
                  className="w-full mt-1 p-2 border rounded-md"
                />
              </div>
            </div>
          )}
        </div>

        {/* Pages Sitemap */}
        <div className="bg-card rounded-lg border p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold">Sitemap Pagini</h3>
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={settings.sitemaps.pages.enabled}
                onChange={(e) => updateSitemap('pages', { enabled: e.target.checked })}
                className="w-4 h-4"
              />
              <span className="text-sm">Activ</span>
            </label>
          </div>
          {settings.sitemaps.pages.enabled && (
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium">Frecventa schimbare</label>
                <select
                  value={settings.sitemaps.pages.changefreq || 'monthly'}
                  onChange={(e) => updateSitemap('pages', { changefreq: e.target.value })}
                  className="w-full mt-1 p-2 border rounded-md"
                >
                  <option value="always">Intotdeauna</option>
                  <option value="hourly">Orar</option>
                  <option value="daily">Zilnic</option>
                  <option value="weekly">Saptamanal</option>
                  <option value="monthly">Lunar</option>
                  <option value="yearly">Anual</option>
                </select>
              </div>
              <div>
                <label className="text-sm font-medium">Prioritate (0-1)</label>
                <input
                  type="number"
                  step="0.1"
                  min="0"
                  max="1"
                  value={settings.sitemaps.pages.priority || 0.6}
                  onChange={(e) => updateSitemap('pages', { priority: parseFloat(e.target.value) })}
                  className="w-full mt-1 p-2 border rounded-md"
                />
              </div>
            </div>
          )}
        </div>

        {/* Categories Sitemap */}
        <div className="bg-card rounded-lg border p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold">Sitemap Categorii</h3>
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={settings.sitemaps.categories.enabled}
                onChange={(e) => updateSitemap('categories', { enabled: e.target.checked })}
                className="w-4 h-4"
              />
              <span className="text-sm">Activ</span>
            </label>
          </div>
          {settings.sitemaps.categories.enabled && (
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium">Frecventa schimbare</label>
                <select
                  value={settings.sitemaps.categories.changefreq || 'weekly'}
                  onChange={(e) => updateSitemap('categories', { changefreq: e.target.value })}
                  className="w-full mt-1 p-2 border rounded-md"
                >
                  <option value="always">Intotdeauna</option>
                  <option value="hourly">Orar</option>
                  <option value="daily">Zilnic</option>
                  <option value="weekly">Saptamanal</option>
                  <option value="monthly">Lunar</option>
                  <option value="yearly">Anual</option>
                </select>
              </div>
              <div>
                <label className="text-sm font-medium">Prioritate (0-1)</label>
                <input
                  type="number"
                  step="0.1"
                  min="0"
                  max="1"
                  value={settings.sitemaps.categories.priority || 0.7}
                  onChange={(e) => updateSitemap('categories', { priority: parseFloat(e.target.value) })}
                  className="w-full mt-1 p-2 border rounded-md"
                />
              </div>
            </div>
          )}
        </div>

        {/* Tags Sitemap */}
        <div className="bg-card rounded-lg border p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold">Sitemap Tag-uri</h3>
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={settings.sitemaps.tags.enabled}
                onChange={(e) => updateSitemap('tags', { enabled: e.target.checked })}
                className="w-4 h-4"
              />
              <span className="text-sm">Activ</span>
            </label>
          </div>
          {settings.sitemaps.tags.enabled && (
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium">Frecventa schimbare</label>
                <select
                  value={settings.sitemaps.tags.changefreq || 'weekly'}
                  onChange={(e) => updateSitemap('tags', { changefreq: e.target.value })}
                  className="w-full mt-1 p-2 border rounded-md"
                >
                  <option value="always">Intotdeauna</option>
                  <option value="hourly">Orar</option>
                  <option value="daily">Zilnic</option>
                  <option value="weekly">Saptamanal</option>
                  <option value="monthly">Lunar</option>
                  <option value="yearly">Anual</option>
                </select>
              </div>
              <div>
                <label className="text-sm font-medium">Prioritate (0-1)</label>
                <input
                  type="number"
                  step="0.1"
                  min="0"
                  max="1"
                  value={settings.sitemaps.tags.priority || 0.6}
                  onChange={(e) => updateSitemap('tags', { priority: parseFloat(e.target.value) })}
                  className="w-full mt-1 p-2 border rounded-md"
                />
              </div>
            </div>
          )}
        </div>

        {/* News Sitemap */}
        <div className="bg-card rounded-lg border p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold">Sitemap Stiri (Google News)</h3>
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={settings.sitemaps.news.enabled}
                onChange={(e) => updateSitemap('news', { enabled: e.target.checked })}
                className="w-4 h-4"
              />
              <span className="text-sm">Activ</span>
            </label>
          </div>
          {settings.sitemaps.news.enabled && (
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium">Nume Publicatie</label>
                <input
                  type="text"
                  value={settings.sitemaps.news.publicationName || ''}
                  onChange={(e) => updateSitemap('news', { publicationName: e.target.value })}
                  className="w-full mt-1 p-2 border rounded-md"
                />
              </div>
              <div>
                <label className="text-sm font-medium">Limba Publicatiei</label>
                <select
                  value={settings.sitemaps.news.publicationLanguage || 'ro'}
                  onChange={(e) => updateSitemap('news', { publicationLanguage: e.target.value })}
                  className="w-full mt-1 p-2 border rounded-md"
                >
                  <option value="ro">Romana</option>
                  <option value="en">Engleza</option>
                </select>
              </div>
              <div>
                <label className="text-sm font-medium">Varsta maxima postari (zile)</label>
                <input
                  type="number"
                  min="1"
                  max="7"
                  value={settings.sitemaps.news.daysOld || 2}
                  onChange={(e) => updateSitemap('news', { daysOld: parseInt(e.target.value) })}
                  className="w-full mt-1 p-2 border rounded-md"
                />
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Save Button */}
      <div className="flex items-center gap-4">
        <button
          onClick={saveSettings}
          disabled={saving}
          className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-md hover:bg-primary/90 disabled:opacity-50"
        >
          {saving ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
          {saving ? 'Se salveaza...' : 'Salveaza Setarile'}
        </button>
        {saved && (
          <span className="flex items-center gap-1 text-green-600">
            <CheckCircle className="w-4 h-4" />
            Setari salvate!
          </span>
        )}
      </div>

      {/* Robots.txt Management */}
      <div className="bg-card rounded-lg border p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Bot className="w-5 h-5" />
            <h2 className="text-lg font-semibold">Robots.txt</h2>
          </div>
          <div className="flex gap-2">
            <button
              onClick={loadRobotsTxt}
              className="flex items-center gap-2 px-3 py-1.5 text-sm bg-muted hover:bg-muted/80 rounded-md"
            >
              <RefreshCw className="w-4 h-4" />
              Reincarca
            </button>
            <a
              href={`${siteUrl}/robots.txt`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 px-3 py-1.5 text-sm bg-muted hover:bg-muted/80 rounded-md"
            >
              <ExternalLink className="w-4 h-4" />
              Vizualizeaza live
            </a>
          </div>
        </div>

        {/* Robots.txt Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <div className="bg-muted p-3 rounded-lg">
            <div className="flex items-center gap-2 text-green-600 mb-1">
              <Shield className="w-4 h-4" />
              <span className="text-sm font-medium">Status</span>
            </div>
            <p className="text-lg font-semibold">{robotsSettings.enabled ? 'Activ' : 'Dezactivat'}</p>
          </div>
          <div className="bg-muted p-3 rounded-lg">
            <div className="flex items-center gap-2 text-blue-600 mb-1">
              <Bot className="w-4 h-4" />
              <span className="text-sm font-medium">Boti blocati</span>
            </div>
            <p className="text-lg font-semibold">{robotsSettings.blockUnsafeBots ? '100+' : '0'}</p>
          </div>
          <div className="bg-muted p-3 rounded-lg">
            <div className="flex items-center gap-2 text-orange-600 mb-1">
              <Settings className="w-4 h-4" />
              <span className="text-sm font-medium">Reguli active</span>
            </div>
            <p className="text-lg font-semibold">
              {[robotsSettings.excludeAdmin, robotsSettings.excludePagination, robotsSettings.excludeArchives].filter(Boolean).length + 
              (robotsSettings.customRules ? 1 : 0) + 1}
            </p>
          </div>
          <div className="bg-muted p-3 rounded-lg">
            <div className="flex items-center gap-2 text-purple-600 mb-1">
              <Globe className="w-4 h-4" />
              <span className="text-sm font-medium">Sitemap-uri</span>
            </div>
            <p className="text-lg font-semibold">
              {settings?.sitemaps ? 
                Object.values(settings.sitemaps).filter((s: any) => s.enabled).length + 1 : 0}
            </p>
          </div>
        </div>

        {/* Feature Toggles */}
        <div className="space-y-3 mb-6">
          <h3 className="font-medium text-sm text-muted-foreground mb-3">Configurare automata</h3>
          <label className="flex items-center gap-3">
            <input
              type="checkbox"
              checked={robotsSettings.enabled}
              onChange={(e) => setRobotsSettings({ ...robotsSettings, enabled: e.target.checked })}
              className="w-4 h-4"
            />
            <span className="text-sm">Activeaza robots.txt (daca dezactivati, toti botii sunt blocati)</span>
          </label>
          <label className="flex items-center gap-3">
            <input
              type="checkbox"
              checked={robotsSettings.blockUnsafeBots}
              onChange={(e) => setRobotsSettings({ ...robotsSettings, blockUnsafeBots: e.target.checked })}
              className="w-4 h-4"
            />
            <span className="text-sm">Blocheaza boti nesiguri/maliciosi</span>
          </label>
          <label className="flex items-center gap-3">
            <input
              type="checkbox"
              checked={robotsSettings.excludeAdmin}
              onChange={(e) => setRobotsSettings({ ...robotsSettings, excludeAdmin: e.target.checked })}
              className="w-4 h-4"
            />
            <span className="text-sm">Exclude paginile admin (/admin, /api/admin, /editor)</span>
          </label>
          <label className="flex items-center gap-3">
            <input
              type="checkbox"
              checked={robotsSettings.excludePagination}
              onChange={(e) => setRobotsSettings({ ...robotsSettings, excludePagination: e.target.checked })}
              className="w-4 h-4"
            />
            <span className="text-sm">Exclude paginarea postgrid widget</span>
          </label>
          <label className="flex items-center gap-3">
            <input
              type="checkbox"
              checked={robotsSettings.excludeArchives}
              onChange={(e) => setRobotsSettings({ ...robotsSettings, excludeArchives: e.target.checked })}
              className="w-4 h-4"
            />
            <span className="text-sm">Exclude arhivele de categorii si tag-uri</span>
          </label>
        </div>

        {/* Custom Rules */}
        <div className="mb-6">
          <h3 className="font-medium text-sm text-muted-foreground mb-3">Reguli personalizate</h3>
          <textarea
            value={robotsSettings.customRules || ''}
            onChange={(e) => setRobotsSettings({ ...robotsSettings, customRules: e.target.value })}
            placeholder="Adauga reguli personalizate (ex: Disallow: /path)\nAllow: /path/allowed"
            className="w-full h-24 p-3 border rounded-md text-xs font-mono"
          />
          <p className="text-xs text-muted-foreground mt-1">Foloseste sintaxa standard robots.txt</p>
        </div>

        {/* Preview */}
        {robotsTxt && (
          <div>
            <h3 className="font-medium text-sm text-muted-foreground mb-3">Preview Robots.txt</h3>
            <div className="bg-muted p-4 rounded-lg overflow-x-auto">
              <pre className="text-xs whitespace-pre-wrap break-all font-mono">
                {robotsTxt}
              </pre>
            </div>
          </div>
        )}
      </div>

      {/* Preview Modal */}
      {previewXml && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-background rounded-lg border w-full max-w-4xl max-h-[80vh] overflow-hidden">
            <div className="flex items-center justify-between p-4 border-b">
              <h3 className="font-semibold">Preview: {previewType}</h3>
              <button
                onClick={() => setPreviewXml(null)}
                className="p-2 hover:bg-secondary rounded-md"
              >
                <XCircle className="w-4 h-4" />
              </button>
            </div>
            <div className="p-4 overflow-auto max-h-[calc(80vh-60px)]">
              <pre className="text-xs bg-muted p-4 rounded-lg overflow-x-auto whitespace-pre-wrap break-all">
                {previewXml}
              </pre>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
