import SitemapSettingsClient from './SitemapSettingsClient';

export default function SitemapSettingsPage() {
  return <SitemapSettingsClient />;
}
