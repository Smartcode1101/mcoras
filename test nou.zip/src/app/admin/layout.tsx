'use client';
import { LayoutDashboard, FileText, Sparkles, Menu, Settings, LogOut, User, BarChart3, ImageIcon, Folder, Tag, Zap, Code, Map, X, HardDrive } from 'lucide-react';
import Link from 'next/link';
import { NavItem } from './NavItem';
import { useEffect, useState } from 'react';
import { usePathname, useRouter } from 'next/navigation';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { useAuth } from '@/contexts/auth-context';

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const pathname = usePathname();
  const router = useRouter();
  const { user, token, logout, isLoading } = useAuth();
  const isEditor = pathname?.includes('/editor');
  const [faviconUrl, setFaviconUrl] = useState('/favicon.ico');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const handleLogout = () => {
    logout();
    router.push('/auth/login');
  };

  const closeSidebar = () => setSidebarOpen(false);

  useEffect(() => {
    document.documentElement.classList.add('admin-area');
    return () => {
      document.documentElement.classList.remove('admin-area');
    };
  }, []);

  // Set favicon from site settings
  useEffect(() => {
    const loadFavicon = async () => {
      try {
        const response = await fetch('/api/site-settings');
        if (response.ok) {
          const data = await response.json();
          if (data.logoUrl) {
            setFaviconUrl(data.logoUrl);
            // Update favicon dynamically
            const link = document.querySelector("link[rel*='icon']") as HTMLLinkElement || document.createElement('link') as HTMLLinkElement;
            link.setAttribute('rel', 'icon');
            link.setAttribute('href', data.logoUrl);
            if (!document.head.contains(link)) {
              document.head.appendChild(link);
            }
          }
        }
      } catch (error) {
        console.error('Error loading favicon:', error);
      }
    };
    loadFavicon();
  }, []);

  // Client-side authentication check - simplified since middleware handles JWT verification
  useEffect(() => {
    // Only check authentication after loading is complete
    if (isLoading) {
      console.log('AdminLayout: Still loading authentication, waiting...');
      return;
    }

    if (!user) {
      console.log('AdminLayout: No user found, redirecting to login');
      router.push('/auth/login?redirect=' + encodeURIComponent(pathname || '/admin'));
      return;
    }

    if (user.role !== 'admin') {
      console.log('AdminLayout: User is not admin, redirecting to login');
      logout();
      router.push('/auth/login?redirect=' + encodeURIComponent(pathname || '/admin'));
      return;
    }

    console.log('AdminLayout: Authentication verified for admin user:', user.username);
  }, [user, pathname, router, logout, isLoading]);

  if (isEditor) {
    return (
      <div className="h-screen bg-background">
        {children}
      </div>
    );
  }

  // Show loading state while checking authentication
  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen bg-background">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-sm text-muted-foreground">Se verifică autentificarea...</p>
        </div>
      </div>
    );
  }

  // Fixed sidebar layout for all admin pages - no collapse functionality
  return (
    <TooltipProvider>
      <div className="flex h-screen bg-background">
        {/* Mobile overlay */}
        {sidebarOpen && (
          <div 
            className="fixed inset-0 bg-black/50 z-40 lg:hidden"
            onClick={closeSidebar}
          />
        )}
        
        {/* Sidebar - hidden on mobile by default, slides in when open */}
        <div className={`
          w-64 border-r shrink-0 fixed lg:relative inset-y-0 left-0 z-50 transform transition-transform duration-200 ease-in-out lg:translate-x-0 bg-background
          ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'}
        `}>
          <div className="flex flex-col h-full">
            <div className="p-4 border-b flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sparkles className="w-6 h-6 text-primary" />
                <span className="font-semibold">One Smart</span>
              </div>
              <button 
                onClick={closeSidebar}
                className="lg:hidden p-1 rounded-md hover:bg-sidebar-accent"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-4">
              <nav className="space-y-2">
                <Link
                  href="/admin"
                  onClick={closeSidebar}
                  className={`flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    pathname === '/admin' ? 'bg-sidebar-accent text-sidebar-accent-foreground' : 'text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'
                  }`}
                >
                  <LayoutDashboard className="w-4 h-4" />
                  <span className="hidden sm:inline">Panou de control</span>
                  <span className="sm:hidden">Dashboard</span>
                </Link>
                <Link
                  href="/admin/pages"
                  onClick={closeSidebar}
                  className={`flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    pathname === '/admin/pages' ? 'bg-sidebar-accent text-sidebar-accent-foreground' : 'text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'
                  }`}
                >
                  <FileText className="w-4 h-4" />
                  <span className="hidden sm:inline">Pagini</span>
                  <span className="sm:hidden">Pagini</span>
                </Link>
                <Link
                  href="/admin/menu"
                  onClick={closeSidebar}
                  className={`flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    pathname === '/admin/menu' ? 'bg-sidebar-accent text-sidebar-accent-foreground' : 'text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'
                  }`}
                >
                  <Menu className="w-4 h-4" />
                  Meniu
                </Link>
                <Link
                  href="/admin/media"
                  onClick={closeSidebar}
                  className={`flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    pathname === '/admin/media' ? 'bg-sidebar-accent text-sidebar-accent-foreground' : 'text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'
                  }`}
                >
                  <ImageIcon className="w-4 h-4" />
                  <span className="hidden sm:inline">Galerie Media</span>
                  <span className="sm:hidden">Media</span>
                </Link>
                <Link
                  href="/admin/categories"
                  onClick={closeSidebar}
                  className={`flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    pathname === '/admin/categories' ? 'bg-sidebar-accent text-sidebar-accent-foreground' : 'text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'
                  }`}
                >
                  <Folder className="w-4 h-4" />
                  Categorii
                </Link>
                <Link
                  href="/admin/tags"
                  onClick={closeSidebar}
                  className={`flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    pathname === '/admin/tags' ? 'bg-sidebar-accent text-sidebar-accent-foreground' : 'text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'
                  }`}
                >
                  <Tag className="w-4 h-4" />
                  Tag-uri
                </Link>
                <div className="pt-4">
                  <p className="px-3 text-xs font-semibold text-sidebar-foreground/70 uppercase tracking-wider mb-2">
                    Setări site
                  </p>
                  <Link
                    href="/admin/site-settings"
                    onClick={closeSidebar}
                    className={`flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                      pathname === '/admin/site-settings' ? 'bg-sidebar-accent text-sidebar-accent-foreground' : 'text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'
                    }`}
                  >
                    <Settings className="h-4 w-4" />
                    <span className="hidden sm:inline">Setări Generale</span>
                    <span className="sm:inline">General</span>
                  </Link>
                  <Link
                    href="/admin/site-settings/header"
                    onClick={closeSidebar}
                    className={`flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                      pathname === '/admin/site-settings/header' ? 'bg-sidebar-accent text-sidebar-accent-foreground' : 'text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'
                    }`}
                  >
                    <Settings className="w-4 h-4" />
                    Header
                  </Link>
                  <Link
                    href="/admin/site-settings/footer"
                    onClick={closeSidebar}
                    className={`flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                      pathname === '/admin/site-settings/footer' ? 'bg-sidebar-accent text-sidebar-accent-foreground' : 'text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'
                    }`}
                  >
                    <Settings className="w-4 h-4" />
                    Footer
                  </Link>
                  <Link
                    href="/admin/performance-settings"
                    onClick={closeSidebar}
                    className={`flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                      pathname === '/admin/performance-settings' ? 'bg-sidebar-accent text-sidebar-accent-foreground' : 'text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'
                    }`}
                  >
                    <Zap className="w-4 h-4" />
                    <span className="hidden sm:inline">Performanță</span>
                    <span className="sm:hidden">Perf.</span>
                  </Link>
                  <Link
                    href="/admin/sitemap-settings"
                    onClick={closeSidebar}
                    className={`flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                      pathname === '/admin/sitemap-settings' ? 'bg-sidebar-accent text-sidebar-accent-foreground' : 'text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'
                    }`}
                  >
                    <Map className="w-4 h-4" />
                    Sitemaps
                  </Link>
                </div>
                <div className="pt-4">
                  <Link
                    href="/admin/users"
                    onClick={closeSidebar}
                    className={`flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                      pathname === '/admin/users' ? 'bg-sidebar-accent text-sidebar-accent-foreground' : 'text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'
                    }`}
                  >
                    <User className="w-4 h-4" />
                    Utilizatori
                  </Link>
                  <Link
                    href="/admin/analytics"
                    onClick={closeSidebar}
                    className={`flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                      pathname === '/admin/analytics' ? 'bg-sidebar-accent text-sidebar-accent-foreground' : 'text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'
                    }`}
                  >
                    <BarChart3 className="w-4 h-4" />
                    Analytics
                  </Link>
                  <Link
                    href="/admin/backup"
                    onClick={closeSidebar}
                    className={`flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                      pathname === '/admin/backup' ? 'bg-sidebar-accent text-sidebar-accent-foreground' : 'text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'
                    }`}
                  >
                    <HardDrive className="w-4 h-4" />
                    Backup
                  </Link>
                </div>
              </nav>
            </div>
            <div className="border-t p-4">
              <div className="flex items-center gap-2 mb-3">
                <User className="w-4 h-4" />
                <span className="text-sm font-medium truncate">{user?.username || 'Admin'}</span>
              </div>
              <button
                onClick={handleLogout}
                className="flex items-center gap-2 w-full px-3 py-2 text-sm font-medium rounded-md transition-colors hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
              >
                <LogOut className="w-4 h-4" />
                Logout
              </button>
            </div>
          </div>
        </div>
        <div className="flex-1 flex flex-col overflow-hidden">
          <header className="flex items-center h-14 px-2 md:px-4 border-b shrink-0 gap-2">
            <button 
              onClick={() => setSidebarOpen(true)}
              className="lg:hidden p-2 rounded-md hover:bg-sidebar-accent"
            >
              <Menu className="w-5 h-5" />
            </button>
            <h1 className="text-base md:text-lg font-semibold truncate">
              {pathname === '/admin' && 'Panou de Control'}
              {pathname === '/admin/pages' && 'Pagini'}
              {pathname === '/admin/menu' && 'Meniu'}
              {pathname === '/admin/media' && 'Galerie Media'}
              {pathname === '/admin/categories' && 'Categorii'}
              {pathname === '/admin/tags' && 'Tag-uri'}
              {pathname === '/admin/site-settings' && 'Setări Generale'}
              {pathname === '/admin/site-settings/header' && 'Header'}
              {pathname === '/admin/site-settings/footer' && 'Footer'}
              {pathname === '/admin/performance-settings' && 'Performanță'}
              {pathname === '/admin/sitemap-settings' && 'Sitemaps'}
              {pathname === '/admin/users' && 'Utilizatori'}
              {pathname === '/admin/analytics' && 'Analytics'}
              {pathname === '/admin/backup' && 'Backup'}
            </h1>
            <div className="flex-1" />
          </header>
          <main className="flex-1 overflow-y-auto bg-background p-2 md:p-4">
            {children}
          </main>
        </div>
      </div>
    </TooltipProvider>
  );
}
