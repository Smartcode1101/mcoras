'use client';

import { useState, useEffect } from 'react';
import type { Tag } from '@/lib/types';
import { X } from 'lucide-react';

export default function TagsAdminPage() {
  const [tags, setTags] = useState<Tag[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingTag, setEditingTag] = useState<Tag | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    slug: '',
    description: '',
    metaTitle: '',
    metaDescription: '',
    metaKeywords: ''
  });

  useEffect(() => {
    fetchTags();
  }, []);

  const fetchTags = async () => {
    try {
      const response = await fetch('/api/tags');
      if (response.ok) {
        const data = await response.json();
        setTags(data);
      }
    } catch (error) {
      console.error('Eroare la încărcarea tag-urilor:', error);
    } finally {
      setLoading(false);
    }
  };

  const generateSlug = (name: string) => {
    return name
      .toLowerCase()
      .replace(/[ăâîșț]/g, (match) => {
        const map: { [key: string]: string } = { 'ă': 'a', 'â': 'a', 'î': 'i', 'ș': 's', 'ț': 't' };
        return map[match] || match;
      })
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '');
  };

  const handleNameChange = (name: string) => {
    setFormData(prev => ({
      ...prev,
      name,
      slug: generateSlug(name)
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const url = editingTag 
        ? `/api/tags/${editingTag.id}`
        : '/api/tags';
      
      const method = editingTag ? 'PUT' : 'POST';
      
      const response = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });

      if (response.ok) {
        fetchTags();
        resetForm();
      } else {
        const error = await response.json();
        alert(error.error || 'Eroare la salvarea tag-ului');
      }
    } catch (error) {
      console.error('Eroare:', error);
      alert('Eroare la salvarea tag-ului');
    }
  };

  const handleEdit = (tag: Tag) => {
    setEditingTag(tag);
    setFormData({
      name: tag.name,
      slug: tag.slug,
      description: tag.description || '',
      metaTitle: tag.metaTitle || '',
      metaDescription: tag.metaDescription || '',
      metaKeywords: tag.metaKeywords || ''
    });
    setShowForm(true);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Sigur doriți să ștergeți acest tag?')) return;
    
    try {
      const response = await fetch(`/api/tags/${id}`, {
        method: 'DELETE'
      });

      if (response.ok) {
        fetchTags();
      }
    } catch (error) {
      console.error('Eroare la ștergere:', error);
    }
  };

  const resetForm = () => {
    setShowForm(false);
    setEditingTag(null);
    setFormData({
      name: '',
      slug: '',
      description: '',
      metaTitle: '',
      metaDescription: '',
      metaKeywords: ''
    });
  };

  if (loading) {
    return <div className="p-4 md:p-8">Se încarcă...</div>;
  }

  return (
    <div className="p-4 md:p-8">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
        <h1 className="text-xl md:text-2xl font-bold">Tag-uri</h1>
        <button
          onClick={() => setShowForm(true)}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors text-sm md:text-base w-full sm:w-auto"
        >
          + Adaugă tag
        </button>
      </div>

      {showForm && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-2 md:p-4">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-2xl max-h-[90vh] md:max-h-[85vh] overflow-hidden flex flex-col">
            {/* Header */}
            <div className="flex items-center justify-between p-5 border-b bg-gray-50">
              <h2 className="text-xl font-bold text-gray-800">
                {editingTag ? 'Editează tag' : 'Adaugă tag nou'}
              </h2>
              <button
                onClick={resetForm}
                className="p-2 hover:bg-gray-200 rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            {/* Form content */}
            <div className="overflow-y-auto flex-1 p-5">
              <form onSubmit={handleSubmit} className="space-y-5">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Nume *</label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => handleNameChange(e.target.value)}
                    className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all text-gray-900 bg-white"
                    placeholder="Ex: Minecraft"
                    required
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Slug *</label>
                  <input
                    type="text"
                    value={formData.slug}
                    onChange={(e) => setFormData(prev => ({ ...prev, slug: e.target.value }))}
                    className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all text-gray-900 bg-gray-100"
                    placeholder="ex: minecraft"
                    required
                  />
                  <p className="text-xs text-gray-500 mt-1">URL: /tag/<strong>{formData.slug || '...'}</strong></p>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Descriere</label>
                  <textarea
                    value={formData.description}
                    onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                    className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all resize-none text-gray-900 bg-white"
                    rows={3}
                    placeholder="Descriere scurtă a tag-ului..."
                  />
                </div>

                <div className="border-t pt-5 mt-5">
                  <h3 className="font-semibold text-gray-800 mb-4 flex items-center gap-2">
                    <span className="w-2 h-2 bg-blue-500 rounded-full"></span>
                    Setări SEO
                  </h3>
                  
                  <div className="space-y-4 bg-gray-50 p-4 rounded-lg">
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-2">Meta Title</label>
                      <input
                        type="text"
                        value={formData.metaTitle}
                        onChange={(e) => setFormData(prev => ({ ...prev, metaTitle: e.target.value }))}
                        className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all text-gray-900 bg-white"
                        placeholder="Titlu pentru motoarele de căutare"
                      />
                      <p className="text-xs text-gray-500 mt-1">{formData.metaTitle.length}/60 caractere recomandate</p>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-2">Meta Description</label>
                      <textarea
                        value={formData.metaDescription}
                        onChange={(e) => setFormData(prev => ({ ...prev, metaDescription: e.target.value }))}
                        className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all resize-none text-gray-900 bg-white"
                        rows={2}
                        placeholder="Descriere pentru motoarele de căutare"
                      />
                      <p className="text-xs text-gray-500 mt-1">{formData.metaDescription.length}/160 caractere recomandate</p>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-2">Meta Keywords</label>
                      <input
                        type="text"
                        value={formData.metaKeywords}
                        onChange={(e) => setFormData(prev => ({ ...prev, metaKeywords: e.target.value }))}
                        className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all text-gray-900 bg-white"
                        placeholder="cuvinte, cheie, separate, prin, virgulă"
                      />
                    </div>
                  </div>
                </div>
              </form>
            </div>
            
            {/* Footer */}
            <div className="flex gap-3 p-5 border-t bg-gray-50">
              <button
                type="submit"
                onClick={handleSubmit}
                className="flex-1 bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors font-medium"
              >
                {editingTag ? 'Salvează modificările' : 'Creează tag-ul'}
              </button>
              <button
                type="button"
                onClick={resetForm}
                className="px-6 py-3 bg-gray-200 text-gray-800 border border-gray-300 rounded-lg hover:bg-gray-300 transition-colors font-medium"
              >
                Anulează
              </button>
            </div>
          </div>
        </div>
      )}

      {tags.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-lg shadow">
          <div className="text-gray-400 text-5xl mb-4">🏷️</div>
          <p className="text-gray-500 text-lg">Nu există tag-uri.</p>
          <p className="text-gray-400 text-sm mt-2">Apasă "Adaugă tag" pentru a crea primul tag.</p>
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {tags.map((tag) => (
            <div
              key={tag.id}
              className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden hover:shadow-md transition-shadow"
            >
              <div className="p-5">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-purple-100 text-purple-800">
                        Tag
                      </span>
                    </div>
                    <h3 className="font-semibold text-gray-900 text-lg mt-2">{tag.name}</h3>
                    <p className="text-sm text-gray-500 font-mono mt-1">/{tag.slug}</p>
                  </div>
                </div>
                {tag.description && (
                  <p className="text-sm text-gray-600 mt-3 line-clamp-2">{tag.description}</p>
                )}
              </div>
              <div className="px-5 py-3 bg-gray-50 border-t flex justify-end gap-2">
                <button
                  onClick={() => handleEdit(tag)}
                  className="px-3 py-1.5 text-sm font-medium text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                >
                  Editează
                </button>
                <button
                  onClick={() => handleDelete(tag.id)}
                  className="px-3 py-1.5 text-sm font-medium text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                >
                  Șterge
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
