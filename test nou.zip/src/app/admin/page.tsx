
'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/contexts/auth-context';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { LayoutDashboard, FileText, Menu, Settings, Users, Sparkles, ImageIcon } from 'lucide-react';
import Link from 'next/link';
import Head from 'next/head';

export default function AdminDashboard() {
  const { user, isLoading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!isLoading && !user) {
      router.push('/auth/login?redirect=/admin');
    }
  }, [user, isLoading, router]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!user) {
    return null; // Will redirect
  }

  return (
    <>
      <Head>
        <title>Panou Administrare - One Smart</title>
        <meta name="description" content="Gestionează conținutul și setările site-ului One Smart" />
      </Head>
      <div className="p-4 md:p-8">
        <div className="mb-6 md:mb-8">
          <h1 className="text-xl md:text-3xl font-bold mb-2">Bun venit în Panoul de Administrare, {user.username}!</h1>
          <p className="text-muted-foreground text-sm md:text-base">Gestionează conținutul și setările site-ului tău One Smart.</p>
        </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
        <Link href="/admin/pages">
          <Card className="hover:shadow-lg transition-shadow cursor-pointer">
            <CardHeader>
              <FileText className="w-8 h-8 text-primary mb-2" />
              <CardTitle>Pagini</CardTitle>
              <CardDescription>
                Creează și gestionează paginile site-ului tău
              </CardDescription>
            </CardHeader>
          </Card>
        </Link>

        <Link href="/admin/menu">
          <Card className="hover:shadow-lg transition-shadow cursor-pointer">
            <CardHeader>
              <Menu className="w-8 h-8 text-primary mb-2" />
              <CardTitle>Meniu</CardTitle>
              <CardDescription>
                Configurează structura de navigare
              </CardDescription>
            </CardHeader>
          </Card>
        </Link>

        <Link href="/admin/media">
          <Card className="hover:shadow-lg transition-shadow cursor-pointer">
            <CardHeader>
              <ImageIcon className="w-8 h-8 text-primary mb-2" />
              <CardTitle>Galerie Media</CardTitle>
              <CardDescription>
                Gestionează imaginile și fișierele încărcate
              </CardDescription>
            </CardHeader>
          </Card>
        </Link>

        <Link href="/admin/site-settings">
          <Card className="hover:shadow-lg transition-shadow cursor-pointer">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Setări Generale
              </CardTitle>
              <Settings className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <p className="text-xs text-muted-foreground">
                Configurează limba și alte setări
              </p>
            </CardContent>
          </Card>
        </Link>

        <Link href="/admin/site-settings/header">
          <Card className="hover:shadow-lg transition-shadow cursor-pointer">
            <CardHeader>
              <Settings className="w-8 h-8 text-primary mb-2" />
              <CardTitle>Header</CardTitle>
              <CardDescription>
                Personalizează antetul site-ului
              </CardDescription>
            </CardHeader>
          </Card>
        </Link>

        <Link href="/admin/site-settings/footer">
          <Card className="hover:shadow-lg transition-shadow cursor-pointer">
            <CardHeader>
              <Settings className="w-8 h-8 text-primary mb-2" />
              <CardTitle>Footer</CardTitle>
              <CardDescription>
                Personalizează subsolul site-ului
              </CardDescription>
            </CardHeader>
          </Card>
        </Link>

         <Link href="/admin/users">
           <Card className="hover:shadow-lg transition-shadow cursor-pointer">
             <CardHeader>
               <Users className="w-8 h-8 text-primary mb-2" />
               <CardTitle>Utilizatori</CardTitle>
               <CardDescription>
                 Gestionează conturile și rolurile utilizatorilor
               </CardDescription>
             </CardHeader>
           </Card>
         </Link>

         <Link href="/admin/analytics">
           <Card className="hover:shadow-lg transition-shadow cursor-pointer">
             <CardHeader>
               <LayoutDashboard className="w-8 h-8 text-primary mb-2" />
               <CardTitle>Analytics</CardTitle>
               <CardDescription>
                 Statistici trafic și vizitatori
               </CardDescription>
             </CardHeader>
           </Card>
         </Link>

        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader>
            <Users className="w-8 h-8 text-primary mb-2" />
            <CardTitle>Cont Utilizator</CardTitle>
            <CardDescription>
              Sistem de autentificare activ
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              Conectat ca: <strong>{user.username}</strong><br />
              Email: {user.email}<br />
              Rol: {user.role === 'admin' ? 'Administrator' : 'Abonat'}
            </p>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader>
            <Sparkles className="w-8 h-8 text-primary mb-2" />
            <CardTitle>One Smart</CardTitle>
            <CardDescription>
              Platformă de creare pagini web
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              Versiunea: 1.0.0<br />
              Status: Activ
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
    </>
  );
}

