import { Editor } from '@/components/editor/Editor';
import { getPageById } from '@/lib/page-data';
import { notFound } from 'next/navigation';

export const dynamic = 'force-dynamic';

export default async function EditorPage({ params }: { params: Promise<{ pageId: string }> }) {
  const { pageId } = await params;

  if (pageId === 'new') {
    return <Editor />;
  }

  const page = await getPageById(pageId);

  if (!page) {
    notFound();
  }

  return <Editor initialPageData={page} />;
}
