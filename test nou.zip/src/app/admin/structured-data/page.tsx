import { redirect } from 'next/navigation';

export default function StructuredDataPage() {
  redirect('/admin/pages');
}
