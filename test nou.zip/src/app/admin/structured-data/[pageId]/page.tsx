import StructuredDataClient from './StructuredDataClient';

interface Props {
  params: Promise<{ pageId: string }>;
}

export default async function StructuredDataPage({ params }: Props) {
  const { pageId } = await params;
  return <StructuredDataClient pageId={pageId} />;
}
