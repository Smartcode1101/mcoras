'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  ArrowLeft, 
  Copy, 
  Eye, 
  EyeOff, 
  Trash2, 
  Plus, 
  FileJson, 
  CheckCircle, 
  AlertCircle,
  ExternalLink
} from 'lucide-react';

interface SchemaDefinition {
  type: string;
  name: string;
  description: string;
  fields: string[];
  required: string[];
}

interface SchemaConfig {
  type: string;
  enabled: boolean;
  customFields?: Record<string, unknown>;
}

interface CustomSchema {
  id: string;
  name: string;
  schema: Record<string, unknown>;
}

interface PageStructuredData {
  pageId: string;
  schemas: SchemaConfig[];
  customSchemas: CustomSchema[];
}

interface PageData {
  id: string;
  title: string;
  slug: string;
  type: string;
  seoDescription?: string;
  thumbnail?: string;
  createdAt: string;
  updatedAt: string;
}

interface Props {
  pageId: string;
}

// Șabloane pentru scheme personalizate simple
interface SchemaTemplate {
  type: string;
  name: string;
  icon: string;
  fields: Array<{name: string; label: string; placeholder: string}>;
  questions?: Array<{question: string; answer: string}>;
  steps?: Array<{name: string; text: string}>;
}

const schemaTemplates: SchemaTemplate[] = [
  {
    type: 'FAQPage',
    name: 'FAQ - Întrebări Frecvente',
    icon: '❓',
    fields: [
      { name: 'name', label: 'Titlu FAQ', placeholder: 'Întrebări despre servicii' },
      { name: 'description', label: 'Descriere', placeholder: 'Răspunsuri la întrebările frecvente' }
    ],
    questions: [
      { question: 'Care este programul de lucru?', answer: 'Luni-Vineri: 9:00-18:00' },
      { question: 'Oferiți garanție?', answer: 'Da, oferim garanție de 24 de luni.' }
    ]
  },
  {
    type: 'HowTo',
    name: 'HowTo - Ghid Tutorial',
    icon: '📝',
    fields: [
      { name: 'name', label: 'Titlu Ghid', placeholder: 'Cum să construiești o casă' },
      { name: 'description', label: 'Descriere scurtă', placeholder: 'Ghid pas cu pas' }
    ],
    steps: [
      { name: 'Pasul 1', text: 'Pregătește materialele necesare' },
      { name: 'Pasul 2', text: 'Fundamentul casei' }
    ]
  },
  {
    type: 'Product',
    name: 'Product - Produs',
    icon: '📦',
    fields: [
      { name: 'name', label: 'Nume Produs', placeholder: 'Numele produsului' },
      { name: 'description', label: 'Descriere', placeholder: 'Descrierea produsului' },
      { name: 'brand', label: 'Brand', placeholder: 'Numele brandului' },
      { name: 'price', label: 'Preț', placeholder: '100.00' },
      { name: 'currency', label: 'Monedă', placeholder: 'RON' }
    ]
  },
  {
    type: 'Review',
    name: 'Review - Recenzie',
    icon: '⭐',
    fields: [
      { name: 'itemReviewed', label: 'Produs/Service revizuit', placeholder: 'Numele produsului' },
      { name: 'reviewBody', label: 'Conținut recenzie', placeholder: 'Opinia ta despre produs' },
      { name: 'ratingValue', label: 'Rating (1-5)', placeholder: '5' },
      { name: 'author', label: 'Autor recenzie', placeholder: 'Numele tău' }
    ]
  },
  {
    type: 'Event',
    name: 'Event - Eveniment',
    icon: '📅',
    fields: [
      { name: 'name', label: 'Nume Eveniment', placeholder: 'Numele evenimentului' },
      { name: 'description', label: 'Descriere', placeholder: 'Ce este evenimentul' },
      { name: 'startDate', label: 'Data început', placeholder: '2025-01-15T18:00' },
      { name: 'location', label: 'Locație', placeholder: 'Adresa sau numele locației' }
    ]
  },
  {
    type: 'LocalBusiness',
    name: 'LocalBusiness - Afacere Locală',
    icon: '🏪',
    fields: [
      { name: 'name', label: 'Nume Afacere', placeholder: 'Numele companiei' },
      { name: 'description', label: 'Descriere', placeholder: 'Ce oferă afacerea' },
      { name: 'streetAddress', label: 'Adresă', placeholder: 'Strada, Număr' },
      { name: 'addressLocality', label: 'Oraș', placeholder: 'București' },
      { name: 'telephone', label: 'Telefon', placeholder: '+40 123 456 789' }
    ]
  }
];

export default function StructuredDataClient({ pageId }: Props) {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [page, setPage] = useState<PageData | null>(null);
  const [availableSchemas, setAvailableSchemas] = useState<Record<string, SchemaDefinition>>({});
  const [pageSchema, setPageSchema] = useState<PageStructuredData | null>(null);
  const [autoSchemas, setAutoSchemas] = useState<Record<string, unknown>[]>([]);
  const [activeTab, setActiveTab] = useState<'auto' | 'custom'>('auto');
  const [expandedSchema, setExpandedSchema] = useState<number | string | null>(null);
  
  // Formular simplificat pentru scheme personalizate
  const [selectedTemplate, setSelectedTemplate] = useState<string | null>(null);
  const [formData, setFormData] = useState<Record<string, string>>({});
  const [faqQuestions, setFaqQuestions] = useState<Array<{question: string, answer: string}>>([]);
  const [howToSteps, setHowToSteps] = useState<Array<{name: string, text: string}>>([]);
  const [customJsonMode, setCustomJsonMode] = useState(false);
  const [customJson, setCustomJson] = useState('{\n  "@context": "https://schema.org",\n  "@type": "Thing",\n  "name": "Exemplu"\n}');

  useEffect(() => {
    loadData();
  }, [pageId]);

  const loadData = async () => {
    try {
      const res = await fetch(`/api/admin/structured-data?pageId=${pageId}`);
      const data = await res.json();
      
      setPage(data.page);
      setAvailableSchemas(data.availableSchemas || {});
      setPageSchema(data.pageSchema);
      
      const autoRes = await fetch(`/api/admin/structured-data?pageId=${pageId}&generate=auto`);
      const autoData = await autoRes.json();
      setAutoSchemas(autoData.schemas || []);
      
    } catch (error) {
      console.error('Eroare la încărcare:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleAddCustomSchema = async () => {
    setSaving(true);
    try {
      let schemaObj: Record<string, unknown>;
      
      if (customJsonMode) {
        schemaObj = JSON.parse(customJson);
      } else if (selectedTemplate) {
        const template = schemaTemplates.find(t => t.type === selectedTemplate);
        if (!template) throw new Error('Template negăsit');
        
        // Construiește schema în funcție de tip
        switch (template.type) {
          case 'FAQPage':
            schemaObj = {
              "@context": "https://schema.org",
              "@type": "FAQPage",
              "mainEntity": faqQuestions.map(q => ({
                "@type": "Question",
                "name": q.question,
                "acceptedAnswer": {
                  "@type": "Answer",
                  "text": q.answer
                }
              }))
            };
            break;
          case 'HowTo':
            schemaObj = {
              "@context": "https://schema.org",
              "@type": "HowTo",
              "name": formData.name || template.name,
              "description": formData.description || '',
              "step": howToSteps.map((s, i) => ({
                "@type": "HowToStep",
                "name": s.name,
                "text": s.text,
                "position": i + 1
              }))
            };
            break;
          case 'Product':
            schemaObj = {
              "@context": "https://schema.org",
              "@type": "Product",
              "name": formData.name,
              "description": formData.description,
              "brand": {
                "@type": "Brand",
                "name": formData.brand || ''
              },
              "offers": {
                "@type": "Offer",
                "price": formData.price || '0',
                "priceCurrency": formData.currency || 'RON'
              }
            };
            break;
          case 'Review':
            schemaObj = {
              "@context": "https://schema.org",
              "@type": "Review",
              "itemReviewed": formData.itemReviewed,
              "reviewBody": formData.reviewBody,
              "reviewRating": {
                "@type": "Rating",
                "ratingValue": parseInt(formData.ratingValue || '5'),
                "bestRating": 5
              },
              "author": {
                "@type": "Person",
                "name": formData.author || 'Anonim'
              }
            };
            break;
          case 'Event':
            schemaObj = {
              "@context": "https://schema.org",
              "@type": "Event",
              "name": formData.name,
              "description": formData.description,
              "startDate": formData.startDate,
              "location": {
                "@type": "Place",
                "name": formData.location,
                "address": formData.location
              }
            };
            break;
          case 'LocalBusiness':
            schemaObj = {
              "@context": "https://schema.org",
              "@type": "LocalBusiness",
              "name": formData.name,
              "description": formData.description,
              "address": {
                "@type": "PostalAddress",
                "streetAddress": formData.streetAddress,
                "addressLocality": formData.addressLocality
              },
              "telephone": formData.telephone
            };
            break;
          default:
            schemaObj = { "@context": "https://schema.org", "@type": template.type };
        }
      } else {
        throw new Error('Selectează un tip de schemă');
      }
      
      const currentSchemas = pageSchema?.customSchemas || [];
      const templateName = selectedTemplate 
        ? schemaTemplates.find(t => t.type === selectedTemplate)?.name || selectedTemplate
        : 'Schema Personalizată';
      
      const newSchema: CustomSchema = {
        id: `custom-${Date.now()}`,
        name: templateName,
        schema: schemaObj
      };
      
      await fetch('/api/admin/structured-data', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          pageId,
          schemas: pageSchema?.schemas || [],
          customSchemas: [...currentSchemas, newSchema]
        })
      });
      
      // Reset
      setSelectedTemplate(null);
      setFormData({});
      setFaqQuestions([]);
      setHowToSteps([]);
      setCustomJson('{\n  "@context": "https://schema.org",\n  "@type": "Thing",\n  "name": "Exemplu"\n}');
      setCustomJsonMode(false);
      loadData();
    } catch (e) {
      alert(e instanceof Error ? e.message : 'Eroare! Verificați datele introduse.');
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteCustomSchema = async (customSchemaId: string) => {
    if (!confirm('Sigur doriți să ștergeți această schemă?')) return;
    
    try {
      await fetch(`/api/admin/structured-data?pageId=${pageId}&customSchemaId=${customSchemaId}`, {
        method: 'DELETE'
      });
      loadData();
    } catch (error) {
      console.error('Eroare la ștergere:', error);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  const formatJson = (data: unknown) => JSON.stringify(data, null, 2);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!page) {
    return (
      <div className="p-8 text-center">
        <p className="text-red-500 mb-4">Pagina nu a fost găsită</p>
        <Button onClick={() => router.push('/admin/pages')}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Înapoi la pagini
        </Button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header simplu */}
      <div className="border-b bg-white px-6 py-4">
        <div className="flex items-center gap-4">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => router.push('/admin/pages')}
            className="gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            Înapoi
          </Button>
          <div>
            <h1 className="text-xl font-semibold">Date Structurate SEO</h1>
            <div className="flex items-center gap-2 mt-1">
              <span className="text-sm text-muted-foreground">{page.title}</span>
              <Badge variant="outline">{page.type === 'post' ? 'Postare' : 'Pagină'}</Badge>
            </div>
          </div>
        </div>
      </div>

      <div className="p-6 max-w-5xl mx-auto space-y-6">
        {/* Tabs */}
        <div className="flex gap-2 border-b">
          <button
            onClick={() => setActiveTab('auto')}
            className={`px-4 py-2 font-medium text-sm border-b-2 -mb-px transition ${
              activeTab === 'auto' 
                ? 'border-primary text-primary' 
                : 'border-transparent text-muted-foreground hover:text-foreground'
            }`}
          >
            📋 Scheme Generate Automat
          </button>
          <button
            onClick={() => setActiveTab('custom')}
            className={`px-4 py-2 font-medium text-sm border-b-2 -mb-px transition ${
              activeTab === 'custom' 
                ? 'border-primary text-primary' 
                : 'border-transparent text-muted-foreground hover:text-foreground'
            }`}
          >
            ➕ Scheme Personalizate
          </button>
        </div>

        {activeTab === 'auto' && (
          <div className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertCircle className="w-5 h-5 text-blue-500" />
                  Generare Automată
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-muted-foreground">
                  Aceste scheme sunt generate automat din conținutul paginii și sunt incluse automat în pagină.
                  {page.type === 'post' && ' Pentru postări se generează schema NewsArticle.'}
                  {page.type === 'page' && ' Pentru pagini se generează schema WebPage.'}
                </p>
              </CardContent>
            </Card>

            {autoSchemas.map((schema, index) => (
              <Card key={index}>
                <CardHeader className="py-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <FileJson className="w-4 h-4 text-green-600" />
                      <span className="font-medium">{(schema['@type'] as string)}</span>
                      <Badge variant="secondary" className="text-xs">
                        {(schema['@type'] as string) === 'NewsArticle' ? 'Articol' : 
                         (schema['@type'] as string) === 'WebPage' ? 'Pagină' : 
                         (schema['@type'] as string) === 'BreadcrumbList' ? 'Navigare' : 'Schema'}
                      </Badge>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setExpandedSchema(expandedSchema === index ? null : index)}
                      >
                        {expandedSchema === index ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => copyToClipboard(formatJson(schema))}
                      >
                        <Copy className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                {expandedSchema === index && (
                  <CardContent>
                    <pre className="bg-gray-900 text-green-400 p-4 rounded-lg overflow-x-auto text-xs font-mono">
                      {formatJson(schema)}
                    </pre>
                  </CardContent>
                )}
              </Card>
            ))}
          </div>
        )}

        {activeTab === 'custom' && (
          <div className="space-y-6">
            {/* Scheme existente */}
            {pageSchema?.customSchemas && pageSchema.customSchemas.length > 0 && (
              <div className="space-y-4">
                <h3 className="font-medium text-lg">Scheme Personalizate Adăugate</h3>
                {pageSchema.customSchemas.map((custom) => (
                  <Card key={custom.id}>
                    <CardHeader className="py-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <CheckCircle className="w-4 h-4 text-green-600" />
                          <span className="font-medium">{custom.name}</span>
                          <Badge variant="outline" className="text-xs">{(custom.schema['@type'] as string)}</Badge>
                        </div>
                        <div className="flex gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setExpandedSchema(expandedSchema === custom.id ? null : custom.id)}
                          >
                            {expandedSchema === custom.id ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => copyToClipboard(formatJson(custom.schema))}
                          >
                            <Copy className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            className="text-red-600 hover:text-red-700"
                            onClick={() => handleDeleteCustomSchema(custom.id)}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </CardHeader>
                    {expandedSchema === custom.id && (
                      <CardContent>
                        <pre className="bg-gray-900 text-green-400 p-4 rounded-lg overflow-x-auto text-xs font-mono">
                          {formatJson(custom.schema)}
                        </pre>
                      </CardContent>
                    )}
                  </Card>
                ))}
              </div>
            )}

            {/* Adaugă schemă nouă */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Plus className="w-5 h-5" />
                  Adaugă Schemă Nouă
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Selectare mod */}
                <div className="flex gap-2">
                  <Button
                    variant={!customJsonMode ? 'default' : 'outline'}
                    onClick={() => setCustomJsonMode(false)}
                  >
                    📝 Formular Simplu
                  </Button>
                  <Button
                    variant={customJsonMode ? 'default' : 'outline'}
                    onClick={() => setCustomJsonMode(true)}
                  >
                    🔧 JSON Manual
                  </Button>
                </div>

                {!customJsonMode ? (
                  <>
                    {/* Selectare tip schemă */}
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                      {schemaTemplates.map((template) => (
                        <button
                          key={template.type}
                          onClick={() => {
                            setSelectedTemplate(template.type);
                            setFormData({});
                            if (template.type === 'FAQPage' && template.questions) setFaqQuestions([...template.questions]);
                            if (template.type === 'HowTo' && template.steps) setHowToSteps([...template.steps]);
                          }}
                          className={`p-4 text-left border rounded-lg transition ${
                            selectedTemplate === template.type 
                              ? 'border-primary bg-primary/5 ring-2 ring-primary' 
                              : 'hover:bg-muted/50'
                          }`}
                        >
                          <div className="text-2xl mb-1">{template.icon}</div>
                          <div className="font-medium text-sm">{template.type}</div>
                          <div className="text-xs text-muted-foreground">{template.name}</div>
                        </button>
                      ))}
                    </div>

                    {/* Formular dinamic */}
                    {selectedTemplate && (
                      <div className="space-y-4 border-t pt-4">
                        <h4 className="font-medium">
                          Completează datele pentru {schemaTemplates.find(t => t.type === selectedTemplate)?.name}
                        </h4>
                        
                        {selectedTemplate === 'FAQPage' && (
                          <div className="space-y-4">
                            {faqQuestions.map((q, i) => (
                              <div key={i} className="grid grid-cols-1 md:grid-cols-2 gap-2">
                                <Input 
                                  placeholder="Întrebarea"
                                  value={q.question}
                                  onChange={(e) => {
                                    const updated = [...faqQuestions];
                                    updated[i].question = e.target.value;
                                    setFaqQuestions(updated);
                                  }}
                                />
                                <div className="flex gap-2">
                                  <Input 
                                    placeholder="Răspunsul"
                                    value={q.answer}
                                    onChange={(e) => {
                                      const updated = [...faqQuestions];
                                      updated[i].answer = e.target.value;
                                      setFaqQuestions(updated);
                                    }}
                                  />
                                  <Button 
                                    variant="ghost" 
                                    size="icon"
                                    className="text-red-500"
                                    onClick={() => setFaqQuestions(faqQuestions.filter((_, idx) => idx !== i))}
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </Button>
                                </div>
                              </div>
                            ))}
                            <Button
                              variant="outline"
                              onClick={() => setFaqQuestions([...faqQuestions, {question: '', answer: ''}])}
                            >
                              <Plus className="w-4 h-4 mr-2" />
                              Adaugă Întrebare
                            </Button>
                          </div>
                        )}

                        {selectedTemplate === 'HowTo' && (
                          <div className="space-y-4">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              <div>
                                <label className="text-sm font-medium">Titlu Ghid</label>
                                <Input 
                                  placeholder="Cum să..."
                                  value={formData.name || ''}
                                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                                />
                              </div>
                              <div>
                                <label className="text-sm font-medium">Descriere</label>
                                <Input 
                                  placeholder="Descriere scurtă"
                                  value={formData.description || ''}
                                  onChange={(e) => setFormData({...formData, description: e.target.value})}
                                />
                              </div>
                            </div>
                            {howToSteps.map((step, i) => (
                              <div key={i} className="flex gap-2">
                                <Input 
                                  placeholder={`Pasul ${i + 1}`}
                                  value={step.name}
                                  onChange={(e) => {
                                    const updated = [...howToSteps];
                                    updated[i].name = e.target.value;
                                    setHowToSteps(updated);
                                  }}
                                  className="w-32"
                                />
                                <Input 
                                  placeholder="Descriere pas"
                                  value={step.text}
                                  onChange={(e) => {
                                    const updated = [...howToSteps];
                                    updated[i].text = e.target.value;
                                    setHowToSteps(updated);
                                  }}
                                />
                                <Button 
                                  variant="ghost" 
                                  size="icon"
                                  className="text-red-500"
                                  onClick={() => setHowToSteps(howToSteps.filter((_, idx) => idx !== i))}
                                >
                                  <Trash2 className="w-4 h-4" />
                                </Button>
                              </div>
                            ))}
                            <Button
                              variant="outline"
                              onClick={() => setHowToSteps([...howToSteps, {name: '', text: ''}])}
                            >
                              <Plus className="w-4 h-4 mr-2" />
                              Adaugă Pas
                            </Button>
                          </div>
                        )}

                        {['Product', 'Review', 'Event', 'LocalBusiness'].includes(selectedTemplate) && (
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {schemaTemplates
                              .find(t => t.type === selectedTemplate)
                              ?.fields.map(field => (
                                <div key={field.name}>
                                  <label className="text-sm font-medium">{field.label}</label>
                                  <Input 
                                    placeholder={field.placeholder}
                                    value={formData[field.name] || ''}
                                    onChange={(e) => setFormData({...formData, [field.name]: e.target.value})}
                                  />
                                </div>
                              ))}
                          </div>
                        )}

                        <Button onClick={handleAddCustomSchema} disabled={saving} className="w-full">
                          {saving ? 'Se salvează...' : '💾 Salvează Schema'}
                        </Button>
                      </div>
                    )}
                  </>
                ) : (
                  <div className="space-y-4">
                    <div>
                      <label className="text-sm font-medium">JSON-LD Schema</label>
                      <Textarea 
                        value={customJson}
                        onChange={(e) => setCustomJson(e.target.value)}
                        rows={15}
                        className="font-mono text-xs"
                      />
                    </div>
                    <Button onClick={handleAddCustomSchema} disabled={saving} className="w-full">
                      {saving ? 'Se salvează...' : '💾 Salvează Schema JSON'}
                    </Button>
                  </div>
                )}

                {/* Link testare */}
                <div className="pt-4 border-t">
                  <a
                    href="https://search.google.com/test/rich-results"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 text-sm text-blue-600 hover:underline"
                  >
                    <ExternalLink className="w-4 h-4" />
                    Testează schemele cu Google Rich Results
                  </a>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Info */}
        <Card className="bg-yellow-50 border-yellow-200">
          <CardContent className="py-4">
            <p className="text-sm text-yellow-800">
              💡 Datele structurate (Schema.org) ajută motoarele de căutare să înțeleagă mai bine conținutul paginii și pot afișa rezultate îmbunătățite (rich snippets).
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}