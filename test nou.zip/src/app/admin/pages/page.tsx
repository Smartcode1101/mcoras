import Link from 'next/link';
import Head from 'next/head';
import { Button } from '@/components/ui/button';
import { PlusCircle } from 'lucide-react';
import { PageList } from '../PageList';
import { Suspense } from 'react';
import { Skeleton } from '@/components/ui/skeleton';

export default function ManagePages() {
  return (
    <>
      <Head>
        <title>Gestionare Pagini - One Smart</title>
        <meta name="description" content="Creează și gestionează paginile site-ului One Smart" />
      </Head>
      <div className="p-4 md:p-8">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
        <h1 className="text-2xl md:text-3xl font-bold">Gestionează Paginile</h1>
        <Button asChild size="sm">
          <Link href="/admin/editor/new">
            <PlusCircle className="mr-2 h-4 w-4" />
            Creează Pagină
          </Link>
        </Button>
      </div>
      <Suspense fallback={<PageListSkeleton />}>
        <PageList />
      </Suspense>
    </div>
    </>
  );
}

function PageListSkeleton() {
  return (
    <div className="space-y-4">
      {[...Array(3)].map((_, i) => (
        <div key={i} className="flex items-center justify-between p-4 border rounded-lg">
          <div className="space-y-2">
            <Skeleton className="h-4 w-48" />
            <Skeleton className="h-3 w-64" />
          </div>
          <div className="flex gap-2">
            <Skeleton className="h-9 w-20" />
            <Skeleton className="h-9 w-20" />
          </div>
        </div>
      ))}
    </div>
  );
}
