'use client';

import { useEffect, useState } from 'react';
import Head from 'next/head';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Eye, Users, Globe, TrendingUp, Activity, RotateCcw, Settings, CheckCircle, XCircle, ExternalLink, Radar, Search, ArrowRight, Bot, Globe2, Link2 } from 'lucide-react';
import type { AnalyticsData, LiveTrafficEntry } from '@/lib/analytics';
import ExampleAnalyticsComponent from '@/components/analytics/ExampleAnalyticsComponent';
import SimpleAnalyticsConnector from '@/components/analytics/SimpleAnalyticsConnector';
import { ga4 } from '@/lib/google-analytics';

// Helper function to get country flag emoji
function getCountryFlag(countryCode: string): string {
  if (!countryCode || countryCode === 'XX') return '🌍';
  
  const codePoints = countryCode
    .toUpperCase()
    .split('')
    .map(char => 127397 + char.charCodeAt(0));
  
  return String.fromCodePoint(...codePoints);
}

export default function AnalyticsPage() {
  const [analyticsData, setAnalyticsData] = useState<AnalyticsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [realtimeData, setRealtimeData] = useState<{ timestamp: string; views: number }[]>([]);
  const [resetting, setResetting] = useState(false);
  const [ga4Connected, setGa4Connected] = useState(false);
  // Live Traffic states
  const [liveTraffic, setLiveTraffic] = useState<LiveTrafficEntry[]>([]);
  const [trafficStats, setTrafficStats] = useState<{ type: string; count: number; percentage: number }[]>([]);
  const [countryStats, setCountryStats] = useState<{ country: string; countryCode: string; count: number }[]>([]);

  useEffect(() => {
    const fetchAnalytics = async () => {
      try {
        console.log('Fetching main analytics data...');
        const response = await fetch('/api/admin/analytics');
        console.log('Main analytics response status:', response.status);
        if (response.ok) {
          const result = await response.json();
          console.log('Main analytics data received:', result);
          setAnalyticsData(result.success ? result.data : null);
        } else {
          console.error('Main analytics API error:', response.status);
        }
      } catch (error) {
        console.error('Error fetching analytics:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchAnalytics();

    // Set up real-time updates every 30 seconds
    const interval = setInterval(fetchAnalytics, 30000);

    return () => clearInterval(interval);
  }, []);

  // Fetch realtime data separately
  useEffect(() => {
    const fetchRealtimeData = async () => {
      try {
        console.log('Fetching realtime analytics data...');
        const response = await fetch('/api/admin/analytics?type=realtime');
        console.log('Realtime response status:', response.status);
        if (response.ok) {
          const result = await response.json();
          console.log('Realtime data received:', result);
          setRealtimeData(result.success ? result.data : []);
        } else {
          console.error('Realtime API error:', response.status);
        }
      } catch (error) {
        console.error('Error fetching realtime data:', error);
      }
    };

    fetchRealtimeData();

    // Update realtime data every 5 seconds
    const realtimeInterval = setInterval(fetchRealtimeData, 5000);

    return () => clearInterval(realtimeInterval);
  }, []);

  // Fetch live traffic data
  useEffect(() => {
    const fetchLiveTraffic = async () => {
      try {
        const response = await fetch('/api/admin/analytics?type=livetraffic');
        if (response.ok) {
          const result = await response.json();
          setLiveTraffic(result.success ? result.data : []);
        }
      } catch (error) {
        console.error('Error fetching live traffic:', error);
      }
    };

    const fetchTrafficStats = async () => {
      try {
        const response = await fetch('/api/admin/analytics?type=traffic');
        if (response.ok) {
          const result = await response.json();
          setTrafficStats(result.success ? result.data : []);
        }
      } catch (error) {
        console.error('Error fetching traffic stats:', error);
      }
    };

    const fetchCountryStats = async () => {
      try {
        const response = await fetch('/api/admin/analytics?type=countries');
        if (response.ok) {
          const result = await response.json();
          setCountryStats(result.success ? result.data : []);
        }
      } catch (error) {
        console.error('Error fetching country stats:', error);
      }
    };

    fetchLiveTraffic();
    fetchTrafficStats();
    fetchCountryStats();

    // Update live traffic every 10 seconds
    const liveTrafficInterval = setInterval(fetchLiveTraffic, 10000);
    const statsInterval = setInterval(() => {
      fetchTrafficStats();
      fetchCountryStats();
    }, 30000);

    return () => {
      clearInterval(liveTrafficInterval);
      clearInterval(statsInterval);
    };
  }, []);

  // Verifică statusul conexiunii Google Analytics
  useEffect(() => {
    const checkGA4Connection = async () => {
      try {
        const response = await fetch('/api/analytics/google/properties');
        const data = await response.json();
        if (data.success) {
          setGa4Connected(data.connected);
        }
      } catch (error) {
        console.error('Error checking GA4 connection:', error);
      }
    };

    checkGA4Connection();
  }, []);

  const handleResetAnalytics = async () => {
    if (!confirm('Ești sigur că vrei să resetezi toate datele de analytics? Această acțiune nu poate fi anulată.')) {
      return;
    }

    setResetting(true);
    try {
      const response = await fetch('/api/admin/analytics', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ action: 'reset' }),
      });

      if (response.ok) {
        // Refresh data immediately
        const fetchAnalytics = async () => {
          try {
            const response = await fetch('/api/admin/analytics');
            if (response.ok) {
              const result = await response.json();
              setAnalyticsData(result.success ? result.data : null);
            }
          } catch (error) {
            console.error('Error fetching analytics after reset:', error);
          }
        };

        await fetchAnalytics();
        alert('Datele de analytics au fost resetate cu succes!');
      } else {
        alert('Eroare la resetarea datelor de analytics.');
      }
    } catch (error) {
      console.error('Error resetting analytics:', error);
      alert('Eroare la resetarea datelor de analytics.');
    } finally {
      setResetting(false);
    }
  };

  if (loading) {
    return (
      <>
        <Head>
          <title>Analytics - One Smart</title>
          <meta name="description" content="Statistici trafic și vizitatori One Smart" />
        </Head>
        <div className="p-4 md:p-6 lg:p-8">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-gray-200 rounded w-1/4"></div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="h-32 bg-gray-200 rounded"></div>
              ))}
            </div>
          </div>
        </div>
      </>
    );
  }

  if (!analyticsData) {
    return (
      <>
        <Head>
          <title>Analytics - One Smart</title>
          <meta name="description" content="Statistici trafic și vizitatori One Smart" />
        </Head>
        <div className="p-4 md:p-6 lg:p-8">
          <div className="text-center">
            <p className="text-muted-foreground">Nu s-au putut încărca datele de analytics.</p>
          </div>
        </div>
      </>
    );
  }

  return (
    <>
      <Head>
        <title>Analytics - One Smart</title>
        <meta name="description" content="Statistici trafic și vizitatori One Smart" />
      </Head>
      <div className="p-4 md:p-6 lg:p-8">
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold mb-2">Analytics</h1>
              <p className="text-muted-foreground">Statistici trafic și vizitatori în timp real</p>
            </div>
            <Button
              onClick={handleResetAnalytics}
              disabled={resetting}
              variant="destructive"
              className="flex items-center gap-2"
            >
              <RotateCcw className={`h-4 w-4 ${resetting ? 'animate-spin' : ''}`} />
              {resetting ? 'Resetare...' : 'Resetează Analytics'}
            </Button>
          </div>


        </div>

        {/* Google Analytics Simple Setup */}
        <SimpleAnalyticsConnector />

        {/* Real-time Activity */}
        <div className="mb-6">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-lg">
                <Activity className="h-4 w-4 text-green-500" />
                Activitate în Timp Real
                <Badge variant="secondary" className="ml-auto text-xs">
                  Live
                </Badge>
              </CardTitle>
              <CardDescription className="text-sm">
                Vizualizări în ultimele 60 de secunde
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="h-24 sm:h-28 md:h-32 flex items-end gap-1">
                {realtimeData.slice(-20).map((point, index) => (
                  <div
                    key={point.timestamp}
                    className="bg-green-500 rounded-t flex-1 transition-all duration-300 min-h-[2px]"
                    style={{
                      height: `${Math.max((point.views / 10) * 100, 4)}%`,
                      opacity: index === realtimeData.length - 1 ? 1 : 0.7
                    }}
                    title={`${point.views} views at ${new Date(point.timestamp).toLocaleTimeString()}`}
                  />
                ))}
              </div>
              <div className="flex justify-between text-xs text-muted-foreground mt-2">
                <span>60 sec ago</span>
                <span>Now</span>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Overview Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6 mb-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Vizualizări Totale</CardTitle>
              <Eye className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{analyticsData.totalViews.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">
                +12% față de luna trecută
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Vizitatori Unici</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{analyticsData.uniqueVisitors.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">
                +8% față de luna trecută
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Sesiuni Noi</CardTitle>
              <Users className="h-4 w-4 text-blue-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {analyticsData.pageViews.filter(pv => pv.sessionType === 'new').length}
              </div>
              <p className="text-xs text-muted-foreground">
                Prima vizită
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Întoarceri</CardTitle>
              <Users className="h-4 w-4 text-green-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {analyticsData.pageViews.filter(pv => pv.sessionType === 'returning').length}
              </div>
              <p className="text-xs text-muted-foreground">
                Vizite repetate
              </p>
            </CardContent>
          </Card>

        </div>

        {/* Top Pages */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6 mb-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                Pagini Populare
              </CardTitle>
              <CardDescription>
                Cele mai accesate pagini în ultimele 24 de ore
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {analyticsData.topPages.map((page, index) => (
                  <div key={page.page} className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Badge variant="secondary" className="w-6 h-6 rounded-full p-0 flex items-center justify-center">
                        {index + 1}
                      </Badge>
                      <span className="font-medium">{page.page}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Eye className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm font-medium">{page.views}</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Session Types */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                Tipuri de Sesiuni
              </CardTitle>
              <CardDescription>
                Vizitatori noi vs. cei care se întorc
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {(() => {
                  const newSessions = analyticsData.pageViews.filter(pv => pv.sessionType === 'new').length;
                  const returningSessions = analyticsData.pageViews.filter(pv => pv.sessionType === 'returning').length;
                  const totalSessions = newSessions + returningSessions;

                  return [
                    {
                      type: 'Noi',
                      count: newSessions,
                      percentage: totalSessions > 0 ? Math.round((newSessions / totalSessions) * 100) : 0,
                      color: 'bg-blue-500'
                    },
                    {
                      type: 'Întoarcere',
                      count: returningSessions,
                      percentage: totalSessions > 0 ? Math.round((returningSessions / totalSessions) * 100) : 0,
                      color: 'bg-green-500'
                    }
                  ].map((session, index) => (
                    <div key={session.type} className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className={`w-3 h-3 rounded-full ${session.color}`}></div>
                        <span className="font-medium">{session.type}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-medium">{session.count}</span>
                        <span className="text-xs text-muted-foreground">({session.percentage}%)</span>
                      </div>
                    </div>
                  ));
                })()}
              </div>
            </CardContent>
          </Card>

        </div>

        {/* Live Traffic - Wordfence Style */}
        <div className="mb-6">
          <Card className="border-green-500/30">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-lg">
                <Radar className="h-4 w-4 text-green-500" />
                Live Traffic
                <Badge variant="secondary" className="ml-auto text-xs bg-green-500/20 text-green-500">
                  Live
                </Badge>
              </CardTitle>
              <CardDescription className="text-sm">
                Vizualizări în timp real - Direct, Google Organic, Referrals, Crawlers
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-0">
              {/* Traffic Type Stats */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
                <div className="flex items-center gap-2 p-2 rounded bg-blue-500/10">
                  <ArrowRight className="h-4 w-4 text-blue-500" />
                  <div>
                    <div className="text-lg font-bold">{trafficStats.find(t => t.type === 'Direct')?.count || 0}</div>
                    <div className="text-xs text-muted-foreground">Direct</div>
                  </div>
                </div>
                <div className="flex items-center gap-2 p-2 rounded bg-green-500/10">
                  <Search className="h-4 w-4 text-green-500" />
                  <div>
                    <div className="text-lg font-bold">{trafficStats.find(t => t.type === 'Organic (Google)')?.count || 0}</div>
                    <div className="text-xs text-muted-foreground">Google</div>
                  </div>
                </div>
                <div className="flex items-center gap-2 p-2 rounded bg-purple-500/10">
                  <Link2 className="h-4 w-4 text-purple-500" />
                  <div>
                    <div className="text-lg font-bold">{trafficStats.find(t => t.type === 'Referral')?.count || 0}</div>
                    <div className="text-xs text-muted-foreground">Referral</div>
                  </div>
                </div>
                <div className="flex items-center gap-2 p-2 rounded bg-orange-500/10">
                  <Bot className="h-4 w-4 text-orange-500" />
                  <div>
                    <div className="text-lg font-bold">{trafficStats.find(t => t.type === 'Crawlers/Bots')?.count || 0}</div>
                    <div className="text-xs text-muted-foreground">Bots</div>
                  </div>
                </div>
              </div>

              {/* Traffic Table */}
              <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-2 px-2">Tip</th>
                      <th className="text-left py-2 px-2">Pagina</th>
                      <th className="text-left py-2 px-2">Sursă</th>
                      <th className="text-left py-2 px-2">
                        <Globe2 className="h-3 w-3 inline mr-1" />
                        Țară
                      </th>
                      <th className="text-right py-2 px-2">Ora</th>
                    </tr>
                  </thead>
                  <tbody>
                    {liveTraffic.slice(0, 20).map((entry) => (
                      <tr key={entry.id} className="border-b hover:bg-muted/50">
                        <td className="py-2 px-2">
                          {entry.trafficType === 'direct' && (
                            <Badge variant="outline" className="bg-blue-500/10 text-blue-500 border-blue-500/30">
                              <ArrowRight className="h-3 w-3 mr-1" />
                              Direct
                            </Badge>
                          )}
                          {entry.trafficType === 'organic' && (
                            <Badge variant="outline" className="bg-green-500/10 text-green-500 border-green-500/30">
                              <Search className="h-3 w-3 mr-1" />
                              Google
                            </Badge>
                          )}
                          {entry.trafficType === 'referral' && (
                            <Badge variant="outline" className="bg-purple-500/10 text-purple-500 border-purple-500/30">
                              <Link2 className="h-3 w-3 mr-1" />
                              Referral
                            </Badge>
                          )}
                          {entry.trafficType === 'crawler' && (
                            <Badge variant="outline" className="bg-orange-500/10 text-orange-500 border-orange-500/30">
                              <Bot className="h-3 w-3 mr-1" />
                              {entry.crawlerName || 'Bot'}
                            </Badge>
                          )}
                        </td>
                        <td className="py-2 px-2 max-w-[200px] truncate">{entry.page}</td>
                        <td className="py-2 px-2 max-w-[150px] truncate text-muted-foreground">
                          {entry.referrer ? entry.referrer.substring(0, 30) : '-'}
                        </td>
                        <td className="py-2 px-2">
                          <div className="flex items-center gap-1">
                            <span className="text-lg">{getCountryFlag(entry.countryCode)}</span>
                            <span>{entry.country}</span>
                          </div>
                        </td>
                        <td className="py-2 px-2 text-right text-muted-foreground">
                          {new Date(entry.timestamp).toLocaleTimeString()}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Country Stats */}
        {countryStats.length > 0 && (
          <div className="mb-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Globe className="h-5 w-5" />
                  Vizitatori pe Țări
                </CardTitle>
                <CardDescription>
                  Distribuția vizitatorilor pe țări
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {countryStats.slice(0, 10).map((stat, index) => (
                    <div key={stat.country} className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-lg">{getCountryFlag(stat.countryCode)}</span>
                        <span className="font-medium">{stat.country}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-32 h-2 bg-muted rounded overflow-hidden">
                          <div 
                            className="h-full bg-primary"
                            style={{ width: `${(stat.count / (countryStats[0]?.count || 1)) * 100}%` }}
                          />
                        </div>
                        <span className="text-sm text-muted-foreground w-12 text-right">{stat.count}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Hourly Stats */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="h-5 w-5" />
              Trafic Orar (Ultimele 24 ore)
            </CardTitle>
            <CardDescription>
              Vizualizări pe ore în ultimele 24 de ore
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-6 sm:grid-cols-8 md:grid-cols-12 lg:grid-cols-24 gap-1 sm:gap-2">
              {analyticsData.hourlyStats.map((hour) => (
                <div key={hour.hour} className="text-center">
                  <div className="text-xs text-muted-foreground mb-1 hidden sm:block">{hour.hour}</div>
                  <div className="bg-primary/20 rounded p-1 sm:p-2">
                    <div className="text-xs sm:text-sm font-medium">{hour.views}</div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* GA4 Testing Component */}
        {ga4Connected && (
          <div className="mt-8">
            <h2 className="text-2xl font-bold mb-4">Testare Google Analytics 4</h2>
            <p className="text-muted-foreground mb-6">
              Folosește această componentă pentru a testa funcționalitatea GA4 și a verifica că evenimentele se trimit corect.
            </p>
            <ExampleAnalyticsComponent />
          </div>
        )}
      </div>
    </>
  );
}