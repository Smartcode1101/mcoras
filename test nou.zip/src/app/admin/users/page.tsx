'use client';

import Head from 'next/head';

import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/auth-context';
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Users, UserPlus, Shield, User, Trash2, Crown } from 'lucide-react';
import { User as UserType } from '@/lib/user-data';

export default function UsersManagementPage() {
  const { user, isLoading } = useAuth();
  const router = useRouter();
  const [users, setUsers] = useState<UserType[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!isLoading) {
      if (!user) {
        console.log('🔄 Redirect către login - utilizator neautentificat');
        router.push('/auth/login?redirect=/admin/users');
      } else if (user.role !== 'admin') {
        console.log('🔄 Redirect către admin - utilizator fără rol admin');
        router.push('/admin'); // Redirect to main admin if not admin role
      } else {
        console.log('✅ Utilizator admin autentificat - afișare pagină utilizatori');
      }
    }
  }, [user, isLoading, router]);

  useEffect(() => {
    if (user) {
      fetchUsers();
    }
  }, [user]);

  const fetchUsers = async () => {
    console.log('🔍 Încărcare utilizatori...');
    const token = localStorage.getItem('authToken');
    try {
      const response = await fetch('/api/admin/users', {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      if (response.ok) {
        const data = await response.json();
        setUsers(data.users);
        console.log(`✅ Utilizatori încărcați: ${data.users.length} utilizatori găsiți`);
      } else {
        console.error('❌ Eroare la încărcarea utilizatorilor:', response.status);
        setError('Failed to fetch users');
      }
    } catch (error) {
      console.error('❌ Eroare de rețea la încărcarea utilizatorilor:', error);
      setError('An error occurred while fetching users');
    } finally {
      setLoading(false);
    }
  };

  const handleRoleChange = async (userId: string, newRole: 'admin' | 'subscriber') => {
    console.log(`🔄 Schimbare rol pentru utilizatorul ${userId}: ${newRole}`);
    const token = localStorage.getItem('authToken');
    try {
      const response = await fetch('/api/admin/users/role', {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({ userId, role: newRole }),
      });

      if (response.ok) {
        setUsers(users.map(u =>
          u.id === userId ? { ...u, role: newRole } : u
        ));
        console.log(`✅ Rol schimbat cu succes pentru utilizatorul ${userId}`);
      } else {
        console.error('❌ Eroare la schimbarea rolului:', response.status);
        setError('Failed to update user role');
      }
    } catch (error) {
      console.error('❌ Eroare de rețea la schimbarea rolului:', error);
      setError('An error occurred while updating user role');
    }
  };

  const handleDeleteUser = async (userId: string) => {
    if (!confirm('Ești sigur că vrei să ștergi acest utilizator?')) {
      console.log('❌ Ștergere utilizator anulată de către utilizator');
      return;
    }

    console.log(`🗑️ Ștergere utilizator ${userId}...`);
    const token = localStorage.getItem('authToken');
    try {
      const response = await fetch('/api/admin/users', {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({ userId }),
      });

      if (response.ok) {
        setUsers(users.filter(u => u.id !== userId));
        console.log(`✅ Utilizator ${userId} șters cu succes`);
      } else {
        console.error('❌ Eroare la ștergerea utilizatorului:', response.status);
        setError('Failed to delete user');
      }
    } catch (error) {
      console.error('❌ Eroare de rețea la ștergerea utilizatorului:', error);
      setError('An error occurred while deleting user');
    }
  };

  if (isLoading || loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!user) {
    console.log('🚫 Utilizator null - return null (redirect în useEffect)');
    return null; // Will redirect
  }

  if (user.role !== 'admin') {
    console.log('🚫 Utilizator fără rol admin - afișare mesaj acces restricționat');
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Card className="w-full max-w-md">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Shield className="w-12 h-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">Acces restricționat</h3>
            <p className="text-muted-foreground text-center mb-4">
              Nu aveți permisiunea de a accesa această pagină.
            </p>
            <Button onClick={() => router.push('/admin')}>
              Înapoi la Panoul de Administrare
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  console.log('✅ Utilizator admin validat - continuare renderizare');

  console.log('🎨 Renderizare componentă gestionare utilizatori');
  console.log('👤 Utilizator curent:', user);
  console.log('📊 Număr utilizatori:', users.length);

  return (
    <>
      <Head>
        <title>Gestionare Utilizatori - One Smart</title>
        <meta name="description" content="Administrare conturi și roluri utilizatori One Smart" />
      </Head>
      <div className="p-4 md:p-8">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6 md:mb-8">
        <div>
          <h1 className="text-xl md:text-3xl font-bold mb-2">Gestionare Utilizatori</h1>
          <p className="text-muted-foreground text-sm md:text-base">Administrare conturi și roluri utilizatori</p>
        </div>
        <Button onClick={() => console.log('➕ Buton Adaugă Utilizator apăsat')} className="w-full sm:w-auto">
          <UserPlus className="w-4 h-4 mr-2" />
          <span className="sm:hidden">Adaugă</span>
          <span className="hidden sm:inline">Adaugă Utilizator</span>
        </Button>
      </div>

      {error && (
        <Alert variant="destructive" className="mb-6">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <div className="grid gap-4 md:gap-6">
        {users.map((userData) => (
          <Card key={userData.id}>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  {userData.role === 'admin' ? (
                    <Crown className="w-5 h-5 text-yellow-500" />
                  ) : (
                    <User className="w-5 h-5 text-blue-500" />
                  )}
                  <div>
                    <CardTitle className="text-lg">{userData.username}</CardTitle>
                    <CardDescription>{userData.email}</CardDescription>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Badge variant={userData.role === 'admin' ? 'default' : 'secondary'}>
                    {userData.role === 'admin' ? 'Administrator' : 'Abonat'}
                  </Badge>
                  {userData.id !== user?.id && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        console.log(`🔄 Click buton schimbare rol pentru ${userData.username}`);
                        handleRoleChange(
                          userData.id,
                          userData.role === 'admin' ? 'subscriber' : 'admin'
                        );
                      }}
                    >
                      <Shield className="w-4 h-4 mr-2" />
                      {userData.role === 'admin' ? 'Degradează' : 'Promovează'}
                    </Button>
                  )}
                  {userData.id !== user?.id && (
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => {
                        console.log(`🗑️ Click buton ștergere pentru ${userData.username}`);
                        handleDeleteUser(userData.id);
                      }}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-sm text-muted-foreground">
                Înregistrat: {new Date(userData.createdAt).toLocaleDateString('ro-RO')}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {users.length === 0 && !loading && (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Users className="w-12 h-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">Niciun utilizator găsit</h3>
            <p className="text-muted-foreground text-center">
              Nu există încă utilizatori înregistrați în sistem.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
    </>
  );
}